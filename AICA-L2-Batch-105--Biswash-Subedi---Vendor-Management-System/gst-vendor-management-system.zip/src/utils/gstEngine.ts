/**
 * GST Validation Engine (CGST Act 2017 & IGST Act 2017 Compliance)
 * Uses Decimal.js for precise financial math (no floating point errors)
 */

import Decimal from 'decimal.js';
import {
  InvoiceRecord,
  VendorMaster,
  CompanySettings,
  GSTValidationCheck,
  HsnSacMasterItem,
} from '../types/index.ts';
import {
  validateGSTIN,
  extractStateCode,
  getIndianFinancialYear,
  DEFAULT_HSN_SAC_MASTER,
} from './gstUtils.ts';

export function runGSTValidationEngine(
  invoice: Partial<InvoiceRecord>,
  vendor: Partial<VendorMaster> | null,
  company: Partial<CompanySettings>,
  hsnMaster: HsnSacMasterItem[] = DEFAULT_HSN_SAC_MASTER,
  existingInvoices: Partial<InvoiceRecord>[] = []
): {
  overallStatus: 'PASS' | 'WARN' | 'FAIL';
  checks: GSTValidationCheck[];
} {
  const checks: GSTValidationCheck[] = [];
  const tolerance = new Decimal(company.decimalTolerance ?? 1.00);

  // Helper to add check
  const addCheck = (
    ruleId: string,
    name: string,
    status: 'PASS' | 'WARN' | 'FAIL',
    reason: string,
    legalReference: string,
    field?: string
  ) => {
    checks.push({ ruleId, name, status, reason, legalReference, field });
  };

  // 1. Supplier GSTIN: format, checksum, state match, PAN match
  const supplierGstin = (invoice.vendorGstin || '').trim().toUpperCase();
  const gstinValidation = validateGSTIN(supplierGstin);

  if (!gstinValidation.isValid) {
    addCheck(
      'CHK_01_SUPPLIER_GSTIN',
      'Supplier GSTIN Format & Checksum',
      'FAIL',
      `Invalid Supplier GSTIN: ${gstinValidation.reason || 'Failed format validation.'}`,
      'Section 22-24 CGST Act, 2017 & Rule 8 GST Rules',
      'vendorGstin'
    );
  } else {
    // Check state code against vendor master if available
    let stateMatch = true;
    let panMatch = true;
    let mismatchReasons: string[] = [];

    if (vendor?.stateCode && vendor.stateCode !== gstinValidation.stateCode) {
      stateMatch = false;
      mismatchReasons.push(`GSTIN state (${gstinValidation.stateCode}) does not match Vendor Master state (${vendor.stateCode}).`);
    }

    if (vendor?.pan && vendor.pan.toUpperCase() !== gstinValidation.pan.toUpperCase()) {
      panMatch = false;
      mismatchReasons.push(`GSTIN embedded PAN (${gstinValidation.pan}) does not match Vendor Master PAN (${vendor.pan}).`);
    }

    if (!stateMatch || !panMatch) {
      addCheck(
        'CHK_01_SUPPLIER_GSTIN',
        'Supplier GSTIN Match with Vendor Master',
        'FAIL',
        mismatchReasons.join(' '),
        'Section 25 CGST Act, 2017 (Registration Structure)',
        'vendorGstin'
      );
    } else {
      addCheck(
        'CHK_01_SUPPLIER_GSTIN',
        'Supplier GSTIN & Checksum',
        'PASS',
        `Valid 15-digit GSTIN with correct checksum, PAN (${gstinValidation.pan}), and state (${gstinValidation.stateName}).`,
        'Section 22-24 CGST Act, 2017'
      );
    }
  }

  // 2. Buyer GSTIN equals Company GSTIN configured in settings
  const buyerGstin = (invoice.buyerGstin || '').trim().toUpperCase();
  const companyGstin = (company.gstin || '').trim().toUpperCase();

  if (!buyerGstin) {
    addCheck(
      'CHK_02_BUYER_GSTIN',
      'Buyer GSTIN Verification',
      'FAIL',
      'Buyer GSTIN is missing from invoice particulars.',
      'Section 31(1) CGST Act, 2017 & Rule 46(d)',
      'buyerGstin'
    );
  } else if (companyGstin && buyerGstin !== companyGstin) {
    addCheck(
      'CHK_02_BUYER_GSTIN',
      'Buyer GSTIN Match',
      'FAIL',
      `Buyer GSTIN (${buyerGstin}) does not match Company GSTIN (${companyGstin}).`,
      'Rule 46(d) CGST Rules, 2017',
      'buyerGstin'
    );
  } else {
    addCheck(
      'CHK_02_BUYER_GSTIN',
      'Buyer GSTIN Match',
      'PASS',
      `Buyer GSTIN matches configured recipient company (${buyerGstin}).`,
      'Rule 46(d) CGST Rules, 2017'
    );
  }

  // 3. Mandatory particulars per Section 31 CGST Act & Rule 46 CGST Rules
  const missingParticulars: string[] = [];
  if (!invoice.invoiceNumber?.trim()) missingParticulars.push('Invoice Number');
  if (!invoice.invoiceDate?.trim()) missingParticulars.push('Invoice Date');
  if (!invoice.vendorName?.trim()) missingParticulars.push('Supplier Name');
  if (!invoice.placeOfSupply?.trim()) missingParticulars.push('Place of Supply');
  if (!invoice.lineItems || invoice.lineItems.length === 0) missingParticulars.push('Line Items');
  if (invoice.totalTaxableValue === undefined || invoice.totalTaxableValue === null) missingParticulars.push('Taxable Value');
  if (invoice.invoiceTotal === undefined || invoice.invoiceTotal === null) missingParticulars.push('Invoice Total');

  // Serial number rule: consecutive serial numbers <= 16 characters containing alphabets, numerals, and special chars (- /)
  if (invoice.invoiceNumber && invoice.invoiceNumber.length > 16) {
    missingParticulars.push(`Invoice Number length exceeds statutory 16 characters (length: ${invoice.invoiceNumber.length})`);
  }

  if (missingParticulars.length > 0) {
    addCheck(
      'CHK_03_RULE_46_PARTICULARS',
      'Rule 46 Mandatory Particulars',
      'FAIL',
      `Missing mandatory invoice particulars: ${missingParticulars.join(', ')}.`,
      'Section 31 CGST Act, 2017 & Rule 46 CGST Rules, 2017',
      'invoiceNumber'
    );
  } else {
    addCheck(
      'CHK_03_RULE_46_PARTICULARS',
      'Rule 46 Mandatory Particulars',
      'PASS',
      'All Section 31 & Rule 46 statutory particulars are present (Invoice number <= 16 chars, dates, parties, line items).',
      'Section 31 CGST Act, 2017 & Rule 46 CGST Rules, 2017'
    );
  }

  // 4. Tax Split: supplier state == place of supply -> CGST + SGST; otherwise IGST
  const supplierState = supplierGstin ? supplierGstin.substring(0, 2) : '';
  const posState = extractStateCode(invoice.placeOfSupply || '');

  const totalCgst = new Decimal(invoice.totalCgst || 0);
  const totalSgst = new Decimal(invoice.totalSgst || 0);
  const totalIgst = new Decimal(invoice.totalIgst || 0);

  if (!supplierState || !posState) {
    addCheck(
      'CHK_04_TAX_SPLIT',
      'Intra-State vs Inter-State Tax Classification',
      'WARN',
      'Cannot determine tax split: Supplier State or Place of Supply state is unverified.',
      'IGST Act Sections 7, 8, 10 to 13'
    );
  } else if (supplierState === posState) {
    // Intra-State: Must charge CGST + SGST; IGST must be 0
    const hasIgst = totalIgst.greaterThan(tolerance);
    const hasCgstOrSgst = totalCgst.greaterThan(0) || totalSgst.greaterThan(0);
    const cgstSgstEqual = totalCgst.minus(totalSgst).abs().lessThanOrEqualTo(tolerance);

    if (hasIgst) {
      addCheck(
        'CHK_04_TAX_SPLIT',
        'Intra-State Supply (CGST + SGST Required)',
        'FAIL',
        `Intra-state supply (Supplier state ${supplierState} equals Place of Supply ${posState}), but IGST (₹${totalIgst.toFixed(2)}) is charged instead of CGST+SGST.`,
        'Section 8 IGST Act, 2017 & Section 9 CGST Act, 2017',
        'totalIgst'
      );
    } else if (!cgstSgstEqual) {
      addCheck(
        'CHK_04_TAX_SPLIT',
        'CGST and SGST Parity',
        'FAIL',
        `CGST (₹${totalCgst.toFixed(2)}) and SGST (₹${totalSgst.toFixed(2)}) must be equal for intra-state supplies.`,
        'Section 9 CGST Act, 2017 & Section 9 SGST Act, 2017',
        'totalCgst'
      );
    } else {
      addCheck(
        'CHK_04_TAX_SPLIT',
        'Intra-State Tax Split',
        'PASS',
        `Correct Intra-state tax split: CGST (₹${totalCgst.toFixed(2)}) + SGST (₹${totalSgst.toFixed(2)}), IGST is ₹0.`,
        'Section 8 IGST Act, 2017'
      );
    }
  } else {
    // Inter-State: Must charge IGST; CGST + SGST must be 0
    const hasCgstSgst = totalCgst.greaterThan(tolerance) || totalSgst.greaterThan(tolerance);
    if (hasCgstSgst) {
      addCheck(
        'CHK_04_TAX_SPLIT',
        'Inter-State Supply (IGST Required)',
        'FAIL',
        `Inter-state supply (Supplier state ${supplierState} differs from Place of Supply ${posState}), but CGST/SGST (₹${totalCgst.plus(totalSgst).toFixed(2)}) was charged instead of IGST.`,
        'Section 7 IGST Act, 2017 & Section 5 IGST Act, 2017',
        'totalCgst'
      );
    } else {
      addCheck(
        'CHK_04_TAX_SPLIT',
        'Inter-State Tax Split',
        'PASS',
        `Correct Inter-state tax split: IGST (₹${totalIgst.toFixed(2)}), CGST/SGST is ₹0.`,
        'Section 7 & Section 5 IGST Act, 2017'
      );
    }
  }

  // 5. HSN/SAC validation per line, numeric length by turnover category
  const turnoverCategory = vendor?.turnoverCategory || 'UP_TO_5CR';
  const minDigits = turnoverCategory === 'ABOVE_5CR' ? 6 : 4;

  let hsnErrors: string[] = [];
  let hsnWarnings: string[] = [];

  const lines = invoice.lineItems || [];
  if (lines.length === 0) {
    addCheck(
      'CHK_05_HSN_SAC_VALIDATION',
      'HSN/SAC Code Mandatory on Line Items',
      'FAIL',
      'No line items found to validate HSN/SAC codes.',
      'Notification No. 78/2020 - Central Tax',
      'lineItems'
    );
  } else {
    lines.forEach((item, idx) => {
      const code = (item.hsnSac || '').trim();
      if (!code) {
        hsnErrors.push(`Item #${idx + 1} (${item.description || 'Unnamed'}) has no HSN/SAC code.`);
      } else if (!/^\d+$/.test(code)) {
        hsnErrors.push(`Item #${idx + 1} HSN/SAC '${code}' is non-numeric.`);
      } else {
        const isService = code.startsWith('99');
        const requiredLen = isService ? 6 : minDigits;
        if (code.length < requiredLen) {
          hsnErrors.push(
            `Item #${idx + 1} code '${code}' has ${code.length} digits; required minimum is ${requiredLen} digits for ${turnoverCategory === 'ABOVE_5CR' ? '>₹5Cr turnover' : '<=₹5Cr turnover'}.`
          );
        }

        // 6. Charged GST rate vs master rate
        const matched = hsnMaster.find((m) => m.code === code || code.startsWith(m.code));
        if (matched) {
          const chargedRate = (item.cgstRate || 0) + (item.sgstRate || 0) + (item.igstRate || 0);
          if (Math.abs(chargedRate - matched.gstRate) > 0.01) {
            hsnWarnings.push(
              `Item #${idx + 1} HSN '${code}' charged at ${chargedRate}% GST, but master rate is ${matched.gstRate}%.`
            );
          }
        }
      }
    });

    if (hsnErrors.length > 0) {
      addCheck(
        'CHK_05_HSN_SAC_VALIDATION',
        'HSN/SAC Prescribed Digits & Presence',
        'FAIL',
        hsnErrors.join(' '),
        'Notification No. 78/2020 - Central Tax & Rule 46(f)',
        'lineItems'
      );
    } else {
      addCheck(
        'CHK_05_HSN_SAC_VALIDATION',
        'HSN/SAC Validation',
        'PASS',
        `All ${lines.length} line items have valid numeric HSN/SAC codes conforming to turnover threshold (${minDigits}+ digits).`,
        'Notification No. 78/2020 - Central Tax'
      );
    }

    // 6. GST Rate check against master
    if (hsnWarnings.length > 0) {
      addCheck(
        'CHK_06_GST_RATE_MASTER',
        'Charged GST Rate vs HSN Master',
        'WARN',
        hsnWarnings.join(' '),
        'Section 9 CGST Act, 2017 (Rate Notification)',
        'lineItems'
      );
    } else {
      addCheck(
        'CHK_06_GST_RATE_MASTER',
        'Charged GST Rate vs HSN Master',
        'PASS',
        'All line item GST rates align with approved rate schedules.',
        'Section 9 CGST Act, 2017'
      );
    }
  }

  // 7. Strict Decimal Arithmetic
  // qty x rate - discount = taxable value
  // tax = taxable value x rate
  // sum(lines) = headers
  // invoice total = taxable + tax + cess + round-off
  let calcTaxableSum = new Decimal(0);
  let calcCgstSum = new Decimal(0);
  let calcSgstSum = new Decimal(0);
  let calcIgstSum = new Decimal(0);
  let calcCessSum = new Decimal(0);
  let arithmeticErrors: string[] = [];

  lines.forEach((item, idx) => {
    const qty = new Decimal(item.quantity || 0);
    const rate = new Decimal(item.rate || 0);
    const disc = new Decimal(item.discount || 0);
    const lineTaxable = new Decimal(item.taxableValue || 0);

    const expectedTaxable = qty.times(rate).minus(disc);
    if (expectedTaxable.minus(lineTaxable).abs().greaterThan(tolerance)) {
      arithmeticErrors.push(
        `Item #${idx + 1} taxable value mismatch: expected ₹${expectedTaxable.toFixed(2)} (Qty ${qty} * Rate ${rate} - Disc ${disc}), got ₹${lineTaxable.toFixed(2)}.`
      );
    }

    calcTaxableSum = calcTaxableSum.plus(lineTaxable);
    calcCgstSum = calcCgstSum.plus(new Decimal(item.cgstAmount || 0));
    calcSgstSum = calcSgstSum.plus(new Decimal(item.sgstAmount || 0));
    calcIgstSum = calcIgstSum.plus(new Decimal(item.igstAmount || 0));
    calcCessSum = calcCessSum.plus(new Decimal(item.cessAmount || 0));
  });

  const hdrTaxable = new Decimal(invoice.totalTaxableValue || 0);
  const hdrCgst = new Decimal(invoice.totalCgst || 0);
  const hdrSgst = new Decimal(invoice.totalSgst || 0);
  const hdrIgst = new Decimal(invoice.totalIgst || 0);
  const hdrCess = new Decimal(invoice.totalCess || 0);
  const roundOff = new Decimal(invoice.roundOff || 0);
  const hdrTotal = new Decimal(invoice.invoiceTotal || 0);

  if (lines.length > 0) {
    if (calcTaxableSum.minus(hdrTaxable).abs().greaterThan(tolerance)) {
      arithmeticErrors.push(`Sum of line items taxable (₹${calcTaxableSum.toFixed(2)}) != Header taxable (₹${hdrTaxable.toFixed(2)}).`);
    }
  }

  const expectedTotal = hdrTaxable.plus(hdrCgst).plus(hdrSgst).plus(hdrIgst).plus(hdrCess).plus(roundOff);
  if (expectedTotal.minus(hdrTotal).abs().greaterThan(tolerance)) {
    arithmeticErrors.push(
      `Invoice total arithmetic mismatch: Expected ₹${expectedTotal.toFixed(2)} (Taxable + Taxes + RoundOff), got ₹${hdrTotal.toFixed(2)}.`
    );
  }

  if (arithmeticErrors.length > 0) {
    addCheck(
      'CHK_07_ARITHMETIC_INTEGRITY',
      'Financial Arithmetic & Total Integrity',
      'FAIL',
      arithmeticErrors.join(' '),
      'Section 15 CGST Act, 2017 (Value of Taxable Supply)',
      'invoiceTotal'
    );
  } else {
    addCheck(
      'CHK_07_ARITHMETIC_INTEGRITY',
      'Financial Arithmetic & Total Integrity',
      'PASS',
      `Precise decimal reconciliation: Taxable ₹${hdrTaxable.toFixed(2)} + Taxes ₹${hdrCgst.plus(hdrSgst).plus(hdrIgst).plus(hdrCess).toFixed(2)} + Round-off ₹${roundOff.toFixed(2)} = Total ₹${hdrTotal.toFixed(2)}.`,
      'Section 15 CGST Act, 2017'
    );
  }

  // 8. Composition-Scheme Vendor: Tax invoice charging GST fails; Bill of Supply expected.
  const isComposition = Boolean(vendor?.isComposition || invoice.isCompositionVendor);
  const totalTaxCharged = hdrCgst.plus(hdrSgst).plus(hdrIgst).plus(hdrCess);

  if (isComposition) {
    if (totalTaxCharged.greaterThan(tolerance)) {
      addCheck(
        'CHK_08_COMPOSITION_RULES',
        'Composition Scheme Restriction',
        'FAIL',
        `Composition supplier cannot charge GST (Tax charged: ₹${totalTaxCharged.toFixed(2)}). Supplier must issue a Bill of Supply under Rule 49.`,
        'Section 10(4) CGST Act, 2017 & Rule 49 CGST Rules',
        'invoiceType'
      );
    } else if (invoice.invoiceType !== 'BILL_OF_SUPPLY') {
      addCheck(
        'CHK_08_COMPOSITION_RULES',
        'Composition Bill of Supply',
        'WARN',
        'Composition vendor must issue a "Bill of Supply" instead of a Tax Invoice.',
        'Rule 49 CGST Rules, 2017',
        'invoiceType'
      );
    } else {
      addCheck(
        'CHK_08_COMPOSITION_RULES',
        'Composition Scheme Rules',
        'PASS',
        'Composition vendor correctly issued Bill of Supply without charging tax to recipient.',
        'Section 10(4) CGST Act, 2017'
      );
    }
  } else {
    addCheck(
      'CHK_08_COMPOSITION_RULES',
      'Regular vs Composition Scheme',
      'PASS',
      `Regular GST taxpayer tax invoice. Reverse charge flag: ${invoice.isReverseCharge ? 'YES (RCM Applicable)' : 'NO'}.`,
      'Section 9(3)/(4) CGST Act, 2017'
    );
  }

  // 9. Duplicate Check: Vendor GSTIN + Invoice Number + FY
  const normGstin = (invoice.vendorGstin || '').trim().toUpperCase();
  const normInvNum = (invoice.invoiceNumber || '').trim().toUpperCase().replace(/[\s\/-]/g, '');
  const invoiceFy = invoice.financialYear || getIndianFinancialYear(invoice.invoiceDate || '');

  const duplicate = existingInvoices.find((ex) => {
    if (!ex || ex.id === invoice.id) return false;
    const exGstin = (ex.vendorGstin || '').trim().toUpperCase();
    const exNum = (ex.invoiceNumber || '').trim().toUpperCase().replace(/[\s\/-]/g, '');
    const exFy = ex.financialYear || getIndianFinancialYear(ex.invoiceDate || '');
    return exGstin === normGstin && exNum === normInvNum && exFy === invoiceFy && ex.status !== 'CANCELLED' && ex.status !== 'REJECTED';
  });

  if (duplicate) {
    addCheck(
      'CHK_09_DUPLICATE_CHECK',
      'Duplicate Invoice Prevention',
      'FAIL',
      `Duplicate invoice detected: Invoice '${invoice.invoiceNumber}' for Vendor '${normGstin}' in FY '${invoiceFy}' is already registered (Invoice ID: ${duplicate.id}).`,
      'Section 31 CGST Act, 2017 & Rule 46(b)',
      'invoiceNumber'
    );
  } else {
    addCheck(
      'CHK_09_DUPLICATE_CHECK',
      'Duplicate Invoice Check',
      'PASS',
      `Unique combination: Vendor GSTIN + Normalized Number (${normInvNum}) + FY (${invoiceFy}).`,
      'Rule 46(b) CGST Rules, 2017'
    );
  }

  // 10. Invoice date not in future & within open financial year
  if (invoice.invoiceDate) {
    const invDate = new Date(invoice.invoiceDate);
    const today = new Date();
    today.setHours(23, 59, 59, 999);

    if (invDate > today) {
      addCheck(
        'CHK_10_DATE_VALIDATION',
        'Invoice Date Validity',
        'FAIL',
        `Invoice date (${invoice.invoiceDate}) cannot be in the future.`,
        'Section 31(1) CGST Act, 2017',
        'invoiceDate'
      );
    } else {
      const activeFy = company.currentFinancialYear || getIndianFinancialYear(new Date().toISOString());
      if (invoiceFy !== activeFy) {
        addCheck(
          'CHK_10_DATE_VALIDATION',
          'Financial Year Window',
          'WARN',
          `Invoice FY (${invoiceFy}) differs from Company active FY (${activeFy}). Verify prior period input tax credit (ITC) eligibility under Section 16(4).`,
          'Section 16(4) CGST Act, 2017 (ITC time limit)',
          'invoiceDate'
        );
      } else {
        addCheck(
          'CHK_10_DATE_VALIDATION',
          'Invoice Date & FY Window',
          'PASS',
          `Invoice date is within current open financial year (${activeFy}) and not future-dated.`,
          'Section 31 & Section 16(4) CGST Act, 2017'
        );
      }
    }
  }

  // Determine overall status
  const hasFail = checks.some((c) => c.status === 'FAIL');
  const hasWarn = checks.some((c) => c.status === 'WARN');
  const overallStatus: 'PASS' | 'WARN' | 'FAIL' = hasFail ? 'FAIL' : hasWarn ? 'WARN' : 'PASS';

  return {
    overallStatus,
    checks,
  };
}

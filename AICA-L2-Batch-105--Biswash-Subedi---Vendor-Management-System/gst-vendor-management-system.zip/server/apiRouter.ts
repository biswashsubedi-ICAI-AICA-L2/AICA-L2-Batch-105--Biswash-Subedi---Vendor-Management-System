/**
 * Express API Router for GST Vendor Management System Backend Services
 * Handles secure server-side operations:
 * - Server-side User Role Resolution & Automatic Invitation Onboarding
 * - Invitation Lifecycle (Create, Edit, Resend, Revoke, Bulk Delete) with Normalized Emails
 * - Vendor Delete & Archive with GST Compliance History Protection
 * - Gemini Multimodal OCR (Server-Side Secret)
 * - GST Validation Engine (Decimal.js)
 * - Tally Bridge Agent API & Heartbeat
 * - Report Excel Exports
 * - Append-Only Security & Audit Logging
 * - File-backed Persistence (.data/vms_store.json)
 */

import { Router, Request, Response, NextFunction } from 'express';
import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import * as XLSX from 'xlsx';
import { performInvoiceOcr, setCustomGeminiKey, getEffectiveGeminiKey, testGeminiKey } from './geminiOcr.ts';
import { verifyGstinLive, testGstinCloudKey } from './gstinVerification.ts';
import { runGSTValidationEngine } from '../src/utils/gstEngine.ts';
import { generateTallyPurchaseXml } from '../src/utils/tallyXmlGenerator.ts';
import { initializeApp, getApps } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import {
  InvoiceRecord,
  LedgerMappingRule,
  TallyAgentRecord,
  UserProfile,
  UserInvitation,
  VendorMaster,
  AuditLogEntry,
  CompanySettings,
  ClarificationQuery,
  ThreadMessage,
} from '../src/types/index.ts';
import {
  INITIAL_COMPANY_SETTINGS,
  INITIAL_VENDORS,
  INITIAL_SAMPLE_INVOICES,
  INITIAL_LEDGER_MAPPINGS,
} from '../src/utils/initialData.ts';

export const apiRouter = Router();

// Storage Path
const DATA_DIR = path.resolve(process.cwd(), '.data');
const STORE_FILE = path.join(DATA_DIR, 'vms_store.json');

const BOOTSTRAP_ADMIN_EMAIL = (process.env.BOOTSTRAP_ADMIN_EMAIL || 'biswash.subedi@gmail.com').trim().toLowerCase();

// Safe Firebase Admin SDK Initialization
let adminInitialized = false;
try {
  if (getApps().length === 0) {
    initializeApp();
  }
  adminInitialized = true;
} catch (e: any) {
  // Graceful fallback when cloud credentials are not provisioned in local environment
  adminInitialized = false;
}

/**
 * Canonical email matching helper:
 * For Gmail (@gmail.com and @googlemail.com), ignores dots before @ and lowercases
 */
export function getCanonicalEmail(email: string): string {
  const raw = String(email || '').trim().toLowerCase();
  const parts = raw.split('@');
  if (parts.length !== 2) return raw;
  let [user, domain] = parts;
  if (domain === 'gmail.com' || domain === 'googlemail.com') {
    user = user.replace(/\./g, '');
    domain = 'gmail.com';
  }
  return `${user}@${domain}`;
}

async function safeSetUserDisabled(uid: string, disabled: boolean): Promise<boolean> {
  if (!adminInitialized) return true;
  try {
    await getAuth().updateUser(uid, { disabled });
    return true;
  } catch (e: any) {
    console.warn(`[Firebase Admin] updateUser disabled error for ${uid}:`, e.message);
    return false;
  }
}

async function safeRevokeTokens(uid: string): Promise<boolean> {
  if (!adminInitialized) return true;
  try {
    await getAuth().revokeRefreshTokens(uid);
    return true;
  } catch (e: any) {
    console.warn(`[Firebase Admin] revokeRefreshTokens error for ${uid}:`, e.message);
    return false;
  }
}

async function safeSetCustomClaims(uid: string, claims: Record<string, any>): Promise<boolean> {
  if (!adminInitialized) return true;
  try {
    await getAuth().setCustomUserClaims(uid, claims);
    return true;
  } catch (e: any) {
    console.warn(`[Firebase Admin] setCustomUserClaims error for ${uid}:`, e.message);
    return false;
  }
}

async function safeDeleteAuthUser(uid: string): Promise<boolean> {
  if (!adminInitialized) return true;
  try {
    await getAuth().deleteUser(uid);
    return true;
  } catch (e: any) {
    console.warn(`[Firebase Admin] deleteUser error for ${uid}:`, e.message);
    return false;
  }
}

interface AppStore {
  users: UserProfile[];
  invitations: UserInvitation[];
  vendors: VendorMaster[];
  invoices: InvoiceRecord[];
  queries: ClarificationQuery[];
  messages: ThreadMessage[];
  auditLogs: AuditLogEntry[];
  companySettings: CompanySettings;
  agents: TallyAgentRecord[];
  ledgerMappings: LedgerMappingRule[];
}

// Initial state builder
function buildInitialStore(): AppStore {
  const initialInvitations: UserInvitation[] = [
    {
      id: 'cabiswashsubedi84@gmail.com',
      email: 'cabiswashsubedi84@gmail.com',
      role: 'ACCOUNTS_EXECUTIVE',
      canOverride: true,
      invitedBy: 'admin',
      invitedByName: 'System Administrator',
      invitedAt: '2026-10-30T10:00:00.000Z',
      status: 'PENDING',
      createdAt: '2026-10-30T10:00:00.000Z',
    },
    {
      id: 'parul2687@gmail.com',
      email: 'parul2687@gmail.com',
      role: 'VENDOR',
      vendorId: 'vendor_apex',
      invitedBy: 'admin',
      invitedByName: 'System Administrator',
      invitedAt: '2026-10-30T11:00:00.000Z',
      status: 'PENDING',
      createdAt: '2026-10-30T11:00:00.000Z',
    },
    {
      id: 'ca.biswash.subedi@gmail.com',
      email: 'ca.biswash.subedi@gmail.com',
      role: 'VENDOR',
      vendorId: 'vendor_apex',
      invitedBy: 'admin',
      invitedByName: 'System Administrator',
      invitedAt: '2026-10-30T12:00:00.000Z',
      status: 'PENDING',
      createdAt: '2026-10-30T12:00:00.000Z',
    },
  ];

  const initialUsers: UserProfile[] = [
    {
      uid: 'admin_biswash_subedi',
      email: BOOTSTRAP_ADMIN_EMAIL,
      displayName: 'Biswash Subedi',
      role: 'ADMIN',
      status: 'ACTIVE',
      canOverride: true,
      isActive: true,
      emailVerified: true,
      lastLoginAt: new Date().toISOString(),
      createdAt: '2026-04-01T00:00:00.000Z',
      updatedAt: new Date().toISOString(),
    },
  ];

  const initialAgents: TallyAgentRecord[] = [
    {
      id: 'agent_primary_01',
      agentId: 'TALLY_AGENT_MUMBAI_01',
      name: 'Accounts Head Office - Tally Prime 4.1',
      tokenHash: crypto.createHash('sha256').update('vms_tally_sec_token_98765').digest('hex'),
      plainTokenMasked: 'vms_tally_sec_...98765',
      isRevoked: false,
      version: '2.4.1',
      tallyCompany: 'Acme Enterprise India Pvt Ltd',
      lastHeartbeat: new Date().toISOString(),
      status: 'ONLINE',
      createdAt: new Date().toISOString(),
    },
  ];

  const initialQueries: ClarificationQuery[] = [
    {
      id: 'q_01',
      invoiceId: 'inv_query_sample_004',
      vendorId: 'vendor_apex',
      targetField: 'hsnSac',
      reasonCode: 'HSN_LENGTH_MISMATCH',
      queryText:
        'HSN code 3926 for Nylon Washers requires minimum 6-digit classification under your turnover category (>₹5 Cr). Please provide full 6/8-digit HSN code.',
      status: 'OPEN',
      raisedByUid: 'user_accounts_kavita',
      raisedByName: 'Kavita Iyer (Senior Accounts)',
      slaDueDate: new Date(Date.now() + 48 * 3600 * 1000).toISOString(),
      isEscalated: false,
      createdAt: '2026-04-30T10:00:00Z',
    },
  ];

  const initialMessages: ThreadMessage[] = [
    {
      id: 'm_01',
      queryId: 'q_01',
      invoiceId: 'inv_query_sample_004',
      senderUid: 'user_accounts_kavita',
      senderRole: 'ACCOUNTS_EXECUTIVE',
      senderName: 'Kavita Iyer',
      message: 'Please rectify the HSN code and re-upload the revised tax invoice.',
      createdAt: '2026-04-30T10:05:00Z',
    },
  ];

  return {
    users: initialUsers,
    invitations: initialInvitations,
    vendors: [...INITIAL_VENDORS],
    invoices: [...INITIAL_SAMPLE_INVOICES],
    queries: initialQueries,
    messages: initialMessages,
    auditLogs: [],
    companySettings: { ...INITIAL_COMPANY_SETTINGS },
    agents: initialAgents,
    ledgerMappings: [...INITIAL_LEDGER_MAPPINGS],
  };
}

let store: AppStore = buildInitialStore();

export function deduplicateInvitations(invList: UserInvitation[]): UserInvitation[] {
  const map = new Map<string, UserInvitation>();
  for (const inv of invList || []) {
    const key = (inv.id || inv.email || '').trim().toLowerCase();
    if (!key) continue;
    if (!map.has(key)) {
      map.set(key, { ...inv, id: key, email: key });
    } else {
      const existing = map.get(key)!;
      const invTime = new Date(inv.createdAt || inv.invitedAt || 0).getTime();
      const existingTime = new Date(existing.createdAt || existing.invitedAt || 0).getTime();
      if (inv.status === 'PENDING' && existing.status !== 'PENDING') {
        map.set(key, { ...inv, id: key, email: key });
      } else if (invTime >= existingTime) {
        map.set(key, { ...inv, id: key, email: key });
      }
    }
  }
  return Array.from(map.values());
}

export function deduplicateUsers(userList: UserProfile[]): UserProfile[] {
  const map = new Map<string, UserProfile>();
  for (const u of userList || []) {
    const key = (u.uid || u.email || '').trim().toLowerCase();
    if (!key) continue;
    if (!map.has(key)) {
      map.set(key, u);
    } else {
      const existing = map.get(key)!;
      const uTime = new Date(u.updatedAt || u.createdAt || 0).getTime();
      const existingTime = new Date(existing.updatedAt || existing.createdAt || 0).getTime();
      if (uTime >= existingTime) {
        map.set(key, u);
      }
    }
  }
  return Array.from(map.values());
}

function loadStore() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    if (fs.existsSync(STORE_FILE)) {
      const data = fs.readFileSync(STORE_FILE, 'utf-8');
      const loaded = JSON.parse(data);

      const loadedInvoices: InvoiceRecord[] = loaded.invoices || store.invoices;
      // Ensure all standard sample invoices (including inv_apex_2026_1234) are present
      for (const sampleInv of INITIAL_SAMPLE_INVOICES) {
        if (!loadedInvoices.some((i) => i.id === sampleInv.id || (i.invoiceNumber === sampleInv.invoiceNumber && i.vendorId === sampleInv.vendorId))) {
          loadedInvoices.unshift(sampleInv);
        }
      }

      store = {
        users: deduplicateUsers(loaded.users || store.users),
        invitations: deduplicateInvitations(loaded.invitations || store.invitations),
        vendors: loaded.vendors || store.vendors,
        invoices: loadedInvoices,
        queries: loaded.queries || store.queries,
        messages: loaded.messages || store.messages,
        auditLogs: loaded.auditLogs || store.auditLogs,
        companySettings: loaded.companySettings || store.companySettings,
        agents: loaded.agents || store.agents,
        ledgerMappings: loaded.ledgerMappings || store.ledgerMappings || [...INITIAL_LEDGER_MAPPINGS],
      };
      if (store.companySettings?.geminiApiKey) {
        setCustomGeminiKey(store.companySettings.geminiApiKey);
      }
      // Persist cleaned store
      saveStore();
    } else {
      if (store.companySettings?.geminiApiKey) {
        setCustomGeminiKey(store.companySettings.geminiApiKey);
      }
      saveStore();
    }
  } catch (err) {
    console.error('Error loading persistent store:', err);
  }
}

function saveStore() {
  try {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
    store.invitations = deduplicateInvitations(store.invitations);
    store.users = deduplicateUsers(store.users);
    fs.writeFileSync(STORE_FILE, JSON.stringify(store, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error saving persistent store:', err);
  }
}

// Initial load
loadStore();

export function hashAgentToken(token: string): string {
  return crypto.createHash('sha256').update(token.trim()).digest('hex');
}

// Append-only Server Audit Logger
function logServerAudit(
  userUid: string,
  userEmail: string,
  userRole: any,
  action: string,
  remarks: string,
  invoiceId?: string
) {
  const entry: AuditLogEntry = {
    id: `srv_log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    invoiceId,
    userUid: userUid || 'system',
    userEmail: String(userEmail || 'system').trim().toLowerCase(),
    userRole: userRole || 'SYSTEM',
    action,
    remarks,
    createdAt: new Date().toISOString(),
  };
  store.auditLogs.unshift(entry);
  saveStore();
}

/**
 * Health check endpoint for Cloud Run
 */
apiRouter.get(['/api/health', '/health'], (req: Request, res: Response) => {
  res.status(200).json({
    status: 'HEALTHY',
    service: 'GST Vendor Management System',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    geminiConfigured: Boolean(process.env.GEMINI_API_KEY),
    bootstrapAdmin: BOOTSTRAP_ADMIN_EMAIL,
  });
});

/**
 * AUTH: Server-side User Login & Role Resolution
 * Implements:
 * 1. Email normalization (trim and lowercase)
 * 2. Lookup invitation by normalized verified email
 * 3. Pre-registered onboarding: if pending invitation exists, auto-activate user profile as ACTIVE
 *    and mark invitation ACCEPTED with acceptedUid and acceptedAt
 * 4. Rule: If a user's profile is ALREADY active, never overwrite its role from an old invitation!
 * 5. Bootstrap Admin: first sign-in of BOOTSTRAP_ADMIN_EMAIL gets ADMIN if no admin exists
 * 6. Default new sign-in without invitation: role="PENDING", status="PENDING_APPROVAL"
 * 7. Deactivated user rejection
 * 8. Audit logging
 */
apiRouter.post('/api/auth/resolve-user', (req: Request, res: Response) => {
  try {
    const { uid, email, displayName, emailVerified } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Missing email' });
    }

    const normEmail = String(email).trim().toLowerCase();
    const canonEmail = getCanonicalEmail(normEmail);

    // Look up invitation by normalized or canonical email
    const invitation = store.invitations.find(
      (inv) =>
        (getCanonicalEmail(inv.email) === canonEmail || inv.email.trim().toLowerCase() === normEmail) &&
        (inv.status === 'PENDING' || inv.status === 'pending')
    );

    // 1. Resolve profile by Firebase UID first
    let userByUid = uid ? store.users.find((u) => u.uid === uid) : undefined;

    // 2. Resolve matching profiles by exact email and canonical email
    let matchingEmailUsers = store.users.filter(
      (u) =>
        (getCanonicalEmail(u.email) === canonEmail || u.email.trim().toLowerCase() === normEmail) &&
        !u.isArchived &&
        !u.mergedIntoUid
    );

    let existingUser: UserProfile | undefined = userByUid;

    // Duplicate detection & resolution logic
    if (!existingUser) {
      if (matchingEmailUsers.length === 1) {
        existingUser = matchingEmailUsers[0];
        if (uid && existingUser.uid !== uid) {
          existingUser.uid = uid; // Re-link UID
          existingUser.updatedAt = new Date().toISOString();
        }
      } else if (matchingEmailUsers.length > 1) {
        const activeProfiles = matchingEmailUsers.filter((u) => u.status === 'ACTIVE');
        const deactivatedProfiles = matchingEmailUsers.filter((u) => u.status === 'DEACTIVATED');

        if (activeProfiles.length > 0 && deactivatedProfiles.length > 0) {
          // Status Conflict between duplicate profiles!
          matchingEmailUsers.forEach((u) => {
            u.isDuplicateConflict = true;
          });
          logServerAudit(
            uid || 'system',
            normEmail,
            'SYSTEM',
            'DUPLICATE_PROFILE_CONFLICT',
            `Found conflicting duplicate profiles for ${normEmail} (canonical: ${canonEmail}). Sign-in blocked until Admin resolves duplicate.`
          );
          saveStore();
          return res.status(403).json({
            error: 'Your account has duplicate conflicting profiles. Please contact the System Administrator to resolve this duplicate.',
            code: 'DUPLICATE_CONFLICT',
          });
        }

        if (activeProfiles.length > 0) {
          // Keep newest active profile, link UID, merge others
          activeProfiles.sort(
            (a, b) =>
              new Date(b.updatedAt || b.createdAt || 0).getTime() -
              new Date(a.updatedAt || a.createdAt || 0).getTime()
          );
          existingUser = activeProfiles[0];
          if (uid) existingUser.uid = uid;
          for (const other of matchingEmailUsers) {
            if (other !== existingUser) {
              other.mergedIntoUid = existingUser.uid;
              other.isArchived = true;
            }
          }
        } else {
          existingUser = matchingEmailUsers[0];
          if (uid) existingUser.uid = uid;
        }
      }
    } else {
      // User found by UID. Check if duplicate ghost profiles exist for same canonical email
      const duplicateGhosts = matchingEmailUsers.filter((u) => u.uid !== existingUser!.uid);
      if (duplicateGhosts.length > 0) {
        const hasDeactivatedGhost = duplicateGhosts.some((u) => u.status === 'DEACTIVATED');
        if (existingUser.status === 'ACTIVE' && hasDeactivatedGhost) {
          for (const ghost of duplicateGhosts) {
            ghost.mergedIntoUid = existingUser.uid;
            ghost.isArchived = true;
          }
          saveStore();
        }
      }
    }

    if (existingUser) {
      // Re-map UID if this was created prior to Firebase UID
      if (uid && existingUser.uid !== uid) {
        existingUser.uid = uid;
      }

      // Check if deactivated
      if (existingUser.status === 'DEACTIVATED') {
        const exactReason =
          existingUser.deactivatedReason ||
          existingUser.statusReason ||
          'Deactivated by administrator';
        logServerAudit(
          existingUser.uid,
          normEmail,
          existingUser.role,
          'DENIED_ACCESS_ATTEMPT',
          `Deactivated user attempted to sign in. Server status reason: ${exactReason}`
        );
        return res.status(403).json({
          error: 'Your account has been deactivated. Please contact the System Administrator.',
          code: 'USER_DEACTIVATED',
        });
      }

      // CRITICAL RULE: If user is ALREADY active, NEVER overwrite role from an old invitation!
      if (existingUser.status === 'ACTIVE') {
        existingUser.lastLoginAt = new Date().toISOString();
        if (emailVerified !== undefined) existingUser.emailVerified = Boolean(emailVerified);
        saveStore();

        logServerAudit(
          existingUser.uid,
          normEmail,
          existingUser.role,
          'USER_SIGN_IN',
          `Active user ${normEmail} signed in with role ${existingUser.role}.`
        );
        return res.status(200).json({ user: existingUser, invitationFound: false });
      }

      // If user was PENDING_APPROVAL and there is a pending invitation: ACTIVATE IMMEDIATELY!
      if (invitation) {
        existingUser.role = invitation.role;
        existingUser.status = 'ACTIVE';
        existingUser.isActive = true;
        existingUser.vendorId = invitation.vendorId || undefined;
        existingUser.canOverride = Boolean(invitation.canOverride);
        existingUser.lastLoginAt = new Date().toISOString();
        existingUser.updatedAt = new Date().toISOString();
        if (emailVerified !== undefined) existingUser.emailVerified = Boolean(emailVerified);

        invitation.status = 'ACCEPTED';
        invitation.acceptedUid = existingUser.uid;
        invitation.acceptedAt = new Date().toISOString();

        logServerAudit(
          existingUser.uid,
          normEmail,
          existingUser.role,
          'USER_ONBOARDED_VIA_INVITATION',
          `Pre-registered invitation found for ${normEmail}. Pending profile automatically activated with role ${invitation.role}.`
        );
        saveStore();
        return res.status(200).json({ user: existingUser, invitationFound: true });
      }

      // Still awaiting approval
      existingUser.lastLoginAt = new Date().toISOString();
      saveStore();
      return res.status(200).json({ user: existingUser, invitationFound: false });
    }

    // NEW USER: Not registered previously
    let assignedRole: UserProfile['role'] = 'PENDING';
    let assignedStatus: UserProfile['status'] = 'PENDING_APPROVAL';
    let assignedVendorId: string | undefined = undefined;
    let canOverride = false;
    let invitationFound = false;
    let auditNote = `New user signed in with pending approval.`;

    if (invitation) {
      // Auto-activate with invited role
      assignedRole = invitation.role;
      assignedStatus = 'ACTIVE';
      assignedVendorId = invitation.vendorId;
      canOverride = Boolean(invitation.canOverride);
      invitation.status = 'ACCEPTED';
      invitation.acceptedUid = uid || `usr_${Date.now()}`;
      invitation.acceptedAt = new Date().toISOString();
      invitationFound = true;
      auditNote = `New user pre-registered via invitation automatically activated as ${assignedRole}.`;
    } else if (
      normEmail === BOOTSTRAP_ADMIN_EMAIL ||
      canonEmail === getCanonicalEmail(BOOTSTRAP_ADMIN_EMAIL)
    ) {
      const existingActiveAdmin = store.users.find(
        (u) => u.role === 'ADMIN' && u.status === 'ACTIVE'
      );
      if (!existingActiveAdmin) {
        assignedRole = 'ADMIN';
        assignedStatus = 'ACTIVE';
        canOverride = true;
        auditNote = 'Initial Bootstrap Admin assigned automatically on first login.';
      }
    }

    const newUser: UserProfile = {
      uid: uid || `usr_${Date.now()}`,
      email: normEmail,
      displayName: displayName || normEmail.split('@')[0],
      role: assignedRole,
      status: assignedStatus,
      isActive: assignedStatus === 'ACTIVE',
      vendorId: assignedVendorId,
      canOverride,
      emailVerified: Boolean(emailVerified),
      lastLoginAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    store.users.push(newUser);
    logServerAudit(
      newUser.uid,
      normEmail,
      newUser.role,
      invitation ? 'USER_ONBOARDED_VIA_INVITATION' : 'USER_SIGN_IN',
      auditNote
    );
    saveStore();

    return res.status(200).json({ user: newUser, invitationFound });
  } catch (error: any) {
    console.error('Resolve User Error:', error);
    return res.status(500).json({ error: error.message });
  }
});

/**
 * Reactive Profile Status Polling for Pending Approval Screen
 * Automatically activates user if an invitation was created while user is on pending screen!
 */
apiRouter.get('/api/auth/profile-status', (req: Request, res: Response) => {
  try {
    const { email, uid } = req.query;
    if (!email) {
      return res.status(400).json({ error: 'Missing email' });
    }
    const normEmail = String(email).trim().toLowerCase();

    let user = store.users.find(
      (u) => u.email.trim().toLowerCase() === normEmail || (uid && u.uid === String(uid))
    );

    // Check if an invitation was created for this pending user
    if (user && user.status === 'PENDING_APPROVAL') {
      const pendingInv = store.invitations.find(
        (inv) =>
          inv.email.trim().toLowerCase() === normEmail &&
          (inv.status === 'PENDING' || inv.status === 'pending')
      );
      if (pendingInv) {
        user.role = pendingInv.role;
        user.status = 'ACTIVE';
        user.isActive = true;
        user.vendorId = pendingInv.vendorId;
        user.canOverride = Boolean(pendingInv.canOverride);
        user.updatedAt = new Date().toISOString();

        pendingInv.status = 'ACCEPTED';
        pendingInv.acceptedUid = user.uid;
        pendingInv.acceptedAt = new Date().toISOString();

        logServerAudit(
          user.uid,
          normEmail,
          user.role,
          'USER_ONBOARDED_VIA_INVITATION',
          `User ${normEmail} automatically onboarded as ${user.role} via invitation.`
        );
        saveStore();
      }
    }

    // Check if an invitation exists for a DIFFERENT address
    const otherPendingInvs = store.invitations
      .filter((inv) => (inv.status === 'PENDING' || inv.status === 'pending') && inv.email.trim().toLowerCase() !== normEmail)
      .map((inv) => inv.email);

    return res.status(200).json({
      user: user || null,
      isActive: user?.status === 'ACTIVE',
      otherPendingInvitations: otherPendingInvs,
    });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * Invitation Info query (for login/pending screen notices)
 */
apiRouter.get('/api/auth/invitation-info', (req: Request, res: Response) => {
  const email = String(req.query.email || '').trim().toLowerCase();
  const invitation = store.invitations.find(
    (inv) => inv.email.trim().toLowerCase() === email && (inv.status === 'PENDING' || inv.status === 'pending')
  );

  const pendingInvitations = store.invitations
    .filter((inv) => inv.status === 'PENDING' || inv.status === 'pending')
    .map((inv) => inv.email);

  return res.status(200).json({
    hasInvitation: Boolean(invitation),
    invitation: invitation || null,
    allPendingEmails: pendingInvitations,
  });
});

/**
 * Log Sign Out
 */
apiRouter.post('/api/auth/log-signout', (req: Request, res: Response) => {
  const { uid, email, role, reason } = req.body;
  if (email) {
    logServerAudit(
      uid || 'unknown',
      String(email).toLowerCase(),
      role || 'VENDOR',
      'USER_SIGN_OUT',
      reason || 'User signed out voluntarily.'
    );
  }
  return res.status(200).json({ success: true });
});

/**
 * ADMIN: Get all users & invitations
 */
apiRouter.get('/api/admin/users', (req: Request, res: Response) => {
  return res.status(200).json({
    users: deduplicateUsers(store.users),
    invitations: deduplicateInvitations(store.invitations),
  });
});

/**
 * ADMIN: Assign Role, Vendor, and Override permission
 */
apiRouter.post('/api/admin/users/assign-role', (req: Request, res: Response) => {
  try {
    const { adminUid, targetUid, role, vendorId, canOverride, status } = req.body;

    const targetUser = store.users.find((u) => u.uid === targetUid);
    if (!targetUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    // Check allowed domains for internal roles (Accounts, Admin)
    if (role === 'ACCOUNTS_EXECUTIVE' || role === 'ADMIN') {
      const allowedDomains = (store.companySettings.allowedInternalDomains || '')
        .split(',')
        .map((d) => d.trim().toLowerCase())
        .filter(Boolean);

      const userDomain = targetUser.email.split('@')[1]?.toLowerCase();
      if (allowedDomains.length > 0 && (!userDomain || !allowedDomains.includes(userDomain))) {
        logServerAudit(
          adminUid || 'admin',
          targetUser.email,
          targetUser.role,
          'DENIED_ACCESS_ATTEMPT',
          `Cannot assign role ${role} to domain @${userDomain}. Allowed domains: ${allowedDomains.join(', ')}`
        );
        return res.status(400).json({
          error: `Domain @${userDomain} is not permitted for internal roles. Allowed domains: ${allowedDomains.join(', ')}`,
        });
      }
    }

    const oldRole = targetUser.role;
    targetUser.role = role;
    if (status) targetUser.status = status;
    targetUser.isActive = targetUser.status === 'ACTIVE';
    targetUser.vendorId = role === 'VENDOR' ? vendorId : undefined;
    targetUser.canOverride = Boolean(canOverride);
    targetUser.updatedAt = new Date().toISOString();

    logServerAudit(
      adminUid || 'admin',
      targetUser.email,
      role,
      'ROLE_ASSIGNMENT',
      `Assigned role ${role} (Vendor: ${vendorId || 'N/A'}, Override: ${canOverride ? 'YES' : 'NO'}, Status: ${targetUser.status}). Previous role: ${oldRole}.`
    );
    saveStore();

    return res.status(200).json({ success: true, user: targetUser });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * Helper: Atomic Activation logic
 */
async function executeUserActivation(targetUser: UserProfile, adminUid?: string) {
  const nowIso = new Date().toISOString();
  targetUser.status = 'ACTIVE';
  targetUser.isActive = true;
  targetUser.deactivatedReason = undefined;
  targetUser.deactivatedBy = undefined;
  targetUser.deactivatedAt = undefined;
  targetUser.statusReason = undefined;
  targetUser.isDuplicateConflict = false;
  targetUser.updatedAt = nowIso;

  // Sync with Firebase Auth: enable user and refresh custom claims
  await safeSetUserDisabled(targetUser.uid, false);
  await safeSetCustomClaims(targetUser.uid, {
    role: targetUser.role,
    status: 'ACTIVE',
    canOverride: Boolean(targetUser.canOverride),
    vendorId: targetUser.vendorId,
  });

  logServerAudit(
    adminUid || 'admin',
    targetUser.email,
    targetUser.role,
    'USER_ACTIVATION',
    `User ${targetUser.email} (UID: ${targetUser.uid}) activated by admin. Firebase Auth enabled, claims refreshed.`
  );
  saveStore();
}

/**
 * Helper: Atomic Deactivation logic
 */
async function executeUserDeactivation(targetUser: UserProfile, reason?: string, adminUid?: string) {
  const nowIso = new Date().toISOString();
  targetUser.status = 'DEACTIVATED';
  targetUser.isActive = false;
  targetUser.deactivatedReason = String(reason || 'Deactivated by Admin').trim();
  targetUser.deactivatedBy = adminUid || 'admin';
  targetUser.deactivatedAt = nowIso;
  targetUser.statusReason = targetUser.deactivatedReason;
  targetUser.updatedAt = nowIso;

  // Sync with Firebase Auth: disable user and revoke tokens
  await safeSetUserDisabled(targetUser.uid, true);
  await safeRevokeTokens(targetUser.uid);

  logServerAudit(
    adminUid || 'admin',
    targetUser.email,
    targetUser.role,
    'USER_DEACTIVATION',
    `User ${targetUser.email} deactivated by admin. Reason: ${targetUser.deactivatedReason}. Firebase Auth disabled, refresh tokens revoked.`
  );
  saveStore();
}

/**
 * ADMIN: Activate User (Atomic Action)
 */
apiRouter.post('/api/admin/users/activate', async (req: Request, res: Response) => {
  try {
    const { adminUid, targetUid } = req.body;
    const targetUser = store.users.find((u) => u.uid === targetUid);
    if (!targetUser) return res.status(404).json({ error: 'User not found' });

    await executeUserActivation(targetUser, adminUid);
    return res.status(200).json({ success: true, user: targetUser });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: Deactivate User (Atomic Action)
 */
apiRouter.post('/api/admin/users/deactivate', async (req: Request, res: Response) => {
  try {
    const { adminUid, targetUid, reason } = req.body;
    const targetUser = store.users.find((u) => u.uid === targetUid);
    if (!targetUser) return res.status(404).json({ error: 'User not found' });

    if (adminUid && targetUser.uid === adminUid) {
      return res.status(400).json({ error: 'You cannot deactivate your own account.' });
    }
    if (targetUser.role === 'ADMIN') {
      const activeAdmins = store.users.filter(
        (u) => u.role === 'ADMIN' && u.status === 'ACTIVE' && u.uid !== targetUid
      );
      if (activeAdmins.length === 0) {
        return res.status(400).json({ error: 'Cannot deactivate the last remaining active Administrator.' });
      }
    }

    await executeUserDeactivation(targetUser, reason, adminUid);
    return res.status(200).json({ success: true, user: targetUser });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: Activate / Deactivate user (Legacy wrapper for backward-compatibility)
 */
apiRouter.post('/api/admin/users/toggle-status', async (req: Request, res: Response) => {
  try {
    const { adminUid, targetUid, newStatus, reason } = req.body;
    const targetUser = store.users.find((u) => u.uid === targetUid);
    if (!targetUser) return res.status(404).json({ error: 'User not found' });

    if (newStatus === 'ACTIVE') {
      await executeUserActivation(targetUser, adminUid);
    } else {
      if (adminUid && targetUser.uid === adminUid) {
        return res.status(400).json({ error: 'You cannot deactivate your own account.' });
      }
      if (targetUser.role === 'ADMIN') {
        const activeAdmins = store.users.filter(
          (u) => u.role === 'ADMIN' && u.status === 'ACTIVE' && u.uid !== targetUid
        );
        if (activeAdmins.length === 0) {
          return res.status(400).json({ error: 'Cannot deactivate the last remaining active Administrator.' });
        }
      }
      await executeUserDeactivation(targetUser, reason, adminUid);
    }

    return res.status(200).json({ success: true, user: targetUser });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: Check Access Diagnostics (Verification Drawer)
 */
apiRouter.get('/api/admin/users/:uid/access-status', async (req: Request, res: Response) => {
  try {
    const { uid } = req.params;
    const user = store.users.find((u) => u.uid === uid);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const canonEmail = getCanonicalEmail(user.email);
    const duplicates = store.users.filter(
      (u) => getCanonicalEmail(u.email) === canonEmail && u.uid !== user.uid && !u.isArchived
    );

    const vendor = user.vendorId ? store.vendors.find((v) => v.id === user.vendorId) : null;

    let authUserRecord: any = null;
    if (adminInitialized) {
      try {
        authUserRecord = await getAuth().getUser(uid);
      } catch (e: any) {
        authUserRecord = { disabled: user.status === 'DEACTIVATED', error: e.message };
      }
    } else {
      authUserRecord = { disabled: user.status === 'DEACTIVATED', simulated: true };
    }

    const isAuthInSync = user.status === 'ACTIVE' ? !authUserRecord.disabled : authUserRecord.disabled;

    return res.status(200).json({
      user,
      firestoreStatus: user.status,
      isActive: user.isActive,
      deactivatedReason:
        user.deactivatedReason || user.statusReason || (user.status === 'DEACTIVATED' ? 'Deactivated' : null),
      authDisabled: Boolean(authUserRecord.disabled),
      roleClaims: {
        role: user.role,
        canOverride: Boolean(user.canOverride),
        vendorId: user.vendorId || null,
      },
      vendorLink: {
        vendorId: user.vendorId || null,
        vendorName: vendor ? vendor.legalName : null,
        vendorStatus: vendor ? vendor.status : null,
      },
      duplicates: duplicates.map((d) => ({
        uid: d.uid,
        email: d.email,
        status: d.status,
        role: d.role,
      })),
      isSynced: isAuthInSync && duplicates.length === 0,
    });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: Resync Access (Repair Drift between systems)
 */
apiRouter.post('/api/admin/users/:uid/resync-access', async (req: Request, res: Response) => {
  try {
    const { uid } = req.params;
    const { adminUid } = req.body;
    const user = store.users.find((u) => u.uid === uid);
    if (!user) return res.status(404).json({ error: 'User not found' });

    const shouldBeDisabled = user.status === 'DEACTIVATED';
    await safeSetUserDisabled(user.uid, shouldBeDisabled);
    if (shouldBeDisabled) {
      await safeRevokeTokens(user.uid);
    } else {
      await safeSetCustomClaims(user.uid, {
        role: user.role,
        status: user.status,
        canOverride: Boolean(user.canOverride),
        vendorId: user.vendorId,
      });
    }

    user.isDuplicateConflict = false;
    user.updatedAt = new Date().toISOString();

    logServerAudit(
      adminUid || 'admin',
      user.email,
      user.role,
      'USER_ACCESS_RESYNCED',
      `Access repaired and resynced for ${user.email}. Profile status: ${user.status}, Auth disabled: ${shouldBeDisabled}.`
    );
    saveStore();

    return res.status(200).json({ success: true, message: 'User access resynced successfully.', user });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: Resolve Duplicate Profiles
 */
apiRouter.post('/api/admin/users/resolve-duplicate', (req: Request, res: Response) => {
  try {
    const { adminUid, canonicalEmail, keepUid } = req.body;
    if (!canonicalEmail || !keepUid) {
      return res.status(400).json({ error: 'Missing canonicalEmail or keepUid' });
    }

    const canon = getCanonicalEmail(canonicalEmail);
    const matches = store.users.filter((u) => getCanonicalEmail(u.email) === canon);
    const keeper = matches.find((u) => u.uid === keepUid);
    if (!keeper) return res.status(404).json({ error: 'Target user to keep not found' });

    let mergedCount = 0;
    for (const u of matches) {
      if (u.uid !== keepUid) {
        u.mergedIntoUid = keepUid;
        u.isArchived = true;
        u.isDuplicateConflict = false;
        mergedCount++;
      }
    }

    keeper.isDuplicateConflict = false;
    keeper.updatedAt = new Date().toISOString();

    logServerAudit(
      adminUid || 'admin',
      keeper.email,
      keeper.role,
      'RESOLVE_DUPLICATE_USERS',
      `Resolved duplicates for canonical email ${canon}. Retained UID ${keepUid} as primary, merged ${mergedCount} legacy records.`
    );
    saveStore();

    return res.status(200).json({ success: true, user: keeper, mergedCount });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: Delete Single User
 * Requirements:
 * - Admin cannot delete self
 * - Admin cannot delete last remaining active Admin
 * - Confirmation: typed user email
 * - Deletes profile, deletes/disables auth user, revokes tokens, deletes pending invitations
 * - Preserves audit trails, approvals, queries with snapshot
 * - Preserves linked vendor and invoices
 */
apiRouter.delete('/api/admin/users/:uid', async (req: Request, res: Response) => {
  try {
    const { uid } = req.params;
    const { adminUid, confirmEmail, reason } = req.body;

    const targetUser = store.users.find((u) => u.uid === uid);
    if (!targetUser) return res.status(404).json({ error: 'User not found' });

    if (adminUid && targetUser.uid === adminUid) {
      return res.status(400).json({ error: 'Security restriction: An Administrator cannot delete their own account.' });
    }

    if (targetUser.role === 'ADMIN' && targetUser.status === 'ACTIVE') {
      const activeAdmins = store.users.filter(
        (u) => u.role === 'ADMIN' && u.status === 'ACTIVE' && u.uid !== uid
      );
      if (activeAdmins.length === 0) {
        return res.status(400).json({ error: 'Security restriction: Cannot delete the last remaining active Administrator.' });
      }
    }

    if (String(confirmEmail || '').trim().toLowerCase() !== targetUser.email.trim().toLowerCase()) {
      return res.status(400).json({
        error: `Confirmation email mismatch. Please type exact email "${targetUser.email}" to confirm deletion.`,
      });
    }

    const canonEmail = getCanonicalEmail(targetUser.email);

    // 1. Delete from store.users
    store.users = store.users.filter((u) => u.uid !== uid);

    // 2. Delete pending invitations for this email
    store.invitations = store.invitations.filter(
      (inv) => getCanonicalEmail(inv.email) !== canonEmail
    );

    // 3. Delete / disable auth user and revoke tokens
    await safeDeleteAuthUser(uid);
    await safeRevokeTokens(uid);

    logServerAudit(
      adminUid || 'admin',
      targetUser.email,
      targetUser.role,
      'DELETE_USER',
      `Permanently deleted user ${targetUser.email} (UID: ${targetUser.uid}, Role: ${targetUser.role}). Reason: ${reason || 'Administrator deletion'}. Audit trails preserved.`
    );
    saveStore();

    return res.status(200).json({ success: true, deletedUid: uid });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: Bulk User Delete
 * Requirements:
 * - Admin cannot delete self
 * - Cannot delete last active admin
 * - Confirmation: typed count (e.g. "DELETE 3")
 */
apiRouter.post('/api/admin/users/bulk-delete', async (req: Request, res: Response) => {
  try {
    const { adminUid, uids, confirmCount, reason } = req.body;
    if (!Array.isArray(uids) || uids.length === 0) {
      return res.status(400).json({ error: 'No user UIDs specified for deletion.' });
    }

    const expectedConfirm = `DELETE ${uids.length}`;
    if (String(confirmCount || '').trim().toUpperCase() !== expectedConfirm) {
      return res.status(400).json({
        error: `Confirmation mismatch. Please type "${expectedConfirm}" to confirm bulk deletion.`,
      });
    }

    if (adminUid && uids.includes(adminUid)) {
      return res.status(400).json({
        error: 'Security restriction: Your own Administrator account cannot be selected for deletion.',
      });
    }

    const activeAdmins = store.users.filter((u) => u.role === 'ADMIN' && u.status === 'ACTIVE');
    const remainingActiveAdmins = activeAdmins.filter((u) => !uids.includes(u.uid));
    if (remainingActiveAdmins.length === 0) {
      return res.status(400).json({
        error: 'Security restriction: Bulk deletion would eliminate all active Administrators.',
      });
    }

    const deletedEmails: string[] = [];
    for (const uid of uids) {
      const u = store.users.find((user) => user.uid === uid);
      if (u) {
        deletedEmails.push(u.email);
        await safeDeleteAuthUser(uid);
        await safeRevokeTokens(uid);
      }
    }

    // Delete users from store
    store.users = store.users.filter((u) => !uids.includes(u.uid));

    // Delete pending invitations for deleted users
    const deletedCanonEmails = new Set(deletedEmails.map((e) => getCanonicalEmail(e)));
    store.invitations = store.invitations.filter(
      (inv) => !deletedCanonEmails.has(getCanonicalEmail(inv.email))
    );

    logServerAudit(
      adminUid || 'admin',
      'bulk-users',
      'ADMIN',
      'BULK_DELETE_USERS',
      `Bulk deleted ${uids.length} user(s): ${deletedEmails.join(', ')}. Reason: ${reason || 'Admin bulk deletion'}. Audit history preserved.`
    );
    saveStore();

    return res.status(200).json({ success: true, deletedCount: uids.length });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: INVITATIONS API
 */
apiRouter.get('/api/admin/invitations', (req: Request, res: Response) => {
  return res.status(200).json(deduplicateInvitations(store.invitations));
});

/**
 * ADMIN: Create Pre-registered Invitation
 * Rules:
 * - Normalized email as document ID (strictly unique per email)
 * - If email already has a profile in PENDING_APPROVAL: activate immediately with invited role & mark accepted!
 */
apiRouter.post('/api/admin/invitations/create', (req: Request, res: Response) => {
  try {
    const { adminUid, email, role, vendorId, canOverride } = req.body;
    if (!email || !role) {
      return res.status(400).json({ error: 'Email and role are required' });
    }

    const normEmail = String(email).trim().toLowerCase();

    // Enforce domain check for internal roles
    if (role === 'ACCOUNTS_EXECUTIVE' || role === 'ADMIN') {
      const allowedDomains = (store.companySettings.allowedInternalDomains || '')
        .split(',')
        .map((d) => d.trim().toLowerCase())
        .filter(Boolean);

      const domain = normEmail.split('@')[1];
      if (allowedDomains.length > 0 && (!domain || !allowedDomains.includes(domain))) {
        return res.status(400).json({
          error: `Email domain @${domain} is not in the allowed internal domains list (${allowedDomains.join(', ')}).`,
        });
      }
    }

    // Look for ANY existing invitation document for this normalized email ID
    const existingInvIdx = store.invitations.findIndex(
      (i) =>
        (i.id && i.id.trim().toLowerCase() === normEmail) ||
        (i.email && i.email.trim().toLowerCase() === normEmail)
    );

    // Look for existing user profile in pending_approval
    const existingPendingUser = store.users.find(
      (u) => u.email.trim().toLowerCase() === normEmail && u.status === 'PENDING_APPROVAL'
    );

    const nowIso = new Date().toISOString();

    const newInv: UserInvitation = {
      id: normEmail,
      email: normEmail,
      role,
      vendorId: role === 'VENDOR' ? vendorId : undefined,
      canOverride: Boolean(canOverride),
      invitedBy: adminUid || 'admin',
      invitedByName: 'System Administrator',
      invitedAt: nowIso,
      status: existingPendingUser ? 'ACCEPTED' : 'PENDING',
      acceptedUid: existingPendingUser ? existingPendingUser.uid : undefined,
      acceptedAt: existingPendingUser ? nowIso : undefined,
      createdAt: nowIso,
    };

    if (existingInvIdx >= 0) {
      store.invitations[existingInvIdx] = newInv;
    } else {
      store.invitations.push(newInv);
    }
    store.invitations = deduplicateInvitations(store.invitations);

    // ONBOARDING RULE: If user already has a pending profile, activate immediately!
    if (existingPendingUser) {
      existingPendingUser.role = role;
      existingPendingUser.status = 'ACTIVE';
      existingPendingUser.isActive = true;
      existingPendingUser.vendorId = role === 'VENDOR' ? vendorId : undefined;
      existingPendingUser.canOverride = Boolean(canOverride);
      existingPendingUser.updatedAt = nowIso;

      logServerAudit(
        adminUid || 'admin',
        normEmail,
        role,
        'ADMIN_INVITATION_ACTIVATED_PENDING_USER',
        `Admin invited ${normEmail} as ${role}. Existing pending profile activated immediately to ACTIVE without requiring sign out.`
      );
    } else {
      logServerAudit(
        adminUid || 'admin',
        normEmail,
        role,
        'CREATE_INVITATION',
        `Created pre-registered invitation for ${normEmail} as ${role} (Vendor: ${vendorId || 'N/A'}, Override: ${canOverride ? 'YES' : 'NO'}).`
      );
    }

    saveStore();

    return res.status(201).json({
      success: true,
      invitation: newInv,
      activatedUser: existingPendingUser || null,
    });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: Edit Invitation
 */
apiRouter.put('/api/admin/invitations/:id', (req: Request, res: Response) => {
  try {
    const rawId = decodeURIComponent(req.params.id).trim().toLowerCase();
    const { adminUid, role, vendorId, canOverride } = req.body;

    const inv = store.invitations.find(
      (i) => i.id.trim().toLowerCase() === rawId || i.email.trim().toLowerCase() === rawId
    );

    if (!inv) {
      return res.status(404).json({ error: 'Invitation not found' });
    }

    if (inv.status === 'ACCEPTED' || inv.status === 'accepted') {
      return res.status(400).json({
        error: 'Accepted invitations cannot be edited. Update the user role directly in the Users list.',
      });
    }

    const prevRole = inv.role;
    if (role) inv.role = role;
    inv.vendorId = role === 'VENDOR' ? vendorId : undefined;
    inv.canOverride = Boolean(canOverride);

    logServerAudit(
      adminUid || 'admin',
      inv.email,
      inv.role,
      'EDIT_INVITATION',
      `Edited invitation for ${inv.email}: Role changed from ${prevRole} to ${inv.role} (Vendor: ${inv.vendorId || 'N/A'}, Override: ${inv.canOverride ? 'YES' : 'NO'}).`
    );
    saveStore();

    return res.status(200).json({ success: true, invitation: inv });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: Resend Invitation
 */
apiRouter.post('/api/admin/invitations/:id/resend', (req: Request, res: Response) => {
  try {
    const rawId = decodeURIComponent(req.params.id).trim().toLowerCase();
    const { adminUid } = req.body;

    const inv = store.invitations.find(
      (i) => i.id.trim().toLowerCase() === rawId || i.email.trim().toLowerCase() === rawId
    );

    if (!inv) {
      return res.status(404).json({ error: 'Invitation not found' });
    }

    inv.lastSentAt = new Date().toISOString();
    logServerAudit(
      adminUid || 'admin',
      inv.email,
      inv.role,
      'RESEND_INVITATION',
      `Resent invitation notification email to ${inv.email} for role ${inv.role}.`
    );
    saveStore();

    return res.status(200).json({ success: true, invitation: inv });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: Delete (Revoke) Invitation
 * Rule: Cannot delete accepted invitations.
 */
apiRouter.delete('/api/admin/invitations/:id', (req: Request, res: Response) => {
  try {
    const rawId = decodeURIComponent(req.params.id).trim().toLowerCase();
    const adminUid = (req.query.adminUid as string) || 'admin';

    const invIdx = store.invitations.findIndex(
      (i) => i.id.trim().toLowerCase() === rawId || i.email.trim().toLowerCase() === rawId
    );

    if (invIdx === -1) {
      return res.status(404).json({ error: 'Invitation not found' });
    }

    const inv = store.invitations[invIdx];
    if (inv.status === 'ACCEPTED' || inv.status === 'accepted') {
      return res.status(400).json({
        error: 'Accepted invitations cannot be deleted. The user must be deactivated from the Users list instead.',
      });
    }

    store.invitations.splice(invIdx, 1);
    logServerAudit(
      adminUid,
      inv.email,
      inv.role,
      'REVOKE_INVITATION',
      `Revoked and deleted pre-registered invitation for ${inv.email} (${inv.role}).`
    );
    saveStore();

    return res.status(200).json({ success: true });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: Bulk Delete Pending Invitations
 */
apiRouter.post('/api/admin/invitations/bulk-delete', (req: Request, res: Response) => {
  try {
    const { ids, adminUid } = req.body;
    if (!Array.isArray(ids) || ids.length === 0) {
      return res.status(400).json({ error: 'ids array is required' });
    }

    const normalizedIds = ids.map((id) => String(id).trim().toLowerCase());
    let deletedCount = 0;

    store.invitations = store.invitations.filter((inv) => {
      const match =
        normalizedIds.includes(inv.id.trim().toLowerCase()) ||
        normalizedIds.includes(inv.email.trim().toLowerCase());
      if (match && inv.status !== 'ACCEPTED' && inv.status !== 'accepted') {
        deletedCount++;
        return false;
      }
      return true;
    });

    logServerAudit(
      adminUid || 'admin',
      'system',
      'ADMIN',
      'BULK_REVOKE_INVITATIONS',
      `Bulk deleted ${deletedCount} pending invitations.`
    );
    saveStore();

    return res.status(200).json({ success: true, count: deletedCount });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: VENDOR MANAGEMENT & HISTORY CHECK (Rule A, B, C)
 */
apiRouter.get('/api/admin/vendors', (req: Request, res: Response) => {
  return res.status(200).json(store.vendors);
});

apiRouter.post('/api/admin/vendors/create', (req: Request, res: Response) => {
  try {
    const {
      legalName,
      tradeName,
      gstin,
      pan,
      stateCode,
      stateName,
      address,
      pincode,
      contactPerson,
      email,
      phone,
      bankAccountName,
      bankAccountNumber,
      bankIfsc,
      bankName,
      isMsme,
      msmeRegistrationNumber,
      isComposition,
      turnoverCategory,
      tallyLedgerName,
      adminUid,
    } = req.body;

    if (!legalName || !String(legalName).trim()) {
      return res.status(400).json({ error: 'Legal Entity Name is required' });
    }
    if (!gstin || !String(gstin).trim()) {
      return res.status(400).json({ error: '15-digit GSTIN is required' });
    }

    const cleanGstin = String(gstin).trim().toUpperCase();
    if (!/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(cleanGstin)) {
      return res.status(400).json({ error: 'Invalid 15-character GSTIN format (e.g., 27AAACA1234A1Z1)' });
    }

    // Check duplicate GSTIN
    const existing = store.vendors.find((v) => v.gstin.toUpperCase() === cleanGstin && v.status !== 'ARCHIVED');
    if (existing) {
      return res.status(400).json({
        error: `A vendor with GSTIN ${cleanGstin} already exists ("${existing.legalName}").`,
      });
    }

    const cleanPan = pan ? String(pan).trim().toUpperCase() : cleanGstin.slice(2, 12);
    const cleanStateCode = stateCode || cleanGstin.slice(0, 2);

    const newVendor: VendorMaster = {
      id: `vendor_${Date.now()}`,
      legalName: String(legalName).trim(),
      tradeName: tradeName ? String(tradeName).trim() : String(legalName).trim(),
      gstin: cleanGstin,
      pan: cleanPan,
      stateCode: cleanStateCode,
      stateName: stateName || 'State',
      address: address ? String(address).trim() : 'Registered Commercial Address',
      pincode: pincode ? String(pincode).trim() : '400001',
      contactPerson: contactPerson ? String(contactPerson).trim() : 'Authorized Signatory',
      email: email ? String(email).trim().toLowerCase() : 'vendor@domain.com',
      phone: phone ? String(phone).trim() : '+91 98000 00000',
      bankAccountName: bankAccountName ? String(bankAccountName).trim() : String(legalName).trim(),
      bankAccountNumber: bankAccountNumber ? String(bankAccountNumber).trim() : '000011112222',
      bankIfsc: bankIfsc ? String(bankIfsc).trim().toUpperCase() : 'HDFC0000001',
      bankName: bankName ? String(bankName).trim() : 'HDFC Bank',
      isMsme: Boolean(isMsme),
      msmeRegistrationNumber: msmeRegistrationNumber ? String(msmeRegistrationNumber).trim() : undefined,
      isComposition: Boolean(isComposition),
      turnoverCategory: turnoverCategory === 'ABOVE_5CR' ? 'ABOVE_5CR' : 'UP_TO_5CR',
      status: 'ACTIVE',
      tallyLedgerName: tallyLedgerName ? String(tallyLedgerName).trim() : String(legalName).trim(),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    store.vendors.push(newVendor);
    logServerAudit(
      adminUid || 'admin',
      'system',
      'ADMIN',
      'CREATE_VENDOR',
      `Registered vendor master for "${newVendor.legalName}" (${newVendor.gstin}). State: ${newVendor.stateName} (${newVendor.stateCode}).`
    );
    saveStore();
    return res.status(201).json({ success: true, vendor: newVendor });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * Vendor Delete Eligibility Checker
 * Inspects invoices, clarification queries, and postings.
 */
apiRouter.get('/api/admin/vendors/:id/delete-eligibility', (req: Request, res: Response) => {
  const { id } = req.params;
  const vendor = store.vendors.find((v) => v.id === id);
  if (!vendor) {
    return res.status(404).json({ error: 'Vendor not found' });
  }

  const invoiceCount = store.invoices.filter((i) => i.vendorId === id).length;
  // Sample queries count
  const queryCount = store.invoices.filter(
    (i) => i.vendorId === id && i.status === 'CLARIFICATION_REQUESTED'
  ).length;

  const hasHistory = invoiceCount > 0 || queryCount > 0;

  let reason = '';
  if (hasHistory) {
    reason = `This vendor has ${invoiceCount} invoice(s) on record. Under GST audit trail compliance, permanent deletion is not permitted. You can Archive this vendor instead.`;
  } else {
    reason = `This vendor has 0 invoices, 0 queries, and no accounting records. Permanent deletion is permitted.`;
  }

  return res.status(200).json({
    vendor,
    canDeletePermanently: !hasHistory,
    invoiceCount,
    queryCount,
    reason,
  });
});

/**
 * ADMIN: Update Vendor Master Details (including GSTIN, Legal Name, Address, Bank, etc.)
 */
const handleVendorUpdate = (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const vendor = store.vendors.find((v) => v.id === id);
    if (!vendor) return res.status(404).json({ error: 'Vendor not found' });

    const {
      legalName,
      tradeName,
      gstin,
      pan,
      stateCode,
      stateName,
      address,
      pincode,
      contactPerson,
      email,
      phone,
      turnoverCategory,
      isComposition,
      isMsme,
      msmeRegistrationNumber,
      bankAccountName,
      bankAccountNumber,
      bankIfsc,
      bankName,
      tallyLedgerName,
      adminUid,
    } = req.body;

    const oldGstin = vendor.gstin;
    const oldName = vendor.legalName;

    if (legalName) vendor.legalName = String(legalName).trim();
    if (tradeName !== undefined) vendor.tradeName = String(tradeName).trim();
    if (gstin) {
      const cleanGstin = String(gstin).trim().toUpperCase();
      vendor.gstin = cleanGstin;
      if (cleanGstin.length >= 12 && !pan) {
        vendor.pan = cleanGstin.slice(2, 12);
      }
      if (cleanGstin.length >= 2 && !stateCode) {
        vendor.stateCode = cleanGstin.slice(0, 2);
      }
    }
    if (pan) vendor.pan = String(pan).trim().toUpperCase();
    if (stateCode) vendor.stateCode = String(stateCode).trim();
    if (stateName) vendor.stateName = String(stateName).trim();
    if (address !== undefined) vendor.address = String(address).trim();
    if (pincode !== undefined) vendor.pincode = String(pincode).trim();
    if (contactPerson !== undefined) vendor.contactPerson = String(contactPerson).trim();
    if (email !== undefined) vendor.email = String(email).trim().toLowerCase();
    if (phone !== undefined) vendor.phone = String(phone).trim();
    if (turnoverCategory) vendor.turnoverCategory = turnoverCategory === 'ABOVE_5CR' ? 'ABOVE_5CR' : 'UP_TO_5CR';
    if (isComposition !== undefined) vendor.isComposition = Boolean(isComposition);
    if (isMsme !== undefined) vendor.isMsme = Boolean(isMsme);
    if (msmeRegistrationNumber !== undefined) vendor.msmeRegistrationNumber = String(msmeRegistrationNumber).trim();
    if (bankAccountName !== undefined) vendor.bankAccountName = String(bankAccountName).trim();
    if (bankAccountNumber !== undefined) vendor.bankAccountNumber = String(bankAccountNumber).trim();
    if (bankIfsc !== undefined) vendor.bankIfsc = String(bankIfsc).trim().toUpperCase();
    if (bankName !== undefined) vendor.bankName = String(bankName).trim();
    if (tallyLedgerName !== undefined) vendor.tallyLedgerName = String(tallyLedgerName).trim();

    vendor.updatedAt = new Date().toISOString();

    logServerAudit(
      adminUid || 'admin',
      'system',
      'ADMIN',
      'UPDATE_VENDOR',
      `Updated vendor master for "${vendor.legalName}" (${vendor.gstin}). Previous: "${oldName}" (${oldGstin}).`
    );

    saveStore();
    return res.status(200).json({ success: true, vendor });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
};

apiRouter.post('/api/admin/vendors/:id/update', handleVendorUpdate);
apiRouter.put('/api/admin/vendors/:id', handleVendorUpdate);

/**
 * ADMIN: Delete Vendor (Rule A: Permanent Delete if No History)
 */
apiRouter.delete('/api/admin/vendors/:id', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { confirmVendorName, reason, adminUid } = req.body;

    const vendor = store.vendors.find((v) => v.id === id);
    if (!vendor) return res.status(404).json({ error: 'Vendor not found' });

    // Check history
    const invoiceCount = store.invoices.filter((i) => i.vendorId === id).length;
    if (invoiceCount > 0) {
      return res.status(400).json({
        error: `Vendor has ${invoiceCount} invoice(s) on record. Under GST audit trail compliance, permanent deletion is disallowed. Please archive the vendor instead.`,
      });
    }

    // Verify confirmation name (allow matching legalName, tradeName, gstin, 'confirm', 'delete', or blank vendor)
    const normalizedConfirm = String(confirmVendorName || '').trim().toLowerCase();
    const legalMatch = vendor.legalName.trim().toLowerCase() === normalizedConfirm;
    const tradeMatch = vendor.tradeName.trim().toLowerCase() === normalizedConfirm;
    const gstinMatch = vendor.gstin.trim().toLowerCase() === normalizedConfirm;
    const isKeyword = normalizedConfirm === 'confirm' || normalizedConfirm === 'delete';
    const isBlankVendor = !vendor.legalName.trim() || !vendor.gstin.trim();

    if (normalizedConfirm && !legalMatch && !tradeMatch && !gstinMatch && !isKeyword && !isBlankVendor) {
      return res.status(400).json({
        error: `Confirmation vendor name did not match "${vendor.legalName}". Please type the vendor name or GSTIN to confirm.`,
      });
    }

    const effectiveReason =
      String(reason || '').trim() || 'Permanently deleted unused/blank vendor with 0 transaction history.';

    // Remove vendor
    store.vendors = store.vendors.filter((v) => v.id !== id);

    // Cascading: Revoke pending invitations linked to this vendor
    let revokedInvCount = 0;
    store.invitations = store.invitations.filter((inv) => {
      if (inv.vendorId === id && (inv.status === 'PENDING' || inv.status === 'pending')) {
        revokedInvCount++;
        return false;
      }
      return true;
    });

    // Cascading: Deactivate and unlink users linked to this vendor
    let deactivatedUserCount = 0;
    store.users.forEach((u) => {
      if (u.vendorId === id) {
        u.status = 'DEACTIVATED';
        u.isActive = false;
        u.deactivatedReason = 'Vendor permanently deleted';
        u.deactivatedBy = adminUid || 'admin';
        u.deactivatedAt = new Date().toISOString();
        u.statusReason = 'Vendor permanently deleted';
        u.vendorId = undefined;
        u.updatedAt = new Date().toISOString();
        deactivatedUserCount++;
      }
    });

    logServerAudit(
      adminUid || 'admin',
      'system',
      'ADMIN',
      'DELETE_VENDOR_PERMANENT',
      `Permanently deleted vendor "${vendor.legalName}" (${vendor.gstin}). Reason: ${reason}. Revoked ${revokedInvCount} pending invitation(s), deactivated ${deactivatedUserCount} user(s).`
    );
    saveStore();

    return res.status(200).json({
      success: true,
      revokedInvitations: revokedInvCount,
      deactivatedUsers: deactivatedUserCount,
    });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: Archive Vendor (Rule B: Soft Delete when History Exists)
 */
apiRouter.post('/api/admin/vendors/:id/archive', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { reason, adminUid } = req.body;

    const vendor = store.vendors.find((v) => v.id === id);
    if (!vendor) return res.status(404).json({ error: 'Vendor not found' });

    if (!reason || !String(reason).trim()) {
      return res.status(400).json({ error: 'A mandatory reason is required to archive this vendor.' });
    }

    const nowIso = new Date().toISOString();
    vendor.status = 'ARCHIVED';
    vendor.archiveReason = String(reason).trim();
    vendor.archivedAt = nowIso;
    vendor.archivedBy = adminUid || 'admin';
    vendor.updatedAt = nowIso;

    // Deactivate vendor users with mandatory reason "Vendor archived"
    let deactivatedCount = 0;
    store.users.forEach((u) => {
      if (u.vendorId === id) {
        u.status = 'DEACTIVATED';
        u.isActive = false;
        u.deactivatedReason = 'Vendor archived';
        u.deactivatedBy = adminUid || 'admin';
        u.deactivatedAt = nowIso;
        u.statusReason = 'Vendor archived';
        u.updatedAt = nowIso;
        deactivatedCount++;
      }
    });

    logServerAudit(
      adminUid || 'admin',
      'system',
      'ADMIN',
      'ARCHIVE_VENDOR',
      `Archived vendor "${vendor.legalName}" (${vendor.gstin}). Reason: ${reason}. Deactivated ${deactivatedCount} vendor user(s). Invoices and audit history preserved.`
    );
    saveStore();

    return res.status(200).json({ success: true, vendor, deactivatedUsers: deactivatedCount });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: Restore Archived Vendor
 */
apiRouter.post('/api/admin/vendors/:id/restore', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { reason, adminUid } = req.body;

    const vendor = store.vendors.find((v) => v.id === id);
    if (!vendor) return res.status(404).json({ error: 'Vendor not found' });

    const nowIso = new Date().toISOString();
    vendor.status = 'ACTIVE';
    vendor.archiveReason = undefined;
    vendor.archivedAt = undefined;
    vendor.archivedBy = undefined;
    vendor.updatedAt = nowIso;

    logServerAudit(
      adminUid || 'admin',
      'system',
      'ADMIN',
      'RESTORE_VENDOR',
      `Restored archived vendor "${vendor.legalName}" (${vendor.gstin}) to ACTIVE status. Reason: ${reason || 'Administrator restored vendor master'}.`
    );
    saveStore();

    return res.status(200).json({ success: true, vendor });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: Bulk Vendor Delete / Archive
 */
apiRouter.post('/api/admin/vendors/bulk-delete', (req: Request, res: Response) => {
  try {
    const { vendorIds, reason, adminUid } = req.body;
    if (!Array.isArray(vendorIds) || vendorIds.length === 0) {
      return res.status(400).json({ error: 'vendorIds array is required' });
    }

    let deletedCount = 0;
    let archivedCount = 0;

    vendorIds.forEach((vId) => {
      const vendor = store.vendors.find((v) => v.id === vId);
      if (!vendor) return;

      const invoiceCount = store.invoices.filter((i) => i.vendorId === vId).length;
      if (invoiceCount === 0) {
        // Permanent delete
        store.vendors = store.vendors.filter((v) => v.id !== vId);
        deletedCount++;
      } else {
        // Archive
        vendor.status = 'ARCHIVED';
        vendor.archiveReason = reason || 'Bulk archive by Administrator';
        vendor.archivedAt = new Date().toISOString();
        vendor.archivedBy = adminUid || 'admin';
        archivedCount++;
      }
    });

    logServerAudit(
      adminUid || 'admin',
      'system',
      'ADMIN',
      'BULK_VENDOR_OPERATION',
      `Bulk vendor operation completed: ${deletedCount} permanently deleted (0 history), ${archivedCount} archived (has GST history). Reason: ${reason || 'N/A'}`
    );
    saveStore();

    return res.status(200).json({ success: true, deletedCount, archivedCount });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ADMIN: Approve / Reject Vendor Master Registration
 */
apiRouter.post('/api/admin/vendors/approve/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const vendor = store.vendors.find((v) => v.id === id);
  if (!vendor) return res.status(404).json({ error: 'Vendor not found' });
  vendor.status = 'ACTIVE';
  vendor.updatedAt = new Date().toISOString();
  saveStore();
  return res.status(200).json({ success: true, vendor });
});

apiRouter.post('/api/admin/vendors/reject/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const vendor = store.vendors.find((v) => v.id === id);
  if (!vendor) return res.status(404).json({ error: 'Vendor not found' });
  vendor.status = 'REJECTED';
  vendor.updatedAt = new Date().toISOString();
  saveStore();
  return res.status(200).json({ success: true, vendor });
});

/**
 * ============================================================================
 * INVOICES & CLARIFICATION QUERIES REST API (Single source of truth)
 * ============================================================================
 */

// GET all invoices (or filtered by vendorId)
apiRouter.get('/api/invoices', (req: Request, res: Response) => {
  try {
    const { vendorId } = req.query;
    if (vendorId && typeof vendorId === 'string') {
      const filtered = store.invoices.filter((i) => i.vendorId === vendorId);
      return res.status(200).json(filtered);
    }
    return res.status(200).json(store.invoices);
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

// GET single invoice by id
apiRouter.get('/api/invoices/:id', (req: Request, res: Response) => {
  const { id } = req.params;
  const invoice = store.invoices.find((i) => i.id === id);
  if (!invoice) return res.status(404).json({ error: 'Invoice not found' });
  return res.status(200).json(invoice);
});

// POST save / submit invoice
apiRouter.post('/api/invoices', (req: Request, res: Response) => {
  try {
    const { invoice, auditRemark, userEmail } = req.body;
    if (!invoice || !invoice.invoiceNumber) {
      return res.status(400).json({ error: 'Invoice with valid invoiceNumber is required' });
    }

    const nowIso = new Date().toISOString();
    const invoiceId = invoice.id || `inv_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
    const prepared: InvoiceRecord = {
      ...invoice,
      id: invoiceId,
      status: invoice.status || 'UNDER_REVIEW',
      createdAt: invoice.createdAt || nowIso,
      updatedAt: nowIso,
    };

    const existingIndex = store.invoices.findIndex(
      (i) => i.id === prepared.id || (i.invoiceNumber === prepared.invoiceNumber && i.vendorId === prepared.vendorId)
    );

    if (existingIndex >= 0) {
      store.invoices[existingIndex] = {
        ...store.invoices[existingIndex],
        ...prepared,
        id: store.invoices[existingIndex].id, // preserve original id
        updatedAt: nowIso,
      };
    } else {
      store.invoices.unshift(prepared);
    }

    saveStore();

    logServerAudit(
      prepared.submittedByUid || 'vendor',
      userEmail || 'vendor',
      'VENDOR',
      'SAVE_INVOICE',
      auditRemark || `Invoice ${prepared.invoiceNumber} saved. Status: ${prepared.status}`,
      prepared.id
    );

    return res.status(200).json({ success: true, invoice: prepared });
  } catch (error: any) {
    console.error('Save Invoice Error:', error);
    return res.status(500).json({ error: error.message });
  }
});

// PATCH update invoice status & approval
apiRouter.patch('/api/invoices/:id/status', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const {
      newStatus,
      remarks,
      reviewedByUid,
      reviewedByName,
      overrideReason,
      rejectionReason,
      extraFields,
      userEmail,
    } = req.body;

    const invoice = store.invoices.find((i) => i.id === id);
    if (!invoice) return res.status(404).json({ error: 'Invoice not found' });

    const oldStatus = invoice.status;

    // Enforce locked posted-state restrictions: cannot update TDS on POSTED invoices
    if (oldStatus === 'POSTED') {
      const isAttemptingTdsUpdate =
        extraFields &&
        typeof extraFields === 'object' &&
        (extraFields.tdsSection !== undefined ||
          extraFields.tdsRate !== undefined ||
          extraFields.tdsAmount !== undefined ||
          extraFields.netPayableAmount !== undefined ||
          extraFields.tdsGlAccount !== undefined ||
          extraFields.noTdsReason !== undefined);

      if (isAttemptingTdsUpdate) {
        return res.status(403).json({
          error: 'Invoice is locked after Tally posting. Updating TDS is prohibited for POSTED invoices.',
        });
      }
    }

    invoice.status = newStatus;
    invoice.updatedAt = new Date().toISOString();

    if (reviewedByUid) invoice.reviewedByUid = reviewedByUid;
    if (reviewedByName) invoice.reviewedByName = reviewedByName;
    if (overrideReason) {
      invoice.overrideReason = overrideReason;
      invoice.overriddenBy = reviewedByName;
    }
    if (rejectionReason) invoice.rejectionReason = rejectionReason;
    if (extraFields && typeof extraFields === 'object') {
      Object.assign(invoice, extraFields);
    }

    // If transitioning to RESUBMITTED or UNDER_REVIEW, automatically resolve any open clarification queries
    if (newStatus === 'RESUBMITTED' || newStatus === 'UNDER_REVIEW') {
      if (Array.isArray(store.queries)) {
        store.queries.forEach((q) => {
          if (q.invoiceId === id && q.status === 'OPEN') {
            q.status = 'RESOLVED';
          }
        });
      }
    }

    saveStore();

    logServerAudit(
      reviewedByUid || 'accounts_user',
      userEmail || 'accounts',
      'ACCOUNTS_EXECUTIVE',
      `TRANSITION_TO_${newStatus}`,
      remarks || `Status transitioned from ${oldStatus} to ${newStatus}`,
      id
    );

    return res.status(200).json({ success: true, invoice });
  } catch (error: any) {
    console.error('Update Invoice Status Error:', error);
    return res.status(500).json({ error: error.message });
  }
});

// POST resolve clarification query & resubmit invoice
apiRouter.post('/api/invoices/:id/resolve-query', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { queryId, resolutionMessage, userUid, userName, userRole, userEmail } = req.body || {};

    const invoice = store.invoices.find((i) => i.id === id);
    if (!invoice) return res.status(404).json({ error: 'Invoice not found' });

    // Mark query as resolved
    store.queries = store.queries || [];
    let resolvedCount = 0;
    store.queries.forEach((q) => {
      if (q.invoiceId === id || (queryId && q.id === queryId)) {
        q.status = 'RESOLVED';
        resolvedCount++;
      }
    });

    // Update invoice status to RESUBMITTED
    const oldStatus = invoice.status;
    invoice.status = 'RESUBMITTED';
    invoice.updatedAt = new Date().toISOString();

    // Add resolution message to thread
    const messageText = resolutionMessage?.trim() || 'Vendor resolved queries and resubmitted invoice to Accounts Review.';
    const newMsg: ThreadMessage = {
      id: `m_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      queryId: queryId || (store.queries.find((q) => q.invoiceId === id)?.id),
      invoiceId: id,
      senderUid: userUid || 'vendor_user',
      senderRole: userRole || 'VENDOR',
      senderName: userName || 'Vendor Representative',
      message: messageText,
      createdAt: new Date().toISOString(),
    };
    store.messages = store.messages || [];
    store.messages.push(newMsg);

    saveStore();

    logServerAudit(
      userUid || 'vendor',
      userEmail || 'vendor',
      userRole || 'VENDOR',
      'RESOLVE_AND_RESUBMIT',
      `Clarification marked resolved and invoice ${invoice.invoiceNumber} resubmitted to Accounts Review.`,
      id
    );

    return res.status(200).json({
      success: true,
      invoice,
      resolvedQueriesCount: resolvedCount,
      message: newMsg,
    });
  } catch (error: any) {
    console.error('Resolve and Resubmit Error:', error);
    return res.status(500).json({ error: error.message });
  }
});

// DELETE single invoice by id (Available to vendor or admin)
apiRouter.delete('/api/invoices/:id', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const { reason, userEmail, userRole, userUid } = req.body || {};

    const index = store.invoices.findIndex((i) => i.id === id);
    if (index === -1) {
      return res.status(404).json({ error: 'Invoice not found' });
    }

    const targetInvoice = store.invoices[index];

    // Remove invoice
    store.invoices.splice(index, 1);

    // Remove associated queries and messages
    store.queries = (store.queries || []).filter((q) => q.invoiceId !== id);
    store.messages = (store.messages || []).filter((m) => m.invoiceId !== id);

    saveStore();

    logServerAudit(
      userUid || 'vendor_user',
      userEmail || targetInvoice.submittedByName || 'vendor',
      userRole || 'VENDOR',
      'DELETE_INVOICE',
      reason || `Deleted invoice ${targetInvoice.invoiceNumber} (Total: ₹${targetInvoice.invoiceTotal})`,
      id
    );

    return res.status(200).json({
      success: true,
      message: `Invoice ${targetInvoice.invoiceNumber} deleted successfully`,
      deletedInvoiceId: id,
    });
  } catch (error: any) {
    console.error('Delete Invoice Error:', error);
    return res.status(500).json({ error: error.message });
  }
});

// GET clarification queries
apiRouter.get('/api/queries', (req: Request, res: Response) => {
  try {
    const { invoiceId, vendorId } = req.query;
    let list = store.queries || [];
    if (invoiceId && typeof invoiceId === 'string') {
      list = list.filter((q) => q.invoiceId === invoiceId);
    }
    if (vendorId && typeof vendorId === 'string') {
      list = list.filter((q) => q.vendorId === vendorId);
    }
    return res.status(200).json(list);
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

// POST create clarification query
apiRouter.post('/api/queries', (req: Request, res: Response) => {
  try {
    const queryData = req.body;
    if (!queryData.invoiceId || !queryData.queryText) {
      return res.status(400).json({ error: 'Missing invoiceId or queryText' });
    }

    const newQuery: ClarificationQuery = {
      ...queryData,
      id: queryData.id || `q_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      status: queryData.status || 'OPEN',
      isEscalated: Boolean(queryData.isEscalated),
      createdAt: new Date().toISOString(),
    };

    store.queries = store.queries || [];
    store.queries.unshift(newQuery);

    // Also update invoice status to CLARIFICATION_REQUESTED
    const invoice = store.invoices.find((i) => i.id === newQuery.invoiceId);
    if (invoice && invoice.status !== 'CLARIFICATION_REQUESTED') {
      invoice.status = 'CLARIFICATION_REQUESTED';
      invoice.updatedAt = new Date().toISOString();
    }

    saveStore();

    logServerAudit(
      newQuery.raisedByUid || 'accounts',
      req.body.userEmail || 'accounts',
      'ACCOUNTS_EXECUTIVE',
      'RAISE_CLARIFICATION_QUERY',
      `Clarification query raised on invoice ${newQuery.invoiceId}: ${newQuery.queryText}`,
      newQuery.invoiceId
    );

    return res.status(200).json({ success: true, query: newQuery });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

// GET messages for a query or invoice
apiRouter.get('/api/queries/:id/messages', (req: Request, res: Response) => {
  const { id } = req.params;
  const list = (store.messages || []).filter((m) => m.queryId === id || m.invoiceId === id);
  return res.status(200).json(list);
});

// POST message to thread
apiRouter.post('/api/queries/:id/messages', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    const msgData = req.body;
    const newMsg: ThreadMessage = {
      ...msgData,
      id: `m_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      queryId: id,
      createdAt: new Date().toISOString(),
    };

    store.messages = store.messages || [];
    store.messages.push(newMsg);
    saveStore();

    return res.status(200).json({ success: true, message: newMsg });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * Server-side Gemini Multimodal OCR Endpoint
 * Supports both /api/ocr and /api/ocr/extract-invoice
 * Normalizes extracted fields to camelCase for VendorUploadModal and preserves raw data
 */
async function handleOcrExtraction(req: Request, res: Response) {
  try {
    const fileBase64 = req.body.fileBase64 || req.body.file_base64 || req.body.data;
    const mimeType = req.body.fileType || req.body.mimeType || req.body.contentType || 'application/pdf';
    const modelName = req.body.defaultModelName || req.body.modelName || store.companySettings.defaultModelName || 'gemini-3.8-flash';
    const userEmail = req.body.userEmail;

    if (!fileBase64) {
      return res.status(400).json({
        success: false,
        error: 'Missing fileBase64 data in request body',
      });
    }

    if (userEmail) {
      const user = store.users.find((u) => u.email.toLowerCase() === String(userEmail).toLowerCase());
      if (user && user.status === 'DEACTIVATED') {
        return res.status(403).json({ success: false, error: 'Account is deactivated' });
      }
    }

    const ocrResult = await performInvoiceOcr(
      fileBase64,
      mimeType,
      modelName,
      req.body.vendorGstin,
      req.body.buyerGstin || store.companySettings.gstin
    );

    // Map line items to InvoiceLineItem interface expected by VendorUploadModal
    const mappedLineItems = (ocrResult.line_items || []).map((item, idx) => {
      const taxable = Number(item.taxable_value || 0);
      const cgst = Number(item.cgst_amount || 0);
      const sgst = Number(item.sgst_amount || 0);
      const igst = Number(item.igst_amount || 0);
      const cess = Number(item.cess_amount || 0);
      const computedTotal = taxable + cgst + sgst + igst + cess;

      return {
        id: `li_${Date.now()}_${idx + 1}`,
        itemNumber: Number(item.item_number || idx + 1),
        description: item.description || `Line Item #${idx + 1}`,
        hsnSac: String(item.hsn_sac || '').trim() || '847130',
        quantity: Number(item.quantity || 1),
        uom: String(item.uom || 'NOS').trim().toUpperCase(),
        rate: Number(item.rate || (item.quantity ? taxable / item.quantity : taxable)),
        discount: Number(item.discount || 0),
        taxableValue: taxable,
        cgstRate: Number(item.cgst_rate || 0),
        cgstAmount: cgst,
        sgstRate: Number(item.sgst_rate || 0),
        sgstAmount: sgst,
        igstRate: Number(item.igst_rate || 0),
        igstAmount: igst,
        cessAmount: cess,
        total: computedTotal > 0 ? computedTotal : taxable,
      };
    });

    // Normalize place of supply (e.g. "27-Maharashtra" -> "27 - Maharashtra")
    let normalizedPlaceOfSupply = ocrResult.place_of_supply || '27 - Maharashtra';
    if (/^\d{2}/.test(normalizedPlaceOfSupply) && !normalizedPlaceOfSupply.includes(' - ')) {
      const stateCode = normalizedPlaceOfSupply.slice(0, 2);
      const stateName = normalizedPlaceOfSupply.replace(/^\d{2}[-\s]*/, '').trim();
      normalizedPlaceOfSupply = `${stateCode} - ${stateName || 'Maharashtra'}`;
    }

    return res.status(200).json({
      success: true,
      data: ocrResult,
      // Top-level properties directly populated in VendorUploadModal.tsx:
      invoiceNumber: ocrResult.invoice_number || '',
      invoiceDate: ocrResult.invoice_date || new Date().toISOString().slice(0, 10),
      financialYear: ocrResult.financial_year || '',
      poReference: ocrResult.po_reference || '',
      placeOfSupply: normalizedPlaceOfSupply,
      isReverseCharge: Boolean(ocrResult.reverse_charge),
      narration: ocrResult.narration || '',
      lineItems: mappedLineItems,
      totalTaxableValue: Number(ocrResult.total_taxable_value || 0),
      totalCgst: Number(ocrResult.total_cgst || 0),
      totalSgst: Number(ocrResult.total_sgst || 0),
      totalIgst: Number(ocrResult.total_igst || 0),
      totalCess: Number(ocrResult.total_cess || 0),
      roundOff: Number(ocrResult.round_off || 0),
      invoiceTotal: Number(ocrResult.invoice_total || 0),
      isMultipleInvoicesDetected: Boolean(ocrResult.is_multi_invoice_detected),
      multipleInvoicesWarning: ocrResult.is_multi_invoice_detected
        ? `Multiple invoices detected in file (${ocrResult.detected_invoice_count || '2+'}). Extracted primary invoice.`
        : null,
      tokensUsed: ocrResult.token_usage || null,
      confidenceByField: ocrResult.confidence_by_field || {},
      warnings: ocrResult.warnings || [],
    });
  } catch (error: any) {
    console.error('OCR API Error:', error);
    return res.status(500).json({
      success: false,
      error: error.message || 'Invoice OCR processing failed',
    });
  }
}

apiRouter.post('/api/ocr', handleOcrExtraction);
apiRouter.post('/api/ocr/extract-invoice', handleOcrExtraction);

/**
 * Company Settings REST Endpoints
 */
apiRouter.get('/api/company-settings', (req: Request, res: Response) => {
  return res.status(200).json(store.companySettings);
});

apiRouter.post('/api/company-settings', (req: Request, res: Response) => {
  try {
    const newSettings = req.body;
    if (!newSettings || typeof newSettings !== 'object') {
      return res.status(400).json({ error: 'Settings object is required' });
    }

    const prevKey = store.companySettings.geminiApiKey;
    store.companySettings = {
      ...store.companySettings,
      ...newSettings,
      updatedAt: new Date().toISOString(),
    };

    if (newSettings.geminiApiKey !== undefined) {
      setCustomGeminiKey(newSettings.geminiApiKey);
    }

    saveStore();

    logServerAudit(
      req.body.adminUid || 'admin',
      req.body.userEmail || 'admin',
      'ADMIN',
      'UPDATE_COMPANY_SETTINGS',
      `Updated company settings (Legal Name: "${store.companySettings.legalName}", GSTIN: ${store.companySettings.gstin}, Model: ${store.companySettings.defaultModelName}).`
    );

    return res.status(200).json({ success: true, companySettings: store.companySettings });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * Gemini AI Configuration & Verification Endpoints
 */
apiRouter.get('/api/admin/gemini-config', (req: Request, res: Response) => {
  const effectiveKey = getEffectiveGeminiKey();
  const hasCustomKey = Boolean(store.companySettings?.geminiApiKey);
  const hasEnvKey = Boolean(process.env.GEMINI_API_KEY);

  let maskedKey = '';
  if (store.companySettings?.geminiApiKey) {
    const k = store.companySettings.geminiApiKey.trim();
    maskedKey = k.length > 8 ? `${k.slice(0, 6)}••••••••${k.slice(-4)}` : '••••••••';
  } else if (process.env.GEMINI_API_KEY) {
    const k = process.env.GEMINI_API_KEY.trim();
    maskedKey = k.length > 8 ? `${k.slice(0, 6)}••••••••${k.slice(-4)}` : '••••••••';
  }

  return res.status(200).json({
    configured: Boolean(effectiveKey),
    source: hasCustomKey ? 'CUSTOM' : (hasEnvKey ? 'ENV' : 'NONE'),
    maskedKey,
    hasCustomKey,
    defaultModelName: store.companySettings?.defaultModelName || 'gemini-3.8-flash',
  });
});

apiRouter.post('/api/admin/gemini-test', async (req: Request, res: Response) => {
  try {
    const { geminiApiKey } = req.body;
    const testResult = await testGeminiKey(geminiApiKey);
    return res.status(testResult.success ? 200 : 400).json(testResult);
  } catch (error: any) {
    return res.status(500).json({ success: false, error: error.message });
  }
});

apiRouter.post('/api/admin/gemini-key', async (req: Request, res: Response) => {
  try {
    const { geminiApiKey, adminUid, userEmail } = req.body;
    const cleanKey = String(geminiApiKey || '').trim();

    if (!cleanKey) {
      return res.status(400).json({ error: 'Gemini API key is required. To remove, use the clear option.' });
    }

    // Validate the key first by attempting a test call
    const testResult = await testGeminiKey(cleanKey);
    if (!testResult.success) {
      return res.status(400).json({
        error: `Gemini API key test failed: ${testResult.error || 'Invalid API Key'}. Please check that your key is valid and has Gemini API enabled in Google AI Studio / Google Cloud.`,
      });
    }

    // Save key
    store.companySettings.geminiApiKey = cleanKey;
    store.companySettings.updatedAt = new Date().toISOString();
    setCustomGeminiKey(cleanKey);
    saveStore();

    logServerAudit(
      adminUid || 'admin',
      userEmail || 'admin',
      'ADMIN',
      'CONFIGURED_GEMINI_API_KEY',
      `Custom Gemini API key configured and validated successfully (Masked: ${cleanKey.slice(0, 6)}...${cleanKey.slice(-4)}).`
    );

    const maskedKey = cleanKey.length > 8 ? `${cleanKey.slice(0, 6)}••••••••${cleanKey.slice(-4)}` : '••••••••';
    return res.status(200).json({
      success: true,
      message: 'Gemini API key saved and validated successfully!',
      maskedKey,
      source: 'CUSTOM',
    });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

apiRouter.post('/api/admin/gemini-key/remove', (req: Request, res: Response) => {
  try {
    const { adminUid, userEmail } = req.body;
    store.companySettings.geminiApiKey = undefined;
    store.companySettings.updatedAt = new Date().toISOString();
    setCustomGeminiKey(null);
    saveStore();

    logServerAudit(
      adminUid || 'admin',
      userEmail || 'admin',
      'ADMIN',
      'REMOVED_CUSTOM_GEMINI_KEY',
      `Custom Gemini API key removed. Falling back to server environment variables if available.`
    );

    const fallbackEffective = getEffectiveGeminiKey();
    return res.status(200).json({
      success: true,
      message: 'Custom Gemini API key cleared.',
      configured: Boolean(fallbackEffective),
      source: fallbackEffective ? 'ENV' : 'NONE',
    });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * ============================================================================
 * REAL-TIME GSTIN VALIDATION ENDPOINTS (https://gstin.cloud/api/v1/verify)
 * ============================================================================
 */

// Verification query called automatically when an invoice is opened
apiRouter.post('/api/gstin/verify', async (req: Request, res: Response) => {
  try {
    const { gstin, vendorId } = req.body;
    if (!gstin) {
      return res.status(400).json({ error: 'GSTIN is required for real-time verification.' });
    }

    const cleanGstin = String(gstin).trim().toUpperCase();
    const vendor = vendorId ? store.vendors.find((v) => v.id === vendorId || v.gstin === cleanGstin) : store.vendors.find((v) => v.gstin === cleanGstin);

    const vendorHint = vendor
      ? { legalName: vendor.legalName, tradeName: vendor.tradeName, address: vendor.address }
      : undefined;

    const apiKey = store.companySettings?.gstinCloudApiKey || process.env.GSTIN_CLOUD_API_KEY;
    const verification = await verifyGstinLive(cleanGstin, apiKey, vendorHint);

    return res.status(200).json({
      success: true,
      verification,
    });
  } catch (error: any) {
    console.error('GSTIN verification error:', error);
    return res.status(500).json({ error: error.message || 'GSTIN verification failed' });
  }
});

// Admin Configuration for gstin.cloud API key
apiRouter.get('/api/admin/gstin-config', (req: Request, res: Response) => {
  const customKey = store.companySettings?.gstinCloudApiKey;
  const envKey = process.env.GSTIN_CLOUD_API_KEY;
  const effectiveKey = customKey || envKey;

  let maskedKey = '';
  if (customKey) {
    const k = customKey.trim();
    maskedKey = k.length > 8 ? `${k.slice(0, 4)}••••••••${k.slice(-4)}` : '••••••••';
  } else if (envKey) {
    const k = envKey.trim();
    maskedKey = k.length > 8 ? `${k.slice(0, 4)}••••••••${k.slice(-4)}` : '••••••••';
  }

  return res.status(200).json({
    configured: Boolean(effectiveKey),
    source: customKey ? 'CUSTOM' : (envKey ? 'ENV' : 'NONE'),
    maskedKey,
    hasCustomKey: Boolean(customKey),
  });
});

// Test connection to gstin.cloud API
apiRouter.post('/api/admin/gstin-test', async (req: Request, res: Response) => {
  try {
    const keyToTest = req.body.apiKey || req.body.gstinCloudApiKey || store.companySettings?.gstinCloudApiKey || process.env.GSTIN_CLOUD_API_KEY;
    if (!keyToTest) {
      return res.status(400).json({ success: false, message: 'No x-api-key provided or configured for gstin.cloud.' });
    }
    const result = await testGstinCloudKey(keyToTest);
    return res.status(result.success ? 200 : 400).json(result);
  } catch (error: any) {
    return res.status(500).json({ success: false, message: error.message });
  }
});

// Save gstin.cloud x-api-key
apiRouter.post('/api/admin/gstin-key', async (req: Request, res: Response) => {
  try {
    const { apiKey, gstinCloudApiKey, adminUid, userEmail } = req.body;
    const cleanKey = String(apiKey || gstinCloudApiKey || '').trim();

    if (!cleanKey) {
      return res.status(400).json({ error: 'x-api-key is required.' });
    }

    store.companySettings.gstinCloudApiKey = cleanKey;
    store.companySettings.updatedAt = new Date().toISOString();
    saveStore();

    logServerAudit(
      adminUid || 'admin',
      userEmail || 'admin',
      'ADMIN',
      'CONFIGURED_GSTIN_CLOUD_KEY',
      `Configured and saved gstin.cloud x-api-key for real-time statutory GSTIN verification.`
    );

    const maskedKey = cleanKey.length > 8 ? `${cleanKey.slice(0, 4)}••••••••${cleanKey.slice(-4)}` : '••••••••';
    return res.status(200).json({
      success: true,
      message: 'gstin.cloud x-api-key saved and activated successfully!',
      maskedKey,
      source: 'CUSTOM',
    });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

// Remove custom gstin.cloud key
apiRouter.post('/api/admin/gstin-key/remove', (req: Request, res: Response) => {
  try {
    const { adminUid, userEmail } = req.body;
    store.companySettings.gstinCloudApiKey = undefined;
    store.companySettings.updatedAt = new Date().toISOString();
    saveStore();

    logServerAudit(
      adminUid || 'admin',
      userEmail || 'admin',
      'ADMIN',
      'REMOVED_GSTIN_CLOUD_KEY',
      `Custom gstin.cloud API key removed.`
    );

    const fallbackEffective = Boolean(process.env.GSTIN_CLOUD_API_KEY);
    return res.status(200).json({
      success: true,
      message: 'Custom gstin.cloud x-api-key removed.',
      configured: fallbackEffective,
      source: fallbackEffective ? 'ENV' : 'NONE',
    });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * GST Validation Service Endpoint
 */
apiRouter.post('/api/validate-gst', (req: Request, res: Response) => {
  try {
    const { invoice, vendor, company, existingInvoices } = req.body;
    const result = runGSTValidationEngine(
      invoice || {},
      vendor || null,
      company || store.companySettings,
      undefined,
      existingInvoices || store.invoices
    );
    return res.status(200).json(result);
  } catch (error: any) {
    console.error('GST Validation API Error:', error);
    return res.status(500).json({ error: error.message || 'GST validation failed' });
  }
});

/**
 * Tally XML Generation Preview Endpoint
 */
apiRouter.post('/api/tally/preview-xml', (req: Request, res: Response) => {
  try {
    const { invoice, ledgerMappings, companyName } = req.body;
    if (!invoice) return res.status(400).json({ error: 'Invoice record is required' });
    const result = generateTallyPurchaseXml(invoice, ledgerMappings || [], companyName || store.companySettings.legalName);
    return res.status(200).json(result);
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * Tally XML Download Endpoint (Manual Fallback)
 */
apiRouter.post('/api/tally/download-xml', (req: Request, res: Response) => {
  try {
    const { invoice, ledgerMappings, companyName } = req.body;
    if (!invoice) return res.status(400).json({ error: 'Invoice data required' });

    // Enforce locked posted-state restrictions: cannot download XML for POSTED invoices
    const isPostedInStore = store.invoices.some(
      (i) =>
        (i.id === invoice.id ||
          (i.invoiceNumber === invoice.invoiceNumber && i.vendorGstin === invoice.vendorGstin)) &&
        i.status === 'POSTED'
    );
    if (invoice.status === 'POSTED' || isPostedInStore) {
      return res.status(403).json({
        error: 'Invoice is locked after Tally posting. XML download is disabled for POSTED invoices.',
      });
    }

    const result = generateTallyPurchaseXml(invoice, ledgerMappings || [], companyName || store.companySettings.legalName);
    const filename = `Tally_Purchase_${(invoice.invoiceNumber || 'Voucher').replace(/[^a-zA-Z0-9_-]/g, '_')}.xml`;

    res.setHeader('Content-Type', 'application/xml');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    return res.send(result.xml);
  } catch (error: any) {
    return res.status(500).send(`Error generating XML: ${error.message}`);
  }
});

/**
 * Tally Prime Ledger Mappings CRUD Endpoints
 */
apiRouter.get('/api/ledger-mappings', (req: Request, res: Response) => {
  return res.status(200).json(store.ledgerMappings || []);
});

apiRouter.post('/api/ledger-mappings', (req: Request, res: Response) => {
  try {
    const newRule = req.body as LedgerMappingRule;
    if (!newRule || !newRule.tallyLedgerName) {
      return res.status(400).json({ error: 'Missing mapping information or tallyLedgerName' });
    }
    store.ledgerMappings = store.ledgerMappings || [];
    const idx = store.ledgerMappings.findIndex((m) => m.id === newRule.id);
    if (idx >= 0) {
      store.ledgerMappings[idx] = { ...newRule, updatedAt: new Date().toISOString() };
    } else {
      store.ledgerMappings.push({
        ...newRule,
        id: newRule.id || `map_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        updatedAt: new Date().toISOString(),
      });
    }
    saveStore();
    return res.status(200).json({ success: true, ledgerMappings: store.ledgerMappings });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

apiRouter.delete('/api/ledger-mappings/:id', (req: Request, res: Response) => {
  try {
    const { id } = req.params;
    store.ledgerMappings = (store.ledgerMappings || []).filter((m) => m.id !== id);
    saveStore();
    return res.status(200).json({ success: true, ledgerMappings: store.ledgerMappings });
  } catch (error: any) {
    return res.status(500).json({ error: error.message });
  }
});

/**
 * Tally Agent Authentication Middleware
 */
function authenticateAgent(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({
      error: 'Unauthorized: Missing or invalid Bearer token header',
    });
  }

  const rawToken = authHeader.replace('Bearer ', '').trim();
  const tokenHash = hashAgentToken(rawToken);

  const matchedAgent = store.agents.find(
    (a) => a.tokenHash === tokenHash && !a.isRevoked
  );

  if (!matchedAgent) {
    return res.status(403).json({
      error: 'Forbidden: Agent token is invalid, revoked, or not registered',
    });
  }

  (req as any).agent = matchedAgent;
  next();
}

/**
 * Tally Agent API: GET /agent/invoices/pending
 */
apiRouter.get('/agent/invoices/pending', authenticateAgent, (req: Request, res: Response) => {
  const agent = (req as any).agent as TallyAgentRecord;
  agent.lastHeartbeat = new Date().toISOString();
  agent.status = 'ONLINE';

  const includeAll = req.query.all === 'true' || req.query.include_posted === 'true';
  const queryInvoice = req.query.invoice ? String(req.query.invoice).trim() : null;

  const pendingInvoices = store.invoices.filter((i) => {
    if (queryInvoice) {
      return (i.id === queryInvoice || i.invoiceNumber.toLowerCase() === queryInvoice.toLowerCase()) &&
        ['APPROVED', 'POSTED', 'POSTING_FAILED'].includes(i.status);
    }
    if (includeAll) {
      return ['APPROVED', 'POSTED', 'POSTING_FAILED'].includes(i.status);
    }
    return i.status === 'APPROVED';
  });

  const activeMappings = (store.ledgerMappings && store.ledgerMappings.length > 0) ? store.ledgerMappings : INITIAL_LEDGER_MAPPINGS;
  const pending = pendingInvoices.map((inv) => {
    const { xml } = generateTallyPurchaseXml(inv, activeMappings, agent.tallyCompany || store.companySettings.legalName);
    return {
      invoiceId: inv.id,
      invoiceNumber: inv.invoiceNumber,
      invoiceDate: inv.invoiceDate,
      vendorName: inv.vendorName,
      vendorGstin: inv.vendorGstin,
      invoiceTotal: inv.invoiceTotal,
      tallyXml: xml,
      status: inv.status,
    };
  });

  return res.status(200).json({
    success: true,
    count: pending.length,
    agentId: agent.agentId,
    invoices: pending,
  });
});

/**
 * Tally Agent API: POST /agent/invoices/:id/requeue
 * Resets status to APPROVED so it can be re-fetched and re-imported into Tally Prime
 */
apiRouter.post('/agent/invoices/:id/requeue', authenticateAgent, (req: Request, res: Response) => {
  const { id } = req.params;
  const invoice = store.invoices.find((i) => i.id === id || i.invoiceNumber.toLowerCase() === id.toLowerCase());
  if (!invoice) return res.status(404).json({ error: 'Invoice not found' });

  invoice.status = 'APPROVED';
  invoice.tallyVoucherGuid = undefined;
  invoice.tallyLastError = undefined;
  invoice.updatedAt = new Date().toISOString();
  saveStore();

  logServerAudit(
    (req as any).agent?.agentId || 'tally_agent',
    'system',
    'ADMIN',
    'REQUEUE_FOR_TALLY',
    `Invoice #${invoice.invoiceNumber} re-queued for Tally Prime Bridge Agent import`,
    invoice.id
  );

  return res.status(200).json({
    success: true,
    message: `Invoice #${invoice.invoiceNumber} status reset to APPROVED (Ready for Agent)`,
    invoice,
  });
});

/**
 * Tally Agent API: POST /agent/invoices/:id/result
 */
apiRouter.post('/agent/invoices/:id/result', authenticateAgent, (req: Request, res: Response) => {
  const { id } = req.params;
  const { status, tallyVoucherGuid, tallyVoucherNumber, errorMessage } = req.body;

  if (status !== 'POSTED' && status !== 'POSTING_FAILED') {
    return res.status(400).json({ error: "Invalid status: Expected 'POSTED' or 'POSTING_FAILED'" });
  }

  const invoice = store.invoices.find((i) => i.id === id);
  if (invoice) {
    if (status === 'POSTED') {
      invoice.status = 'POSTED';
      invoice.tallyVoucherGuid = tallyVoucherGuid || `TALLY-GUID-${Date.now()}`;
      invoice.tallyVoucherNumber = tallyVoucherNumber || invoice.invoiceNumber;
      invoice.tallyPostedAt = new Date().toISOString();
    } else {
      invoice.status = 'POSTING_FAILED';
      invoice.tallyLastError = errorMessage || 'Unknown Tally Prime XML error';
    }
    saveStore();
  }

  return res.status(200).json({
    success: true,
    invoiceId: id,
    status,
    updatedAt: new Date().toISOString(),
  });
});

/**
 * Tally Agent API: POST /agent/heartbeat
 */
apiRouter.post('/agent/heartbeat', authenticateAgent, (req: Request, res: Response) => {
  const agent = (req as any).agent as TallyAgentRecord;
  const { version, tallyCompany } = req.body;

  agent.lastHeartbeat = new Date().toISOString();
  agent.status = 'ONLINE';
  if (version) agent.version = version;
  if (tallyCompany) agent.tallyCompany = tallyCompany;
  saveStore();

  return res.status(200).json({
    success: true,
    agentId: agent.agentId,
    timestamp: agent.lastHeartbeat,
    status: 'ONLINE',
  });
});

/**
 * Admin Agent Management Endpoints
 */
apiRouter.get('/api/admin/agents', (req: Request, res: Response) => {
  return res.status(200).json(store.agents);
});

apiRouter.post('/api/admin/agents/create', (req: Request, res: Response) => {
  const { name, agentId, plainToken, tallyCompany } = req.body;
  if (!name || !plainToken) {
    return res.status(400).json({ error: 'Name and token are required' });
  }

  const generatedId = agentId || `AGENT_${Date.now()}`;
  const tokenHash = hashAgentToken(plainToken);
  const masked = plainToken.length > 8 ? `${plainToken.slice(0, 6)}...${plainToken.slice(-4)}` : '••••••••';

  const newAgent: TallyAgentRecord = {
    id: `agent_${Date.now()}`,
    agentId: generatedId,
    name,
    tokenHash,
    plainTokenMasked: masked,
    isRevoked: false,
    version: '1.0.0',
    tallyCompany: tallyCompany || store.companySettings.legalName,
    lastHeartbeat: undefined,
    status: 'OFFLINE',
    createdAt: new Date().toISOString(),
  };

  store.agents.push(newAgent);
  saveStore();
  return res.status(201).json(newAgent);
});

apiRouter.post('/api/admin/agents/:id/toggle-revoke', (req: Request, res: Response) => {
  const { id } = req.params;
  const agent = store.agents.find((a) => a.id === id);
  if (!agent) return res.status(404).json({ error: 'Agent not found' });
  agent.isRevoked = !agent.isRevoked;
  saveStore();
  return res.status(200).json(agent);
});

apiRouter.post('/api/sync-approved-invoices', (req: Request, res: Response) => {
  const { invoices } = req.body;
  if (Array.isArray(invoices)) {
    store.invoices = invoices;
    saveStore();
  }
  return res.status(200).json({ count: store.invoices.length });
});

/**
 * Reports Export to Excel (.xlsx)
 * Clean title: "GST Vendor Management System" without any marketing tagline.
 */
apiRouter.post('/api/reports/export', (req: Request, res: Response) => {
  try {
    const { invoices, auditLogs, vendors, requesterEmail } = req.body;
    let invList: InvoiceRecord[] = invoices || store.invoices;

    // Role scoping: if requester is vendor, filter to their vendor ID
    if (requesterEmail) {
      const user = store.users.find((u) => u.email.toLowerCase() === String(requesterEmail).toLowerCase());
      if (user?.role === 'VENDOR' && user.vendorId) {
        invList = invList.filter((i) => i.vendorId === user.vendorId);
      }
    }

    const wb = XLSX.utils.book_new();

    // 1. Ageing Report
    const now = Date.now();
    const ageingData = invList.map((inv) => {
      const invDate = inv.invoiceDate ? new Date(inv.invoiceDate).getTime() : now;
      const daysOld = Math.max(0, Math.floor((now - invDate) / (1000 * 60 * 60 * 24)));
      let bucket = '0-30 Days';
      if (daysOld > 90) bucket = '90+ Days';
      else if (daysOld > 60) bucket = '61-90 Days';
      else if (daysOld > 30) bucket = '31-60 Days';

      return {
        'Invoice ID': inv.id,
        'Invoice Number': inv.invoiceNumber,
        'Invoice Date': inv.invoiceDate,
        'Vendor Name': inv.vendorName,
        'Vendor GSTIN': inv.vendorGstin,
        Status: inv.status,
        'Total (INR)': inv.invoiceTotal,
        'Age (Days)': daysOld,
        'Ageing Bucket': bucket,
      };
    });
    const wsAgeing = XLSX.utils.json_to_sheet(ageingData);
    XLSX.utils.book_append_sheet(wb, wsAgeing, 'Invoice Ageing');

    // 2. Pending Clarifications
    const queryInvoices = invList.filter((i) => i.status === 'CLARIFICATION_REQUESTED');
    const queryData = queryInvoices.map((inv) => ({
      'Invoice Number': inv.invoiceNumber,
      'Vendor Name': inv.vendorName,
      'Vendor GSTIN': inv.vendorGstin,
      'Invoice Total': inv.invoiceTotal,
      'Submission Date': inv.createdAt?.slice(0, 10),
      Status: 'Awaiting Vendor Resubmission',
    }));
    const wsQueries = XLSX.utils.json_to_sheet(queryData);
    XLSX.utils.book_append_sheet(wb, wsQueries, 'Pending Clarifications');

    // 3. Tally Postings
    const tallyData = invList
      .filter((i) => ['POSTED', 'POSTING_FAILED', 'POSTING_TO_TALLY', 'APPROVED'].includes(i.status))
      .map((inv) => ({
        'Invoice Number': inv.invoiceNumber,
        'Vendor Name': inv.vendorName,
        'Invoice Total': inv.invoiceTotal,
        'Tally Status': inv.status,
        'Tally Voucher GUID': inv.tallyVoucherGuid || '-',
        'Tally Voucher Number': inv.tallyVoucherNumber || '-',
        'Tally Error Message': inv.tallyLastError || '-',
        'Posted At': inv.tallyPostedAt || '-',
      }));
    const wsTally = XLSX.utils.json_to_sheet(tallyData);
    XLSX.utils.book_append_sheet(wb, wsTally, 'Tally Postings');

    // 4. Vendor Summary
    const vendorSummaryMap: Record<string, { count: number; totalAmount: number; gstin: string; legalName: string }> = {};
    invList.forEach((inv) => {
      const vName = inv.vendorName || 'Unknown Vendor';
      if (!vendorSummaryMap[vName]) {
        vendorSummaryMap[vName] = { count: 0, totalAmount: 0, gstin: inv.vendorGstin, legalName: vName };
      }
      vendorSummaryMap[vName].count++;
      vendorSummaryMap[vName].totalAmount += inv.invoiceTotal || 0;
    });
    const vendorSummaryData = Object.values(vendorSummaryMap).map((v) => ({
      'Vendor Legal Name': v.legalName,
      'Vendor GSTIN': v.gstin,
      'Total Invoices': v.count,
      'Total Value (INR)': Number(v.totalAmount.toFixed(2)),
    }));
    const wsVendor = XLSX.utils.json_to_sheet(vendorSummaryData);
    XLSX.utils.book_append_sheet(wb, wsVendor, 'Vendor Summary');

    // 5. OCR Accuracy
    const ocrData = invList.map((inv) => ({
      'Invoice Number': inv.invoiceNumber,
      'Vendor GSTIN': inv.vendorGstin,
      'Overall OCR Confidence': `${Math.round((inv.ocrConfidence || 0.9) * 100)}%`,
      'Validation Status': inv.validationStatus,
    }));
    const wsOcr = XLSX.utils.json_to_sheet(ocrData);
    XLSX.utils.book_append_sheet(wb, wsOcr, 'OCR Accuracy');

    // 6. Overrides & Approvals
    const overrides = invList
      .filter((i) => Boolean(i.overrideReason) || i.status === 'APPROVED')
      .map((inv) => ({
        'Invoice Number': inv.invoiceNumber,
        'Vendor Name': inv.vendorName,
        'Invoice Total': inv.invoiceTotal,
        'Status': inv.status,
        'Overridden Reason': inv.overrideReason || 'Standard Approval (No Override)',
        'Reviewed By': inv.reviewedByName || inv.reviewedByUid || 'Accounts Team',
        'Updated At': inv.updatedAt,
      }));
    const wsOverrides = XLSX.utils.json_to_sheet(overrides);
    XLSX.utils.book_append_sheet(wb, wsOverrides, 'Overrides & Approvals');

    const buffer = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' });
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', 'attachment; filename="GST_Vendor_Management_System_Reports.xlsx"');
    return res.send(buffer);
  } catch (error: any) {
    console.error('Export Error:', error);
    return res.status(500).json({ error: error.message });
  }
});

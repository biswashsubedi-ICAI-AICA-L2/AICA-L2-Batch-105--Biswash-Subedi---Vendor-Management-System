/**
 * GST Vendor Management System (VMS)
 * Main Application Shell with Strict Authentication Gate & Role Routing
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext.tsx';
import { Header } from './components/Header.tsx';
import { LoginPage } from './components/Auth/LoginPage.tsx';
import { PendingApprovalScreen } from './components/Auth/PendingApprovalScreen.tsx';
import { NotAuthorizedScreen } from './components/Auth/NotAuthorizedScreen.tsx';
import { VendorDashboard } from './components/VendorPortal/VendorDashboard.tsx';
import { VendorUploadModal } from './components/VendorPortal/VendorUploadModal.tsx';
import { VendorMasterView } from './components/VendorPortal/VendorMasterView.tsx';
import { AccountsReviewScreen } from './components/AccountsReview/AccountsReviewScreen.tsx';
import { ClarificationThread } from './components/ClarificationLoop/ClarificationThread.tsx';
import { TallyAgentPanel } from './components/TallyIntegration/TallyAgentPanel.tsx';
import { AdminPanel } from './components/AdminPanel/AdminPanel.tsx';
import { ReportsDashboard } from './components/Reports/ReportsDashboard.tsx';
import { InvoiceRecord } from './types/index.ts';
import { Loader2 } from 'lucide-react';

const MainAppContent: React.FC = () => {
  const { currentUser, currentRole, isAuthenticated, isLoading, saveInvoice, invoices } = useAuth();

  // Navigation State
  const [activeTab, setActiveTab] = useState<string>('');
  const [selectedReviewInvoiceId, setSelectedReviewInvoiceId] = useState<string | undefined>(undefined);
  const [threadInvoice, setThreadInvoice] = useState<InvoiceRecord | null>(null);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [resubmitInvoice, setResubmitInvoice] = useState<InvoiceRecord | null>(null);

  // Set default workspace tab based on role upon login
  useEffect(() => {
    if (currentUser) {
      if (currentRole === 'VENDOR') {
        setActiveTab('vendor-dashboard');
      } else if (currentRole === 'ACCOUNTS_EXECUTIVE') {
        setActiveTab('accounts-review-queue');
      } else if (currentRole === 'ADMIN') {
        setActiveTab('admin-users');
      }
    }
  }, [currentUser?.uid, currentRole]);

  // Loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#F5F7FA] flex flex-col items-center justify-center space-y-3 text-[#52606D]">
        <Loader2 className="w-8 h-8 animate-spin text-[#1F4E9C]" />
        <p className="text-sm font-medium tracking-wide text-[#1F2933]">
          Verifying GST VMS Session...
        </p>
      </div>
    );
  }

  // 1. GATE: Root URL must show ONLY clean login page if not authenticated
  if (!isAuthenticated || !currentUser) {
    return (
      <LoginPage
        onLoginSuccess={() => {
          // Defaults handle tab navigation in useEffect
        }}
      />
    );
  }

  // 2. GATE: Pending user sees ONLY "Your access request is awaiting approval" page
  if (currentUser.status === 'PENDING_APPROVAL' || currentUser.role === 'PENDING') {
    return <PendingApprovalScreen />;
  }

  // Helper to determine if a view is permitted for the active role
  const isPermitted = (tab: string): boolean => {
    if (currentRole === 'ADMIN') return true;

    if (currentRole === 'VENDOR') {
      const allowed = ['vendor-dashboard', 'vendor-invoices', 'vendor-queries', 'vendor-master', 'clarification-thread'];
      return allowed.includes(tab);
    }

    if (currentRole === 'ACCOUNTS_EXECUTIVE') {
      const allowed = [
        'accounts-review-queue',
        'accounts-review',
        'tally-posting-status',
        'accounts-vendors',
        'reports',
        'clarification-thread',
      ];
      return allowed.includes(tab);
    }

    return false;
  };

  const handleSelectInvoiceForReview = (invoice: InvoiceRecord) => {
    setSelectedReviewInvoiceId(invoice.id);
    setActiveTab('accounts-review');
  };

  const handleOpenClarification = (invoice: InvoiceRecord) => {
    setThreadInvoice(invoice);
    setActiveTab('clarification-thread');
  };

  const defaultHomeTab =
    currentRole === 'VENDOR'
      ? 'vendor-dashboard'
      : currentRole === 'ACCOUNTS_EXECUTIVE'
      ? 'accounts-review-queue'
      : 'admin-users';

  return (
    <div className="min-h-screen bg-[#F5F7FA] text-[#1F2933] flex flex-col font-sans">
      {/* Header Navigation */}
      <Header
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setIsUploadModalOpen(false);
          setResubmitInvoice(null);
          setActiveTab(tab);
          if (tab !== 'clarification-thread') {
            setThreadInvoice(null);
          }
        }}
        onOpenUploadModal={() => {
          setResubmitInvoice(null);
          setIsUploadModalOpen(true);
        }}
      />

      {/* Main Workspace Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* Permission Guard */}
        {!isPermitted(activeTab) ? (
          <NotAuthorizedScreen onReturnHome={() => setActiveTab(defaultHomeTab)} />
        ) : (
          <>
            {/* VENDOR MODULES */}
            {(activeTab === 'vendor-dashboard' || activeTab === 'vendor-invoices' || activeTab === 'vendor-queries') && (
              <VendorDashboard
                onSelectInvoiceForReview={handleSelectInvoiceForReview}
                onOpenClarification={handleOpenClarification}
                onOpenUploadModal={(targetResubmit) => {
                  setResubmitInvoice(targetResubmit || null);
                  setIsUploadModalOpen(true);
                }}
              />
            )}

            {activeTab === 'vendor-master' && <VendorMasterView />}

            {/* ACCOUNTS EXECUTIVE MODULES */}
            {(activeTab === 'accounts-review-queue' || activeTab === 'accounts-review') && (
              <AccountsReviewScreen
                initialInvoiceId={selectedReviewInvoiceId}
                onOpenClarificationThread={handleOpenClarification}
              />
            )}

            {activeTab === 'accounts-vendors' && (
              <div className="space-y-4">
                <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-6 shadow-sm">
                  <h2 className="text-lg font-bold text-[#0B2545]">Vendor Directory</h2>
                  <p className="text-xs text-[#52606D]">
                    Accounts Executive directory of registered Indian GST vendors.
                  </p>
                </div>
                <AdminPanel initialTab="VENDORS" />
              </div>
            )}

            {activeTab === 'tally-posting-status' && <TallyAgentPanel />}

            {/* CLARIFICATION LOOP */}
            {activeTab === 'clarification-thread' && threadInvoice && (
              <ClarificationThread
                invoice={invoices.find((i) => i.id === threadInvoice.id) || threadInvoice}
                onBack={() => {
                  setActiveTab(currentRole === 'VENDOR' ? 'vendor-dashboard' : 'accounts-review-queue');
                  setThreadInvoice(null);
                }}
              />
            )}

            {/* TALLY BRIDGE AGENT (ADMIN & ACCOUNTS) */}
            {activeTab === 'tally-agent' && <TallyAgentPanel />}

            {/* ADMIN MODULES */}
            {activeTab === 'admin-users' && <AdminPanel initialTab="USERS" />}
            {activeTab === 'admin-vendors' && <AdminPanel initialTab="VENDORS" />}
            {activeTab === 'admin-settings' && <AdminPanel initialTab="SETTINGS" />}
            {activeTab === 'admin-audit' && <AdminPanel initialTab="AUDIT" />}

            {/* REPORTS */}
            {activeTab === 'reports' && <ReportsDashboard />}
          </>
        )}

      </main>

      {/* Global Vendor Upload Modal */}
      {isUploadModalOpen && (
        <VendorUploadModal
          isOpen={isUploadModalOpen}
          resubmitInvoice={resubmitInvoice}
          onClose={() => {
            setIsUploadModalOpen(false);
            setResubmitInvoice(null);
          }}
          onSuccess={(newInv) => {
            saveInvoice(
              newInv,
              resubmitInvoice
                ? `Resubmitted invoice version ${newInv.currentFileVersion}`
                : 'New invoice uploaded by vendor'
            );
            setIsUploadModalOpen(false);
            setResubmitInvoice(null);
          }}
        />
      )}

      {/* Footer */}
      <footer className="border-t border-[#D9E2EC] bg-white text-center py-4 text-xs text-[#52606D]">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>GST Vendor Management System</span>
          <span className="font-mono text-[11px] text-[#52606D]">
            Session: {currentUser.email} ({currentRole})
          </span>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainAppContent />
    </AuthProvider>
  );
}

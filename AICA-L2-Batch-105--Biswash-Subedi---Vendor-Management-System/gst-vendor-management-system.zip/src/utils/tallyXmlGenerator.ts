/**
 * Tally Prime XML Generator
 * Produces official Tally Prime Purchase Voucher XML compliant with Tally XML Request Envelope.
 * Supports:
 * - Idempotent Master Creation (Sundry Creditor with GSTIN, State, PAN)
 * - Purchase Voucher with Credit (Party Ledger), Debits (Purchase & Tax Ledgers, Round Off)
 * - Safe XML entity escaping and UTF-8 handling
 */

import { InvoiceRecord, LedgerMappingRule } from '../types/index.ts';
import { GST_STATE_CODES, extractStateName } from './gstUtils.ts';

export function escapeXml(str: string | number | undefined | null): string {
  if (str === undefined || str === null) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

/**
 * Strict date formatter for Tally Prime XML (YYYYMMDD).
 * Validates year, month, and day against the real calendar (including leap years).
 * Supports standard app date formats: ISO YYYY-MM-DD, ISO timestamp (YYYY-MM-DDTHH:mm:ss),
 * DD/MM/YYYY, DD-MM-YYYY, and YYYYMMDD.
 * Rejects invalid, missing, empty, or ambiguous dates.
 * Strictly does NOT substitute today's date.
 */
export function formatTallyDate(dateStr: string | null | undefined): string {
  if (!dateStr || typeof dateStr !== 'string') {
    throw new Error('Voucher date is required: invoice date is empty or missing.');
  }

  const trimmed = dateStr.trim();
  if (!trimmed) {
    throw new Error('Voucher date is required: invoice date is empty.');
  }

  // Strip ISO timestamp time portion if present (e.g. 2026-11-03T10:00:00.000Z)
  const cleanStr = trimmed.includes('T') ? trimmed.split('T')[0] : trimmed;

  let year: number;
  let month: number;
  let day: number;

  // Format 1: YYYY-MM-DD or YYYY/MM/DD
  const ymdMatch = cleanStr.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})$/);
  // Format 2: DD/MM/YYYY or DD-MM-YYYY
  const dmyMatch = cleanStr.match(/^(\d{1,2})[-/](\d{1,2})[-/](\d{4})$/);
  // Format 3: YYYYMMDD (exactly 8 digits)
  const compactMatch = cleanStr.match(/^(\d{4})(\d{2})(\d{2})$/);

  if (ymdMatch) {
    year = parseInt(ymdMatch[1], 10);
    month = parseInt(ymdMatch[2], 10);
    day = parseInt(ymdMatch[3], 10);
  } else if (dmyMatch) {
    day = parseInt(dmyMatch[1], 10);
    month = parseInt(dmyMatch[2], 10);
    year = parseInt(dmyMatch[3], 10);
  } else if (compactMatch) {
    year = parseInt(compactMatch[1], 10);
    month = parseInt(compactMatch[2], 10);
    day = parseInt(compactMatch[3], 10);
  } else {
    throw new Error(
      `Invalid invoice date format: "${dateStr}". Expected ISO date format (YYYY-MM-DD) or DD/MM/YYYY.`
    );
  }

  // Strict Calendar Validation
  if (isNaN(year) || isNaN(month) || isNaN(day)) {
    throw new Error(`Invalid invoice date numbers in "${dateStr}".`);
  }

  if (year < 1900 || year > 2100) {
    throw new Error(`Invoice year ${year} is outside valid range (1900-2100) in "${dateStr}".`);
  }

  if (month < 1 || month > 12) {
    throw new Error(`Invoice month ${month} is invalid (must be 1-12) in "${dateStr}".`);
  }

  const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  const daysInMonth = [31, isLeapYear ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDays = daysInMonth[month - 1];

  if (day < 1 || day > maxDays) {
    throw new Error(
      `Invoice day ${day} is invalid for month ${month}/${year} (max days: ${maxDays}) in "${dateStr}".`
    );
  }

  const pad = (n: number) => (n < 10 ? '0' + n : String(n));
  return `${year}${pad(month)}${pad(day)}`;
}

export function generateTallyPurchaseXml(
  invoice: InvoiceRecord,
  ledgerMappings: LedgerMappingRule[] = [],
  companyName: string = 'Demo Company'
): {
  xml: string;
  missingMappings: string[];
} {
  const missingMappings: string[] = [];

  // Determine Party Ledger Name
  const vendorMapping = ledgerMappings.find(
    (m) => m.mappingType === 'VENDOR' && m.matchKey === invoice.vendorId
  );
  const partyLedgerName = vendorMapping?.tallyLedgerName || invoice.vendorName || 'Sundry Creditor';

  // Determine Default Purchase Ledger
  const defaultPurchaseMapping = ledgerMappings.find(
    (m) => m.mappingType === 'HSN_SAC' && m.matchKey === 'DEFAULT'
  );
  const defaultPurchaseLedger = defaultPurchaseMapping?.tallyLedgerName || 'Purchase - GST';

  // Determine Tax Ledgers
  const cgstMapping = ledgerMappings.find(
    (m) => m.mappingType === 'TAX_HEAD' && m.matchKey === 'CGST'
  );
  const sgstMapping = ledgerMappings.find(
    (m) => m.mappingType === 'TAX_HEAD' && m.matchKey === 'SGST'
  );
  const igstMapping = ledgerMappings.find(
    (m) => m.mappingType === 'TAX_HEAD' && m.matchKey === 'IGST'
  );
  const roundOffMapping = ledgerMappings.find(
    (m) => m.mappingType === 'ROUND_OFF'
  );

  const cgstLedgerName = cgstMapping?.tallyLedgerName || 'Input CGST';
  const sgstLedgerName = sgstMapping?.tallyLedgerName || 'Input SGST';
  const igstLedgerName = igstMapping?.tallyLedgerName || 'Input IGST';
  const roundOffLedgerName = roundOffMapping?.tallyLedgerName || 'Round Off';

  // Check mandatory tax mapping if amount > 0
  if (invoice.totalCgst > 0 && !cgstMapping) {
    // If no mapping, record warning
  }
  if (invoice.totalSgst > 0 && !sgstMapping) {
    // If no mapping, record warning
  }
  if (invoice.totalIgst > 0 && !igstMapping) {
    // If no mapping, record warning
  }

  const tallyDate = formatTallyDate(invoice.invoiceDate);
  const tallyGuid = `VMS-${invoice.id}`;
  const supplierStateCode = invoice.vendorGstin ? invoice.vendorGstin.substring(0, 2) : '27';
  const supplierStateName = GST_STATE_CODES[supplierStateCode] || 'Maharashtra';
  const placeOfSupplyState = invoice.placeOfSupply ? extractStateName(invoice.placeOfSupply) : supplierStateName;

  // Build Party Ledger Idempotent Master creation (Sundry Creditor)
  const partyMasterXml = `
    <LEDGER NAME="${escapeXml(partyLedgerName)}" ACTION="Create">
      <NAME.LIST>
        <NAME>${escapeXml(partyLedgerName)}</NAME>
      </NAME.LIST>
      <PARENT>Sundry Creditors</PARENT>
      <ISBILLWISEON>Yes</ISBILLWISEON>
      <AFFECTSSTOCK>No</AFFECTSSTOCK>
      <LEDSTATENAME>${escapeXml(supplierStateName)}</LEDSTATENAME>
      <PARTYGSTIN>${escapeXml(invoice.vendorGstin)}</PARTYGSTIN>
      <GSTREGISTRATIONTYPE>Regular</GSTREGISTRATIONTYPE>
      <PANNUMBER>${escapeXml(invoice.vendorGstin ? invoice.vendorGstin.slice(2, 12) : '')}</PANNUMBER>
    </LEDGER>`;

  // Build Ledger Entries inside Voucher:
  // 1. Credit Party (Total Invoice Amount is Negative in Tally)
  // 2. Debit Line Purchases (Positive in Tally)
  // 3. Debit CGST/SGST or IGST (Positive in Tally)
  // 4. Debit/Credit Round Off

  const tdsDeduction = Number(invoice.tdsAmount || 0);
  const netPartyPayable = invoice.netPayableAmount !== undefined ? invoice.netPayableAmount : Math.max(0, invoice.invoiceTotal - tdsDeduction);
  const partyAmount = -Math.abs(Number((tdsDeduction > 0 ? netPartyPayable : invoice.invoiceTotal).toFixed(2)));

  // TDS Ledger Master and Voucher Entry
  // Priority: 1. Specifically chosen tdsGlAccount on invoice, 2. Tally Ledger Mapping rule for section, 3. 'TDS Payable' default
  const sectionKey = (invoice.tdsSection || '').trim();
  const tdsRule = ledgerMappings.find(
    (m) => m.mappingType === 'TDS' && (m.matchKey === sectionKey || m.matchKey === 'ALL_TDS' || m.matchKey === 'DEFAULT')
  );
  const tdsLedgerName = invoice.tdsGlAccount || tdsRule?.tallyLedgerName || 'TDS Payable';
  let tdsMasterXml = '';
  let tdsLedgerEntryXml = '';

  if (tdsDeduction > 0) {
    tdsMasterXml = `
    <LEDGER NAME="${escapeXml(tdsLedgerName)}" ACTION="Create">
      <NAME.LIST>
        <NAME>${escapeXml(tdsLedgerName)}</NAME>
      </NAME.LIST>
      <PARENT>Duties &amp; Taxes</PARENT>
      <ISBILLWISEON>No</ISBILLWISEON>
      <AFFECTSSTOCK>No</AFFECTSSTOCK>
      <TAXTYPE>TDS</TAXTYPE>
    </LEDGER>`;

    tdsLedgerEntryXml = `
            <!-- TDS Ledger Entry (Credit) under Duties & Taxes -->
            <ALLLEDGERENTRIES.LIST>
              <LEDGERNAME>${escapeXml(tdsLedgerName)}</LEDGERNAME>
              <ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>
              <LEDGERFROMITEM>No</LEDGERFROMITEM>
              <REMOVEZEROENTRIES>No</REMOVEZEROENTRIES>
              <ISPARTYLEDGER>No</ISPARTYLEDGER>
              <AMOUNT>${-Math.abs(Number(tdsDeduction.toFixed(2)))}</AMOUNT>
            </ALLLEDGERENTRIES.LIST>`;
  }

  let lineLedgerXml = '';
  // Aggregate lines by HSN or Ledger
  const hsnMap: Record<string, { taxable: number; ledgerName: string }> = {};

  if (invoice.lineItems && invoice.lineItems.length > 0) {
    invoice.lineItems.forEach((line) => {
      const hsnRule = ledgerMappings.find(
        (m) => m.mappingType === 'HSN_SAC' && m.matchKey === line.hsnSac
      );
      const ledger = hsnRule?.tallyLedgerName || defaultPurchaseLedger;
      if (!hsnMap[ledger]) {
        hsnMap[ledger] = { taxable: 0, ledgerName: ledger };
      }
      hsnMap[ledger].taxable += Number(line.taxableValue || 0);
    });

    for (const [ledgerName, item] of Object.entries(hsnMap)) {
      lineLedgerXml += `
      <ALLLEDGERENTRIES.LIST>
        <LEDGERNAME>${escapeXml(ledgerName)}</LEDGERNAME>
        <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
        <LEDGERFROMITEM>No</LEDGERFROMITEM>
        <REMOVEZEROENTRIES>No</REMOVEZEROENTRIES>
        <ISPARTYLEDGER>No</ISPARTYLEDGER>
        <AMOUNT>${Number(item.taxable.toFixed(2))}</AMOUNT>
      </ALLLEDGERENTRIES.LIST>`;
    }
  } else {
    lineLedgerXml += `
      <ALLLEDGERENTRIES.LIST>
        <LEDGERNAME>${escapeXml(defaultPurchaseLedger)}</LEDGERNAME>
        <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
        <LEDGERFROMITEM>No</LEDGERFROMITEM>
        <AMOUNT>${Number(invoice.totalTaxableValue.toFixed(2))}</AMOUNT>
      </ALLLEDGERENTRIES.LIST>`;
  }

  // Tax Entries
  let taxLedgersXml = '';
  if (invoice.totalCgst > 0) {
    taxLedgersXml += `
      <ALLLEDGERENTRIES.LIST>
        <LEDGERNAME>${escapeXml(cgstLedgerName)}</LEDGERNAME>
        <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
        <ISPARTYLEDGER>No</ISPARTYLEDGER>
        <AMOUNT>${Number(invoice.totalCgst.toFixed(2))}</AMOUNT>
      </ALLLEDGERENTRIES.LIST>`;
  }

  if (invoice.totalSgst > 0) {
    taxLedgersXml += `
      <ALLLEDGERENTRIES.LIST>
        <LEDGERNAME>${escapeXml(sgstLedgerName)}</LEDGERNAME>
        <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
        <ISPARTYLEDGER>No</ISPARTYLEDGER>
        <AMOUNT>${Number(invoice.totalSgst.toFixed(2))}</AMOUNT>
      </ALLLEDGERENTRIES.LIST>`;
  }

  if (invoice.totalIgst > 0) {
    taxLedgersXml += `
      <ALLLEDGERENTRIES.LIST>
        <LEDGERNAME>${escapeXml(igstLedgerName)}</LEDGERNAME>
        <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
        <ISPARTYLEDGER>No</ISPARTYLEDGER>
        <AMOUNT>${Number(invoice.totalIgst.toFixed(2))}</AMOUNT>
      </ALLLEDGERENTRIES.LIST>`;
  }

  if (invoice.totalCess > 0) {
    taxLedgersXml += `
      <ALLLEDGERENTRIES.LIST>
        <LEDGERNAME>Input GST Cess</LEDGERNAME>
        <ISDEEMEDPOSITIVE>Yes</ISDEEMEDPOSITIVE>
        <ISPARTYLEDGER>No</ISPARTYLEDGER>
        <AMOUNT>${Number(invoice.totalCess.toFixed(2))}</AMOUNT>
      </ALLLEDGERENTRIES.LIST>`;
  }

  let roundOffXml = '';
  if (invoice.roundOff && Math.abs(invoice.roundOff) > 0.001) {
    const isRoundOffPositive = invoice.roundOff > 0;
    roundOffXml = `
      <ALLLEDGERENTRIES.LIST>
        <LEDGERNAME>${escapeXml(roundOffLedgerName)}</LEDGERNAME>
        <ISDEEMEDPOSITIVE>${isRoundOffPositive ? 'Yes' : 'No'}</ISDEEMEDPOSITIVE>
        <ISPARTYLEDGER>No</ISPARTYLEDGER>
        <AMOUNT>${Number(invoice.roundOff.toFixed(2))}</AMOUNT>
      </ALLLEDGERENTRIES.LIST>`;
  }

  const ldcNarration = invoice.isLowerDeductionCertificate
    ? ` [Sec 197 Lower Deduction Cert #${invoice.lowerDeductionCertNumber || 'FORM 13'} @ ${invoice.tdsRate}%]`
    : (tdsDeduction > 0 ? ` [TDS u/s ${invoice.tdsSection || ''} @ ${invoice.tdsRate}%: Rs.${tdsDeduction.toFixed(2)}]` : '');

  const narration = invoice.narration
    ? `${invoice.narration} (VMS Inv #${invoice.invoiceNumber}, Supplier: ${invoice.vendorName}, GSTIN: ${invoice.vendorGstin})${ldcNarration}`
    : `Purchase against Supplier Invoice #${invoice.invoiceNumber} dt. ${invoice.invoiceDate} (GSTIN: ${invoice.vendorGstin})${ldcNarration}`;

  const fullXml = `<?xml version="1.0" encoding="UTF-8"?>
<ENVELOPE>
  <HEADER>
    <TALLYREQUEST>Import Data</TALLYREQUEST>
  </HEADER>
  <BODY>
    <IMPORTDATA>
      <REQUESTDESC>
        <REPORTNAME>Vouchers</REPORTNAME>
        <STATICVARIABLES>
          <SVCURRENTCOMPANY>${escapeXml(companyName)}</SVCURRENTCOMPANY>
        </STATICVARIABLES>
      </REQUESTDESC>
      <REQUESTDATA>
        <TALLYMESSAGE xmlns:UDF="TallyUDF">
          ${partyMasterXml}
          ${tdsMasterXml}
          <VOUCHER VCHTYPE="Purchase" ACTION="Create" OBJVIEW="Invoice Voucher View">
            <DATE>${tallyDate}</DATE>
            <GUID>${escapeXml(tallyGuid)}</GUID>
            <VOUCHERTYPENAME>Purchase</VOUCHERTYPENAME>
            <VOUCHERNUMBER>${escapeXml(invoice.invoiceNumber)}</VOUCHERNUMBER>
            <REFERENCE>${escapeXml(invoice.id)}</REFERENCE>
            <REFERENCEDATE>${tallyDate}</REFERENCEDATE>
            <PARTYLEDGERNAME>${escapeXml(partyLedgerName)}</PARTYLEDGERNAME>
            <PARTYNAME>${escapeXml(partyLedgerName)}</PARTYNAME>
            <BASICBUYERNAME>${escapeXml(invoice.buyerName || companyName)}</BASICBUYERNAME>
            <PLACEOFSUPPLY>${escapeXml(placeOfSupplyState)}</PLACEOFSUPPLY>
            <NARRATION>${escapeXml(narration)}</NARRATION>
            <EFFECTIVEDATE>${tallyDate}</EFFECTIVEDATE>
            <ISINVOICE>Yes</ISINVOICE>
            <PERSISTEDVIEW>Invoice Voucher View</PERSISTEDVIEW>
            
            <!-- Supplier Invoice Details -->
            <BASICPURCHASEORDERNO>${escapeXml(invoice.poReference || '')}</BASICPURCHASEORDERNO>
            <BILLOFLADINGNO>${escapeXml(invoice.invoiceNumber)}</BILLOFLADINGNO>
            <BILLOFLADINGDATE>${tallyDate}</BILLOFLADINGDATE>

            <!-- Party Ledger Entry (Credit) -->
            <ALLLEDGERENTRIES.LIST>
              <LEDGERNAME>${escapeXml(partyLedgerName)}</LEDGERNAME>
              <ISDEEMEDPOSITIVE>No</ISDEEMEDPOSITIVE>
              <LEDGERFROMITEM>No</LEDGERFROMITEM>
              <REMOVEZEROENTRIES>No</REMOVEZEROENTRIES>
              <ISPARTYLEDGER>Yes</ISPARTYLEDGER>
              <AMOUNT>${partyAmount}</AMOUNT>
              <BILLALLOCATIONS.LIST>
                <NAME>${escapeXml(invoice.invoiceNumber)}</NAME>
                <BILLTYPE>New Ref</BILLTYPE>
                <AMOUNT>${partyAmount}</AMOUNT>
              </BILLALLOCATIONS.LIST>
            </ALLLEDGERENTRIES.LIST>

            ${tdsLedgerEntryXml}

            <!-- Expense / Purchase Ledger Entries (Debit) -->
            ${lineLedgerXml}

            <!-- Tax Head Entries (Debit) -->
            ${taxLedgersXml}

            <!-- Round Off Entry -->
            ${roundOffXml}
          </VOUCHER>
        </TALLYMESSAGE>
      </REQUESTDATA>
    </IMPORTDATA>
  </BODY>
</ENVELOPE>`;

  const fullXmlTrimmed = fullXml.trim();
  // Strict XML Validation before returning: blocks export/posting if invalid
  validateTallyPurchaseXml(fullXmlTrimmed, invoice.invoiceNumber);

  return {
    xml: fullXmlTrimmed,
    missingMappings,
  };
}

/**
 * Strict validator for generated Tally Purchase Voucher XML.
 * Requires:
 * - Matching voucher view attributes: OBJVIEW="Invoice Voucher View", <PERSISTEDVIEW>Invoice Voucher View</PERSISTEDVIEW>, <ISINVOICE>Yes</ISINVOICE>
 * - Exactly one valid 8-digit voucher date in <DATE>YYYYMMDD</DATE>
 * - Expected voucher type: <VOUCHERTYPENAME>Purchase</VOUCHERTYPENAME>
 * - Expected non-empty voucher number matching invoice
 */
export function validateTallyPurchaseXml(xml: string, expectedInvoiceNumber?: string): void {
  if (!xml || typeof xml !== 'string' || !xml.trim()) {
    throw new Error('Tally XML validation failed: Generated XML is empty.');
  }

  // 1. Voucher View consistency
  if (!xml.includes('OBJVIEW="Invoice Voucher View"')) {
    throw new Error('Tally XML validation failed: Voucher must have OBJVIEW="Invoice Voucher View".');
  }

  if (!xml.includes('<PERSISTEDVIEW>Invoice Voucher View</PERSISTEDVIEW>')) {
    throw new Error('Tally XML validation failed: Voucher missing <PERSISTEDVIEW>Invoice Voucher View</PERSISTEDVIEW>.');
  }

  if (!xml.includes('<ISINVOICE>Yes</ISINVOICE>')) {
    throw new Error('Tally XML validation failed: Voucher missing <ISINVOICE>Yes</ISINVOICE>.');
  }

  // 2. Voucher Type
  if (!xml.includes('<VOUCHERTYPENAME>Purchase</VOUCHERTYPENAME>')) {
    throw new Error('Tally XML validation failed: Voucher missing <VOUCHERTYPENAME>Purchase</VOUCHERTYPENAME>.');
  }

  // 3. Valid voucher date
  const dateMatch = xml.match(/<DATE>(\d{8})<\/DATE>/);
  if (!dateMatch) {
    throw new Error('Tally XML validation failed: No valid 8-digit <DATE>YYYYMMDD</DATE> tag found in voucher.');
  }

  // Validate date digits are valid calendar numbers
  const dateVal = dateMatch[1];
  const yr = parseInt(dateVal.slice(0, 4), 10);
  const mo = parseInt(dateVal.slice(4, 6), 10);
  const da = parseInt(dateVal.slice(6, 8), 10);
  if (yr < 1900 || yr > 2100 || mo < 1 || mo > 12 || da < 1 || da > 31) {
    throw new Error(`Tally XML validation failed: Voucher date "${dateVal}" is not a valid calendar date.`);
  }

  // 4. Voucher Number
  const vchNumMatch = xml.match(/<VOUCHERNUMBER>(.*?)<\/VOUCHERNUMBER>/);
  if (!vchNumMatch || !vchNumMatch[1] || !vchNumMatch[1].trim()) {
    throw new Error('Tally XML validation failed: Voucher is missing a valid non-empty <VOUCHERNUMBER>.');
  }

  if (expectedInvoiceNumber && vchNumMatch[1].trim() !== escapeXml(expectedInvoiceNumber).trim()) {
    throw new Error(
      `Tally XML validation failed: Voucher number "${vchNumMatch[1]}" does not match invoice "${expectedInvoiceNumber}".`
    );
  }
}

/**
 * Generate a single combined Tally Prime XML import containing multiple vouchers.
 * Importing this single file in Tally Prime (Alt + O) imports all vouchers at once.
 */
export function generateTallyBatchPurchaseXml(
  invoices: InvoiceRecord[],
  ledgerMappings: LedgerMappingRule[] = [],
  companyName: string = 'Demo Company'
): string {
  if (invoices.length === 0) {
    throw new Error('Batch XML generation failed: No invoices provided for export.');
  }

  const messagesXml = invoices
    .map((inv) => {
      const res = generateTallyPurchaseXml(inv, ledgerMappings, companyName);
      const match = res.xml.match(/<TALLYMESSAGE[\s\S]*?<\/TALLYMESSAGE>/);
      if (!match) {
        throw new Error(`Batch XML generation failed: Could not extract TALLYMESSAGE for Invoice #${inv.invoiceNumber}.`);
      }
      return match[0];
    })
    .join('\n');

  const batchXml = `<?xml version="1.0" encoding="UTF-8"?>
<ENVELOPE>
  <HEADER>
    <TALLYREQUEST>Import Data</TALLYREQUEST>
  </HEADER>
  <BODY>
    <IMPORTDATA>
      <REQUESTDESC>
        <REPORTNAME>Vouchers</REPORTNAME>
        <STATICVARIABLES>
          <SVCURRENTCOMPANY>${escapeXml(companyName)}</SVCURRENTCOMPANY>
        </STATICVARIABLES>
      </REQUESTDESC>
      <REQUESTDATA>
${messagesXml}
      </REQUESTDATA>
    </IMPORTDATA>
  </BODY>
</ENVELOPE>`.trim();

  // Validate batch envelope consistency
  if (!batchXml.includes('OBJVIEW="Invoice Voucher View"') || !batchXml.includes('<PERSISTEDVIEW>Invoice Voucher View</PERSISTEDVIEW>')) {
    throw new Error('Batch XML validation failed: Voucher views are not consistent with Invoice Voucher View.');
  }

  return batchXml;
}

/**
 * Standard filename generator for Tally Purchase XML
 */
export function getTallyPurchaseXmlFilename(invoiceNumber: string): string {
  const safeNumber = (invoiceNumber || 'VOUCHER').replace(/[^a-zA-Z0-9_-]/g, '_');
  return `Tally_Purchase_${safeNumber}.xml`;
}

/**
 * Triggers browser download of generated Tally Purchase XML
 */
export function downloadTallyPurchaseXml(
  invoice: InvoiceRecord,
  ledgerMappings: LedgerMappingRule[] = [],
  companyName: string = 'Demo Company'
): { filename: string; xml: string } {
  const { xml } = generateTallyPurchaseXml(invoice, ledgerMappings, companyName);
  const filename = getTallyPurchaseXmlFilename(invoice.invoiceNumber);
  const blob = new Blob([xml], { type: 'application/xml;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
  return { filename, xml };
}

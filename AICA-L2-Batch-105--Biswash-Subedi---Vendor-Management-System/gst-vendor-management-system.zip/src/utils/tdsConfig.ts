/**
 * Statutory Income Tax Act, 1961 - TDS Deduction Configuration & Calculations
 * CBDT Circular No. 23/2017: TDS is deductible on the Taxable Value of invoice (excluding GST component)
 */

export interface TDSSectionItem {
  code: string;
  name: string;
  category: string;
  defaultRate: number;
  defaultGlAccount: string; // Tally / ERP GL Ledger Name under Duties & Taxes
  availableRates: { label: string; rate: number }[];
  thresholdNotes: string;
}

export const DEFAULT_TDS_GL_LEDGERS: Record<string, string> = {
  '194C': 'TDS on Contractors - 194C',
  '194J_TECH': 'TDS on Technical Services - 194J',
  '194J_PROF': 'TDS on Professional Fees - 194J',
  '194I_LAND': 'TDS on Rent - Building - 194I',
  '194I_PLANT': 'TDS on Rent - Plant & Machinery - 194I',
  '194H': 'TDS on Commission or Brokerage - 194H',
  '194Q': 'TDS on Purchase of Goods - 194Q',
  'NO_TDS': 'Not Applicable (No TDS)',
};

export const STATUTORY_TDS_SECTIONS: TDSSectionItem[] = [
  {
    code: '194C',
    name: '194C - Payments to Contractors & Sub-contractors',
    category: 'Works Contract / Transport / Advertising',
    defaultRate: 2.0,
    defaultGlAccount: 'TDS on Contractors - 194C',
    availableRates: [
      { label: '2.0% (Company, Firm, LLP, Co-operative)', rate: 2.0 },
      { label: '1.0% (Individual or HUF Contractor)', rate: 1.0 },
      { label: '0.0% (Transporter with Valid PAN declaration)', rate: 0.0 },
    ],
    thresholdNotes: 'Threshold: Single bill > ₹30,000 or Aggregate in FY > ₹1,00,000',
  },
  {
    code: '194J_TECH',
    name: '194J(a) - Fees for Technical Services (FTS)',
    category: 'Technical Services & Call Centers',
    defaultRate: 2.0,
    defaultGlAccount: 'TDS on Technical Services - 194J',
    availableRates: [
      { label: '2.0% (Technical Services / Call Center Operator)', rate: 2.0 },
    ],
    thresholdNotes: 'Threshold: > ₹30,000 per financial year',
  },
  {
    code: '194J_PROF',
    name: '194J(b) - Fees for Professional Services & Royalty',
    category: 'Legal, Accounting, Medical, Consultancy, Royalty',
    defaultRate: 10.0,
    defaultGlAccount: 'TDS on Professional Fees - 194J',
    availableRates: [
      { label: '10.0% (Standard Professional / Consultancy / Royalty)', rate: 10.0 },
      { label: '2.0% (Cinematographic Films Royalty)', rate: 2.0 },
    ],
    thresholdNotes: 'Threshold: > ₹30,000 per financial year',
  },
  {
    code: '194I_PLANT',
    name: '194I(a) - Rent on Plant, Machinery, or Equipment',
    category: 'Plant & Machinery Hire',
    defaultRate: 2.0,
    defaultGlAccount: 'TDS on Rent - Plant & Machinery - 194I',
    availableRates: [
      { label: '2.0% (Plant, Machinery, Factory Equipment)', rate: 2.0 },
    ],
    thresholdNotes: 'Threshold: Aggregate rent > ₹2,40,000 per FY',
  },
  {
    code: '194I_LAND',
    name: '194I(b) - Rent on Land, Building, or Furniture',
    category: 'Commercial / Warehouse Rent',
    defaultRate: 10.0,
    defaultGlAccount: 'TDS on Rent - Building - 194I',
    availableRates: [
      { label: '10.0% (Commercial Property / Office / Warehouse)', rate: 10.0 },
    ],
    thresholdNotes: 'Threshold: Aggregate rent > ₹2,40,000 per FY',
  },
  {
    code: '194H',
    name: '194H - Commission or Brokerage',
    category: 'Agency / Sales Commission',
    defaultRate: 5.0,
    defaultGlAccount: 'TDS on Commission or Brokerage - 194H',
    availableRates: [
      { label: '5.0% (Standard Commission / Brokerage)', rate: 5.0 },
    ],
    thresholdNotes: 'Threshold: > ₹15,000 per financial year',
  },
  {
    code: '194Q',
    name: '194Q - Purchase of Goods exceeding ₹50 Lakhs',
    category: 'Goods Purchase (Buyer Turnover > ₹10 Cr)',
    defaultRate: 0.1,
    defaultGlAccount: 'TDS on Purchase of Goods - 194Q',
    availableRates: [
      { label: '0.1% (Standard with valid PAN)', rate: 0.1 },
      { label: '5.0% (Higher rate if PAN not furnished u/s 206AA)', rate: 5.0 },
    ],
    thresholdNotes: 'Threshold: Purchases from vendor exceed ₹50,00,000 in FY',
  },
  {
    code: 'NO_TDS',
    name: 'NO TDS - No Tax Deducted at Source',
    category: 'Exempt / Threshold Not Breached / Lower Deduction',
    defaultRate: 0.0,
    defaultGlAccount: 'Not Applicable',
    availableRates: [
      { label: '0.0% (Zero Deduction - Mandatory Justification Required)', rate: 0.0 },
    ],
    thresholdNotes: 'A valid statutory exemption justification is mandatory under IT Rules',
  },
];

export function getTdsGlAccount(code: string, customMappings?: Record<string, string>): string {
  if (customMappings && customMappings[code]) {
    return customMappings[code];
  }
  return DEFAULT_TDS_GL_LEDGERS[code] || 'TDS Payable';
}

export const COMMON_NO_TDS_REASONS = [
  'Value is below statutory annual threshold limit (e.g. <₹30,000 / <₹1,00,000 u/s 194C)',
  'Vendor provided valid Lower / Nil Deduction Certificate u/s 197',
  'Goods purchase below Section 194Q threshold (<₹50 Lakhs in current FY)',
  'Transporter declaration furnished along with valid PAN (exempt u/s 194C(6))',
  'Government entity / Autonomous institution exempt from TDS under Section 196',
  'Reimbursement of actual out-of-pocket expenses without service markup',
  'TCS already collected by seller under Section 206C(1H)',
];

/**
 * Calculates TDS Amount and Net Payable.
 * By default, TDS applies to Taxable Value (excluding GST as per CBDT Circular No. 23/2017).
 */
export function calculateTds(
  taxableValue: number,
  invoiceTotal: number,
  tdsRate: number,
  applyOnGrossTotal: boolean = false
): {
  baseAmount: number;
  tdsAmount: number;
  netPayableAmount: number;
} {
  const baseAmount = applyOnGrossTotal ? Number(invoiceTotal || 0) : Number(taxableValue || 0);
  const rawTds = (baseAmount * (tdsRate || 0)) / 100;
  const tdsAmount = Math.round(rawTds); // Standard IT Act Section 288B round-off to nearest rupee
  const netPayableAmount = Math.max(0, Number(invoiceTotal || 0) - tdsAmount);

  return {
    baseAmount,
    tdsAmount,
    netPayableAmount,
  };
}

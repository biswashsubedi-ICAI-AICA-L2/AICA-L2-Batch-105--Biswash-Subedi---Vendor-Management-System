/**
 * Local Indian GST Tax Invoice Text Parser
 * Instant local regex & statutory heuristic extraction from digital PDF text streams.
 * Complies with Section 31 of CGST Act, 2017 & Rule 46 of CGST Rules, 2017.
 * Acts as an offline/instant sub-100ms parser for digital invoices.
 */

export interface LocalOcrPayload {
  supplier_name: string | null;
  supplier_gstin: string | null;
  buyer_name: string | null;
  buyer_gstin: string | null;
  invoice_number: string | null;
  invoice_date: string | null; // ISO YYYY-MM-DD
  financial_year: string | null;
  po_reference?: string | null;
  place_of_supply: string | null;
  reverse_charge: boolean;
  currency: string;
  narration?: string | null;
  line_items: Array<{
    item_number: number;
    description: string;
    hsn_sac: string;
    quantity: number;
    uom: string;
    rate: number;
    discount: number;
    taxable_value: number;
    cgst_rate: number;
    cgst_amount: number;
    sgst_rate: number;
    sgst_amount: number;
    igst_rate: number;
    igst_amount: number;
    cess_amount: number;
  }>;
  total_taxable_value: number;
  total_cgst: number;
  total_sgst: number;
  total_igst: number;
  total_cess: number;
  round_off: number;
  invoice_total: number;
  confidence_by_field: Record<string, number>;
  warnings: string[];
  is_multi_invoice_detected?: boolean;
  detected_invoice_count?: number;
  token_usage?: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
}

const GSTIN_REGEX = /\b([0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1})\b/g;

// Words that must NEVER be considered an invoice number
const FORBIDDEN_INV_WORDS = new Set([
  'INVOICE', 'TAX', 'BILL', 'ORIGINAL', 'DUPLICATE', 'TRIPLICATE', 'SUPPLIER',
  'BUYER', 'CONSIGNEE', 'DATE', 'DATED', 'GSTIN', 'TOTAL', 'AMOUNT', 'RUPEES',
  'DETAILS', 'PARTICULARS', 'NUMBER', 'PAGE', 'OF', 'RECIPIENT', 'CUSTOMER',
  'STATE', 'CODE', 'PAN', 'HSN', 'SAC', 'DESCRIPTION', 'QTY', 'RATE', 'CGST', 'SGST', 'IGST'
]);

export const INDIAN_STATES_MAP: Record<string, string> = {
  '01': '01-Jammu and Kashmir',
  '02': '02-Himachal Pradesh',
  '03': '03-Punjab',
  '04': '04-Chandigarh',
  '05': '05-Uttarakhand',
  '06': '06-Haryana',
  '07': '07-Delhi',
  '08': '08-Rajasthan',
  '09': '09-Uttar Pradesh',
  '10': '10-Bihar',
  '11': '11-Sikkim',
  '12': '12-Arunachal Pradesh',
  '13': '13-Nagaland',
  '14': '14-Manipur',
  '15': '15-Mizoram',
  '16': '16-Tripura',
  '17': '17-Meghalaya',
  '18': '18-Assam',
  '19': '19-West Bengal',
  '20': '20-Jharkhand',
  '21': '21-Odisha',
  '22': '22-Chhattisgarh',
  '23': '23-Madhya Pradesh',
  '24': '24-Gujarat',
  '26': '26-Dadra and Nagar Haveli and Daman and Diu',
  '27': '27-Maharashtra',
  '29': '29-Karnataka',
  '30': '30-Goa',
  '31': '31-Lakshadweep',
  '32': '32-Kerala',
  '33': '33-Tamil Nadu',
  '34': '34-Puducherry',
  '35': '35-Andaman and Nicobar Islands',
  '36': '36-Telangana',
  '37': '37-Andhra Pradesh',
  '38': '38-Ladakh',
  '97': '97-Other Territory',
};

export function normalizeStateToOptionValue(raw: string | null | undefined): string {
  if (!raw) return '27-Maharashtra';
  const clean = String(raw).trim();

  // If already in 27-Maharashtra format
  if (/^\d{2}-[A-Za-z\s]+$/.test(clean)) {
    const code = clean.slice(0, 2);
    if (INDIAN_STATES_MAP[code]) return INDIAN_STATES_MAP[code];
    return clean;
  }

  // If in "27 - Maharashtra" format with spaces around hyphen
  const spacedMatch = clean.match(/^(\d{2})\s*-\s*(.+)$/);
  if (spacedMatch) {
    const code = spacedMatch[1];
    return INDIAN_STATES_MAP[code] || `${code}-${spacedMatch[2].trim()}`;
  }

  // If only 2-digit code
  if (/^\d{2}$/.test(clean) && INDIAN_STATES_MAP[clean]) {
    return INDIAN_STATES_MAP[clean];
  }

  // Check state name substring match
  const lower = clean.toLowerCase();
  for (const [code, optVal] of Object.entries(INDIAN_STATES_MAP)) {
    const stateName = optVal.split('-')[1]?.toLowerCase() || '';
    if (lower.includes(stateName) || stateName.includes(lower)) {
      return optVal;
    }
  }

  return clean;
}

function cleanAmount(raw: string): number {
  if (!raw) return 0;
  // Remove currency signs, commas, spaces, and trailing "/-"
  const clean = raw.replace(/[₹\s,]|(?:Rs\.?)|(?:INR)|(?:\/-)/gi, '').trim();
  const val = parseFloat(clean);
  return isNaN(val) ? 0 : Number(val.toFixed(2));
}

function normalizeDate(raw: string): string {
  if (!raw) return new Date().toISOString().slice(0, 10);
  const clean = raw.trim();

  // Already YYYY-MM-DD
  if (/^\d{4}-\d{2}-\d{2}$/.test(clean)) return clean;

  const parts = clean.split(/[-/.]/);
  if (parts.length === 3) {
    let day = parts[0];
    let month = parts[1];
    let year = parts[2];

    // If first part is 4 digits, it's YYYY-MM-DD or YYYY/MM/DD
    if (day.length === 4) {
      return `${day}-${month.padStart(2, '0')}-${year.padStart(2, '0')}`;
    }

    if (year.length === 2) {
      year = '20' + year;
    }

    const monthMap: Record<string, string> = {
      jan: '01', feb: '02', mar: '03', apr: '04', may: '05', jun: '06',
      jul: '07', aug: '08', sep: '09', oct: '10', nov: '11', dec: '12'
    };

    if (monthMap[month.toLowerCase().slice(0, 3)]) {
      month = monthMap[month.toLowerCase().slice(0, 3)];
    }

    day = day.padStart(2, '0');
    month = month.padStart(2, '0');

    return `${year}-${month}-${day}`;
  }

  return new Date().toISOString().slice(0, 10);
}

function calculateFinancialYear(dateStr: string): string {
  try {
    const d = new Date(dateStr);
    const month = d.getMonth() + 1; // 1-12
    const year = d.getFullYear();
    if (month >= 4) {
      return `${year}-${String(year + 1).slice(2)}`;
    } else {
      return `${year - 1}-${String(year).slice(2)}`;
    }
  } catch {
    return '2026-27';
  }
}

/**
 * Parses raw text extracted from a digital PDF
 */
export function parseInvoiceTextLocally(
  text: string,
  hintVendorGstin?: string,
  hintBuyerGstin?: string
): LocalOcrPayload | null {
  if (!text || text.trim().length < 25) {
    return null;
  }

  const cleanText = text.replace(/\r\n/g, '\n');
  const lines = cleanText.split('\n').map((l) => l.trim()).filter(Boolean);

  // 1. Extract GSTINs
  const gstinMatches = Array.from(cleanText.matchAll(GSTIN_REGEX)).map((m) => m[1]);
  const uniqueGstins = Array.from(new Set(gstinMatches));

  let supplierGstin: string | null = null;
  let buyerGstin: string | null = null;

  if (hintVendorGstin && uniqueGstins.includes(hintVendorGstin)) {
    supplierGstin = hintVendorGstin;
  } else if (uniqueGstins.length > 0) {
    supplierGstin = uniqueGstins[0];
  }

  if (hintBuyerGstin && uniqueGstins.includes(hintBuyerGstin)) {
    buyerGstin = hintBuyerGstin;
  } else if (uniqueGstins.length > 1) {
    buyerGstin = uniqueGstins.find((g) => g !== supplierGstin) || null;
  }

  // 2. Extract Invoice Number
  let invoiceNumber: string | null = null;

  // Patterns for same-line or next-line invoice number
  const invPatterns = [
    /(?:Invoice\s*(?:No\.?|Number|Num|#)|Inv\s*(?:No\.?|#)|Bill\s*(?:No\.?|#)|Tax\s*Invoice\s*(?:No\.?|Number|#)|Doc\s*(?:No\.?|#)|Voucher\s*(?:No\.?|#))\s*[:.\-\s]\s*([A-Za-z0-9\/\-_]{2,30})/i,
    /(?:Invoice\s*(?:No\.?|Number|Num|#)|Inv\s*(?:No\.?|#))\s*[:.\-\s]*\s*([A-Za-z0-9\/\-_]{2,30})/i,
    /(?:Invoice\s*ID)\s*[:.\-\s]\s*([A-Za-z0-9\/\-_]{2,30})/i,
    /(?:^|\s)#\s*([A-Za-z0-9\/\-_]{3,25})/m,
  ];

  for (const regex of invPatterns) {
    const match = cleanText.match(regex);
    if (match && match[1]) {
      const candidate = match[1].trim();
      if (candidate.length >= 2 && !FORBIDDEN_INV_WORDS.has(candidate.toUpperCase())) {
        invoiceNumber = candidate;
        break;
      }
    }
  }

  // Next-line pattern (e.g. "Invoice No." on one line, "APEX/26-27/0043" on next line)
  if (!invoiceNumber) {
    for (let i = 0; i < lines.length - 1; i++) {
      const line = lines[i];
      if (/^(?:Invoice\s*(?:No\.?|Number|#)|Inv\s*(?:No\.?|#)|Bill\s*(?:No\.?|#)|Tax\s*Invoice\s*(?:No\.?|#))[:.\s]*$/i.test(line)) {
        const nextLine = lines[i + 1].trim();
        if (nextLine.length >= 2 && !FORBIDDEN_INV_WORDS.has(nextLine.toUpperCase()) && !nextLine.includes(':')) {
          invoiceNumber = nextLine;
          break;
        }
      }
    }
  }

  // Fallback: look for alphanumeric strings matching common invoice masks (e.g. APEX/26-27/0043, INV/2026/012, 2026-27/042)
  if (!invoiceNumber) {
    const maskMatch = cleanText.match(/\b([A-Z0-9]{2,6}[/\-_][A-Za-z0-9/\-_]{2,20})\b/);
    if (maskMatch && maskMatch[1] && !FORBIDDEN_INV_WORDS.has(maskMatch[1].toUpperCase()) && !/^\d{2}[-/.]\d{2}[-/.]\d{2,4}$/.test(maskMatch[1])) {
      invoiceNumber = maskMatch[1];
    }
  }

  // If no invoice number could be identified, digital local parsing cannot confirm this is a valid invoice
  if (!invoiceNumber) {
    return null;
  }

  // 3. Extract Invoice Date
  let invoiceDate: string = new Date().toISOString().slice(0, 10);
  const datePatterns = [
    /(?:Invoice\s*Date|Date\s*of\s*Invoice|Dated?|Inv\s*Date|Bill\s*Date)\s*[:.\-\s]\s*(\d{1,2}[-/.](?:[A-Za-z]{3}|\d{1,2})[-/.]\d{2,4})/i,
    /(?:Date)\s*[:.\-\s]\s*(\d{1,2}[-/.](?:[A-Za-z]{3}|\d{1,2})[-/.]\d{2,4})/i,
    /\b(\d{1,2}[-/.](?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|\d{1,2})[-/.]\d{4})\b/i,
    /\b(\d{4}-\d{2}-\d{2})\b/,
  ];

  for (const regex of datePatterns) {
    const match = cleanText.match(regex);
    if (match && match[1]) {
      invoiceDate = normalizeDate(match[1]);
      break;
    }
  }

  // Next-line pattern for Date
  if (!invoiceDate || invoiceDate === new Date().toISOString().slice(0, 10)) {
    for (let i = 0; i < lines.length - 1; i++) {
      if (/^(?:Invoice\s*Date|Date\s*of\s*Invoice|Date)[:.\s]*$/i.test(lines[i])) {
        const nextLine = lines[i + 1].trim();
        if (/^\d{1,2}[-/.](?:[A-Za-z]{3}|\d{1,2})[-/.]\d{2,4}$/.test(nextLine) || /^\d{4}-\d{2}-\d{2}$/.test(nextLine)) {
          invoiceDate = normalizeDate(nextLine);
          break;
        }
      }
    }
  }

  // 4. Extract PO Reference
  let poReference: string | null = null;
  const poMatch = cleanText.match(/(?:PO\s*(?:Reference|Ref|No\.?|Number|#)?|Purchase\s*Order\s*(?:Reference|Ref|No\.?|#)?|P\.O\.?\s*(?:Reference|Ref|No\.?|#)?)\s*[:.\-\s]\s*([A-Za-z0-9\/\-_]{3,30})/i);
  if (poMatch && poMatch[1]) {
    const candidate = poMatch[1].trim();
    if (!FORBIDDEN_INV_WORDS.has(candidate.toUpperCase()) && !/^Ref(?:erence)?$/i.test(candidate)) {
      poReference = candidate;
    }
  }

  // 5. Extract Amounts
  let totalTaxable = 0;
  const taxablePatterns = [
    /(?:Total\s*Taxable\s*(?:Value|Amount)?|Taxable\s*(?:Value|Amount)?|Total\s*Amount\s*Before\s*Tax|Sub\s*Total|Taxable\s*Amt|Assessable\s*Value)\s*[:.\-\s]*\s*(?:₹|Rs\.?|INR)?\s*([\d,]+\.?\d*)/i,
    /(?:Total\s*Taxable)\s*[:.\-\s]*\s*(?:₹|Rs\.?|INR)?\s*([\d,]+\.?\d*)/i,
  ];
  for (const regex of taxablePatterns) {
    const match = cleanText.match(regex);
    if (match && match[1]) {
      const val = cleanAmount(match[1]);
      if (val > 0) {
        totalTaxable = val;
        break;
      }
    }
  }

  // Next-line pattern for Taxable Amount
  if (totalTaxable === 0) {
    for (let i = 0; i < lines.length - 1; i++) {
      if (/^(?:Total\s*Taxable\s*(?:Value|Amount)?|Taxable\s*Value|Sub\s*Total)[:.\s]*$/i.test(lines[i])) {
        const nextVal = cleanAmount(lines[i + 1]);
        if (nextVal > 0) {
          totalTaxable = nextVal;
          break;
        }
      }
    }
  }

  let totalAmount = 0;
  const totalPatterns = [
    /(?:Grand\s*Total|Invoice\s*Total|Total\s*Invoice\s*Value|Total\s*Amount\s*After\s*Tax|Total\s*Amount|Net\s*Payable|Total\s*INR|Net\s*Amount|Total\s*Value)\s*[:.\-\s]*\s*(?:₹|Rs\.?|INR)?\s*([\d,]+\.?\d*)/i,
    /(?:Invoice\s*Value\s*\(in\s*figures\))\s*[:.\-\s]*\s*(?:₹|Rs\.?|INR)?\s*([\d,]+\.?\d*)/i,
  ];
  for (const regex of totalPatterns) {
    const match = cleanText.match(regex);
    if (match && match[1]) {
      const val = cleanAmount(match[1]);
      if (val > 0) {
        totalAmount = val;
        break;
      }
    }
  }

  // Next-line pattern for Total
  if (totalAmount === 0) {
    for (let i = 0; i < lines.length - 1; i++) {
      if (/^(?:Grand\s*Total|Invoice\s*Total|Total\s*Amount|Total\s*Invoice\s*Value|Net\s*Payable)[:.\s]*$/i.test(lines[i])) {
        const nextVal = cleanAmount(lines[i + 1]);
        if (nextVal > 0) {
          totalAmount = nextVal;
          break;
        }
      }
    }
  }

  // Tax breakdowns
  let cgst = 0;
  const cgstMatch = cleanText.match(/(?:CGST|Central\s*GST|Central\s*Tax)\s*(?:@\s*\d+%?)?\s*(?:Amount|Total)?\s*[:.\-\s]*\s*(?:₹|Rs\.?|INR)?\s*([\d,]+\.?\d*)/i);
  if (cgstMatch && cgstMatch[1]) cgst = cleanAmount(cgstMatch[1]);

  let sgst = 0;
  const sgstMatch = cleanText.match(/(?:SGST|State\s*GST|State\s*Tax)\s*(?:@\s*\d+%?)?\s*(?:Amount|Total)?\s*[:.\-\s]*\s*(?:₹|Rs\.?|INR)?\s*([\d,]+\.?\d*)/i);
  if (sgstMatch && sgstMatch[1]) sgst = cleanAmount(sgstMatch[1]);

  let igst = 0;
  const igstMatch = cleanText.match(/(?:IGST|Integrated\s*GST|Integrated\s*Tax)\s*(?:@\s*\d+%?)?\s*(?:Amount|Total)?\s*[:.\-\s]*\s*(?:₹|Rs\.?|INR)?\s*([\d,]+\.?\d*)/i);
  if (igstMatch && igstMatch[1]) igst = cleanAmount(igstMatch[1]);

  // Self-consistency reconciling
  if (totalAmount > 0 && totalTaxable === 0) {
    const taxSum = cgst + sgst + igst;
    totalTaxable = taxSum > 0 ? Number((totalAmount - taxSum).toFixed(2)) : Number((totalAmount / 1.18).toFixed(2));
  }
  if (totalTaxable > 0 && totalAmount === 0) {
    const taxSum = cgst + sgst + igst;
    totalAmount = taxSum > 0 ? Number((totalTaxable + taxSum).toFixed(2)) : Number((totalTaxable * 1.18).toFixed(2));
  }

  // If both amounts are still 0, local extraction failed to find financial values
  if (totalTaxable === 0 && totalAmount === 0) {
    return null;
  }

  // 6. Extract HSN/SAC Codes
  const hsnRegex = /\b(?:HSN|SAC)?\s*([0-9]{4,8})\b/g;
  const hsnMatches = Array.from(cleanText.matchAll(hsnRegex))
    .map((m) => m[1])
    .filter((h) => h.length >= 4 && h.length <= 8 && !h.startsWith('202') && !h.startsWith('19') && !h.startsWith('411')); // exclude years, pincodes

  const primaryHsn = hsnMatches.length > 0 ? hsnMatches[0] : '847130';

  // 7. Place of Supply (Extract code & state name, e.g. "10-Bihar", "27-Maharashtra")
  let placeOfSupply = '27-Maharashtra';
  const posMatch = cleanText.match(/(?:Place\s*of\s*Supply|POS|Supply\s*State|State\s*Code|State\s*Name)\s*[:.\-\s]\s*([0-9]{2}[-\sA-Za-z]+|[A-Za-z\s]{3,25})/i);
  if (posMatch && posMatch[1]) {
    const rawPos = posMatch[1].trim();
    placeOfSupply = normalizeStateToOptionValue(rawPos);
  } else if (buyerGstin && /^\d{2}/.test(buyerGstin)) {
    // Recipient state is standard Place of Supply for intra/inter state supplies
    const code = buyerGstin.slice(0, 2);
    placeOfSupply = INDIAN_STATES_MAP[code] || `${code}-State`;
  } else if (supplierGstin && /^\d{2}/.test(supplierGstin)) {
    const code = supplierGstin.slice(0, 2);
    placeOfSupply = INDIAN_STATES_MAP[code] || `${code}-State`;
  }

  // 8. Reverse Charge
  let reverseCharge = false;
  const rcmMatch = cleanText.match(/(?:Reverse\s*Charge|RCM)\s*[:.\-\s]\s*(Yes|No|Y|N|True|False)/i);
  if (rcmMatch && rcmMatch[1]) {
    reverseCharge = /^(Yes|Y|True)$/i.test(rcmMatch[1]);
  }

  // 9. Vendor Name & Buyer Name
  let supplierName: string | null = null;
  let buyerName: string | null = null;

  // Supplier name is typically in the first 1-6 lines before the GSTIN
  for (let i = 0; i < Math.min(lines.length, 8); i++) {
    const l = lines[i];
    const upper = l.toUpperCase();
    if (
      !upper.includes('TAX INVOICE') &&
      !upper.includes('ORIGINAL') &&
      !upper.includes('DUPLICATE') &&
      !upper.includes('TRIPLICATE') &&
      !upper.includes('RECIPIENT') &&
      !upper.includes('GSTIN') &&
      !upper.includes('DATE') &&
      !upper.includes('INVOICE NO') &&
      !upper.includes('SECTION 31') &&
      !upper.includes('RULE 46') &&
      l.length >= 3 &&
      !/^[0-9\W]+$/.test(l)
    ) {
      supplierName = l;
      break;
    }
  }

  // Buyer name after "Billed To", "Bill To", "Buyer", "Recipient", "Customer"
  for (let i = 0; i < lines.length - 1; i++) {
    if (/^(?:Billed\s*to(?:\s*\/\s*Buyer)?|Buyer|Bill\s*To|Customer|Consignee|Recipient)[:.\s]*$/i.test(lines[i])) {
      buyerName = lines[i + 1].trim();
      break;
    }
  }

  // 10. Extract Detailed Line Items with actual Quantities and HSN/SAC Codes
  const cgstRate = (totalTaxable > 0 && cgst > 0) ? Math.round((cgst / totalTaxable) * 100) : (igst > 0 ? 0 : 9);
  const sgstRate = (totalTaxable > 0 && sgst > 0) ? Math.round((sgst / totalTaxable) * 100) : (igst > 0 ? 0 : 9);
  const igstRate = (totalTaxable > 0 && igst > 0) ? Math.round((igst / totalTaxable) * 100) : 0;

  const extractedItems: Array<{
    item_number: number;
    description: string;
    hsn_sac: string;
    quantity: number;
    uom: string;
    rate: number;
    discount: number;
    taxable_value: number;
    cgst_rate: number;
    cgst_amount: number;
    sgst_rate: number;
    sgst_amount: number;
    igst_rate: number;
    igst_amount: number;
    cess_amount: number;
  }> = [];

  // Look for line item table rows containing HSN code, quantity, and amounts
  // Regex pattern matching: [Description] [HSN] [Qty] [Unit/UOM] [Rate] [Taxable Amount]
  const tableRowRegex = /(?:^|\n)\s*(?:[0-9]{1,3}[.)\s]+)?([A-Za-z0-9\s,._\-/()]{3,45})\s+([0-9]{4,8})\s+([0-9]+(?:\.[0-9]+)?)\s*(NOS|PCS|KG|KGS|MTR|BOX|SET|UNT|BAG|LOT|HRS|DAYS)?\s+([0-9,]+(?:\.[0-9]{2})?)\s+([0-9,]+(?:\.[0-9]{2})?)/gi;
  
  let match: RegExpExecArray | null;
  let itemCounter = 1;

  while ((match = tableRowRegex.exec(cleanText)) !== null) {
    const rawDesc = match[1]?.trim();
    const hsn = match[2]?.trim();
    const qty = parseFloat(match[3]) || 1;
    const uom = (match[4] || 'NOS').toUpperCase();
    const rate = cleanAmount(match[5]) || (cleanAmount(match[6]) / (qty || 1));
    const lineTaxable = cleanAmount(match[6]) || Number((qty * rate).toFixed(2));

    if (lineTaxable > 0 && hsn && hsn.length >= 4 && !FORBIDDEN_INV_WORDS.has(rawDesc.toUpperCase())) {
      const lineCgst = cgstRate > 0 ? Number(((lineTaxable * cgstRate) / 100).toFixed(2)) : 0;
      const lineSgst = sgstRate > 0 ? Number(((lineTaxable * sgstRate) / 100).toFixed(2)) : 0;
      const lineIgst = igstRate > 0 ? Number(((lineTaxable * igstRate) / 100).toFixed(2)) : 0;

      extractedItems.push({
        item_number: itemCounter++,
        description: rawDesc || 'Supply Item',
        hsn_sac: hsn,
        quantity: qty,
        uom: uom,
        rate: rate,
        discount: 0,
        taxable_value: lineTaxable,
        cgst_rate: cgstRate,
        cgst_amount: lineCgst,
        sgst_rate: sgstRate,
        sgst_amount: lineSgst,
        igst_rate: igstRate,
        igst_amount: lineIgst,
        cess_amount: 0,
      });
    }
  }

  // If table row regex didn't extract multiple items, check if we found specific HSN codes
  if (extractedItems.length === 0) {
    // Attempt single item with the detected primary HSN
    extractedItems.push({
      item_number: 1,
      description: 'Extracted GST Supply Line Item',
      hsn_sac: primaryHsn,
      quantity: 1,
      uom: 'NOS',
      rate: totalTaxable,
      discount: 0,
      taxable_value: totalTaxable,
      cgst_rate: cgstRate,
      cgst_amount: cgst,
      sgst_rate: sgstRate,
      sgst_amount: sgst,
      igst_rate: igstRate,
      igst_amount: igst,
      cess_amount: 0,
    });
  }

  const confidenceScore = invoiceNumber && (supplierGstin || totalAmount > 0) ? 0.98 : 0.85;

  return {
    supplier_name: supplierName,
    supplier_gstin: supplierGstin,
    buyer_name: buyerName,
    buyer_gstin: buyerGstin,
    invoice_number: invoiceNumber,
    invoice_date: invoiceDate,
    financial_year: calculateFinancialYear(invoiceDate),
    po_reference: poReference,
    place_of_supply: placeOfSupply,
    reverse_charge: reverseCharge,
    currency: 'INR',
    narration: 'Extracted locally via high-speed Indian GST PDF stream parser',
    line_items: extractedItems,
    total_taxable_value: totalTaxable,
    total_cgst: cgst,
    total_sgst: sgst,
    total_igst: igst,
    total_cess: 0,
    round_off: 0,
    invoice_total: totalAmount,
    confidence_by_field: {
      supplier_gstin: supplierGstin ? 0.99 : 0.6,
      invoice_number: invoiceNumber ? 0.98 : 0.5,
      invoice_date: 0.95,
      total_taxable_value: 0.95,
      invoice_total: 0.98,
    },
    warnings: [
      'Locally extracted from PDF text stream (<100ms). Please verify details before final submission.'
    ],
    is_multi_invoice_detected: false,
    detected_invoice_count: 1,
  };
}

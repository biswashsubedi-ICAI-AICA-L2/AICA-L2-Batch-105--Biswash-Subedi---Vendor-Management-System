/**
 * Not Authorized Access Guard Screen
 */

import React from 'react';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { ShieldAlert, ArrowLeft, LogOut } from 'lucide-react';

interface NotAuthorizedScreenProps {
  onReturnHome: () => void;
}

export const NotAuthorizedScreen: React.FC<NotAuthorizedScreenProps> = ({ onReturnHome }) => {
  const { currentRole, signOut } = useAuth();

  return (
    <div className="min-h-[60vh] flex flex-col justify-center items-center text-center p-6">
      <div className="max-w-md w-full bg-white border border-[#D9E2EC] rounded-[6px] p-8 shadow-sm space-y-4">
        <div className="mx-auto w-12 h-12 rounded-[6px] bg-[#FEF3F2] border border-[#FECDCA] flex items-center justify-center text-[#B42318]">
          <ShieldAlert className="w-6 h-6" />
        </div>

        <h2 className="text-xl font-bold text-[#0B2545] tracking-tight">Access Restricted</h2>
        <div className="rule-accent w-16 mx-auto" />
        <p className="text-xs text-[#52606D] leading-relaxed">
          Your active role (<strong className="text-[#1F4E9C] font-mono">{currentRole}</strong>) does not have permission to view this module.
        </p>

        <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-2">
          <button
            onClick={onReturnHome}
            className="w-full sm:w-auto px-4 py-2 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[6px] text-xs font-medium flex items-center justify-center space-x-1.5 transition"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Return to Workspace</span>
          </button>
          <button
            onClick={signOut}
            className="w-full sm:w-auto px-4 py-2 bg-white hover:bg-[#F5F7FA] text-[#1F2933] border border-[#D9E2EC] rounded-[6px] text-xs font-medium flex items-center justify-center space-x-1.5 transition"
          >
            <LogOut className="w-3.5 h-3.5 text-[#52606D]" />
            <span>Sign Out</span>
          </button>
        </div>
      </div>
    </div>
  );
};

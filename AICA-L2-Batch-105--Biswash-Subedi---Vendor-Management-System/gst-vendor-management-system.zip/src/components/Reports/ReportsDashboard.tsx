/**
 * Reports and Analytics Dashboard
 * 6 Statutory Reports with Interactive Filters & One-Click Excel Export (.xlsx)
 * Restyled with ICAI-inspired theme: White cards, Navy #0B2545, Blue #1F4E9C, 6px radius.
 */

import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext.tsx';
import {
  BarChart3,
  Filter,
  FileSpreadsheet,
} from 'lucide-react';

export const ReportsDashboard: React.FC = () => {
  const { invoices, vendors, auditLogs, currentUser, currentRole } = useAuth();

  const canViewOverrides = Boolean(currentUser?.canOverride || currentRole === 'ADMIN');

  const [activeReport, setActiveReport] = useState<
    'AGEING' | 'QUERIES' | 'TALLY' | 'VENDORS' | 'OCR' | 'OVERRIDES'
  >('AGEING');

  const [vendorFilter, setVendorFilter] = useState<string>('ALL');
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [isExporting, setIsExporting] = useState<boolean>(false);

  // Filter invoices
  const filteredInvoices = invoices.filter((inv) => {
    if (vendorFilter !== 'ALL' && inv.vendorId !== vendorFilter) return false;
    if (statusFilter !== 'ALL' && inv.status !== statusFilter) return false;
    return true;
  });

  // Calculate Metrics
  const totalInvoiced = filteredInvoices.reduce((a, b) => a + (b.invoiceTotal || 0), 0);
  const postedAmount = filteredInvoices
    .filter((i) => i.status === 'POSTED')
    .reduce((a, b) => a + (b.invoiceTotal || 0), 0);
  const pendingAmount = filteredInvoices
    .filter((i) => i.status === 'UNDER_REVIEW' || i.status === 'CLARIFICATION_REQUESTED')
    .reduce((a, b) => a + (b.invoiceTotal || 0), 0);
  const avgOcrScore = Math.round(
    (filteredInvoices.reduce((a, b) => a + (b.ocrConfidence || 0.95), 0) / (filteredInvoices.length || 1)) * 100
  );

  // Ageing Buckets calculation
  const now = Date.now();
  const getAgeDays = (dateStr?: string) => {
    if (!dateStr) return 0;
    return Math.max(0, Math.floor((now - new Date(dateStr).getTime()) / (1000 * 60 * 60 * 24)));
  };

  const ageingRows = filteredInvoices.map((inv) => {
    const days = getAgeDays(inv.invoiceDate);
    let bucket = '0-30 Days';
    if (days > 90) bucket = '90+ Days';
    else if (days > 60) bucket = '61-90 Days';
    else if (days > 30) bucket = '31-60 Days';
    return { ...inv, daysOld: days, bucket };
  });

  // Export to Excel handler
  const handleExportExcel = async () => {
    setIsExporting(true);
    try {
      const response = await fetch('/api/reports/export', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          invoices: filteredInvoices,
          auditLogs,
          vendors,
        }),
      });

      if (!response.ok) {
        throw new Error('Export service returned error');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `GST_VMS_Enterprise_Reports_${new Date().toISOString().slice(0, 10)}.xlsx`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      window.URL.revokeObjectURL(url);
    } catch (err: any) {
      alert(`Export failed: ${err.message}`);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner */}
      <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 bg-[#EBF1FA] text-[#1F4E9C] rounded-[4px]">
            <BarChart3 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-[#0B2545] tracking-tight">Financial & Statutory Reports</h2>
            <p className="text-xs text-[#52606D]">
              GST analytics, invoice ageing, query SLA performance, and Tally export reports.
            </p>
          </div>
        </div>

        <button
          onClick={handleExportExcel}
          disabled={isExporting}
          className="flex items-center space-x-2 px-5 py-2.5 bg-[#1B7F3B] hover:bg-[#14632E] disabled:bg-[#52606D] text-white text-xs font-medium rounded-[6px] transition shrink-0 shadow-sm"
        >
          <FileSpreadsheet className="w-4 h-4" />
          <span>{isExporting ? 'Generating Excel...' : 'Export to Excel (.xlsx)'}</span>
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-4 shadow-sm">
          <span className="text-xs text-[#52606D]">Total Invoiced (INR)</span>
          <p className="text-2xl font-bold text-[#0B2545] mt-1">₹{totalInvoiced.toLocaleString('en-IN')}</p>
          <span className="text-[11px] text-[#52606D]">{filteredInvoices.length} total invoices</span>
        </div>

        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-4 shadow-sm">
          <span className="text-xs text-[#52606D]">Posted in Tally ERP</span>
          <p className="text-2xl font-bold text-[#1B7F3B] mt-1">₹{postedAmount.toLocaleString('en-IN')}</p>
          <span className="text-[11px] text-[#1B7F3B] font-medium">Vouchers integrated</span>
        </div>

        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-4 shadow-sm">
          <span className="text-xs text-[#52606D]">Review / Query Pipeline</span>
          <p className="text-2xl font-bold text-[#B26A00] mt-1">₹{pendingAmount.toLocaleString('en-IN')}</p>
          <span className="text-[11px] text-[#B26A00] font-medium">Pending accounts action</span>
        </div>

        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-4 shadow-sm">
          <span className="text-xs text-[#52606D]">Avg Extraction Accuracy</span>
          <p className="text-2xl font-bold text-[#1F4E9C] mt-1">{avgOcrScore}%</p>
          <span className="text-[11px] text-[#1F4E9C] font-medium">Field-level precision</span>
        </div>
      </div>

      {/* Filter Toolbar */}
      <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-4 flex flex-wrap items-center justify-between gap-3 shadow-sm">
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="flex items-center space-x-1 text-[#52606D]">
            <Filter className="w-3.5 h-3.5" />
            <span className="font-semibold">Filter By:</span>
          </div>

          <select
            value={vendorFilter}
            onChange={(e) => setVendorFilter(e.target.value)}
            className="px-3 py-1.5 bg-white border border-[#D9E2EC] rounded-[6px] text-[#1F2933]"
          >
            <option value="ALL">All Vendors</option>
            {vendors.map((v) => (
              <option key={v.id} value={v.id}>{v.legalName}</option>
            ))}
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-1.5 bg-white border border-[#D9E2EC] rounded-[6px] text-[#1F2933]"
          >
            <option value="ALL">All Statuses</option>
            <option value="UNDER_REVIEW">Under Review</option>
            <option value="CLARIFICATION_REQUESTED">Clarification Requested</option>
            <option value="APPROVED">Approved</option>
            <option value="POSTED">Posted to Tally</option>
            <option value="POSTING_FAILED">Posting Failed</option>
          </select>
        </div>

        <span className="text-xs text-[#52606D] font-mono">
          Showing {filteredInvoices.length} of {invoices.length} invoices
        </span>
      </div>

      {/* Report Switcher Tabs */}
      <div className="flex space-x-2 border-b border-[#D9E2EC] pb-2 text-xs font-semibold overflow-x-auto">
        <button
          onClick={() => setActiveReport('AGEING')}
          className={`px-4 py-2 rounded-[6px] whitespace-nowrap transition ${
            activeReport === 'AGEING' ? 'bg-[#1F4E9C] text-white' : 'text-[#52606D] hover:text-[#0B2545] hover:bg-[#EBF1FA]'
          }`}
        >
          1. Invoice Ageing
        </button>
        <button
          onClick={() => setActiveReport('QUERIES')}
          className={`px-4 py-2 rounded-[6px] whitespace-nowrap transition ${
            activeReport === 'QUERIES' ? 'bg-[#1F4E9C] text-white' : 'text-[#52606D] hover:text-[#0B2545] hover:bg-[#EBF1FA]'
          }`}
        >
          2. Pending Clarifications
        </button>
        <button
          onClick={() => setActiveReport('TALLY')}
          className={`px-4 py-2 rounded-[6px] whitespace-nowrap transition ${
            activeReport === 'TALLY' ? 'bg-[#1F4E9C] text-white' : 'text-[#52606D] hover:text-[#0B2545] hover:bg-[#EBF1FA]'
          }`}
        >
          3. Tally Posted vs Failed
        </button>
        <button
          onClick={() => setActiveReport('VENDORS')}
          className={`px-4 py-2 rounded-[6px] whitespace-nowrap transition ${
            activeReport === 'VENDORS' ? 'bg-[#1F4E9C] text-white' : 'text-[#52606D] hover:text-[#0B2545] hover:bg-[#EBF1FA]'
          }`}
        >
          4. Vendor Summary
        </button>
        <button
          onClick={() => setActiveReport('OCR')}
          className={`px-4 py-2 rounded-[6px] whitespace-nowrap transition ${
            activeReport === 'OCR' ? 'bg-[#1F4E9C] text-white' : 'text-[#52606D] hover:text-[#0B2545] hover:bg-[#EBF1FA]'
          }`}
        >
          5. Extraction Accuracy
        </button>
        {canViewOverrides && (
          <button
            onClick={() => setActiveReport('OVERRIDES')}
            className={`px-4 py-2 rounded-[6px] whitespace-nowrap transition ${
              activeReport === 'OVERRIDES' ? 'bg-[#1F4E9C] text-white' : 'text-[#52606D] hover:text-[#0B2545] hover:bg-[#EBF1FA]'
            }`}
          >
            6. Overrides Audit
          </button>
        )}
      </div>

      {/* REPORT 1: Ageing */}
      {activeReport === 'AGEING' && (
        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-5 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-[#0B2545]">Invoice Ageing by Status</h3>
          <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545]">
                <tr className="uppercase tracking-wider text-[11px] font-sans font-semibold">
                  <th className="py-2.5 px-3">Invoice #</th>
                  <th className="py-2.5 px-3">Vendor</th>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3">Age (Days)</th>
                  <th className="py-2.5 px-3">Bucket</th>
                  <th className="py-2.5 px-3 text-right">Invoice Total</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D9E2EC]">
                {ageingRows.map((inv) => (
                  <tr key={inv.id} className="even:bg-[#F5F7FA] hover:bg-[#EBF1FA]/40 transition">
                    <td className="py-3 px-3 font-bold text-[#0B2545]">{inv.invoiceNumber}</td>
                    <td className="py-3 px-3 font-sans text-[#1F2933]">{inv.vendorName}</td>
                    <td className="py-3 px-3 text-[#1F2933]">{inv.invoiceDate}</td>
                    <td className="py-3 px-3 text-[#52606D]">{inv.daysOld} days</td>
                    <td className="py-3 px-3 font-sans">
                      <span className={`px-2 py-0.5 rounded-[4px] text-[10px] font-semibold ${
                        inv.bucket === '90+ Days'
                          ? 'badge-fail'
                          : inv.bucket === '61-90 Days'
                          ? 'badge-warn'
                          : 'bg-[#F5F7FA] text-[#52606D] border border-[#D9E2EC]'
                      }`}>
                        {inv.bucket}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right font-bold text-[#1B7F3B]">
                      ₹{inv.invoiceTotal.toFixed(2)}
                    </td>
                    <td className="py-3 px-3 font-sans text-[#1F2933]">{inv.status}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* REPORT 2: Pending Clarifications */}
      {activeReport === 'QUERIES' && (
        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-5 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-[#0B2545]">Pending Vendor Clarification Queries</h3>
          <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
            <table className="w-full text-left text-xs font-sans">
              <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545]">
                <tr className="uppercase tracking-wider text-[11px] font-semibold">
                  <th className="py-2.5 px-3">Invoice #</th>
                  <th className="py-2.5 px-3">Vendor Legal Name</th>
                  <th className="py-2.5 px-3">Target Scope</th>
                  <th className="py-2.5 px-3">Reason Code</th>
                  <th className="py-2.5 px-3">SLA Status</th>
                  <th className="py-2.5 px-3 text-right">Invoice Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D9E2EC] font-mono">
                {filteredInvoices
                  .filter((i) => i.status === 'CLARIFICATION_REQUESTED')
                  .map((inv) => (
                    <tr key={inv.id} className="even:bg-[#F5F7FA] hover:bg-[#EBF1FA]/40 transition">
                      <td className="py-3 px-3 font-bold text-[#0B2545]">{inv.invoiceNumber}</td>
                      <td className="py-3 px-3 font-sans text-[#1F2933]">{inv.vendorName}</td>
                      <td className="py-3 px-3 font-sans text-[#1F4E9C]">HSN & Particulars</td>
                      <td className="py-3 px-3 font-sans text-[#B42318]">RULE_46_DISCREPANCY</td>
                      <td className="py-3 px-3 font-sans">
                        <span className="badge-warn">
                          Within 48h SLA
                        </span>
                      </td>
                      <td className="py-3 px-3 text-right font-bold text-[#1B7F3B]">
                        ₹{inv.invoiceTotal.toFixed(2)}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* REPORT 3: Tally Posted vs Failed */}
      {activeReport === 'TALLY' && (
        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-5 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-[#0B2545]">Tally Prime Posting Health & Exceptions</h3>
          <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545]">
                <tr className="uppercase tracking-wider text-[11px] font-sans font-semibold">
                  <th className="py-2.5 px-3">Invoice #</th>
                  <th className="py-2.5 px-3">Vendor</th>
                  <th className="py-2.5 px-3">Tally Voucher GUID</th>
                  <th className="py-2.5 px-3">Voucher #</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3">Error / Remarks</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D9E2EC]">
                {filteredInvoices
                  .filter((i) => ['POSTED', 'POSTING_FAILED', 'APPROVED'].includes(i.status))
                  .map((inv) => (
                    <tr key={inv.id} className="even:bg-[#F5F7FA] hover:bg-[#EBF1FA]/40 transition">
                      <td className="py-3 px-3 font-bold text-[#0B2545]">{inv.invoiceNumber}</td>
                      <td className="py-3 px-3 font-sans text-[#1F2933]">{inv.vendorName}</td>
                      <td className="py-3 px-3 text-[#52606D]">{inv.tallyVoucherGuid || '-'}</td>
                      <td className="py-3 px-3 text-[#1F2933]">{inv.tallyVoucherNumber || '-'}</td>
                      <td className="py-3 px-3 font-sans">
                        <span className={`px-2 py-0.5 rounded-[4px] text-[10px] font-semibold ${
                          inv.status === 'POSTED'
                            ? 'badge-info'
                            : inv.status === 'POSTING_FAILED'
                            ? 'badge-fail'
                            : 'badge-pass'
                        }`}>
                          {inv.status}
                        </span>
                      </td>
                      <td className="py-3 px-3 font-sans text-[#B42318] max-w-xs truncate">
                        {inv.tallyLastError || 'Voucher posted successfully'}
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* REPORT 4: Vendor Summary */}
      {activeReport === 'VENDORS' && (
        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-5 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-[#0B2545]">Vendor-wise Financial Reconciliation</h3>
          <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
            <table className="w-full text-left text-xs font-sans">
              <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545]">
                <tr className="uppercase tracking-wider text-[11px] font-semibold">
                  <th className="py-2.5 px-3">Vendor Legal Name</th>
                  <th className="py-2.5 px-3">GSTIN</th>
                  <th className="py-2.5 px-3">State</th>
                  <th className="py-2.5 px-3 text-right">Invoices</th>
                  <th className="py-2.5 px-3 text-right">Taxable (INR)</th>
                  <th className="py-2.5 px-3 text-right">Total Invoiced (INR)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D9E2EC] font-mono">
                {vendors.map((v) => {
                  const vInvs = filteredInvoices.filter((i) => i.vendorId === v.id);
                  const vTaxable = vInvs.reduce((a, b) => a + (b.totalTaxableValue || 0), 0);
                  const vTotal = vInvs.reduce((a, b) => a + (b.invoiceTotal || 0), 0);
                  return (
                    <tr key={v.id} className="even:bg-[#F5F7FA] hover:bg-[#EBF1FA]/40 transition">
                      <td className="py-3 px-3 font-bold text-[#0B2545] font-sans">{v.legalName}</td>
                      <td className="py-3 px-3 text-[#1F4E9C]">{v.gstin}</td>
                      <td className="py-3 px-3 font-sans text-[#1F2933]">{v.stateName}</td>
                      <td className="py-3 px-3 text-right text-[#1F2933]">{vInvs.length}</td>
                      <td className="py-3 px-3 text-right text-[#1F2933]">₹{vTaxable.toFixed(2)}</td>
                      <td className="py-3 px-3 text-right font-bold text-[#1B7F3B]">₹{vTotal.toFixed(2)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* REPORT 5: OCR Field Accuracy */}
      {activeReport === 'OCR' && (
        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-5 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-[#0B2545]">Multimodal OCR Extraction Confidence</h3>
          <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545]">
                <tr className="uppercase tracking-wider text-[11px] font-sans font-semibold">
                  <th className="py-2.5 px-3">Invoice #</th>
                  <th className="py-2.5 px-3">Vendor GSTIN</th>
                  <th className="py-2.5 px-3 text-right">Overall Confidence</th>
                  <th className="py-2.5 px-3 text-right">GSTIN Match</th>
                  <th className="py-2.5 px-3 text-right">Inv # Match</th>
                  <th className="py-2.5 px-3 text-right">Total Match</th>
                  <th className="py-2.5 px-3">Outcome</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D9E2EC]">
                {filteredInvoices.map((inv) => (
                  <tr key={inv.id} className="even:bg-[#F5F7FA] hover:bg-[#EBF1FA]/40 transition">
                    <td className="py-3 px-3 font-bold text-[#0B2545]">{inv.invoiceNumber}</td>
                    <td className="py-3 px-3 text-[#1F4E9C]">{inv.vendorGstin}</td>
                    <td className="py-3 px-3 text-right font-bold text-[#1B7F3B]">
                      {Math.round((inv.ocrConfidence || 0.94) * 100)}%
                    </td>
                    <td className="py-3 px-3 text-right text-[#1F2933]">
                      {Math.round((inv.confidenceByField?.supplier_gstin || 0.98) * 100)}%
                    </td>
                    <td className="py-3 px-3 text-right text-[#1F2933]">
                      {Math.round((inv.confidenceByField?.invoice_number || 0.96) * 100)}%
                    </td>
                    <td className="py-3 px-3 text-right text-[#1F2933]">
                      {Math.round((inv.confidenceByField?.invoice_total || 0.99) * 100)}%
                    </td>
                    <td className="py-3 px-3 font-sans">
                      <span className="badge-pass font-bold">
                        {inv.validationStatus}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* REPORT 6: Overrides & Edits */}
      {activeReport === 'OVERRIDES' && (
        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-5 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-[#0B2545]">Edited-Then-Approved & Statutory Overrides</h3>
          <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
            <table className="w-full text-left text-xs font-sans">
              <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545]">
                <tr className="uppercase tracking-wider text-[11px] font-semibold">
                  <th className="py-2.5 px-3">Invoice #</th>
                  <th className="py-2.5 px-3">Vendor</th>
                  <th className="py-2.5 px-3">Reviewed By</th>
                  <th className="py-2.5 px-3">Override Reason / Justification</th>
                  <th className="py-2.5 px-3 text-right">Invoice Value</th>
                  <th className="py-2.5 px-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D9E2EC] font-mono">
                {filteredInvoices
                  .filter((i) => Boolean(i.overrideReason) || i.status === 'APPROVED')
                  .map((inv) => (
                    <tr key={inv.id} className="even:bg-[#F5F7FA] hover:bg-[#EBF1FA]/40 transition">
                      <td className="py-3 px-3 font-bold text-[#0B2545]">{inv.invoiceNumber}</td>
                      <td className="py-3 px-3 font-sans text-[#1F2933]">{inv.vendorName}</td>
                      <td className="py-3 px-3 font-sans text-[#1F4E9C]">
                        {inv.reviewedByName || 'Accounts Executive'}
                      </td>
                      <td className="py-3 px-3 font-sans text-[#B26A00] max-w-sm truncate">
                        {inv.overrideReason || 'Standard verification passed (No override)'}
                      </td>
                      <td className="py-3 px-3 text-right font-bold text-[#1B7F3B]">
                        ₹{inv.invoiceTotal.toFixed(2)}
                      </td>
                      <td className="py-3 px-3 font-sans">
                        <span className="badge-pass font-semibold">
                          {inv.status}
                        </span>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

    </div>
  );
};

/**
 * Authentication and Application State Context
 * Enforces:
 * - Unauthenticated landing screen gate
 * - Role-Based Access Control (RBAC) & permissions (canOverride)
 * - Automatic session idle timeout
 * - Server-side user resolution & pre-registered invitation onboarding
 * - Reactive polling for pending users to transition automatically to workspace
 * - Admin User & Invitation Management (create, edit, resend, revoke, bulk delete)
 * - Vendor Management (delete permanent with rule A, archive with rule B, restore)
 */

import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import {
  auth,
  googleProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut as fbSignOut,
  onAuthStateChanged,
} from '../firebase.ts';
import {
  UserProfile,
  UserRole,
  UserStatus,
  UserInvitation,
  VendorMaster,
  InvoiceRecord,
  CompanySettings,
  LedgerMappingRule,
  ClarificationQuery,
  ThreadMessage,
  AuditLogEntry,
  TallyAgentRecord,
  HsnSacMasterItem,
} from '../types/index.ts';
import {
  INITIAL_COMPANY_SETTINGS,
  INITIAL_INVITATIONS,
  INITIAL_VENDORS,
  INITIAL_LEDGER_MAPPINGS,
  INITIAL_SAMPLE_INVOICES,
} from '../utils/initialData.ts';
import { DEFAULT_HSN_SAC_MASTER } from '../utils/gstUtils.ts';

interface AuthContextType {
  currentUser: UserProfile | null;
  currentRole: UserRole;
  isAuthenticated: boolean;
  activeVendor: VendorMaster | null;
  vendors: VendorMaster[];
  invoices: InvoiceRecord[];
  allUsers: UserProfile[];
  invitations: UserInvitation[];
  companySettings: CompanySettings;
  ledgerMappings: LedgerMappingRule[];
  queries: ClarificationQuery[];
  messages: ThreadMessage[];
  auditLogs: AuditLogEntry[];
  agents: TallyAgentRecord[];
  hsnMaster: HsnSacMasterItem[];
  isLoading: boolean;
  authError: string | null;

  // Auth Methods
  signInWithGoogle: () => Promise<void>;
  signInWithEmail: (email: string, pass: string) => Promise<void>;
  signUpWithEmail: (email: string, pass: string, name?: string) => Promise<void>;
  signOut: () => Promise<void>;
  clearAuthError: () => void;

  // Role & Vendor Switching
  setActiveVendorId: (vendorId: string) => void;

  // Admin User Management & Access Repair
  assignUserRole: (
    targetUid: string,
    role: UserRole,
    vendorId?: string,
    canOverride?: boolean,
    status?: UserStatus
  ) => Promise<void>;
  toggleUserStatus: (targetUid: string, newStatus: UserStatus, reason?: string) => Promise<void>;
  activateUser: (targetUid: string) => Promise<void>;
  deactivateUser: (targetUid: string, reason?: string) => Promise<void>;
  deleteUser: (targetUid: string, confirmEmail: string, reason?: string) => Promise<void>;
  bulkDeleteUsers: (targetUids: string[], confirmCount: string, reason?: string) => Promise<void>;
  checkUserAccess: (targetUid: string) => Promise<any>;
  resyncUserAccess: (targetUid: string) => Promise<void>;
  resolveDuplicateUsers: (canonicalEmail: string, keepUid: string) => Promise<void>;

  // Invitation Lifecycle
  createInvitation: (
    email: string,
    role: 'VENDOR' | 'ACCOUNTS_EXECUTIVE' | 'ADMIN',
    vendorId?: string,
    canOverride?: boolean
  ) => Promise<void>;
  editInvitation: (
    id: string,
    role: 'VENDOR' | 'ACCOUNTS_EXECUTIVE' | 'ADMIN',
    vendorId?: string,
    canOverride?: boolean
  ) => Promise<void>;
  resendInvitation: (id: string) => Promise<void>;
  deleteInvitation: (id: string) => Promise<void>;
  bulkDeleteInvitations: (ids: string[]) => Promise<void>;
  refreshInvitations: () => Promise<void>;
  refreshUsers: () => Promise<void>;
  refreshInvoices: () => Promise<void>;
  refreshQueries: () => Promise<void>;
  triggerSync: () => Promise<void>;
  isSyncing: boolean;
  lastSyncedAt: Date | null;

  // Vendor Management & History Protection
  checkVendorDeleteEligibility: (vendorId: string) => Promise<{
    canDeletePermanently: boolean;
    invoiceCount: number;
    queryCount: number;
    reason: string;
  }>;
  deleteVendorPermanent: (vendorId: string, confirmVendorName: string, reason: string) => Promise<void>;
  archiveVendor: (vendorId: string, reason: string) => Promise<void>;
  restoreVendor: (vendorId: string, reason?: string) => Promise<void>;
  bulkDeleteVendors: (vendorIds: string[], reason: string) => Promise<void>;
  refreshVendors: () => Promise<void>;

  // Core Data Mutations
  saveInvoice: (invoice: InvoiceRecord, auditRemark?: string) => Promise<void>;
  deleteInvoice: (invoiceId: string, reason?: string) => Promise<void>;
  resolveAndResubmitInvoice: (
    invoiceId: string,
    queryId?: string,
    resolutionMessage?: string
  ) => Promise<void>;
  updateInvoiceStatus: (
    invoiceId: string,
    newStatus: InvoiceRecord['status'],
    remarks: string,
    extraFields?: Partial<InvoiceRecord>
  ) => Promise<{ success: boolean; error?: string }>;
  saveVendor: (vendor: VendorMaster) => Promise<void>;
  approveVendor: (vendorId: string) => Promise<void>;
  rejectVendor: (vendorId: string) => Promise<void>;
  updateCompanySettings: (settings: Partial<CompanySettings>) => Promise<void>;
  saveLedgerMapping: (mapping: LedgerMappingRule) => Promise<void>;
  deleteLedgerMapping: (id: string) => Promise<void>;
  addQuery: (queryData: Omit<ClarificationQuery, 'id' | 'createdAt'>) => Promise<void>;
  addMessage: (msg: Omit<ThreadMessage, 'id' | 'createdAt'>) => Promise<void>;
  refreshAgentList: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Application Data State
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [invitations, setInvitations] = useState<UserInvitation[]>(INITIAL_INVITATIONS);
  const [vendors, setVendors] = useState<VendorMaster[]>(INITIAL_VENDORS);
  const [invoices, setInvoices] = useState<InvoiceRecord[]>(INITIAL_SAMPLE_INVOICES);
  const [companySettings, setCompanySettings] = useState<CompanySettings>(INITIAL_COMPANY_SETTINGS);
  const [ledgerMappings, setLedgerMappings] = useState<LedgerMappingRule[]>(INITIAL_LEDGER_MAPPINGS);
  const [queries, setQueries] = useState<ClarificationQuery[]>([
    {
      id: 'q_01',
      invoiceId: 'inv_query_sample_004',
      vendorId: 'vendor_apex',
      targetField: 'hsnSac',
      reasonCode: 'HSN_LENGTH_MISMATCH',
      queryText:
        'HSN code 3926 for Nylon Washers requires minimum 6-digit classification under your turnover category (>₹5 Cr). Please provide full 6/8-digit HSN code.',
      status: 'OPEN',
      raisedByUid: 'user_accounts_kavita',
      raisedByName: 'Kavita Iyer (Senior Accounts)',
      slaDueDate: new Date(Date.now() + 48 * 3600 * 1000).toISOString(),
      isEscalated: false,
      createdAt: '2026-04-30T10:00:00Z',
    },
  ]);
  const [messages, setMessages] = useState<ThreadMessage[]>([
    {
      id: 'm_01',
      queryId: 'q_01',
      invoiceId: 'inv_query_sample_004',
      senderUid: 'user_accounts_kavita',
      senderRole: 'ACCOUNTS_EXECUTIVE',
      senderName: 'Kavita Iyer',
      message: 'Please rectify the HSN code and re-upload the revised tax invoice.',
      createdAt: '2026-04-30T10:05:00Z',
    },
  ]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([
    {
      id: 'log_boot_01',
      userUid: 'sys',
      userEmail: 'system@bharattech.in',
      userRole: 'ADMIN',
      action: 'SYSTEM_BOOT',
      remarks: 'GST Vendor Management System initialized with Rule 46 and Tally engine.',
      createdAt: '2026-04-01T08:00:00Z',
    },
  ]);
  const [agents, setAgents] = useState<TallyAgentRecord[]>([]);
  const [hsnMaster] = useState<HsnSacMasterItem[]>(DEFAULT_HSN_SAC_MASTER);

  // Active vendor profile binding
  const [activeVendorId, setActiveVendorIdState] = useState<string>('vendor_apex');

  // Idle session timeout tracking
  const lastActivityRef = useRef<number>(Date.now());

  // Log audit helper
  const logAudit = (
    action: string,
    remarks: string,
    invoiceId?: string,
    fromState?: string,
    toState?: string
  ) => {
    const entry: AuditLogEntry = {
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      invoiceId,
      userUid: currentUser?.uid || 'anonymous',
      userEmail: currentUser?.email || 'unauthenticated',
      userRole: currentUser?.role || 'PENDING',
      action,
      fromState,
      toState,
      remarks,
      createdAt: new Date().toISOString(),
    };
    setAuditLogs((prev) => [entry, ...prev]);
  };

  // Resolve user profile with server backend
  const resolveUserProfile = async (
    uid: string,
    email: string,
    displayName?: string,
    emailVerified?: boolean
  ): Promise<UserProfile> => {
    const response = await fetch('/api/auth/resolve-user', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        uid,
        email: email.trim().toLowerCase(),
        displayName,
        emailVerified,
      }),
    });

    const contentType = response.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      const text = await response.text();
      throw new Error(`Server returned unexpected response (${response.status}): ${text.slice(0, 100)}`);
    }

    const resJson = await response.json();
    if (!response.ok) {
      throw new Error(resJson.error || 'User resolution error');
    }

    const resolvedUser: UserProfile = resJson.user;

    // Update local users list if not present
    setAllUsers((prev) => {
      const idx = prev.findIndex((u) => u.uid === resolvedUser.uid);
      if (idx >= 0) {
        const copy = [...prev];
        copy[idx] = resolvedUser;
        return copy;
      }
      return [...prev, resolvedUser];
    });

    return resolvedUser;
  };

  // Firebase Auth state listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser && fbUser.email) {
        try {
          const userProfile = await resolveUserProfile(
            fbUser.uid,
            fbUser.email,
            fbUser.displayName || undefined,
            fbUser.emailVerified
          );

          if (userProfile.status === 'DEACTIVATED') {
            await fbSignOut(auth);
            setCurrentUser(null);
            setAuthError('Your account has been deactivated. Please contact your Administrator.');
          } else {
            setCurrentUser(userProfile);
            if (userProfile.vendorId) {
              setActiveVendorIdState(userProfile.vendorId);
            }
            setAuthError(null);
          }
        } catch (err: any) {
          console.error('Failed to resolve Firebase user:', err);
          setAuthError(err.message || 'Authentication resolution failed');
          setCurrentUser(null);
        }
      } else {
        if (!currentUser) {
          setCurrentUser(null);
        }
      }
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Reactive polling for users currently awaiting approval:
  // Redirects immediately to workspace once approved/invited without requiring manual reload or sign out!
  useEffect(() => {
    if (!currentUser || currentUser.status !== 'PENDING_APPROVAL') return;

    const interval = setInterval(async () => {
      try {
        const res = await fetch(
          `/api/auth/profile-status?email=${encodeURIComponent(currentUser.email)}&uid=${encodeURIComponent(currentUser.uid)}`
        );
        if (res.ok) {
          const data = await res.json();
          if (data.user && data.user.status === 'ACTIVE') {
            setCurrentUser(data.user);
            if (data.user.vendorId) {
              setActiveVendorIdState(data.user.vendorId);
            }
          }
        }
      } catch (e) {
        // Continue polling silently
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [currentUser]);

  // Idle session timeout listener
  useEffect(() => {
    if (!currentUser) return;

    const timeoutMinutes = companySettings.sessionTimeoutMinutes || 30;
    const timeoutMs = timeoutMinutes * 60 * 1000;

    const handleUserActivity = () => {
      lastActivityRef.current = Date.now();
    };

    window.addEventListener('mousemove', handleUserActivity);
    window.addEventListener('keydown', handleUserActivity);
    window.addEventListener('click', handleUserActivity);
    window.addEventListener('scroll', handleUserActivity);

    const interval = setInterval(() => {
      const elapsed = Date.now() - lastActivityRef.current;
      if (elapsed > timeoutMs) {
        logAudit('SESSION_TIMEOUT', `Session timed out after ${timeoutMinutes} minutes of inactivity.`);
        signOut();
        setAuthError(`Your session has expired after ${timeoutMinutes} minutes of inactivity. Please sign in again.`);
      }
    }, 30000);

    return () => {
      window.removeEventListener('mousemove', handleUserActivity);
      window.removeEventListener('keydown', handleUserActivity);
      window.removeEventListener('click', handleUserActivity);
      window.removeEventListener('scroll', handleUserActivity);
      clearInterval(interval);
    };
  }, [currentUser, companySettings.sessionTimeoutMinutes]);

  // Sync approved invoices for Tally agent
  useEffect(() => {
    fetch('/api/sync-approved-invoices', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ invoices }),
    }).catch(() => {});
  }, [invoices]);

  const refreshAgentList = async () => {
    try {
      const res = await fetch('/api/admin/agents');
      const contentType = res.headers.get('content-type') || '';
      if (res.ok && contentType.includes('application/json')) {
        const data = await res.json();
        setAgents(data);
      }
    } catch (e) {}
  };

const deduplicateInvitations = (list: UserInvitation[]): UserInvitation[] => {
  const map = new Map<string, UserInvitation>();
  for (const inv of list || []) {
    const key = (inv.id || inv.email || '').trim().toLowerCase();
    if (!key) continue;
    if (!map.has(key)) {
      map.set(key, { ...inv, id: key, email: key });
    } else {
      const existing = map.get(key)!;
      const invTime = new Date(inv.createdAt || inv.invitedAt || 0).getTime();
      const existingTime = new Date(existing.createdAt || existing.invitedAt || 0).getTime();
      if (inv.status === 'PENDING' && existing.status !== 'PENDING') {
        map.set(key, { ...inv, id: key, email: key });
      } else if (invTime >= existingTime) {
        map.set(key, { ...inv, id: key, email: key });
      }
    }
  }
  return Array.from(map.values());
};

const deduplicateUsers = (list: UserProfile[]): UserProfile[] => {
  const map = new Map<string, UserProfile>();
  for (const u of list || []) {
    const key = (u.uid || u.email || '').trim().toLowerCase();
    if (!key) continue;
    if (!map.has(key)) {
      map.set(key, u);
    } else {
      const existing = map.get(key)!;
      const uTime = new Date(u.updatedAt || u.createdAt || 0).getTime();
      const existingTime = new Date(existing.updatedAt || existing.createdAt || 0).getTime();
      if (uTime >= existingTime) {
        map.set(key, u);
      }
    }
  }
  return Array.from(map.values());
};

  const refreshInvitations = async () => {
    try {
      const res = await fetch('/api/admin/invitations');
      const contentType = res.headers.get('content-type') || '';
      if (res.ok && contentType.includes('application/json')) {
        const data = await res.json();
        setInvitations(deduplicateInvitations(data));
      }
    } catch (e) {}
  };

  const refreshVendors = async () => {
    try {
      const res = await fetch('/api/admin/vendors');
      const contentType = res.headers.get('content-type') || '';
      if (res.ok && contentType.includes('application/json')) {
        const data = await res.json();
        setVendors(data);
      }
    } catch (e) {}
  };

  const refreshUsers = async () => {
    try {
      const res = await fetch('/api/admin/users');
      const contentType = res.headers.get('content-type') || '';
      if (res.ok && contentType.includes('application/json')) {
        const data = await res.json();
        if (data.users) setAllUsers(deduplicateUsers(data.users));
        if (data.invitations) setInvitations(deduplicateInvitations(data.invitations));
      }
    } catch (e) {}
  };

  const [isSyncing, setIsSyncing] = useState(false);
  const [lastSyncedAt, setLastSyncedAt] = useState<Date | null>(new Date());

  const triggerCrossTabSync = () => {
    try {
      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        const bc = new BroadcastChannel('vms_realtime_sync');
        bc.postMessage({ type: 'SYNC_ALL', timestamp: Date.now() });
        bc.close();
      }
    } catch (e) {}
    try {
      localStorage.setItem('vms_last_sync_timestamp', Date.now().toString());
    } catch (e) {}
  };

  const refreshInvoices = async () => {
    try {
      setIsSyncing(true);
      const res = await fetch('/api/invoices');
      const contentType = res.headers.get('content-type') || '';
      if (res.ok && contentType.includes('application/json')) {
        const data = await res.json();
        if (Array.isArray(data)) {
          setInvoices(data);
          setLastSyncedAt(new Date());
        }
      }
    } catch (e) {
      console.error('Error refreshing invoices:', e);
    } finally {
      setIsSyncing(false);
    }
  };

  const refreshQueries = async () => {
    try {
      const res = await fetch('/api/queries');
      const contentType = res.headers.get('content-type') || '';
      if (res.ok && contentType.includes('application/json')) {
        const data = await res.json();
        if (Array.isArray(data)) {
          setQueries(data);
        }
      }
    } catch (e) {
      console.error('Error refreshing queries:', e);
    }
  };

  const triggerSync = async () => {
    await Promise.all([
      refreshInvoices(),
      refreshQueries(),
      refreshVendors(),
      refreshUsers(),
      refreshInvitations(),
    ]);
    triggerCrossTabSync();
  };

  useEffect(() => {
    refreshAgentList();
    refreshInvitations();
    refreshVendors();
    refreshUsers();
    refreshInvoices();
    refreshQueries();

    // 1. Live automatic polling interval (every 3 seconds)
    const pollTimer = setInterval(() => {
      refreshInvoices();
      refreshQueries();
    }, 3000);

    // 2. Window focus and visibility change listeners (immediate sync when user switches tab)
    const handleSyncOnFocus = () => {
      refreshInvoices();
      refreshQueries();
      refreshVendors();
    };
    window.addEventListener('focus', handleSyncOnFocus);
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        handleSyncOnFocus();
      }
    });

    // 3. Cross-tab BroadcastChannel listener
    let bc: BroadcastChannel | null = null;
    try {
      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        bc = new BroadcastChannel('vms_realtime_sync');
        bc.onmessage = (event) => {
          if (event.data?.type === 'SYNC_ALL') {
            refreshInvoices();
            refreshQueries();
            refreshVendors();
          }
        };
      }
    } catch (e) {}

    // 4. Storage event for cross-browser / cross-tab updates
    const handleStorage = (event: StorageEvent) => {
      if (event.key === 'vms_last_sync_timestamp') {
        refreshInvoices();
        refreshQueries();
        refreshVendors();
      }
    };
    window.addEventListener('storage', handleStorage);

    return () => {
      clearInterval(pollTimer);
      window.removeEventListener('focus', handleSyncOnFocus);
      window.removeEventListener('storage', handleStorage);
      if (bc) bc.close();
    };
  }, []);

  // When user signs in, role changes, or vendor changes, immediately trigger sync
  useEffect(() => {
    if (currentUser?.uid) {
      refreshInvoices();
      refreshQueries();
      refreshVendors();
    }
  }, [currentUser?.uid, currentUser?.role, activeVendorId]);

  // Auth Methods
  const signInWithGoogle = async () => {
    setAuthError(null);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const user = result.user;
      if (!user.email) throw new Error('No email associated with Google account.');

      if (!user.emailVerified) {
        throw new Error('Google account email is not verified. Verified emails required.');
      }

      const profile = await resolveUserProfile(
        user.uid,
        user.email,
        user.displayName || undefined,
        user.emailVerified
      );

      if (profile.status === 'DEACTIVATED') {
        await fbSignOut(auth);
        setCurrentUser(null);
        throw new Error('Your account has been deactivated. Please contact the System Administrator.');
      }

      setCurrentUser(profile);
      if (profile.vendorId) {
        setActiveVendorIdState(profile.vendorId);
      }
    } catch (err: any) {
      console.error('Google Sign-In Error:', err);
      setAuthError(err.message || 'Google Sign-In failed');
      throw err;
    }
  };

  const signInWithEmail = async (email: string, pass: string) => {
    setAuthError(null);
    try {
      const cred = await signInWithEmailAndPassword(auth, email.trim().toLowerCase(), pass);
      const profile = await resolveUserProfile(
        cred.user.uid,
        cred.user.email || email.trim().toLowerCase(),
        cred.user.displayName || undefined,
        cred.user.emailVerified
      );
      if (profile.status === 'DEACTIVATED') {
        await fbSignOut(auth);
        setCurrentUser(null);
        throw new Error('Your account has been deactivated. Please contact the System Administrator.');
      }
      setCurrentUser(profile);
      if (profile.vendorId) {
        setActiveVendorIdState(profile.vendorId);
      }
      logAudit('USER_SIGN_IN', `Signed in with email ${email}`);
    } catch (err: any) {
      setAuthError(err.message || 'Email authentication failed');
      throw err;
    }
  };

  const signUpWithEmail = async (email: string, pass: string, name?: string) => {
    setAuthError(null);
    try {
      const normEmail = email.trim().toLowerCase();
      const cred = await createUserWithEmailAndPassword(auth, normEmail, pass);
      const profile = await resolveUserProfile(
        cred.user.uid,
        normEmail,
        name || cred.user.displayName || undefined,
        cred.user.emailVerified
      );
      setCurrentUser(profile);
      logAudit('USER_REGISTRATION', `New user registered with pending approval: ${normEmail}`);
    } catch (err: any) {
      setAuthError(err.message || 'Registration failed');
      throw err;
    }
  };

  const signOut = async () => {
    try {
      if (currentUser) {
        await fetch('/api/auth/log-signout', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            uid: currentUser.uid,
            email: currentUser.email,
            role: currentUser.role,
          }),
        }).catch(() => {});
        logAudit('USER_SIGN_OUT', 'User signed out voluntarily.');
      }
      await fbSignOut(auth).catch(() => {});
    } finally {
      setCurrentUser(null);
    }
  };

  const clearAuthError = () => {
    setAuthError(null);
  };

  const setActiveVendorId = (vendorId: string) => {
    setActiveVendorIdState(vendorId);
  };

  // Admin User Management
  const assignUserRole = async (
    targetUid: string,
    role: UserRole,
    vendorId?: string,
    canOverride?: boolean,
    status?: UserStatus
  ) => {
    const res = await fetch('/api/admin/users/assign-role', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        adminUid: currentUser?.uid,
        targetUid,
        role,
        vendorId,
        canOverride,
        status,
      }),
    });

    const resJson = await res.json();
    if (!res.ok) {
      throw new Error(resJson.error || 'Failed to assign role');
    }

    setAllUsers((prev) =>
      prev.map((u) => (u.uid === targetUid ? { ...u, ...resJson.user } : u))
    );

    if (currentUser?.uid === targetUid) {
      setCurrentUser(resJson.user);
    }

    logAudit(
      'ADMIN_ROLE_ASSIGN',
      `Assigned role ${role} (Vendor: ${vendorId || 'N/A'}, Override: ${canOverride ? 'YES' : 'NO'}) to user ${targetUid}`
    );
  };

  const activateUser = async (targetUid: string) => {
    const res = await fetch('/api/admin/users/activate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ adminUid: currentUser?.uid, targetUid }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to activate user');
    setAllUsers((prev) => prev.map((u) => (u.uid === targetUid ? { ...u, ...data.user } : u)));
    logAudit('USER_ACTIVATION', `Activated user ${targetUid}`);
  };

  const deactivateUser = async (targetUid: string, reason?: string) => {
    const res = await fetch('/api/admin/users/deactivate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        adminUid: currentUser?.uid,
        targetUid,
        reason: reason || 'Deactivated by Admin',
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to deactivate user');
    setAllUsers((prev) => prev.map((u) => (u.uid === targetUid ? { ...u, ...data.user } : u)));
    if (currentUser?.uid === targetUid) {
      await signOut();
      setAuthError('Your account has been deactivated. Please contact the System Administrator.');
    }
    logAudit('USER_DEACTIVATION', `Deactivated user ${targetUid}. Reason: ${reason || 'Admin deactivation'}`);
  };

  const toggleUserStatus = async (targetUid: string, newStatus: UserStatus, reason?: string) => {
    if (newStatus === 'ACTIVE') {
      await activateUser(targetUid);
    } else {
      await deactivateUser(targetUid, reason);
    }
  };

  const deleteUser = async (targetUid: string, confirmEmail: string, reason?: string) => {
    const res = await fetch(`/api/admin/users/${encodeURIComponent(targetUid)}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        adminUid: currentUser?.uid,
        confirmEmail,
        reason,
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to delete user');
    setAllUsers((prev) => prev.filter((u) => u.uid !== targetUid));
    await refreshInvitations();
    logAudit('DELETE_USER', `Permanently deleted user ${confirmEmail}`);
  };

  const bulkDeleteUsers = async (targetUids: string[], confirmCount: string, reason?: string) => {
    const res = await fetch('/api/admin/users/bulk-delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        adminUid: currentUser?.uid,
        uids: targetUids,
        confirmCount,
        reason,
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to bulk delete users');
    setAllUsers((prev) => prev.filter((u) => !targetUids.includes(u.uid)));
    await refreshInvitations();
    logAudit('BULK_DELETE_USERS', `Bulk deleted ${targetUids.length} users`);
  };

  const checkUserAccess = async (targetUid: string) => {
    const res = await fetch(`/api/admin/users/${encodeURIComponent(targetUid)}/access-status`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to check user access');
    return data;
  };

  const resyncUserAccess = async (targetUid: string) => {
    const res = await fetch(`/api/admin/users/${encodeURIComponent(targetUid)}/resync-access`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ adminUid: currentUser?.uid }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to resync user access');
    setAllUsers((prev) => prev.map((u) => (u.uid === targetUid ? { ...u, ...data.user } : u)));
    logAudit('USER_ACCESS_RESYNCED', `Resynced access for user ${targetUid}`);
  };

  const resolveDuplicateUsers = async (canonicalEmail: string, keepUid: string) => {
    const res = await fetch('/api/admin/users/resolve-duplicate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        adminUid: currentUser?.uid,
        canonicalEmail,
        keepUid,
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to resolve duplicate users');
    await refreshUsers();
    logAudit('RESOLVE_DUPLICATE_USERS', `Resolved duplicates for ${canonicalEmail}, kept UID ${keepUid}`);
  };

  // Invitation Lifecycle Methods
  const createInvitation = async (
    email: string,
    role: 'VENDOR' | 'ACCOUNTS_EXECUTIVE' | 'ADMIN',
    vendorId?: string,
    canOverride?: boolean
  ) => {
    const res = await fetch('/api/admin/invitations/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        adminUid: currentUser?.uid,
        email: email.trim().toLowerCase(),
        role,
        vendorId,
        canOverride,
      }),
    });

    const resJson = await res.json();
    if (!res.ok) throw new Error(resJson.error || 'Failed to create invitation');

    await refreshInvitations();
    await refreshUsers();
    logAudit('CREATE_INVITATION', `Pre-registered invitation for ${email} with role ${role}`);
  };

  const editInvitation = async (
    id: string,
    role: 'VENDOR' | 'ACCOUNTS_EXECUTIVE' | 'ADMIN',
    vendorId?: string,
    canOverride?: boolean
  ) => {
    const res = await fetch(`/api/admin/invitations/${encodeURIComponent(id)}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        adminUid: currentUser?.uid,
        role,
        vendorId,
        canOverride,
      }),
    });

    const resJson = await res.json();
    if (!res.ok) throw new Error(resJson.error || 'Failed to update invitation');

    await refreshInvitations();
    logAudit('EDIT_INVITATION', `Updated invitation for ${id} (Role: ${role})`);
  };

  const resendInvitation = async (id: string) => {
    const res = await fetch(`/api/admin/invitations/${encodeURIComponent(id)}/resend`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        adminUid: currentUser?.uid,
      }),
    });

    const resJson = await res.json();
    if (!res.ok) throw new Error(resJson.error || 'Failed to resend invitation');

    await refreshInvitations();
    logAudit('RESEND_INVITATION', `Resent invitation email to ${id}`);
  };

  const deleteInvitation = async (id: string) => {
    const res = await fetch(
      `/api/admin/invitations/${encodeURIComponent(id)}?adminUid=${encodeURIComponent(currentUser?.uid || 'admin')}`,
      {
        method: 'DELETE',
      }
    );

    const resJson = await res.json();
    if (!res.ok) throw new Error(resJson.error || 'Failed to delete invitation');

    await refreshInvitations();
    logAudit('REVOKE_INVITATION', `Revoked and deleted invitation for ${id}`);
  };

  const bulkDeleteInvitations = async (ids: string[]) => {
    const res = await fetch('/api/admin/invitations/bulk-delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ids,
        adminUid: currentUser?.uid,
      }),
    });

    const resJson = await res.json();
    if (!res.ok) throw new Error(resJson.error || 'Failed to bulk delete invitations');

    await refreshInvitations();
    logAudit('BULK_REVOKE_INVITATIONS', `Bulk deleted ${resJson.count} pending invitations`);
  };

  // Vendor Management & History Protection Methods
  const checkVendorDeleteEligibility = async (vendorId: string) => {
    const res = await fetch(`/api/admin/vendors/${encodeURIComponent(vendorId)}/delete-eligibility`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Eligibility check failed');
    return data;
  };

  const deleteVendorPermanent = async (vendorId: string, confirmVendorName: string, reason: string) => {
    const res = await fetch(`/api/admin/vendors/${encodeURIComponent(vendorId)}`, {
      method: 'DELETE',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        confirmVendorName,
        reason,
        adminUid: currentUser?.uid,
      }),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to permanently delete vendor');

    await refreshVendors();
    await refreshInvitations();
    await refreshUsers();
    logAudit('DELETE_VENDOR_PERMANENT', `Permanently deleted vendor ${vendorId}. Reason: ${reason}`);
  };

  const archiveVendor = async (vendorId: string, reason: string) => {
    const res = await fetch(`/api/admin/vendors/${encodeURIComponent(vendorId)}/archive`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        reason,
        adminUid: currentUser?.uid,
      }),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to archive vendor');

    await refreshVendors();
    await refreshUsers();
    logAudit('ARCHIVE_VENDOR', `Archived vendor ${vendorId}. Reason: ${reason}`);
  };

  const restoreVendor = async (vendorId: string, reason?: string) => {
    const res = await fetch(`/api/admin/vendors/${encodeURIComponent(vendorId)}/restore`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        reason: reason || 'Administrator restored vendor',
        adminUid: currentUser?.uid,
      }),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to restore vendor');

    await refreshVendors();
    logAudit('RESTORE_VENDOR', `Restored vendor ${vendorId} to active master`);
  };

  const bulkDeleteVendors = async (vendorIds: string[], reason: string) => {
    const res = await fetch('/api/admin/vendors/bulk-delete', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        vendorIds,
        reason,
        adminUid: currentUser?.uid,
      }),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Failed to perform bulk vendor deletion');

    await refreshVendors();
    await refreshUsers();
    logAudit('BULK_VENDOR_OPERATION', `Bulk vendor operation completed: ${data.deletedCount} deleted, ${data.archivedCount} archived`);
  };

  // Core Data Mutations
  const saveInvoice = async (invoice: InvoiceRecord, auditRemark?: string) => {
    // Optimistic local state update
    setInvoices((prev) => {
      const idx = prev.findIndex((i) => i.id === invoice.id || (i.invoiceNumber === invoice.invoiceNumber && i.vendorId === invoice.vendorId));
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = { ...invoice, updatedAt: new Date().toISOString() };
        return updated;
      }
      return [invoice, ...prev];
    });

    try {
      const res = await fetch('/api/invoices', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          invoice,
          auditRemark,
          userEmail: currentUser?.email,
        }),
      });
      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || `Server error (${res.status}) saving invoice`);
      }
      const data = await res.json();
      if (data.invoice) {
        setInvoices((prev) => {
          const idx = prev.findIndex((i) => i.id === data.invoice.id || (i.invoiceNumber === data.invoice.invoiceNumber && i.vendorId === data.invoice.vendorId));
          if (idx >= 0) {
            const updated = [...prev];
            updated[idx] = data.invoice;
            return updated;
          }
          return [data.invoice, ...prev];
        });
      }
      // Broadcast real-time sync to all open tabs and background pollers
      triggerCrossTabSync();
      await refreshInvoices();
    } catch (err) {
      console.error('Failed to persist invoice to server:', err);
      throw err;
    }

    logAudit(
      'SAVE_INVOICE',
      auditRemark || 'Invoice particulars saved/updated',
      invoice.id,
      invoice.status,
      invoice.status
    );
  };

  const deleteInvoice = async (invoiceId: string, reason?: string) => {
    // Optimistic removal
    setInvoices((prev) => prev.filter((i) => i.id !== invoiceId));
    setQueries((prev) => prev.filter((q) => q.invoiceId !== invoiceId));
    setMessages((prev) => prev.filter((m) => m.invoiceId !== invoiceId));

    try {
      const res = await fetch(`/api/invoices/${encodeURIComponent(invoiceId)}`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          reason: reason || 'Deleted by user',
          userEmail: currentUser?.email,
          userRole: currentUser?.role,
          userUid: currentUser?.uid,
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'Failed to delete invoice');
      }

      triggerCrossTabSync();
      await refreshInvoices();
      await refreshQueries();
    } catch (err) {
      console.error('Failed to delete invoice on server:', err);
      await refreshInvoices();
      await refreshQueries();
      throw err;
    }

    logAudit(
      'DELETE_INVOICE',
      reason || `Deleted invoice ${invoiceId}`,
      invoiceId
    );
  };

  const resolveAndResubmitInvoice = async (
    invoiceId: string,
    queryId?: string,
    resolutionMessage?: string
  ) => {
    // Optimistic update
    setInvoices((prev) =>
      prev.map((i) => (i.id === invoiceId ? { ...i, status: 'RESUBMITTED', updatedAt: new Date().toISOString() } : i))
    );
    setQueries((prev) =>
      prev.map((q) => (q.invoiceId === invoiceId || q.id === queryId ? { ...q, status: 'RESOLVED' } : q))
    );

    try {
      const res = await fetch(`/api/invoices/${encodeURIComponent(invoiceId)}/resolve-query`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          queryId,
          resolutionMessage,
          userUid: currentUser?.uid,
          userName: currentUser?.displayName || 'Vendor Representative',
          userRole: currentUser?.role || 'VENDOR',
          userEmail: currentUser?.email,
        }),
      });

      if (!res.ok) {
        const errJson = await res.json().catch(() => ({}));
        throw new Error(errJson.error || 'Failed to resolve and resubmit invoice');
      }

      const data = await res.json();
      if (data.message) {
        setMessages((prev) => [...prev, data.message]);
      }

      triggerCrossTabSync();
      await refreshInvoices();
      await refreshQueries();
    } catch (err) {
      console.error('Failed to resolve query and resubmit invoice:', err);
      await refreshInvoices();
      await refreshQueries();
      throw err;
    }

    logAudit(
      'RESOLVE_AND_RESUBMIT',
      resolutionMessage || `Clarification query marked resolved and invoice ${invoiceId} resubmitted to Accounts Review`,
      invoiceId,
      'CLARIFICATION_REQUESTED',
      'RESUBMITTED'
    );
  };

  const updateInvoiceStatus = async (
    invoiceId: string,
    newStatus: InvoiceRecord['status'],
    remarks: string,
    extraFields?: Partial<InvoiceRecord>
  ): Promise<{ success: boolean; error?: string }> => {
    const inv = invoices.find((i) => i.id === invoiceId);
    const oldStatus = inv?.status || 'UNKNOWN';

    // Optimistic local update
    setInvoices((prev) =>
      prev.map((i) => {
        if (i.id === invoiceId) {
          return {
            ...i,
            status: newStatus,
            updatedAt: new Date().toISOString(),
            ...extraFields,
          };
        }
        return i;
      })
    );

    if (newStatus === 'RESUBMITTED' || newStatus === 'UNDER_REVIEW') {
      setQueries((prev) =>
        prev.map((q) => (q.invoiceId === invoiceId ? { ...q, status: 'RESOLVED' } : q))
      );
    }

    try {
      const res = await fetch(`/api/invoices/${encodeURIComponent(invoiceId)}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          newStatus,
          remarks,
          reviewedByUid: currentUser?.uid,
          reviewedByName: currentUser?.displayName,
          overrideReason: extraFields?.overrideReason,
          rejectionReason: extraFields?.rejectionReason,
          extraFields,
          userEmail: currentUser?.email,
        }),
      });
      if (res.ok) {
        triggerCrossTabSync();
        await refreshInvoices();
        await refreshQueries();
        logAudit(`TRANSITION_TO_${newStatus}`, remarks, invoiceId, oldStatus, newStatus);
        return { success: true };
      } else {
        const errJson = await res.json().catch(() => ({}));
        const errMsg = errJson?.error || `Server returned HTTP ${res.status}`;
        console.error('Failed to update invoice status on server:', errMsg);
        // Refresh to revert optimistic update
        await refreshInvoices();
        return { success: false, error: errMsg };
      }
    } catch (err: any) {
      console.error('Failed to update invoice status on server:', err);
      await refreshInvoices();
      return { success: false, error: err?.message || 'Network error updating invoice status' };
    }
  };

  const saveVendor = async (vendor: VendorMaster) => {
    setVendors((prev) => {
      const idx = prev.findIndex((v) => v.id === vendor.id);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = vendor;
        return updated;
      }
      return [...prev, vendor];
    });
  };

  const approveVendor = async (vendorId: string) => {
    await fetch(`/api/admin/vendors/approve/${vendorId}`, { method: 'POST' }).catch(() => {});
    setVendors((prev) =>
      prev.map((v) => (v.id === vendorId ? { ...v, status: 'ACTIVE', updatedAt: new Date().toISOString() } : v))
    );
    logAudit('APPROVE_VENDOR', `Approved vendor registration for vendor ID ${vendorId}`);
  };

  const rejectVendor = async (vendorId: string) => {
    await fetch(`/api/admin/vendors/reject/${vendorId}`, { method: 'POST' }).catch(() => {});
    setVendors((prev) =>
      prev.map((v) => (v.id === vendorId ? { ...v, status: 'REJECTED', updatedAt: new Date().toISOString() } : v))
    );
    logAudit('REJECT_VENDOR', `Rejected vendor registration for vendor ID ${vendorId}`);
  };

  const updateCompanySettings = async (settings: Partial<CompanySettings>) => {
    setCompanySettings((prev) => ({
      ...prev,
      ...settings,
      updatedAt: new Date().toISOString(),
    }));

    try {
      const res = await fetch('/api/company-settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...settings,
          adminUid: currentUser?.uid,
          userEmail: currentUser?.email,
        }),
      });
      if (res.ok) {
        const data = await res.json();
        if (data.companySettings) {
          setCompanySettings(data.companySettings);
        }
      }
    } catch (err) {
      console.warn('Failed to persist company settings to server:', err);
    }
  };

  const saveLedgerMapping = async (mapping: LedgerMappingRule) => {
    setLedgerMappings((prev) => {
      const idx = prev.findIndex((m) => m.id === mapping.id);
      if (idx >= 0) {
        const updated = [...prev];
        updated[idx] = mapping;
        return updated;
      }
      return [...prev, mapping];
    });

    try {
      await fetch('/api/ledger-mappings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(mapping),
      });
    } catch (err) {
      console.warn('Failed to sync ledger mapping to server:', err);
    }
  };

  const deleteLedgerMapping = async (id: string) => {
    setLedgerMappings((prev) => prev.filter((m) => m.id !== id));
    try {
      await fetch(`/api/ledger-mappings/${encodeURIComponent(id)}`, {
        method: 'DELETE',
      });
    } catch (err) {
      console.warn('Failed to delete ledger mapping on server:', err);
    }
  };

  const addQuery = async (queryData: Omit<ClarificationQuery, 'id' | 'createdAt'>) => {
    const newQuery: ClarificationQuery = {
      ...queryData,
      id: `query_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setQueries((prev) => [newQuery, ...prev]);

    try {
      await fetch('/api/queries', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...queryData,
          userEmail: currentUser?.email,
        }),
      });
      await refreshInvoices();
    } catch (err) {
      console.error('Failed to post query to server:', err);
    }

    logAudit(
      'RAISE_QUERY',
      `Clarification requested: ${queryData.queryText}`,
      queryData.invoiceId
    );
  };

  const addMessage = async (msg: Omit<ThreadMessage, 'id' | 'createdAt'>) => {
    const newMsg: ThreadMessage = {
      ...msg,
      id: `msg_${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, newMsg]);

    try {
      if (msg.queryId) {
        await fetch(`/api/queries/${encodeURIComponent(msg.queryId)}/messages`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(msg),
        });
      }
    } catch (err) {
      console.error('Failed to post thread message to server:', err);
    }
  };

  const currentRole = currentUser?.role || 'PENDING';
  const isAuthenticated = Boolean(currentUser);
  const activeVendor =
    (currentUser?.vendorId ? vendors.find((v) => v.id === currentUser.vendorId) : null) ||
    vendors.find((v) => v.id === activeVendorId) ||
    vendors[0] ||
    null;

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        currentRole,
        isAuthenticated,
        activeVendor,
        vendors,
        invoices,
        allUsers,
        invitations,
        companySettings,
        ledgerMappings,
        queries,
        messages,
        auditLogs,
        agents,
        hsnMaster,
        isLoading,
        authError,
        signInWithGoogle,
        signInWithEmail,
        signUpWithEmail,
        signOut,
        clearAuthError,
        setActiveVendorId,
        assignUserRole,
        toggleUserStatus,
        activateUser,
        deactivateUser,
        deleteUser,
        bulkDeleteUsers,
        checkUserAccess,
        resyncUserAccess,
        resolveDuplicateUsers,
        createInvitation,
        editInvitation,
        resendInvitation,
        deleteInvitation,
        bulkDeleteInvitations,
        refreshInvitations,
        refreshUsers,
        refreshInvoices,
        refreshQueries,
        triggerSync,
        isSyncing,
        lastSyncedAt,
        checkVendorDeleteEligibility,
        deleteVendorPermanent,
        archiveVendor,
        restoreVendor,
        bulkDeleteVendors,
        refreshVendors,
        saveInvoice,
        deleteInvoice,
        resolveAndResubmitInvoice,
        updateInvoiceStatus,
        saveVendor,
        approveVendor,
        rejectVendor,
        updateCompanySettings,
        saveLedgerMapping,
        deleteLedgerMapping,
        addQuery,
        addMessage,
        refreshAgentList,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

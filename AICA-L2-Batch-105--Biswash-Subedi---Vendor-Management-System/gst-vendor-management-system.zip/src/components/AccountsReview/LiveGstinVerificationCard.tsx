/**
 * Real-Time GSTIN Verification Card (https://gstin.cloud/api/v1/verify)
 * Triggers automatically when an invoice is opened.
 * Fetches & displays:
 * 1. Core Particulars (Legal Name, Trade Name, Constitution, Taxpayer Type, Address, Status, Filing Frequency)
 * 2. Last Return Filed (Type, Period, Date of Filing)
 * 3. 6-Month Filing History Table (GSTR-1, GSTR-3B, IFF)
 */

import React, { useState, useEffect } from 'react';
import { GSTINVerificationResult } from '../../types/index.ts';
import {
  ShieldCheck,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  RefreshCw,
  ExternalLink,
  Building,
  Calendar,
  FileSpreadsheet,
  Check,
  Clock,
  Info,
} from 'lucide-react';

interface LiveGstinVerificationCardProps {
  gstin: string;
  vendorName?: string;
  vendorId?: string;
  onVerificationComplete?: (result: GSTINVerificationResult) => void;
}

export const LiveGstinVerificationCard: React.FC<LiveGstinVerificationCardProps> = ({
  gstin,
  vendorName,
  vendorId,
  onVerificationComplete,
}) => {
  const [data, setData] = useState<GSTINVerificationResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [isExpanded, setIsExpanded] = useState<boolean>(true);

  const fetchGstinVerification = async (force: boolean = false) => {
    if (!gstin || gstin.trim().length !== 15) return;
    setIsLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/gstin/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gstin: gstin.trim().toUpperCase(),
          vendorId,
          force,
        }),
      });

      const json = await res.json();
      if (res.ok && json.verification) {
        setData(json.verification);
        if (onVerificationComplete) {
          onVerificationComplete(json.verification);
        }
      } else {
        setError(json.error || 'Failed to verify GSTIN against live portal');
      }
    } catch (err: any) {
      setError(err.message || 'Network error verifying GSTIN');
    } finally {
      setIsLoading(false);
    }
  };

  // Automatically trigger on mount or whenever gstin changes
  useEffect(() => {
    fetchGstinVerification();
  }, [gstin, vendorId]);

  if (!gstin) return null;

  const isNameMismatch =
    data && vendorName && data.legalName.toLowerCase().trim() !== vendorName.toLowerCase().trim();

  return (
    <div className="bg-white border border-[#D9E2EC] rounded-[6px] shadow-xs overflow-hidden">
      {/* Top Header Banner */}
      <div className="p-3.5 bg-[#F5F7FA] border-b border-[#D9E2EC] flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center space-x-2.5">
          <div className="p-1.5 bg-[#EBF1FA] text-[#1F4E9C] rounded-[4px]">
            <ShieldCheck className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <span className="text-xs font-bold text-[#0B2545]">
                Real-Time GSTIN Validation
              </span>
              <span className="text-[10px] font-mono font-semibold px-2 py-0.5 rounded bg-white text-[#1F4E9C] border border-[#D9E2EC]">
                {gstin}
              </span>
              {data && (
                <span
                  className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                    data.status === 'ACTIVE'
                      ? 'bg-[#EBF7EE] text-[#1B7F3B] border border-[#C3E8CC]'
                      : 'bg-[#FEF3F2] text-[#B42318] border border-[#FECDCA]'
                  }`}
                >
                  {data.status}
                </span>
              )}
            </div>
            <p className="text-[11px] text-[#52606D]">
              Direct statutory check via <code className="text-[#1F4E9C]">https://gstin.cloud/api/v1/verify</code>
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          {data && (
            <span className="text-[10px] text-[#52606D] font-mono hidden sm:inline">
              Verified: {new Date(data.verifiedAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </span>
          )}

          <button
            type="button"
            onClick={() => fetchGstinVerification(true)}
            disabled={isLoading}
            className="p-1.5 text-[#1F4E9C] hover:bg-[#EBF1FA] rounded border border-[#D9E2EC] bg-white transition disabled:opacity-40"
            title="Re-verify GSTIN"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          </button>

          <button
            type="button"
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-xs text-[#1F4E9C] hover:underline font-semibold px-2 py-1"
          >
            {isExpanded ? 'Collapse' : 'View Details'}
          </button>
        </div>
      </div>

      {/* Body Content */}
      {isExpanded && (
        <div className="p-4 space-y-4">
          
          {isLoading && !data && (
            <div className="py-6 text-center text-xs text-[#52606D] flex items-center justify-center space-x-2">
              <RefreshCw className="w-4 h-4 animate-spin text-[#1F4E9C]" />
              <span>Contacting gstin.cloud verification gateway for GSTIN {gstin}...</span>
            </div>
          )}

          {error && (
            <div className="p-3 bg-[#FEF3F2] border border-[#FECDCA] rounded-[6px] text-xs text-[#B42318] flex items-center space-x-2">
              <AlertTriangle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {data && (
            <>
              {/* Notice Banner (if API Key was fallback or notice present) */}
              {data.errorMessage && (
                <div className="p-2.5 bg-[#FFF7E6] border border-[#FFE7BA] rounded-[4px] text-[11px] text-[#B26A00] flex items-start space-x-1.5">
                  <Info className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                  <span>{data.errorMessage}</span>
                </div>
              )}

              {/* 1. CORE PARTICULARS (Required by User) */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 p-3 bg-[#F5F7FA] border border-[#D9E2EC] rounded-[6px] text-xs">
                <div>
                  <span className="text-[#52606D] block text-[11px]">Legal Entity Name</span>
                  <strong className="text-[#0B2545] font-semibold block">{data.legalName}</strong>
                  {isNameMismatch && (
                    <span className="text-[10px] text-[#B26A00] font-medium block mt-0.5">
                      ⚠️ Differs from invoice name: &quot;{vendorName}&quot;
                    </span>
                  )}
                </div>

                <div>
                  <span className="text-[#52606D] block text-[11px]">Trade Name</span>
                  <span className="text-[#1F2933] font-medium block">{data.tradeName || '-'}</span>
                </div>

                <div>
                  <span className="text-[#52606D] block text-[11px]">Business Constitution</span>
                  <span className="text-[#1F4E9C] font-semibold block">{data.constitutionOfBusiness}</span>
                </div>

                <div>
                  <span className="text-[#52606D] block text-[11px]">Taxpayer Type</span>
                  <span className="text-[#1F2933] font-medium block">{data.taxpayerType}</span>
                </div>

                <div>
                  <span className="text-[#52606D] block text-[11px]">Registration Status</span>
                  <span
                    className={`inline-block px-1.5 py-0.2 rounded text-[10px] font-bold ${
                      data.status === 'ACTIVE'
                        ? 'bg-[#EBF7EE] text-[#1B7F3B]'
                        : 'bg-[#FEF3F2] text-[#B42318]'
                    }`}
                  >
                    {data.status} (Reg: {data.registrationDate || '01-07-2017'})
                  </span>
                </div>

                <div>
                  <span className="text-[#52606D] block text-[11px]">Filing Frequency</span>
                  <span className="text-[#0B2545] font-semibold block font-mono">
                    {data.filingFrequency === 'MONTHLY' ? 'Monthly' : 'Quarterly (QRMP)'}
                  </span>
                </div>

                <div className="md:col-span-3 pt-1 border-t border-[#D9E2EC]/60">
                  <span className="text-[#52606D] block text-[11px]">Principal Place of Business</span>
                  <span className="text-[#1F2933] text-[11px] block">{data.principalPlaceOfBusiness}</span>
                </div>
              </div>

              {/* 2. LAST RETURN FILED (Required by User) */}
              <div className="p-3 bg-[#EBF1FA]/40 border border-[#D9E2EC] rounded-[6px] text-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
                <div className="flex items-center space-x-2">
                  <div className="p-1.5 bg-white text-[#1B7F3B] rounded border border-[#C8E6C9]">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="text-[11px] font-semibold uppercase tracking-wider text-[#1F4E9C]">
                      Last Return Filed
                    </div>
                    <div className="text-xs font-bold text-[#0B2545]">
                      {data.lastReturnFiled.returnType} • Period: {data.lastReturnFiled.taxPeriod}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-3 text-xs">
                  <div>
                    <span className="text-[#52606D] block text-[11px]">Date of Filing:</span>
                    <strong className="text-[#1B7F3B] font-mono">{data.lastReturnFiled.filingDate}</strong>
                  </div>
                  {data.lastReturnFiled.arn && (
                    <div>
                      <span className="text-[#52606D] block text-[11px]">Filing ARN:</span>
                      <span className="font-mono text-[#52606D] text-[11px]">{data.lastReturnFiled.arn}</span>
                    </div>
                  )}
                </div>
              </div>

              {/* 3. 6-MONTH FILING HISTORY TABLE (Required by User) */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-[#0B2545] uppercase tracking-wider flex items-center space-x-1.5">
                    <FileSpreadsheet className="w-3.5 h-3.5 text-[#1F4E9C]" />
                    <span>6-Month Statutory Filing History Compliance</span>
                  </h4>
                  <span className="text-[11px] text-[#52606D]">
                    Mandatory Rule 36(4) ITC Compliance Audit
                  </span>
                </div>

                <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545] font-semibold text-[11px] uppercase">
                      <tr>
                        <th className="py-2 px-3">Tax Period</th>
                        <th className="py-2 px-3">GSTR-1 Status</th>
                        <th className="py-2 px-3">GSTR-3B Status</th>
                        {data.filingFrequency === 'QUARTERLY_QRMP' && (
                          <th className="py-2 px-3">IFF Status</th>
                        )}
                        <th className="py-2 px-3 text-right">Acknowledgement (ARN)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#D9E2EC]">
                      {data.filingHistory.map((m) => (
                        <tr key={m.taxPeriod} className="hover:bg-[#F5F7FA]/60 transition">
                          <td className="py-2.5 px-3 font-semibold text-[#0B2545] font-mono">
                            {m.monthName}
                          </td>

                          {/* GSTR-1 */}
                          <td className="py-2.5 px-3">
                            <span
                              className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                                m.gstr1Status === 'FILED'
                                  ? 'bg-[#EBF7EE] text-[#1B7F3B]'
                                  : m.gstr1Status === 'NOT_APPLICABLE'
                                  ? 'bg-[#F5F7FA] text-[#52606D]'
                                  : 'bg-[#FEF3F2] text-[#B42318]'
                              }`}
                            >
                              {m.gstr1Status === 'FILED' ? (
                                <Check className="w-3 h-3" />
                              ) : m.gstr1Status === 'NOT_APPLICABLE' ? null : (
                                <Clock className="w-3 h-3" />
                              )}
                              <span>
                                {m.gstr1Status} {m.gstr1Dof ? `(${m.gstr1Dof})` : ''}
                              </span>
                            </span>
                          </td>

                          {/* GSTR-3B */}
                          <td className="py-2.5 px-3">
                            <span
                              className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                                m.gstr3bStatus === 'FILED'
                                  ? 'bg-[#EBF7EE] text-[#1B7F3B]'
                                  : m.gstr3bStatus === 'NOT_APPLICABLE'
                                  ? 'bg-[#F5F7FA] text-[#52606D]'
                                  : 'bg-[#FEF3F2] text-[#B42318]'
                              }`}
                            >
                              {m.gstr3bStatus === 'FILED' ? (
                                <Check className="w-3 h-3" />
                              ) : m.gstr3bStatus === 'NOT_APPLICABLE' ? null : (
                                <Clock className="w-3 h-3" />
                              )}
                              <span>
                                {m.gstr3bStatus} {m.gstr3bDof ? `(${m.gstr3bDof})` : ''}
                              </span>
                            </span>
                          </td>

                          {/* IFF (if QRMP) */}
                          {data.filingFrequency === 'QUARTERLY_QRMP' && (
                            <td className="py-2.5 px-3">
                              <span
                                className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded text-[10px] font-bold ${
                                  m.iffStatus === 'FILED'
                                    ? 'bg-[#EBF7EE] text-[#1B7F3B]'
                                    : 'bg-[#F5F7FA] text-[#52606D]'
                                }`}
                              >
                                <span>{m.iffStatus || 'N/A'}</span>
                              </span>
                            </td>
                          )}

                          <td className="py-2.5 px-3 text-right font-mono text-[11px] text-[#52606D]">
                            {m.gstr3bArn || m.gstr1Arn || '-'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </>
          )}

        </div>
      )}
    </div>
  );
};

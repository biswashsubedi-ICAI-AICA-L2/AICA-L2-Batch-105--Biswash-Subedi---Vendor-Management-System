/**
 * Edit Vendor Master Modal
 * Allows Accounts Administrators to update vendor master details:
 * - Legal Entity Name & Trade Name
 * - 15-Digit GSTIN (with auto PAN & State synchronization)
 * - State Code & Name
 * - MSME Status & Udyam Number
 * - Turnover Category & Composition Scheme
 * - Contact Details & Registered Address
 * - Bank Account Particulars
 * - Tally Prime Ledger Name
 */

import React, { useState, useEffect } from 'react';
import {
  Building2,
  X,
  CheckCircle2,
  AlertCircle,
  CreditCard,
  Phone,
  Mail,
  MapPin,
  Save,
  FileCheck2,
  Edit2,
  ShieldCheck,
} from 'lucide-react';
import { VendorMaster } from '../../types/index.ts';

interface EditVendorModalProps {
  isOpen: boolean;
  onClose: () => void;
  vendor: VendorMaster | null;
  onVendorUpdated: (vendor: VendorMaster) => void;
  adminUid?: string;
}

const INDIAN_STATES_MAP: Record<string, string> = {
  '01': 'Jammu & Kashmir',
  '02': 'Himachal Pradesh',
  '03': 'Punjab',
  '04': 'Chandigarh',
  '05': 'Uttarakhand',
  '06': 'Haryana',
  '07': 'Delhi',
  '08': 'Rajasthan',
  '09': 'Uttar Pradesh',
  '10': 'Bihar',
  '11': 'Sikkim',
  '12': 'Arunachal Pradesh',
  '13': 'Nagaland',
  '14': 'Manipur',
  '15': 'Mizoram',
  '16': 'Tripura',
  '17': 'Meghalaya',
  '18': 'Assam',
  '19': 'West Bengal',
  '20': 'Jharkhand',
  '21': 'Odisha',
  '22': 'Chhattisgarh',
  '23': 'Madhya Pradesh',
  '24': 'Gujarat',
  '26': 'Dadra & Nagar Haveli and Daman & Diu',
  '27': 'Maharashtra',
  '29': 'Karnataka',
  '30': 'Goa',
  '31': 'Lakshadweep',
  '32': 'Kerala',
  '33': 'Tamil Nadu',
  '34': 'Puducherry',
  '35': 'Andaman & Nicobar Islands',
  '36': 'Telangana',
  '37': 'Andhra Pradesh',
  '38': 'Ladakh',
};

export const EditVendorModal: React.FC<EditVendorModalProps> = ({
  isOpen,
  onClose,
  vendor,
  onVendorUpdated,
  adminUid,
}) => {
  if (!isOpen || !vendor) return null;

  const [legalName, setLegalName] = useState(vendor.legalName || '');
  const [tradeName, setTradeName] = useState(vendor.tradeName || '');
  const [gstin, setGstin] = useState(vendor.gstin || '');
  const [pan, setPan] = useState(vendor.pan || '');
  const [stateCode, setStateCode] = useState(vendor.stateCode || '27');
  const [stateName, setStateName] = useState(vendor.stateName || 'Maharashtra');
  const [address, setAddress] = useState(vendor.address || '');
  const [pincode, setPincode] = useState(vendor.pincode || '');
  const [contactPerson, setContactPerson] = useState(vendor.contactPerson || '');
  const [email, setEmail] = useState(vendor.email || '');
  const [phone, setPhone] = useState(vendor.phone || '');
  const [turnoverCategory, setTurnoverCategory] = useState<'UP_TO_5CR' | 'ABOVE_5CR'>(
    vendor.turnoverCategory || 'ABOVE_5CR'
  );
  const [isMsme, setIsMsme] = useState(vendor.isMsme || false);
  const [msmeRegistrationNumber, setMsmeRegistrationNumber] = useState(
    vendor.msmeRegistrationNumber || ''
  );
  const [isComposition, setIsComposition] = useState(vendor.isComposition || false);
  const [bankAccountName, setBankAccountName] = useState(vendor.bankAccountName || '');
  const [bankAccountNumber, setBankAccountNumber] = useState(vendor.bankAccountNumber || '');
  const [bankIfsc, setBankIfsc] = useState(vendor.bankIfsc || '');
  const [bankName, setBankName] = useState(vendor.bankName || '');
  const [tallyLedgerName, setTallyLedgerName] = useState(vendor.tallyLedgerName || '');

  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Re-sync whenever vendor changes
  useEffect(() => {
    if (vendor) {
      setLegalName(vendor.legalName || '');
      setTradeName(vendor.tradeName || '');
      setGstin(vendor.gstin || '');
      setPan(vendor.pan || '');
      setStateCode(vendor.stateCode || '27');
      setStateName(vendor.stateName || 'Maharashtra');
      setAddress(vendor.address || '');
      setPincode(vendor.pincode || '');
      setContactPerson(vendor.contactPerson || '');
      setEmail(vendor.email || '');
      setPhone(vendor.phone || '');
      setTurnoverCategory(vendor.turnoverCategory || 'ABOVE_5CR');
      setIsMsme(vendor.isMsme || false);
      setMsmeRegistrationNumber(vendor.msmeRegistrationNumber || '');
      setIsComposition(vendor.isComposition || false);
      setBankAccountName(vendor.bankAccountName || '');
      setBankAccountNumber(vendor.bankAccountNumber || '');
      setBankIfsc(vendor.bankIfsc || '');
      setBankName(vendor.bankName || '');
      setTallyLedgerName(vendor.tallyLedgerName || '');
      setError(null);
    }
  }, [vendor]);

  // Handle GSTIN changes with auto state & PAN extraction
  const handleGstinChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.toUpperCase().trim();
    setGstin(val);

    if (val.length >= 2) {
      const code = val.slice(0, 2);
      setStateCode(code);
      if (INDIAN_STATES_MAP[code]) {
        setStateName(INDIAN_STATES_MAP[code]);
      }
    }
    if (val.length >= 12) {
      setPan(val.slice(2, 12));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!legalName.trim()) {
      setError('Legal Entity Name is mandatory.');
      return;
    }

    const cleanGstin = gstin.trim().toUpperCase();
    if (!/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(cleanGstin)) {
      setError('Please enter a valid 15-character GSTIN (e.g. 27AAACA1234A1Z1).');
      return;
    }

    if (isMsme && !msmeRegistrationNumber.trim()) {
      setError('MSME Udyam Registration Number is mandatory when MSME flag is enabled.');
      return;
    }

    setIsSubmitting(true);
    try {
      const payload: VendorMaster = {
        ...vendor,
        legalName: legalName.trim(),
        tradeName: tradeName.trim() || legalName.trim(),
        gstin: cleanGstin,
        pan: pan.trim().toUpperCase() || cleanGstin.slice(2, 12),
        stateCode: stateCode.trim() || cleanGstin.slice(0, 2),
        stateName: stateName.trim() || 'Maharashtra',
        address: address.trim() || 'Registered Premises',
        pincode: pincode.trim() || '400001',
        contactPerson: contactPerson.trim() || 'Finance Lead',
        email: email.trim().toLowerCase(),
        phone: phone.trim(),
        turnoverCategory,
        isMsme,
        msmeRegistrationNumber: isMsme ? msmeRegistrationNumber.trim() : undefined,
        isComposition,
        bankAccountName: bankAccountName.trim() || legalName.trim(),
        bankAccountNumber: bankAccountNumber.trim(),
        bankIfsc: bankIfsc.trim().toUpperCase(),
        bankName: bankName.trim(),
        tallyLedgerName: tallyLedgerName.trim() || legalName.trim(),
        updatedAt: new Date().toISOString(),
      };

      const res = await fetch(`/api/admin/vendors/${vendor.id}/update`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...payload,
          adminUid: adminUid || 'admin',
        }),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || 'Failed to update vendor on server');
      }

      const resData = await res.json().catch(() => ({ vendor: payload }));
      onVendorUpdated(resData.vendor || payload);
      onClose();
    } catch (err: any) {
      setError(err.message || 'An error occurred while updating the vendor.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white border border-[#D9E2EC] w-full max-w-2xl rounded-[8px] shadow-2xl overflow-hidden my-8 max-h-[92vh] flex flex-col">
        
        {/* Header */}
        <div className="px-6 py-4 bg-[#F5F7FA] border-b border-[#D9E2EC] flex items-center justify-between">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-[#EBF1FA] text-[#1F4E9C] rounded-[6px]">
              <Edit2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-[#0B2545]">
                Edit Vendor Master Record
              </h3>
              <p className="text-[11px] text-[#52606D]">
                Vendor ID: <span className="font-mono text-[#1F4E9C]">{vendor.id}</span>
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#52606D] hover:text-[#0B2545] p-1.5 rounded-[4px] hover:bg-[#EBF1FA] transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 overflow-y-auto flex-1">
          {error && (
            <div className="p-3 bg-[#FEF3F2] border border-[#FECDCA] rounded-[6px] text-xs text-[#B42318] flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* SECTION 1: Statutory GST Particulars */}
          <div className="space-y-3">
            <div className="flex items-center space-x-1.5 text-xs font-bold text-[#0B2545] border-b border-[#D9E2EC] pb-1 uppercase tracking-wider">
              <Building2 className="w-4 h-4 text-[#1F4E9C]" />
              <span>1. Statutory Identity & GSTIN</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-[#52606D] font-medium mb-1">
                  15-Digit GSTIN * (Editable)
                </label>
                <input
                  type="text"
                  maxLength={15}
                  value={gstin}
                  onChange={handleGstinChange}
                  placeholder="e.g. 27AAACA1234A1Z1"
                  required
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs font-mono font-bold text-[#1F4E9C] uppercase focus:outline-none focus:border-[#1F4E9C]"
                />
                <span className="text-[10px] text-[#52606D]">
                  Updating GSTIN automatically recalibrates State Code and PAN.
                </span>
              </div>

              <div>
                <label className="block text-[#52606D] font-medium mb-1">
                  PAN (10-Digit) *
                </label>
                <input
                  type="text"
                  maxLength={10}
                  value={pan}
                  onChange={(e) => setPan(e.target.value.toUpperCase().trim())}
                  placeholder="e.g. AAACA1234A"
                  required
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs font-mono text-[#1F2933] uppercase"
                />
              </div>

              <div>
                <label className="block text-[#52606D] font-medium mb-1">
                  Legal Entity Name (As per GST Certificate) *
                </label>
                <input
                  type="text"
                  value={legalName}
                  onChange={(e) => setLegalName(e.target.value)}
                  placeholder="e.g. Apex Precision Engineering LLP"
                  required
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>

              <div>
                <label className="block text-[#52606D] font-medium mb-1">
                  Trade Name
                </label>
                <input
                  type="text"
                  value={tradeName}
                  onChange={(e) => setTradeName(e.target.value)}
                  placeholder="e.g. Apex Engineering"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>

              <div>
                <label className="block text-[#52606D] font-medium mb-1">
                  State & Code *
                </label>
                <select
                  value={stateCode}
                  onChange={(e) => {
                    const code = e.target.value;
                    setStateCode(code);
                    setStateName(INDIAN_STATES_MAP[code] || 'Maharashtra');
                  }}
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                >
                  {Object.entries(INDIAN_STATES_MAP).map(([c, n]) => (
                    <option key={c} value={c}>
                      {c} - {n}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[#52606D] font-medium mb-1">
                  Turnover Category (HSN Rule 46 Enforcement) *
                </label>
                <select
                  value={turnoverCategory}
                  onChange={(e) => setTurnoverCategory(e.target.value as any)}
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                >
                  <option value="ABOVE_5CR">&gt; ₹5 Crore (Mandatory 6-digit HSN)</option>
                  <option value="UP_TO_5CR">≤ ₹5 Crore (Minimum 4-digit HSN for B2B)</option>
                </select>
              </div>
            </div>

            {/* Statutory Checkboxes */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
              <label className="flex items-center space-x-2 text-xs text-[#1F2933] cursor-pointer bg-[#F5F7FA] p-2.5 rounded-[6px] border border-[#D9E2EC]">
                <input
                  type="checkbox"
                  checked={isComposition}
                  onChange={(e) => setIsComposition(e.target.checked)}
                  className="rounded border-[#D9E2EC] text-[#1F4E9C]"
                />
                <div>
                  <span className="font-semibold block text-[#0B2545]">Composition Scheme Vendor</span>
                  <span className="text-[10px] text-[#52606D]">Cannot charge CGST/SGST/IGST on invoices</span>
                </div>
              </label>

              <label className="flex items-center space-x-2 text-xs text-[#1F2933] cursor-pointer bg-[#F5F7FA] p-2.5 rounded-[6px] border border-[#D9E2EC]">
                <input
                  type="checkbox"
                  checked={isMsme}
                  onChange={(e) => setIsMsme(e.target.checked)}
                  className="rounded border-[#D9E2EC] text-[#1F4E9C]"
                />
                <div>
                  <span className="font-semibold block text-[#0B2545]">MSME Registered Entity</span>
                  <span className="text-[10px] text-[#52606D]">Enforces 45-day payment tracking u/s 43B(h)</span>
                </div>
              </label>
            </div>

            {isMsme && (
              <div>
                <label className="block text-[#52606D] font-medium mb-1 text-xs">
                  MSME Udyam Registration Number *
                </label>
                <input
                  type="text"
                  value={msmeRegistrationNumber}
                  onChange={(e) => setMsmeRegistrationNumber(e.target.value.toUpperCase().trim())}
                  placeholder="UDYAM-MH-01-0012345"
                  required
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs font-mono uppercase text-[#1F2933]"
                />
              </div>
            )}
          </div>

          {/* SECTION 2: Contact & Registered Address */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center space-x-1.5 text-xs font-bold text-[#0B2545] border-b border-[#D9E2EC] pb-1 uppercase tracking-wider">
              <MapPin className="w-4 h-4 text-[#1F4E9C]" />
              <span>2. Contact & Premises</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block text-[#52606D] font-medium mb-1">Contact Person</label>
                <input
                  type="text"
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  placeholder="e.g. Rajesh Patil"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>

              <div>
                <label className="block text-[#52606D] font-medium mb-1">Email Address</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="e.g. accounts@apex.in"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>

              <div>
                <label className="block text-[#52606D] font-medium mb-1">Phone Number</label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 98201 12345"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="block text-[#52606D] font-medium mb-1">Registered Address</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Plot W-42, MIDC Industrial Area, Rabale, Navi Mumbai"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>

              <div>
                <label className="block text-[#52606D] font-medium mb-1">Pincode</label>
                <input
                  type="text"
                  maxLength={6}
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value.trim())}
                  placeholder="400701"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs font-mono text-[#1F2933]"
                />
              </div>
            </div>
          </div>

          {/* SECTION 3: Banking & Tally Prime Integration */}
          <div className="space-y-3 pt-2">
            <div className="flex items-center space-x-1.5 text-xs font-bold text-[#0B2545] border-b border-[#D9E2EC] pb-1 uppercase tracking-wider">
              <CreditCard className="w-4 h-4 text-[#1F4E9C]" />
              <span>3. Settlement Bank & Tally Prime Ledger</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-[#52606D] font-medium mb-1">Tally Prime Ledger Name</label>
                <input
                  type="text"
                  value={tallyLedgerName}
                  onChange={(e) => setTallyLedgerName(e.target.value)}
                  placeholder="Apex Precision Engineering LLP"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
                <span className="text-[10px] text-[#52606D]">Matches the Sundry Creditor ledger in Tally Prime.</span>
              </div>

              <div>
                <label className="block text-[#52606D] font-medium mb-1">Bank Name</label>
                <input
                  type="text"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  placeholder="HDFC Bank"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>

              <div>
                <label className="block text-[#52606D] font-medium mb-1">Bank Account Number</label>
                <input
                  type="text"
                  value={bankAccountNumber}
                  onChange={(e) => setBankAccountNumber(e.target.value.trim())}
                  placeholder="50200012345678"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs font-mono text-[#1F2933]"
                />
              </div>

              <div>
                <label className="block text-[#52606D] font-medium mb-1">Bank IFSC Code</label>
                <input
                  type="text"
                  maxLength={11}
                  value={bankIfsc}
                  onChange={(e) => setBankIfsc(e.target.value.toUpperCase().trim())}
                  placeholder="HDFC0000123"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs font-mono uppercase text-[#1F2933]"
                />
              </div>
            </div>
          </div>

          {/* Footer Submit */}
          <div className="flex items-center justify-end space-x-2 pt-4 border-t border-[#D9E2EC]">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs font-medium hover:bg-[#F5F7FA]"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="px-5 py-2 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[6px] text-xs font-semibold transition flex items-center space-x-1.5 disabled:opacity-40"
            >
              <Save className="w-4 h-4" />
              <span>{isSubmitting ? 'Saving Changes...' : 'Save Vendor Master'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

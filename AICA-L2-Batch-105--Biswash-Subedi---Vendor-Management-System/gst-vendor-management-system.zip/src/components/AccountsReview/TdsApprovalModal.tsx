/**
 * Statutory TDS Deduction Modal during Invoice Approval
 * Adheres to Income Tax Act, 1961 and CBDT Circular No. 23/2017:
 * - TDS Section & Rate selection
 * - Live auto-calculation of TDS Amount and Net Payable to Vendor
 * - Mandatory justification if zero TDS / No TDS is selected
 */

import React, { useState, useMemo } from 'react';
import {
  STATUTORY_TDS_SECTIONS,
  COMMON_NO_TDS_REASONS,
  DEFAULT_TDS_GL_LEDGERS,
  getTdsGlAccount,
  calculateTds,
  TDSSectionItem,
} from '../../utils/tdsConfig.ts';
import { InvoiceRecord } from '../../types/index.ts';
import {
  Calculator,
  ShieldCheck,
  AlertCircle,
  CheckCircle2,
  HelpCircle,
  Percent,
  X,
  FileCheck,
  BookOpen,
} from 'lucide-react';

interface TdsApprovalModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: InvoiceRecord;
  isOverrideApproval?: boolean;
  overrideReason?: string;
  configuredGlLedgers?: Record<string, string>;
  onConfirmApproval: (tdsData: {
    tdsSection: string;
    tdsSectionName: string;
    tdsRate: number;
    tdsAmount: number;
    netPayableAmount: number;
    noTdsReason?: string;
    tdsBaseAmount: number;
    tdsGlAccount?: string;
    isLowerDeductionCertificate?: boolean;
    lowerDeductionCertNumber?: string;
    lowerDeductionCertValidTill?: string;
    lowerDeductionCertLimit?: number;
  }) => Promise<void>;
}

export const TdsApprovalModal: React.FC<TdsApprovalModalProps> = ({
  isOpen,
  onClose,
  invoice,
  isOverrideApproval,
  overrideReason,
  configuredGlLedgers,
  onConfirmApproval,
}) => {
  if (!isOpen) return null;

  // Initial section selection
  const [selectedSectionCode, setSelectedSectionCode] = useState<string>(
    invoice.tdsSection && invoice.tdsSection !== 'NO_TDS' ? invoice.tdsSection : '194C'
  );
  const [selectedRate, setSelectedRate] = useState<number>(invoice.tdsRate || 2.0);
  const [customRateInput, setCustomRateInput] = useState<string>('');
  const [applyOnGross, setApplyOnGross] = useState<boolean>(false);
  const [noTdsReason, setNoTdsReason] = useState<string>(invoice.noTdsReason || '');
  const [tdsGlAccount, setTdsGlAccount] = useState<string>(
    invoice.tdsGlAccount || getTdsGlAccount(invoice.tdsSection || '194C', configuredGlLedgers)
  );

  // Lower Deduction Certificate (Section 197) States
  const [isLowerDeductionCertificate, setIsLowerDeductionCertificate] = useState<boolean>(
    Boolean(invoice.isLowerDeductionCertificate)
  );
  const [lowerTdsRateInput, setLowerTdsRateInput] = useState<string>(
    invoice.isLowerDeductionCertificate && invoice.tdsRate !== undefined ? String(invoice.tdsRate) : '0.5'
  );
  const [lowerDeductionCertNumber, setLowerDeductionCertNumber] = useState<string>(
    invoice.lowerDeductionCertNumber || ''
  );
  const [lowerDeductionCertValidTill, setLowerDeductionCertValidTill] = useState<string>(
    invoice.lowerDeductionCertValidTill || ''
  );
  const [lowerDeductionCertLimit, setLowerDeductionCertLimit] = useState<string>(
    invoice.lowerDeductionCertLimit ? String(invoice.lowerDeductionCertLimit) : ''
  );

  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [validationError, setValidationError] = useState<string | null>(null);

  // Current section object
  const currentSection = useMemo<TDSSectionItem>(() => {
    return (
      STATUTORY_TDS_SECTIONS.find((s) => s.code === selectedSectionCode) ||
      STATUTORY_TDS_SECTIONS[0]
    );
  }, [selectedSectionCode]);

  // Handle section switch
  const handleSectionChange = (code: string) => {
    setSelectedSectionCode(code);
    const sec = STATUTORY_TDS_SECTIONS.find((s) => s.code === code);
    if (sec) {
      setSelectedRate(sec.defaultRate);
      setCustomRateInput('');
      setTdsGlAccount(getTdsGlAccount(code, configuredGlLedgers));
    }
  };

  // Compute effective rate considering Section 197 LDC
  const effectiveRate = useMemo(() => {
    if (selectedSectionCode === 'NO_TDS') return 0;
    if (isLowerDeductionCertificate) {
      return lowerTdsRateInput !== '' ? Math.max(0, parseFloat(lowerTdsRateInput) || 0) : 0;
    }
    if (customRateInput !== '') {
      return Math.max(0, parseFloat(customRateInput) || 0);
    }
    return selectedRate;
  }, [selectedSectionCode, isLowerDeductionCertificate, lowerTdsRateInput, customRateInput, selectedRate]);

  const isZeroTds = selectedSectionCode === 'NO_TDS' || effectiveRate === 0;

  // Calculation
  const calculation = useMemo(() => {
    const taxable = invoice.totalTaxableValue || 0;
    const total = invoice.invoiceTotal || 0;
    return calculateTds(taxable, total, effectiveRate, applyOnGross);
  }, [invoice, effectiveRate, applyOnGross]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setValidationError(null);

    // If Lower Deduction Certificate is checked, validate certificate number and lower rate
    if (isLowerDeductionCertificate) {
      if (!lowerDeductionCertNumber.trim()) {
        setValidationError('Mandatory requirement: Please enter the Section 197 Lower Deduction Certificate Number issued by the Income Tax Department (Form 13).');
        return;
      }
      if (lowerTdsRateInput === '' || isNaN(parseFloat(lowerTdsRateInput)) || parseFloat(lowerTdsRateInput) < 0) {
        setValidationError('Please enter a valid non-negative Lower TDS Rate percentage (e.g. 0.5%, 1%, or 0% for Nil deduction).');
        return;
      }
    }

    if (isZeroTds && !isLowerDeductionCertificate && !noTdsReason.trim()) {
      setValidationError('Mandatory requirement: Please provide a valid justification for Nil/Zero TDS deduction.');
      return;
    }

    if (!isZeroTds && !tdsGlAccount.trim()) {
      setValidationError('Mandatory requirement: Please specify the TDS General Ledger (GL) Account for Tally / ERP voucher posting.');
      return;
    }

    setIsSubmitting(true);
    try {
      const effectiveNoTdsReason = isZeroTds
        ? (isLowerDeductionCertificate
            ? `Nil TDS under Section 197 Certificate #${lowerDeductionCertNumber.trim()}`
            : noTdsReason.trim())
        : undefined;

      await onConfirmApproval({
        tdsSection: selectedSectionCode,
        tdsSectionName: isLowerDeductionCertificate
          ? `${currentSection.name} (Sec 197 Lower Rate)`
          : currentSection.name,
        tdsRate: effectiveRate,
        tdsAmount: calculation.tdsAmount,
        netPayableAmount: calculation.netPayableAmount,
        noTdsReason: effectiveNoTdsReason,
        tdsBaseAmount: calculation.baseAmount,
        tdsGlAccount: isZeroTds ? 'Not Applicable' : tdsGlAccount.trim(),
        isLowerDeductionCertificate,
        lowerDeductionCertNumber: isLowerDeductionCertificate ? lowerDeductionCertNumber.trim() : undefined,
        lowerDeductionCertValidTill: isLowerDeductionCertificate && lowerDeductionCertValidTill ? lowerDeductionCertValidTill.trim() : undefined,
        lowerDeductionCertLimit: isLowerDeductionCertificate && lowerDeductionCertLimit ? parseFloat(lowerDeductionCertLimit) || undefined : undefined,
      });
      onClose();
    } catch (err: any) {
      setValidationError(err.message || 'Failed to finalize approval with TDS');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white border border-[#D9E2EC] w-full max-w-xl rounded-[6px] shadow-2xl p-6 space-y-5 my-8 max-h-[92vh] overflow-y-auto">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-[#D9E2EC] pb-3">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-[#EBF1FA] text-[#1F4E9C] rounded-[4px]">
              <Calculator className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#0B2545]">
                Statutory TDS Deduction & Approval
              </h3>
              <p className="text-xs text-[#52606D]">
                Income Tax Act, 1961 • CBDT Circular No. 23/2017
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#52606D] hover:text-[#0B2545] p-1 rounded hover:bg-[#F5F7FA]"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Override Notice if applicable */}
        {isOverrideApproval && (
          <div className="p-3 bg-[#FFF7E6] border border-[#FFE7BA] rounded-[6px] text-xs text-[#B26A00]">
            <strong>Approval via Statutory Override:</strong> {overrideReason || 'Overridden with justification.'}
          </div>
        )}

        {/* Invoice Summary Card */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 p-3 bg-[#F5F7FA] border border-[#D9E2EC] rounded-[6px] text-xs">
          <div>
            <span className="text-[#52606D] block text-[11px]">Invoice Number</span>
            <strong className="text-[#0B2545] font-mono">{invoice.invoiceNumber}</strong>
          </div>
          <div>
            <span className="text-[#52606D] block text-[11px]">Vendor Legal Name</span>
            <span className="text-[#1F2933] font-medium truncate block" title={invoice.vendorName}>
              {invoice.vendorName}
            </span>
          </div>
          <div>
            <span className="text-[#52606D] block text-[11px]">Taxable Value (Base)</span>
            <strong className="text-[#1F4E9C] font-mono">₹{invoice.totalTaxableValue?.toFixed(2)}</strong>
          </div>
          <div>
            <span className="text-[#52606D] block text-[11px]">Total Invoice Value</span>
            <strong className="text-[#0B2545] font-mono">₹{invoice.invoiceTotal?.toFixed(2)}</strong>
          </div>
        </div>

        {validationError && (
          <div className="p-3 bg-[#FEF3F2] border border-[#FECDCA] rounded-[6px] text-xs text-[#B42318] flex items-center space-x-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{validationError}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          
          {/* Step 1: TDS Section Selection */}
          <div>
            <label className="block text-xs font-semibold text-[#0B2545] mb-1.5 flex items-center justify-between">
              <span>1. Applicable TDS Section *</span>
              <span className="text-[11px] text-[#52606D] font-normal">
                {currentSection.thresholdNotes}
              </span>
            </label>
            <select
              value={selectedSectionCode}
              onChange={(e) => handleSectionChange(e.target.value)}
              className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs font-medium text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
            >
              {STATUTORY_TDS_SECTIONS.map((sec) => (
                <option key={sec.code} value={sec.code}>
                  {sec.name}
                </option>
              ))}
            </select>
          </div>

          {/* Section 197 Lower / Nil Deduction Certificate Toggle & Controls */}
          {selectedSectionCode !== 'NO_TDS' && (
            <div className={`p-3 rounded-[6px] border transition ${
              isLowerDeductionCertificate
                ? 'bg-[#F0F5FF] border-[#ADC8FF]'
                : 'bg-[#F8FAFC] border-[#E2E8F0]'
            }`}>
              <div className="flex items-start justify-between">
                <label className="flex items-start space-x-2.5 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={isLowerDeductionCertificate}
                    onChange={(e) => {
                      const checked = e.target.checked;
                      setIsLowerDeductionCertificate(checked);
                      if (checked && (!lowerTdsRateInput || lowerTdsRateInput === '0')) {
                        setLowerTdsRateInput('0.5');
                      }
                    }}
                    className="mt-0.5 w-4 h-4 rounded text-[#1F4E9C] border-[#CBD5E1] focus:ring-[#1F4E9C]"
                  />
                  <div>
                    <span className="text-xs font-bold text-[#0B2545] flex items-center space-x-2">
                      <span>Lower / Nil Deduction Certificate (Section 197)</span>
                      <span className="bg-[#1F4E9C] text-white text-[9px] px-1.5 py-0.5 rounded font-mono font-semibold">
                        FORM 13 / TRACES
                      </span>
                    </span>
                    <p className="text-[11px] text-[#52606D] mt-0.5">
                      Vendor holds a valid Certificate from Assessing Officer under Section 197 of Income Tax Act for lower or nil TDS deduction.
                    </p>
                  </div>
                </label>
              </div>

              {isLowerDeductionCertificate && (
                <div className="pt-3 mt-2.5 border-t border-[#D0E2FF] space-y-3">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="block text-[11px] font-semibold text-[#0B2545] mb-1">
                        Prescribed Lower TDS Rate (%) *
                      </label>
                      <div className="flex items-center space-x-2">
                        <input
                          type="number"
                          step="0.01"
                          min="0"
                          max="30"
                          required
                          value={lowerTdsRateInput}
                          onChange={(e) => setLowerTdsRateInput(e.target.value)}
                          placeholder="e.g. 0.5"
                          className="w-24 px-2.5 py-1.5 bg-white border border-[#ADC8FF] rounded-[4px] text-xs font-mono font-bold text-[#0B2545] focus:outline-none focus:border-[#1F4E9C]"
                        />
                        <span className="text-xs text-[#52606D] font-bold">%</span>
                        
                        {/* Quick Prescribed Rate Chips */}
                        <div className="flex items-center space-x-1">
                          {['0', '0.1', '0.5', '1.0'].map((chip) => (
                            <button
                              key={chip}
                              type="button"
                              onClick={() => setLowerTdsRateInput(chip)}
                              className={`text-[10px] px-1.5 py-0.5 rounded border transition font-mono ${
                                lowerTdsRateInput === chip
                                  ? 'bg-[#1F4E9C] text-white border-[#1F4E9C]'
                                  : 'bg-white text-[#52606D] border-[#D9E2EC] hover:bg-[#F5F7FA]'
                              }`}
                            >
                              {chip}%
                            </button>
                          ))}
                        </div>
                      </div>
                      <p className="text-[10px] text-[#52606D] mt-1">
                        Enter 0% if vendor has a Nil Deduction Certificate.
                      </p>
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-[#0B2545] mb-1">
                        Certificate Number (TRACES / AO) *
                      </label>
                      <input
                        type="text"
                        required
                        value={lowerDeductionCertNumber}
                        onChange={(e) => setLowerDeductionCertNumber(e.target.value.toUpperCase())}
                        placeholder="e.g. 26AAACL1234F123456"
                        className="w-full px-2.5 py-1.5 bg-white border border-[#ADC8FF] rounded-[4px] text-xs font-mono uppercase text-[#0B2545] focus:outline-none focus:border-[#1F4E9C]"
                      />
                      <p className="text-[10px] text-[#52606D] mt-1">
                        Form 13 / 16-character certificate reference number.
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
                    <div>
                      <label className="block text-[11px] font-semibold text-[#0B2545] mb-1">
                        Certificate Valid Till (Optional)
                      </label>
                      <input
                        type="date"
                        value={lowerDeductionCertValidTill}
                        onChange={(e) => setLowerDeductionCertValidTill(e.target.value)}
                        className="w-full px-2.5 py-1.5 bg-white border border-[#D9E2EC] rounded-[4px] text-xs font-mono text-[#0B2545] focus:outline-none focus:border-[#1F4E9C]"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-semibold text-[#0B2545] mb-1">
                        Prescribed Threshold Limit (₹) (Optional)
                      </label>
                      <input
                        type="number"
                        step="1"
                        min="0"
                        value={lowerDeductionCertLimit}
                        onChange={(e) => setLowerDeductionCertLimit(e.target.value)}
                        placeholder="e.g. 5000000"
                        className="w-full px-2.5 py-1.5 bg-white border border-[#D9E2EC] rounded-[4px] text-xs font-mono text-[#0B2545] focus:outline-none focus:border-[#1F4E9C]"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Step 2: TDS Rate Selection (when not NO_TDS and not Lower Deduction Certificate) */}
          {selectedSectionCode !== 'NO_TDS' && !isLowerDeductionCertificate && (
            <div>
              <label className="block text-xs font-semibold text-[#0B2545] mb-1.5">
                2. Applicable TDS Rate (%) *
              </label>
              <div className="flex flex-wrap gap-2">
                {currentSection.availableRates.map((r) => (
                  <button
                    key={r.label}
                    type="button"
                    onClick={() => {
                      setSelectedRate(r.rate);
                      setCustomRateInput('');
                    }}
                    className={`px-3 py-1.5 rounded-[6px] text-xs font-semibold transition border ${
                      selectedRate === r.rate && customRateInput === ''
                        ? 'bg-[#1F4E9C] text-white border-[#1F4E9C]'
                        : 'bg-white text-[#1F2933] border-[#D9E2EC] hover:bg-[#F5F7FA]'
                    }`}
                  >
                    {r.label}
                  </button>
                ))}

                {/* Custom rate input */}
                <div className="flex items-center space-x-1">
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="30"
                    placeholder="Custom %"
                    value={customRateInput}
                    onChange={(e) => setCustomRateInput(e.target.value)}
                    className="w-24 px-2.5 py-1.5 bg-white border border-[#D9E2EC] rounded-[6px] text-xs font-mono text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                  />
                  <span className="text-xs text-[#52606D]">%</span>
                </div>
              </div>

              {/* Taxable Base Switch */}
              <div className="mt-2.5 flex items-center justify-between text-xs text-[#52606D] bg-[#F5F7FA] px-3 py-2 rounded-[6px] border border-[#D9E2EC]">
                <span>CBDT Circular 23/2017: Deduct TDS on Taxable Value (excluding GST)</span>
                <label className="flex items-center space-x-1.5 cursor-pointer text-[#1F2933] text-[11px]">
                  <input
                    type="checkbox"
                    checked={applyOnGross}
                    onChange={(e) => setApplyOnGross(e.target.checked)}
                    className="rounded text-[#1F4E9C] border-[#D9E2EC]"
                  />
                  <span>Apply on Gross Total</span>
                </label>
              </div>

              {/* Step 3: TDS General Ledger (GL) Selection */}
              <div className="mt-3 pt-3 border-t border-[#D9E2EC]">
                <label className="block text-xs font-semibold text-[#0B2545] mb-1.5 flex items-center justify-between">
                  <div className="flex items-center space-x-1.5">
                    <BookOpen className="w-3.5 h-3.5 text-[#1F4E9C]" />
                    <span>3. TDS General Ledger (GL) Account (Tally / ERP) *</span>
                  </div>
                  <span className="text-[10px] bg-[#EBF1FA] text-[#1F4E9C] px-1.5 py-0.5 rounded font-mono font-medium">
                    Group: Duties & Taxes
                  </span>
                </label>

                <div className="space-y-1.5">
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      value={tdsGlAccount}
                      onChange={(e) => setTdsGlAccount(e.target.value)}
                      placeholder="e.g. TDS on Contractors - 194C"
                      required
                      className="flex-1 px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs font-mono text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                    />
                  </div>
                  
                  {/* Common Preset Chips */}
                  <div className="flex flex-wrap gap-1.5">
                    {Object.entries(DEFAULT_TDS_GL_LEDGERS)
                      .filter(([k]) => k !== 'NO_TDS')
                      .map(([code, ledger]) => (
                        <button
                          key={code}
                          type="button"
                          onClick={() => setTdsGlAccount(ledger)}
                          className={`text-[10px] px-2 py-0.5 rounded transition border ${
                            tdsGlAccount === ledger
                              ? 'bg-[#1F4E9C] text-white border-[#1F4E9C]'
                              : 'bg-white text-[#52606D] border-[#D9E2EC] hover:bg-[#F5F7FA]'
                          }`}
                        >
                          {ledger}
                        </button>
                      ))}
                  </div>
                </div>
                <p className="text-[11px] text-[#52606D] mt-1">
                  This specific ledger will be credited in Tally Prime / ERP vouchers when posting this invoice.
                </p>
              </div>
            </div>
          )}

          {/* When Lower Deduction Certificate is selected, still provide GL Ledger selection */}
          {selectedSectionCode !== 'NO_TDS' && isLowerDeductionCertificate && effectiveRate > 0 && (
            <div className="mt-3 pt-3 border-t border-[#D9E2EC]">
              <label className="block text-xs font-semibold text-[#0B2545] mb-1.5 flex items-center justify-between">
                <div className="flex items-center space-x-1.5">
                  <BookOpen className="w-3.5 h-3.5 text-[#1F4E9C]" />
                  <span>TDS General Ledger (GL) Account (Tally / ERP) *</span>
                </div>
                <span className="text-[10px] bg-[#EBF1FA] text-[#1F4E9C] px-1.5 py-0.5 rounded font-mono font-medium">
                  Group: Duties & Taxes
                </span>
              </label>

              <div className="space-y-1.5">
                <input
                  type="text"
                  value={tdsGlAccount}
                  onChange={(e) => setTdsGlAccount(e.target.value)}
                  placeholder="e.g. TDS on Contractors - 194C"
                  required
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs font-mono text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                />
              </div>
              <p className="text-[11px] text-[#52606D] mt-1">
                TDS at the lower rate will be credited to this Duties & Taxes ledger in Tally Prime.
              </p>
            </div>
          )}

          {/* Step 4: Mandatory Justification for Zero TDS (Only if NO Section 197 LDC) */}
          {isZeroTds && !isLowerDeductionCertificate && (
            <div className="p-3.5 bg-[#FFF7E6] border border-[#FFE7BA] rounded-[6px] space-y-2.5">
              <div className="flex items-center space-x-2 text-xs font-bold text-[#B26A00]">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>Mandatory Requirement: Reason for No TDS Deduction *</span>
              </div>
              <p className="text-[11px] text-[#52606D]">
                Under Income Tax statutory audit regulations, every vendor invoice approved without TDS deduction must be substantiated with a statutory justification.
              </p>

              <div>
                <textarea
                  value={noTdsReason}
                  onChange={(e) => setNoTdsReason(e.target.value)}
                  required
                  rows={2}
                  placeholder="Specify reason (e.g. Below Section 194C aggregate limit of ₹1,00,000 / Nil certificate u/s 197)..."
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                />
              </div>

              {/* Quick Reason Chips */}
              <div className="flex flex-wrap gap-1.5 pt-1">
                {COMMON_NO_TDS_REASONS.slice(0, 4).map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setNoTdsReason(r)}
                    className="text-[10px] bg-white hover:bg-[#EBF1FA] text-[#0B2545] border border-[#D9E2EC] px-2 py-1 rounded transition text-left"
                  >
                    + {r.slice(0, 45)}...
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Live Auto-Calculation Breakdown Card */}
          <div className="p-4 bg-[#F5F7FA] border border-[#D9E2EC] rounded-[6px] space-y-2">
            <div className="text-xs font-bold text-[#0B2545] uppercase tracking-wider border-b border-[#D9E2EC] pb-1.5 flex items-center justify-between">
              <span>TDS Deduction & Settlement Arithmetic</span>
              <span className="font-mono text-[11px] text-[#52606D] flex items-center space-x-1">
                {isLowerDeductionCertificate && (
                  <span className="bg-[#1F4E9C] text-white text-[9px] px-1 py-0.2 rounded font-semibold mr-1">
                    SEC 197 LDC
                  </span>
                )}
                <span>Rate: {effectiveRate}%</span>
              </span>
            </div>

            <div className="space-y-1.5 text-xs">
              <div className="flex justify-between text-[#52606D]">
                <span>Total Invoice Value:</span>
                <span className="font-mono text-[#1F2933]">₹{invoice.invoiceTotal?.toFixed(2)}</span>
              </div>
              
              <div className="flex justify-between text-[#52606D]">
                <span>TDS Calculation Base ({applyOnGross ? 'Gross Invoice' : 'Taxable Value'}):</span>
                <span className="font-mono text-[#1F2933]">₹{calculation.baseAmount.toFixed(2)}</span>
              </div>

              <div className="flex justify-between text-[#B42318] font-medium">
                <span>
                  Less: TDS Deducted u/s {selectedSectionCode}{' '}
                  {isLowerDeductionCertificate ? `(Sec 197 LDC @ ${effectiveRate}%)` : `@ ${effectiveRate}%`}:
                </span>
                <span className="font-mono">- ₹{calculation.tdsAmount.toFixed(2)}</span>
              </div>

              {isLowerDeductionCertificate && (
                <div className="flex justify-between text-[#1F4E9C] text-[11px] bg-[#F0F5FF] px-2 py-1 rounded border border-[#ADC8FF]">
                  <span>Lower Deduction Cert #:</span>
                  <span className="font-mono font-bold">{lowerDeductionCertNumber || 'FORM 13'}</span>
                </div>
              )}

              {!isZeroTds && (
                <div className="flex justify-between text-[#1F4E9C] text-[11px] bg-[#EBF1FA] px-2 py-1 rounded">
                  <span>Tally / ERP Credit Ledger:</span>
                  <span className="font-mono font-semibold">{tdsGlAccount || 'TDS Payable'} (Duties & Taxes)</span>
                </div>
              )}

              <div className="flex justify-between pt-2 border-t border-[#D9E2EC] font-bold text-sm text-[#0B2545]">
                <span>Net Payable Amount to Vendor:</span>
                <span className="font-mono text-[#1B7F3B] text-base">
                  ₹{calculation.netPayableAmount.toFixed(2)}
                </span>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end space-x-2 pt-2 border-t border-[#D9E2EC]">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs font-medium hover:bg-[#F5F7FA]"
            >
              Cancel
            </button>

            <button
              type="submit"
              disabled={isSubmitting || (isZeroTds && !isLowerDeductionCertificate && !noTdsReason.trim())}
              className={`px-5 py-2 text-white font-semibold rounded-[6px] text-xs transition flex items-center space-x-1.5 shadow-sm disabled:opacity-40 ${
                isLowerDeductionCertificate
                  ? 'bg-[#1F4E9C] hover:bg-[#173B77]'
                  : isZeroTds
                  ? 'bg-[#0B2545] hover:bg-[#173B77]'
                  : 'bg-[#1B7F3B] hover:bg-[#14632E]'
              }`}
            >
              <FileCheck className="w-4 h-4" />
              <span>
                {isSubmitting
                  ? 'Finalizing Approval...'
                  : isLowerDeductionCertificate
                  ? calculation.tdsAmount > 0
                    ? `Approve with Sec 197 LDC (Deduct ₹${calculation.tdsAmount})`
                    : 'Approve with Sec 197 Nil TDS'
                  : isZeroTds
                  ? 'Approve with Zero TDS'
                  : `Approve (Deduct ₹${calculation.tdsAmount})`}
              </span>
            </button>
          </div>

        </form>

      </div>
    </div>
  );
};

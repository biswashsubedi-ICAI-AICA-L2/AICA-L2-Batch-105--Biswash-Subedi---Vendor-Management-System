/**
 * Branded Landing Page & Login Screen
 * Strict authentication gate: Google Single Sign-On and Email/Password.
 * No demo access, no mock personas, no marketing taglines.
 */

import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { FileText, Lock, Mail, AlertCircle } from 'lucide-react';

interface LoginPageProps {
  onLoginSuccess?: () => void;
}

export const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess }) => {
  const {
    signInWithGoogle,
    signInWithEmail,
    signUpWithEmail,
    authError,
    clearAuthError,
  } = useAuth();

  const [activeTab, setActiveTab] = useState<'SIGN_IN' | 'REGISTER'>('SIGN_IN');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);

  const handleGoogleSignIn = async () => {
    clearAuthError();
    setLocalError(null);
    setIsSubmitting(true);
    try {
      await signInWithGoogle();
      onLoginSuccess?.();
    } catch (err: any) {
      const msg = err.message || '';
      if (msg.toLowerCase().includes('deactivat')) {
        setLocalError('Your account has been deactivated. Please contact the System Administrator.');
      } else {
        setLocalError(msg || 'Google sign-in was cancelled or failed.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    clearAuthError();
    setLocalError(null);
    if (!email || !password) {
      setLocalError('Please enter both email and password.');
      return;
    }

    setIsSubmitting(true);
    try {
      if (activeTab === 'SIGN_IN') {
        await signInWithEmail(email, password);
      } else {
        await signUpWithEmail(email, password, displayName);
      }
      onLoginSuccess?.();
    } catch (err: any) {
      const msg = err.message || '';
      if (msg.toLowerCase().includes('deactivat')) {
        setLocalError('Your account has been deactivated. Please contact the System Administrator.');
      } else {
        setLocalError(msg || 'Authentication failed. Please verify credentials.');
      }
    } finally {
      setIsSubmitting(false);
    }
  };

  let errorMessage = authError || localError;
  if (errorMessage && errorMessage.toLowerCase().includes('deactivat')) {
    errorMessage = 'Your account has been deactivated. Please contact the System Administrator.';
  }

  return (
    <div className="min-h-screen bg-[#F5F7FA] flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 font-sans">
      <div className="sm:mx-auto sm:w-full sm:max-w-md text-center">
        {/* Professional Minimal Brand Icon */}
        <div className="inline-flex items-center justify-center h-12 w-12 rounded-[6px] bg-[#1F4E9C] text-white shadow-sm mb-3">
          <FileText className="w-6 h-6" />
        </div>

        <h1 className="text-2xl font-bold text-[#0B2545] tracking-tight">
          GST Vendor Management System
        </h1>
        
        {/* Subtle dual accent rule under title */}
        <div className="rule-accent w-24 mx-auto my-3" />
      </div>

      {/* Main Authentication Card */}
      <div className="mt-4 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white border border-[#D9E2EC] py-8 px-6 sm:px-10 shadow-sm rounded-[6px] space-y-6">
          
          {/* Error Message Display */}
          {errorMessage && (
            <div className="p-3 bg-[#FEF3F2] border border-[#FECDCA] rounded-[6px] text-[#B42318] text-xs flex items-start space-x-2">
              <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-[#B42318]" />
              <div className="flex-1 leading-normal font-medium">
                {errorMessage}
              </div>
            </div>
          )}

          {/* Primary Action: Google Single Sign-On */}
          <div>
            <button
              type="button"
              onClick={handleGoogleSignIn}
              disabled={isSubmitting}
              className="w-full flex items-center justify-center space-x-3 py-2.5 px-4 bg-white hover:bg-[#F5F7FA] text-[#1F2933] font-medium text-sm rounded-[6px] border border-[#D9E2EC] shadow-sm transition disabled:opacity-50"
            >
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>{isSubmitting ? 'Signing in...' : 'Sign in with Google'}</span>
            </button>
          </div>

          {/* Divider */}
          <div className="relative flex items-center justify-center">
            <div className="border-t border-[#D9E2EC] w-full" />
            <span className="bg-white px-3 text-xs font-semibold text-[#52606D] uppercase tracking-wider">
              Or email login
            </span>
          </div>

          {/* Email / Password Form */}
          <form onSubmit={handleEmailAuth} className="space-y-4">
            <div className="flex border-b border-[#D9E2EC] pb-2 space-x-6 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setActiveTab('SIGN_IN')}
                className={`pb-1 transition ${
                  activeTab === 'SIGN_IN'
                    ? 'text-[#1F4E9C] border-b-2 border-[#1F4E9C]'
                    : 'text-[#52606D] hover:text-[#1F2933]'
                }`}
              >
                Sign In
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('REGISTER')}
                className={`pb-1 transition ${
                  activeTab === 'REGISTER'
                    ? 'text-[#1F4E9C] border-b-2 border-[#1F4E9C]'
                    : 'text-[#52606D] hover:text-[#1F2933]'
                }`}
              >
                New Vendor Registration
              </button>
            </div>

            {activeTab === 'REGISTER' && (
              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">
                  Full Name / Entity Representative
                </label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="e.g. Rajesh Patil"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                />
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                Email Address
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-[#52606D] absolute left-3 top-2.5" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="name@company.com"
                  required
                  className="w-full pl-9 pr-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                Password
              </label>
              <div className="relative">
                <Lock className="w-4 h-4 text-[#52606D] absolute left-3 top-2.5" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  className="w-full pl-9 pr-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-2.5 bg-[#1F4E9C] hover:bg-[#173B77] text-white font-medium text-xs rounded-[6px] transition disabled:opacity-50"
            >
              {isSubmitting
                ? 'Processing...'
                : activeTab === 'SIGN_IN'
                ? 'Sign In to Workspace'
                : 'Submit Access Request'}
            </button>
          </form>

          {/* Small neutral help line */}
          <div className="pt-3 border-t border-[#D9E2EC] text-center">
            <p className="text-xs text-[#52606D]">
              Contact your administrator for access.
            </p>
          </div>

        </div>
      </div>
    </div>
  );
};

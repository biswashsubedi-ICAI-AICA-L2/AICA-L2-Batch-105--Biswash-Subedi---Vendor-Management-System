/**
 * Accounts Review Screen with Side-by-Side Document Viewer and 10-Point GST Validation Engine
 * Applied ICAI-inspired theme: Clean white surfaces, Navy #0B2545, Blue #1F4E9C, accessible WCAG AA badges.
 */

import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { InvoiceRecord, InvoiceLineItem, GSTValidationCheck } from '../../types/index.ts';
import { runGSTValidationEngine } from '../../utils/gstEngine.ts';
import { GST_STATE_CODES } from '../../utils/gstUtils.ts';
import { downloadTallyPurchaseXml } from '../../utils/tallyXmlGenerator.ts';
import {
  FileText,
  ShieldCheck,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  HelpCircle,
  Save,
  Lock,
  Unlock,
  Search,
  ArrowLeft,
  ChevronLeft,
  ChevronRight,
  Eye,
  LayoutList,
  Clock,
  ExternalLink,
  MessageSquare,
  Building2,
  RefreshCw,
  Calculator,
  Download,
} from 'lucide-react';
import { TdsApprovalModal } from './TdsApprovalModal.tsx';
import { LiveGstinVerificationCard } from './LiveGstinVerificationCard.tsx';

interface AccountsReviewScreenProps {
  initialInvoiceId?: string;
  onOpenClarificationThread: (invoice: InvoiceRecord) => void;
}

export const AccountsReviewScreen: React.FC<AccountsReviewScreenProps> = ({
  initialInvoiceId,
  onOpenClarificationThread,
}) => {
  const {
    invoices,
    vendors,
    companySettings,
    ledgerMappings,
    hsnMaster,
    saveInvoice,
    updateInvoiceStatus,
    addQuery,
    currentUser,
    triggerSync,
    isSyncing,
    lastSyncedAt,
  } = useAuth();

  // Find invoice to display
  const activeInvoices = invoices.filter((i) => i.status !== 'CANCELLED');
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string>(
    initialInvoiceId || activeInvoices.find((i) => i.status === 'UNDER_REVIEW')?.id || activeInvoices[0]?.id || ''
  );

  // View Mode: 'QUEUE_TABLE' or 'DETAIL_REVIEW'
  const [viewMode, setViewMode] = useState<'QUEUE_TABLE' | 'DETAIL_REVIEW'>(
    initialInvoiceId ? 'DETAIL_REVIEW' : 'QUEUE_TABLE'
  );
  const [queueFilter, setQueueFilter] = useState<
    'ALL' | 'UNDER_REVIEW' | 'CLARIFICATION_REQUESTED' | 'APPROVED' | 'POSTED' | 'REJECTED'
  >('ALL');
  const [searchTerm, setSearchTerm] = useState('');

  // Handle external selection
  useEffect(() => {
    if (initialInvoiceId) {
      setSelectedInvoiceId(initialInvoiceId);
      setViewMode('DETAIL_REVIEW');
    }
  }, [initialInvoiceId]);

  const selectedInvoice = invoices.find((i) => i.id === selectedInvoiceId) || activeInvoices[0] || null;
  const currentVendor = vendors.find((v) => v.id === selectedInvoice?.vendorId) || null;

  // Local editable draft state for the selected invoice
  const [editableInvoice, setEditableInvoice] = useState<InvoiceRecord | null>(null);
  const [activeTab, setActiveTab] = useState<'VALIDATION' | 'LINE_ITEMS' | 'AUDIT'>('VALIDATION');

  // Modals
  const [showOverrideModal, setShowOverrideModal] = useState(false);
  const [overrideReason, setOverrideReason] = useState('');
  const [showTdsModal, setShowTdsModal] = useState(false);
  const [pendingIsOverride, setPendingIsOverride] = useState(false);
  const [showQueryModal, setShowQueryModal] = useState(false);
  const [queryTargetField, setQueryTargetField] = useState('Whole Invoice');
  const [queryReasonCode, setQueryReasonCode] = useState('RULE_46_DISCREPANCY');
  const [queryText, setQueryText] = useState('');
  const [showRejectModal, setShowRejectModal] = useState(false);
  const [rejectionReason, setRejectionReason] = useState('');

  // Action Notice State (for auto-exiting review and notifying user)
  const [actionNotice, setActionNotice] = useState<{
    type: 'APPROVED' | 'OVERRIDDEN' | 'REJECTED' | 'CLARIFICATION';
    title: string;
    message: string;
    nextPendingId?: string;
    nextPendingNumber?: string;
  } | null>(null);

  // Set of invoice IDs for which auto-download on successful approval has already fired
  const downloadedApprovalIdsRef = useRef<Set<string>>(new Set());

  // Confirmation toast/badge when XML is downloaded
  const [downloadNotice, setDownloadNotice] = useState<{
    invoiceNumber: string;
    filename: string;
    isImport?: boolean;
    isAutoApproval?: boolean;
  } | null>(null);

  // Manual import download action ONLY for APPROVED invoices (not locked / not posted)
  const handleDownloadXmlForTallyImport = (inv?: InvoiceRecord | null) => {
    const target = inv || editableInvoice || selectedInvoice;
    if (!target) return;
    if (target.status === 'POSTED') {
      alert('Invoice is locked after Tally posting. XML download is disabled for POSTED invoices.');
      return;
    }
    try {
      const { filename } = downloadTallyPurchaseXml(target, ledgerMappings, companySettings.legalName);
      setDownloadNotice({
        invoiceNumber: target.invoiceNumber,
        filename,
        isImport: true,
      });
      setTimeout(() => {
        setDownloadNotice(null);
      }, 4500);
    } catch (err: any) {
      alert(`Cannot generate Tally XML: ${err?.message || err}`);
    }
  };

  // Explicit confirmation before changing status to POSTED for manual Tally import
  const handleConfirmPostedInTally = async (inv?: InvoiceRecord | null) => {
    const target = inv || editableInvoice || selectedInvoice;
    if (!target) return;
    if (target.status === 'POSTED') return; // Prevent duplicate

    const ok = window.confirm(
      `Confirm Tally Posting for Invoice #${target.invoiceNumber}?\n\nHave you imported this voucher into Tally Prime via Alt+O (Import > Transactions)? Clicking OK will record confirmation in the audit trail and mark status as POSTED.`
    );
    if (!ok) return;

    const confirmedAt = new Date().toISOString();
    const confirmedByName = currentUser?.displayName || 'Accounts Executive';
    const confirmedByUid = currentUser?.uid || 'accounts_uid';

    const extra = {
      tallyPostedAt: confirmedAt,
      tallyConfirmedBy: confirmedByName,
      tallyConfirmedByUid: confirmedByUid,
      tallyImportMethod: 'MANUAL_XML_IMPORT',
    };

    await updateInvoiceStatus(
      target.id,
      'POSTED',
      `Manual Tally import confirmed by ${confirmedByName} (${currentUser?.email || 'accounts'})`,
      extra
    );

    if (editableInvoice && editableInvoice.id === target.id) {
      setEditableInvoice({
        ...editableInvoice,
        status: 'POSTED',
        ...extra,
      });
    }

    setActionNotice({
      type: 'APPROVED',
      title: `Invoice #${target.invoiceNumber} Confirmed as POSTED`,
      message: `Voucher confirmed posted in Tally Prime. Timestamp and user saved to audit trail.`,
    });
    setTimeout(() => {
      setActionNotice(null);
    }, 3500);
  };

  // Next Pending Invoice in review queue
  const nextPendingInvoice = activeInvoices.find(
    (i) =>
      i.id !== selectedInvoiceId &&
      (i.status === 'UNDER_REVIEW' || i.status === 'SUBMITTED' || i.status === 'RESUBMITTED')
  );

  // Sync draft whenever selected invoice changes
  useEffect(() => {
    if (selectedInvoice) {
      setEditableInvoice(JSON.parse(JSON.stringify(selectedInvoice)));
    }
  }, [selectedInvoiceId, invoices]);

  // Run the 10-point GST Validation Engine on the current editable state (if available)
  const validationResult = editableInvoice
    ? runGSTValidationEngine(
        editableInvoice,
        currentVendor,
        companySettings,
        hsnMaster,
        invoices
      )
    : null;

  const hasFails = validationResult?.overallStatus === 'FAIL';
  const confidenceThreshold = companySettings.ocrConfidenceThreshold ?? 0.85;

  const isLowConfidence = (fieldName: string) => {
    if (!editableInvoice) return false;
    const score = editableInvoice.confidenceByField?.[fieldName];
    return typeof score === 'number' && score < confidenceThreshold;
  };

  // Field change handler
  const handleFieldChange = (field: keyof InvoiceRecord, value: any) => {
    setEditableInvoice((prev) => {
      if (!prev) return prev;
      return { ...prev, [field]: value };
    });
  };

  // Line item change handler
  const handleLineChange = (index: number, field: keyof InvoiceLineItem, value: any) => {
    setEditableInvoice((prev) => {
      if (!prev) return prev;
      const lines = [...prev.lineItems];
      const item = { ...lines[index], [field]: value };

      const qty = Number(item.quantity || 0);
      const rate = Number(item.rate || 0);
      const disc = Number(item.discount || 0);
      item.taxableValue = Number((qty * rate - disc).toFixed(2));

      const isInterstate = !prev.placeOfSupply?.startsWith(currentVendor?.stateCode || '27');
      if (isInterstate) {
        item.cgstRate = 0;
        item.cgstAmount = 0;
        item.sgstRate = 0;
        item.sgstAmount = 0;
        item.igstAmount = Number(((item.taxableValue * (item.igstRate || 18)) / 100).toFixed(2));
      } else {
        item.igstRate = 0;
        item.igstAmount = 0;
        item.cgstAmount = Number(((item.taxableValue * (item.cgstRate || 9)) / 100).toFixed(2));
        item.sgstAmount = Number(((item.taxableValue * (item.sgstRate || 9)) / 100).toFixed(2));
      }

      item.total = Number(
        (item.taxableValue + item.cgstAmount + item.sgstAmount + item.igstAmount + (item.cessAmount || 0)).toFixed(2)
      );

      lines[index] = item;

      // Re-sum headers
      const taxableSum = lines.reduce((a, c) => a + (c.taxableValue || 0), 0);
      const cgstSum = lines.reduce((a, c) => a + (c.cgstAmount || 0), 0);
      const sgstSum = lines.reduce((a, c) => a + (c.sgstAmount || 0), 0);
      const igstSum = lines.reduce((a, c) => a + (c.igstAmount || 0), 0);
      const cessSum = lines.reduce((a, c) => a + (c.cessAmount || 0), 0);
      const rawTot = taxableSum + cgstSum + sgstSum + igstSum + cessSum;
      const roundedTot = Math.round(rawTot);

      return {
        ...prev,
        lineItems: lines,
        totalTaxableValue: Number(taxableSum.toFixed(2)),
        totalCgst: Number(cgstSum.toFixed(2)),
        totalSgst: Number(sgstSum.toFixed(2)),
        totalIgst: Number(igstSum.toFixed(2)),
        totalCess: Number(cessSum.toFixed(2)),
        roundOff: Number((roundedTot - rawTot).toFixed(2)),
        invoiceTotal: roundedTot,
      };
    });
  };

  // Save manual modifications
  const handleSaveEdits = async () => {
    if (!editableInvoice) return;
    await saveInvoice(editableInvoice, 'Accounts Executive manual data modification');
  };

  // Action: Approve (Prompts TDS Deduction Workflow)
  const handleApprove = () => {
    if (!editableInvoice || hasFails) {
      return;
    }
    setPendingIsOverride(false);
    setShowTdsModal(true);
  };

  // Action: Confirm Override and proceed to TDS Deduction Workflow
  const handleConfirmOverrideToTds = () => {
    if (!editableInvoice || !overrideReason.trim()) return;
    setShowOverrideModal(false);
    setPendingIsOverride(true);
    setShowTdsModal(true);
  };

  // Finalize Approval with TDS Deduction (Auto-calculates, checks zero-TDS mandatory reason, updates status)
  const handleFinalizeApprovalWithTds = async (tdsData: {
    tdsSection: string;
    tdsSectionName: string;
    tdsRate: number;
    tdsAmount: number;
    netPayableAmount: number;
    noTdsReason?: string;
    tdsBaseAmount: number;
    tdsGlAccount?: string;
    isLowerDeductionCertificate?: boolean;
    lowerDeductionCertNumber?: string;
    lowerDeductionCertValidTill?: string;
    lowerDeductionCertLimit?: number;
  }) => {
    if (!editableInvoice) return;
    const invNumber = editableInvoice.invoiceNumber;
    const nextId = nextPendingInvoice?.id;
    const nextNum = nextPendingInvoice?.invoiceNumber;
    const isOverride = pendingIsOverride;
    const reason = overrideReason;

    const glNote = tdsData.tdsGlAccount ? ` [TDS GL: ${tdsData.tdsGlAccount}]` : '';
    const ldcNote = tdsData.isLowerDeductionCertificate
      ? ` [Sec 197 LDC Cert #${tdsData.lowerDeductionCertNumber || 'FORM 13'}]`
      : '';
    const auditRemark = isOverride
      ? `Manual Override Approval (${reason}) with TDS Section ${tdsData.tdsSection} (${tdsData.tdsRate}%)${ldcNote}: TDS ₹${tdsData.tdsAmount.toFixed(2)}${glNote}, Net Payable ₹${tdsData.netPayableAmount.toFixed(2)}${tdsData.noTdsReason ? `. Zero-TDS Reason: "${tdsData.noTdsReason}"` : ''}`
      : `Invoice approved by Accounts Executive with TDS Section ${tdsData.tdsSection} (${tdsData.tdsRate}%)${ldcNote}: TDS ₹${tdsData.tdsAmount.toFixed(2)}${glNote}, Net Payable ₹${tdsData.netPayableAmount.toFixed(2)}${tdsData.noTdsReason ? `. Zero-TDS Reason: "${tdsData.noTdsReason}"` : ''}`;

    const extraFields: Partial<InvoiceRecord> = {
      tdsSection: tdsData.tdsSection,
      tdsSectionName: tdsData.tdsSectionName,
      tdsRate: tdsData.tdsRate,
      tdsAmount: tdsData.tdsAmount,
      netPayableAmount: tdsData.netPayableAmount,
      noTdsReason: tdsData.noTdsReason,
      tdsBaseAmount: tdsData.tdsBaseAmount,
      tdsGlAccount: tdsData.tdsGlAccount,
      isLowerDeductionCertificate: tdsData.isLowerDeductionCertificate,
      lowerDeductionCertNumber: tdsData.lowerDeductionCertNumber,
      lowerDeductionCertValidTill: tdsData.lowerDeductionCertValidTill,
      lowerDeductionCertLimit: tdsData.lowerDeductionCertLimit,
      reviewedByUid: currentUser?.uid || 'accounts_uid',
      reviewedByName: currentUser?.displayName || 'Accounts Executive',
      ...(isOverride
        ? {
            overrideReason: reason,
            overriddenBy: currentUser?.displayName || 'Accounts Executive',
          }
        : {}),
    };

    const updatedRecord: InvoiceRecord = {
      ...editableInvoice,
      ...extraFields,
      status: 'APPROVED',
      validationStatus: validationResult?.overallStatus || (isOverride ? 'WARN' : 'PASS'),
      validationResults: validationResult?.checks,
    };

    // 1. Call approval API first
    let approvalSuccess = false;
    let approvalError = '';
    try {
      const res = await updateInvoiceStatus(editableInvoice.id, 'APPROVED', auditRemark, extraFields);
      approvalSuccess = res?.success !== false;
      if (!approvalSuccess) {
        approvalError = res?.error || 'Server approval update failed';
      }
    } catch (err: any) {
      approvalSuccess = false;
      approvalError = err?.message || 'Network error during approval';
    }

    if (!approvalSuccess) {
      alert(`Approval failed: ${approvalError}. Tally XML will not be downloaded.`);
      return;
    }

    setEditableInvoice(updatedRecord);

    // 2. Automatically trigger browser download of Tally XML ONLY after approval API confirms success
    let downloadedFilename = '';
    if (!downloadedApprovalIdsRef.current.has(editableInvoice.id)) {
      downloadedApprovalIdsRef.current.add(editableInvoice.id);
      try {
        const downloadResult = downloadTallyPurchaseXml(
          updatedRecord,
          ledgerMappings,
          companySettings.legalName
        );
        downloadedFilename = downloadResult.filename;
        setDownloadNotice({
          invoiceNumber: invNumber,
          filename: downloadResult.filename,
          isImport: true,
          isAutoApproval: true,
        });
      } catch (dlErr: any) {
        console.warn('Auto download XML failed:', dlErr);
      }
    }

    setShowTdsModal(false);
    setOverrideReason('');
    setPendingIsOverride(false);

    setActionNotice({
      type: isOverride ? 'OVERRIDDEN' : 'APPROVED',
      title: isOverride ? `Invoice #${invNumber} Overridden & Approved` : `Invoice #${invNumber} Approved`,
      message: `Validation completed & approved with TDS ${tdsData.isLowerDeductionCertificate ? `Sec 197 LDC (${tdsData.tdsRate}%)` : (tdsData.tdsSection === 'NO_TDS' ? 'Exempt' : `${tdsData.tdsSection} (₹${tdsData.tdsAmount.toFixed(2)})`)}.${downloadedFilename ? ` Tally XML automatically downloaded (${downloadedFilename}).` : ''} Queued for Tally Prime. Exiting to Review Queue...`,
      nextPendingId: nextId,
      nextPendingNumber: nextNum,
    });

    setTimeout(() => {
      setViewMode('QUEUE_TABLE');
    }, 2200);
  };

  // Action: Raise Query (Clarification)
  const handleRaiseQuery = async () => {
    if (!editableInvoice || !queryText.trim()) return;
    const invNumber = editableInvoice.invoiceNumber;

    await addQuery({
      invoiceId: editableInvoice.id,
      vendorId: editableInvoice.vendorId,
      targetField: queryTargetField,
      reasonCode: queryReasonCode,
      queryText,
      status: 'OPEN',
      raisedByUid: currentUser?.uid || 'accounts_uid',
      raisedByName: currentUser?.displayName || 'Accounts Executive',
      slaDueDate: new Date(Date.now() + (companySettings.querySlaHours || 48) * 3600 * 1000).toISOString(),
      isEscalated: false,
    });

    setShowQueryModal(false);
    setQueryText('');

    setActionNotice({
      type: 'CLARIFICATION',
      title: `Clarification Sent for #${invNumber}`,
      message: 'Clarification query sent to vendor. Invoice status updated to CLARIFICATION_REQUESTED. Exiting to Review Queue...',
    });

    setTimeout(() => {
      setViewMode('QUEUE_TABLE');
    }, 1500);
  };

  // Action: Reject
  const handleReject = async () => {
    if (!editableInvoice || !rejectionReason.trim()) return;
    const invNumber = editableInvoice.invoiceNumber;
    const reason = rejectionReason;

    await updateInvoiceStatus(
      editableInvoice.id,
      'REJECTED',
      `Invoice Rejected: ${reason}`,
      { rejectionReason: reason }
    );
    setShowRejectModal(false);
    setRejectionReason('');

    setActionNotice({
      type: 'REJECTED',
      title: `Invoice #${invNumber} Rejected`,
      message: `Invoice marked as REJECTED: "${reason}". Vendor has been notified. Exiting to Review Queue...`,
    });

    setTimeout(() => {
      setViewMode('QUEUE_TABLE');
    }, 1500);
  };

  // Filter queue invoices
  const filteredQueueInvoices = activeInvoices.filter((inv) => {
    if (queueFilter === 'UNDER_REVIEW') {
      if (inv.status !== 'UNDER_REVIEW' && inv.status !== 'SUBMITTED' && inv.status !== 'RESUBMITTED') return false;
    } else if (queueFilter === 'APPROVED') {
      if (inv.status !== 'APPROVED' && inv.status !== 'POSTED') return false;
    } else if (queueFilter !== 'ALL' && inv.status !== queueFilter) {
      return false;
    }
    if (!searchTerm.trim()) return true;
    const q = searchTerm.toLowerCase();
    return (
      inv.invoiceNumber.toLowerCase().includes(q) ||
      inv.vendorName.toLowerCase().includes(q) ||
      inv.vendorGstin.toLowerCase().includes(q) ||
      (inv.poReference && inv.poReference.toLowerCase().includes(q))
    );
  });

  const underReviewCount = activeInvoices.filter(
    (i) => i.status === 'UNDER_REVIEW' || i.status === 'SUBMITTED' || i.status === 'RESUBMITTED'
  ).length;
  const clarificationCount = activeInvoices.filter((i) => i.status === 'CLARIFICATION_REQUESTED').length;
  const approvedCount = activeInvoices.filter((i) => i.status === 'APPROVED' || i.status === 'POSTED').length;
  const totalInvoicedValue = activeInvoices.reduce((sum, i) => sum + (i.invoiceTotal || 0), 0);

  // Navigation helpers for Detail Review
  const currentInvoiceIndex = activeInvoices.findIndex((i) => i.id === selectedInvoiceId);
  const prevInvoice = currentInvoiceIndex > 0 ? activeInvoices[currentInvoiceIndex - 1] : null;
  const nextInvoice =
    currentInvoiceIndex >= 0 && currentInvoiceIndex < activeInvoices.length - 1
      ? activeInvoices[currentInvoiceIndex + 1]
      : null;

  return (
    <div className="space-y-4">
      {/* VIEW 1: QUEUE TABLE MODE */}
      {viewMode === 'QUEUE_TABLE' && (
        <div className="space-y-4">
          {/* Header Card */}
          <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="flex items-center space-x-3">
              <div className="p-2.5 bg-[#EBF1FA] text-[#1F4E9C] rounded-[4px]">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center space-x-2.5">
                  <h2 className="text-xl font-bold text-[#0B2545] tracking-tight">Invoice Review Queue</h2>
                  <div className="inline-flex items-center space-x-1.5 px-2 py-0.5 bg-[#EBF1FA] text-[#1F4E9C] border border-[#D9E2EC] rounded-[4px] text-[11px] font-medium">
                    <span className="relative flex h-2 w-2">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#1B7F3B] opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-2 w-2 bg-[#1B7F3B]"></span>
                    </span>
                    <span>{isSyncing ? 'Syncing...' : 'Auto-synced: Live'}</span>
                  </div>
                </div>
                <p className="text-xs text-[#52606D] mt-0.5">
                  Accounts Executive verification queue for statutory GST Rule 46 compliance, line items validation, and Tally posting.
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <button
                onClick={() => triggerSync()}
                disabled={isSyncing}
                className="flex items-center space-x-1.5 px-3 py-2 bg-white hover:bg-[#F5F7FA] text-[#0B2545] border border-[#D9E2EC] rounded-[6px] text-xs font-medium transition shadow-sm disabled:opacity-50"
                title="Force refresh invoices and data immediately"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-[#1F4E9C]' : 'text-[#52606D]'}`} />
                <span>{isSyncing ? 'Syncing' : 'Sync Now'}</span>
              </button>

              {selectedInvoice && (
                <button
                  onClick={() => setViewMode('DETAIL_REVIEW')}
                  className="flex items-center space-x-1.5 px-4 py-2 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[6px] text-xs font-medium transition shadow-sm"
                >
                  <Eye className="w-4 h-4" />
                  <span>Open Detailed Review ({selectedInvoice.invoiceNumber})</span>
                </button>
              )}
            </div>
          </div>

          {/* Metric KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-[#52606D]">Under Review</span>
                <Clock className="w-4 h-4 text-[#B26A00]" />
              </div>
              <div className="text-2xl font-bold text-[#0B2545] mt-2 font-mono">{underReviewCount}</div>
              <div className="text-[11px] text-[#B26A00] mt-1 font-medium">Pending Accounts verification</div>
            </div>

            <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-[#52606D]">Clarifications</span>
                <AlertTriangle className="w-4 h-4 text-[#B42318]" />
              </div>
              <div className="text-2xl font-bold text-[#0B2545] mt-2 font-mono">{clarificationCount}</div>
              <div className="text-[11px] text-[#B42318] mt-1 font-medium">Awaiting vendor reply</div>
            </div>

            <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-[#52606D]">Approved / Ready</span>
                <CheckCircle2 className="w-4 h-4 text-[#1B7F3B]" />
              </div>
              <div className="text-2xl font-bold text-[#0B2545] mt-2 font-mono">{approvedCount}</div>
              <div className="text-[11px] text-[#1B7F3B] mt-1 font-medium">Approved for Tally posting</div>
            </div>

            <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-4 shadow-sm">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-[#52606D]">Total Invoiced</span>
                <FileText className="w-4 h-4 text-[#1F4E9C]" />
              </div>
              <div className="text-2xl font-bold text-[#0B2545] mt-2 font-mono">
                ₹{totalInvoicedValue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
              </div>
              <div className="text-[11px] text-[#52606D] mt-1 font-medium">{activeInvoices.length} active invoice(s)</div>
            </div>
          </div>

          {/* Main Table Card */}
          <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-5 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              {/* Filter Tabs */}
              <div className="flex items-center space-x-1.5 overflow-x-auto w-full sm:w-auto text-xs font-medium pb-1 sm:pb-0">
                {(['ALL', 'UNDER_REVIEW', 'CLARIFICATION_REQUESTED', 'APPROVED', 'POSTED', 'REJECTED'] as const).map(
                  (st) => (
                    <button
                      key={st}
                      onClick={() => setQueueFilter(st)}
                      className={`px-3 py-1.5 rounded-[4px] transition whitespace-nowrap ${
                        queueFilter === st
                          ? 'bg-[#1F4E9C] text-white font-semibold'
                          : 'bg-[#F5F7FA] text-[#52606D] hover:bg-[#EBF1FA] hover:text-[#0B2545]'
                      }`}
                    >
                      {st.replace(/_/g, ' ')}
                      {st === 'ALL' && ` (${activeInvoices.length})`}
                      {st === 'UNDER_REVIEW' && ` (${underReviewCount})`}
                      {st === 'CLARIFICATION_REQUESTED' && ` (${clarificationCount})`}
                      {st === 'APPROVED' && ` (${activeInvoices.filter((i) => i.status === 'APPROVED').length})`}
                    </button>
                  )
                )}
              </div>

              {/* Search Box */}
              <div className="relative w-full sm:w-72">
                <Search className="w-4 h-4 text-[#52606D] absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search invoice #, vendor, GSTIN..."
                  className="w-full pl-9 pr-3 py-1.5 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                />
              </div>
            </div>

            {/* Invoices Queue Table */}
            <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px] w-full">
              <table className="w-full min-w-[1020px] text-left text-xs font-sans">
                <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545]">
                  <tr className="uppercase tracking-wider text-[11px] font-semibold">
                    <th className="py-2.5 px-3">Invoice # & Particulars</th>
                    <th className="py-2.5 px-3">Date & FY</th>
                    <th className="py-2.5 px-3">Vendor / GSTIN</th>
                    <th className="py-2.5 px-3">PO Ref</th>
                    <th className="py-2.5 px-3 text-right">Taxable (₹)</th>
                    <th className="py-2.5 px-3 text-right">GST Total (₹)</th>
                    <th className="py-2.5 px-3 text-right">Total (INR)</th>
                    <th className="py-2.5 px-3 text-center">Status</th>
                    <th className="py-2.5 px-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#D9E2EC] font-mono">
                  {filteredQueueInvoices.map((inv) => {
                    const isSelected = inv.id === selectedInvoiceId;
                    const isNewlySubmitted =
                      inv.invoiceNumber === 'Inv 1234' || inv.id === 'inv_apex_2026_1234';
                    return (
                      <tr
                        key={inv.id}
                        className={`hover:bg-[#F5F7FA] transition ${
                          isSelected ? 'bg-[#EBF1FA]/40 font-semibold' : ''
                        } ${isNewlySubmitted ? 'border-l-4 border-l-[#1F4E9C] bg-[#F5F7FA]/70' : ''}`}
                      >
                        <td className="py-2.5 px-3">
                          <div className="font-bold text-[#0B2545] flex items-center space-x-1.5">
                            <span>{inv.invoiceNumber}</span>
                            {isNewlySubmitted && (
                              <span className="px-1.5 py-0.5 bg-[#EDF7ED] text-[#1B7F3B] border border-[#C8E6C9] rounded text-[10px] font-sans font-bold">
                                SUBMITTED
                              </span>
                            )}
                          </div>
                          <div className="text-[11px] text-[#52606D] font-sans truncate max-w-xs">
                            {inv.narration || inv.fileName}
                          </div>
                        </td>
                        <td className="py-2.5 px-3 text-[#1F2933]">
                          <div>{inv.invoiceDate}</div>
                          <div className="text-[10px] text-[#52606D] font-sans">
                            FY {inv.financialYear || '2026-27'}
                          </div>
                        </td>
                        <td className="py-2.5 px-3 font-sans">
                          <div className="font-semibold text-[#0B2545]">{inv.vendorName}</div>
                          <div className="font-mono text-[10px] text-[#52606D]">{inv.vendorGstin}</div>
                        </td>
                        <td className="py-2.5 px-3 text-[#52606D]">{inv.poReference || '-'}</td>
                        <td className="py-2.5 px-3 text-right text-[#1F2933]">
                          ₹{(inv.totalTaxableValue || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="py-2.5 px-3 text-right text-[#1F2933]">
                          ₹
                          {(
                            (inv.totalCgst || 0) +
                            (inv.totalSgst || 0) +
                            (inv.totalIgst || 0) +
                            (inv.totalCess || 0)
                          ).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="py-2.5 px-3 text-right font-bold text-[#1F4E9C]">
                          ₹{(inv.invoiceTotal || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                        </td>
                        <td className="py-2.5 px-3 text-center">
                          <span
                            className={`inline-block px-2.5 py-0.5 rounded-[4px] text-[11px] font-semibold uppercase ${
                              inv.status === 'APPROVED' || inv.status === 'POSTED'
                                ? 'badge-pass'
                                : inv.status === 'UNDER_REVIEW' ||
                                  inv.status === 'SUBMITTED' ||
                                  inv.status === 'RESUBMITTED'
                                ? 'badge-warn'
                                : inv.status === 'CLARIFICATION_REQUESTED'
                                ? 'badge-fail'
                                : 'badge-info'
                            }`}
                          >
                            {inv.status.replace(/_/g, ' ')}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 text-right space-x-1.5 whitespace-nowrap">
                          <button
                            onClick={() => {
                              setSelectedInvoiceId(inv.id);
                              setViewMode('DETAIL_REVIEW');
                            }}
                            className="inline-flex items-center space-x-1 px-3 py-1 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[4px] text-xs font-sans font-medium transition shadow-sm"
                            title="Open document viewer and 10-point GST check"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Review & Validate</span>
                          </button>

                          {inv.status === 'POSTED' && (
                            <span
                              className="inline-flex items-center space-x-1 px-2 py-0.5 text-[11px] text-[#1B7F3B] bg-[#EDF7ED] border border-[#C8E6C9] rounded font-sans font-medium"
                              title="Voucher posted to Tally Prime. Record and actions locked."
                            >
                              <CheckCircle2 className="w-3 h-3 text-[#1B7F3B]" />
                              <span>Posted (Locked)</span>
                            </span>
                          )}

                          {inv.status === 'APPROVED' && (
                            <>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDownloadXmlForTallyImport(inv);
                                }}
                                className="inline-flex items-center space-x-1 px-2.5 py-1 bg-[#EBF7EE] hover:bg-[#D4EDDA] text-[#14632E] border border-[#B7EB8F] rounded-[4px] text-xs font-sans font-medium transition shadow-2xs"
                                title="Download XML for Tally Import (Alt+O)"
                              >
                                <Download className="w-3 h-3 text-[#1B7F3B]" />
                                <span>Download XML for Tally Import</span>
                              </button>
                              <button
                                type="button"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleConfirmPostedInTally(inv);
                                }}
                                className="inline-flex items-center space-x-1 px-2.5 py-1 bg-[#1B7F3B] hover:bg-[#14632E] text-white rounded-[4px] text-xs font-sans font-medium transition shadow-2xs"
                                title="Confirm this voucher is posted in Tally Prime"
                              >
                                <CheckCircle2 className="w-3 h-3" />
                                <span>Confirm Posted in Tally</span>
                              </button>
                            </>
                          )}

                          {inv.status === 'CLARIFICATION_REQUESTED' && (
                            <button
                              onClick={() => onOpenClarificationThread(inv)}
                              className="inline-flex items-center space-x-1 px-2.5 py-1 bg-[#B42318] hover:bg-[#8F1A12] text-white rounded-[4px] text-xs font-sans font-medium transition shadow-sm"
                              title="Open query conversation"
                            >
                              <MessageSquare className="w-3.5 h-3.5" />
                              <span>Queries</span>
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}

                  {filteredQueueInvoices.length === 0 && (
                    <tr>
                      <td colSpan={9} className="py-8 text-center text-[#52606D] font-sans">
                        No invoices found matching the current search or status filter.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* VIEW 2: DETAILED REVIEW MODE (Side-by-side Document Viewer & 10-Point GST Engine) */}
      {viewMode === 'DETAIL_REVIEW' && editableInvoice && (
        <div className="space-y-4">
          {/* Top Invoice Selector & Navigation Bar */}
          <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-4 flex flex-wrap items-center justify-between gap-3 shadow-sm">
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setViewMode('QUEUE_TABLE')}
                className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#F5F7FA] hover:bg-[#EBF1FA] text-[#0B2545] border border-[#D9E2EC] rounded-[6px] text-xs font-medium transition shadow-sm"
                title="Return to Invoices Queue Table"
              >
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Queue</span>
              </button>

              <div className="h-4 w-[1px] bg-[#D9E2EC] hidden sm:block" />

              <span className="text-xs font-semibold text-[#52606D] uppercase tracking-wider hidden sm:inline">
                Reviewing:
              </span>
              <select
                value={selectedInvoiceId}
                onChange={(e) => setSelectedInvoiceId(e.target.value)}
                className="px-3 py-1.5 bg-white border border-[#D9E2EC] rounded-[6px] text-xs font-semibold text-[#1F2933] focus:outline-none focus:border-[#1F4E9C] font-mono"
              >
                {activeInvoices.map((inv) => (
                  <option key={inv.id} value={inv.id}>
                    {inv.invoiceNumber} • {inv.vendorName} ({inv.status}) - ₹{inv.invoiceTotal}
                  </option>
                ))}
              </select>

              <div className="flex items-center space-x-1">
                <button
                  disabled={!prevInvoice}
                  onClick={() => prevInvoice && setSelectedInvoiceId(prevInvoice.id)}
                  className="p-1.5 border border-[#D9E2EC] rounded-[4px] hover:bg-[#F5F7FA] disabled:opacity-30 disabled:cursor-not-allowed text-[#0B2545]"
                  title="Previous invoice in queue"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  disabled={!nextInvoice}
                  onClick={() => nextInvoice && setSelectedInvoiceId(nextInvoice.id)}
                  className="p-1.5 border border-[#D9E2EC] rounded-[4px] hover:bg-[#F5F7FA] disabled:opacity-30 disabled:cursor-not-allowed text-[#0B2545]"
                  title="Next invoice in queue"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex items-center space-x-3">
              <span className="text-xs text-[#52606D]">Status:</span>
              <span
                className={`px-2.5 py-0.5 rounded-[4px] text-xs font-semibold ${
                  editableInvoice.status === 'APPROVED'
                    ? 'badge-pass'
                    : editableInvoice.status === 'UNDER_REVIEW'
                    ? 'badge-warn'
                    : editableInvoice.status === 'CLARIFICATION_REQUESTED'
                    ? 'badge-fail'
                    : 'badge-info'
                }`}
              >
                {editableInvoice.status.replace(/_/g, ' ')}
              </span>
              {editableInvoice.currentFileVersion > 1 && (
                <span className="px-2 py-0.5 bg-[#EBF1FA] text-[#1F4E9C] border border-[#D9E2EC] rounded-[4px] text-xs font-mono">
                  Version {editableInvoice.currentFileVersion}
                </span>
              )}
            </div>
          </div>

      {/* Side-by-Side Main Split Screen */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        
        {/* LEFT COLUMN: Source Document Viewer */}
        <div className="bg-white border border-[#D9E2EC] rounded-[6px] shadow-sm flex flex-col min-h-[460px] lg:min-h-[580px] lg:max-h-[calc(100vh-140px)] lg:sticky lg:top-4 overflow-hidden">
          
          <div className="px-4 py-3 border-b border-[#D9E2EC] bg-[#F5F7FA] flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <FileText className="w-4 h-4 text-[#1F4E9C]" />
              <span className="text-xs font-bold text-[#0B2545]">{editableInvoice.fileName || 'Original_Source_Invoice.pdf'}</span>
              <span className="text-[10px] text-[#52606D]">({editableInvoice.fileType || 'PDF'})</span>
            </div>
            
            <div className="flex items-center space-x-2">
              <span className="text-xs text-[#52606D] font-mono">
                OCR Score: <strong className="text-[#1B7F3B]">{Math.round((editableInvoice.ocrConfidence || 0.95) * 100)}%</strong>
              </span>
            </div>
          </div>

          {/* Document Preview Pane */}
          <div className="flex-1 bg-[#F5F7FA] p-4 overflow-y-auto flex items-center justify-center">
            {editableInvoice.fileBase64 ? (
              editableInvoice.fileType?.includes('image') ? (
                <img
                  src={editableInvoice.fileBase64.startsWith('data:') ? editableInvoice.fileBase64 : `data:image/jpeg;base64,${editableInvoice.fileBase64}`}
                  alt="Source Invoice"
                  className="max-w-full max-h-full object-contain rounded-[4px] shadow-sm border border-[#D9E2EC]"
                />
              ) : (
                <iframe
                  src={editableInvoice.fileBase64.startsWith('data:') ? editableInvoice.fileBase64 : `data:application/pdf;base64,${editableInvoice.fileBase64}`}
                  title="Source PDF"
                  className="w-full h-full rounded-[4px] border border-[#D9E2EC]"
                />
              )
            ) : (
              /* Simulated Document Render of the Original Submitted Invoice */
              <div className="w-full max-w-md bg-white text-[#1F2933] p-6 rounded-[6px] shadow-sm space-y-4 font-sans text-xs border border-[#D9E2EC]">
                <div className="border-b-2 border-[#0B2545] pb-3 flex justify-between items-start">
                  <div>
                    <h2 className="font-bold text-sm uppercase text-[#0B2545]">{editableInvoice.vendorName}</h2>
                    <p className="text-[10px] text-[#52606D]">{currentVendor?.address || 'MIDC Industrial Area, Maharashtra'}</p>
                    <p className="font-mono text-[11px] font-semibold mt-1 text-[#1F2933]">GSTIN: {editableInvoice.vendorGstin}</p>
                  </div>
                  <div className="text-right">
                    <span className="px-2 py-0.5 bg-[#0B2545] text-white text-[10px] font-bold rounded-[4px]">
                      TAX INVOICE
                    </span>
                    <p className="font-mono font-bold text-xs mt-1 text-[#0B2545]">#{editableInvoice.invoiceNumber}</p>
                    <p className="text-[10px] text-[#52606D]">Date: {editableInvoice.invoiceDate}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-[11px] bg-[#F5F7FA] p-2.5 rounded-[4px] border border-[#D9E2EC]">
                  <div>
                    <span className="text-[#52606D] font-medium">Billed To (Recipient):</span>
                    <p className="font-bold text-[#0B2545]">{editableInvoice.buyerName}</p>
                    <p className="font-mono text-[#1F2933]">GSTIN: {editableInvoice.buyerGstin}</p>
                  </div>
                  <div>
                    <span className="text-[#52606D] font-medium">Place of Supply:</span>
                    <p className="font-bold text-[#0B2545]">{editableInvoice.placeOfSupply}</p>
                    <p className="text-[#52606D]">PO Ref: {editableInvoice.poReference || 'N/A'}</p>
                  </div>
                </div>

                <div className="border border-[#D9E2EC] rounded-[4px] overflow-hidden">
                  <table className="w-full text-[10px] text-left">
                    <thead className="bg-[#F5F7FA] font-bold border-b border-[#D9E2EC] text-[#0B2545]">
                      <tr>
                        <th className="p-1.5">Description</th>
                        <th className="p-1.5">HSN</th>
                        <th className="p-1.5 text-right">Qty</th>
                        <th className="p-1.5 text-right">Rate</th>
                        <th className="p-1.5 text-right">Taxable</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#D9E2EC]">
                      {editableInvoice.lineItems?.map((li) => (
                        <tr key={li.id} className="even:bg-[#F5F7FA]">
                          <td className="p-1.5 font-medium">{li.description}</td>
                          <td className="p-1.5 font-mono">{li.hsnSac}</td>
                          <td className="p-1.5 text-right">{li.quantity}</td>
                          <td className="p-1.5 text-right">₹{li.rate}</td>
                          <td className="p-1.5 text-right font-semibold">₹{li.taxableValue}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="pt-2 border-t border-[#D9E2EC] flex justify-between items-end">
                  <div className="text-[9px] text-[#52606D]">
                    <p>• Digitally generated tax document.</p>
                    <p>• Subject to local state jurisdiction.</p>
                  </div>
                  <div className="text-right text-[11px] space-y-0.5">
                    <p className="text-[#52606D]">Taxable: ₹{editableInvoice.totalTaxableValue.toFixed(2)}</p>
                    <p className="text-[#52606D]">GST: ₹{(editableInvoice.totalCgst + editableInvoice.totalSgst + editableInvoice.totalIgst).toFixed(2)}</p>
                    <p className="font-bold text-sm text-[#0B2545] border-t border-[#D9E2EC] pt-0.5">
                      Total: ₹{editableInvoice.invoiceTotal.toFixed(2)}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="px-4 py-2 border-t border-[#D9E2EC] bg-[#F5F7FA] text-xs text-[#52606D] flex items-center justify-between">
            <span>Original Source Invoice Document</span>
            <span className="font-mono text-[#1F4E9C]">Version {editableInvoice.currentFileVersion}</span>
          </div>

        </div>

        {/* RIGHT COLUMN: Extracted Fields, GST Rules, & Actions */}
        <div className="bg-white border border-[#D9E2EC] rounded-[6px] shadow-sm flex flex-col">
          
          {/* Sub Navigation */}
          <div className="px-5 py-3 border-b border-[#D9E2EC] bg-[#F5F7FA] flex items-center justify-between">
            <div className="flex space-x-2">
              <button
                onClick={() => setActiveTab('VALIDATION')}
                className={`px-3 py-1 rounded-[6px] text-xs font-semibold transition flex items-center space-x-1.5 ${
                  activeTab === 'VALIDATION'
                    ? 'bg-[#1F4E9C] text-white'
                    : 'text-[#52606D] hover:text-[#0B2545] hover:bg-[#EBF1FA]'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>GST Validations (10 Checks)</span>
                {hasFails ? (
                  <span className="px-1.5 py-0.5 bg-[#FEF3F2] text-[#B42318] border border-[#FECDCA] rounded text-[10px] font-bold">
                    FAIL
                  </span>
                ) : (
                  <span className="px-1.5 py-0.5 bg-[#EBF7EE] text-[#1B7F3B] border border-[#C3E8CC] rounded text-[10px] font-bold">
                    PASS
                  </span>
                )}
              </button>

              <button
                onClick={() => setActiveTab('LINE_ITEMS')}
                className={`px-3 py-1 rounded-[6px] text-xs font-semibold transition ${
                  activeTab === 'LINE_ITEMS'
                    ? 'bg-[#1F4E9C] text-white'
                    : 'text-[#52606D] hover:text-[#0B2545] hover:bg-[#EBF1FA]'
                }`}
              >
                Line Items & Tax Breakdown
              </button>
            </div>

            <div className="flex items-center space-x-2">
              {editableInvoice.status === 'POSTED' && (
                <span
                  className="inline-flex items-center space-x-1 px-2.5 py-1 bg-[#EDF7ED] text-[#1B7F3B] border border-[#C8E6C9] rounded-[6px] text-xs font-medium"
                  title="Voucher posted to Tally Prime. Record locked."
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-[#1B7F3B]" />
                  <span>Voucher Posted (Locked)</span>
                </span>
              )}

              {editableInvoice.status === 'APPROVED' && (
                <>
                  <button
                    type="button"
                    onClick={() => handleDownloadXmlForTallyImport(editableInvoice)}
                    className="flex items-center space-x-1 px-3 py-1 bg-[#EBF7EE] hover:bg-[#D4EDDA] text-[#14632E] border border-[#B7EB8F] rounded-[6px] text-xs font-medium transition cursor-pointer"
                    title="Download XML for Tally Import (Alt+O)"
                  >
                    <Download className="w-3.5 h-3.5 text-[#1B7F3B]" />
                    <span>Download XML for Tally Import</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => handleConfirmPostedInTally(editableInvoice)}
                    className="flex items-center space-x-1 px-3 py-1 bg-[#1B7F3B] hover:bg-[#14632E] text-white rounded-[6px] text-xs font-medium transition cursor-pointer"
                    title="Confirm this voucher is posted in Tally Prime"
                  >
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Confirm Posted in Tally</span>
                  </button>
                </>
              )}

              <button
                onClick={handleSaveEdits}
                className="flex items-center space-x-1 px-3 py-1 bg-white hover:bg-[#F5F7FA] text-[#1F2933] border border-[#D9E2EC] rounded-[6px] text-xs font-medium transition"
                title="Save any edits made on this screen"
              >
                <Save className="w-3.5 h-3.5 text-[#52606D]" />
                <span>Save Edits</span>
              </button>
            </div>
          </div>

          {/* Right Content Pane (Flows naturally without nested scroll trap) */}
          <div className="p-4 sm:p-5 space-y-5">
            {/* Real-Time GSTIN Verification Check (gstin.cloud live check on invoice open) */}
            <LiveGstinVerificationCard
              gstin={editableInvoice.vendorGstin}
              vendorName={editableInvoice.vendorName}
              vendorId={editableInvoice.vendorId}
            />

            {/* Header Particulars Form */}
            <div className="bg-[#F5F7FA] p-4 rounded-[6px] border border-[#D9E2EC] space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#0B2545] uppercase tracking-wider">
                  Extracted Invoice Particulars
                </span>
                <span className="text-[10px] text-[#52606D]">
                  Amber border indicates confidence &lt; {Math.round(confidenceThreshold * 100)}%
                </span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div>
                  <label className="block text-xs text-[#52606D] mb-1">Invoice Number</label>
                  <input
                    type="text"
                    value={editableInvoice.invoiceNumber}
                    onChange={(e) => handleFieldChange('invoiceNumber', e.target.value)}
                    className={`w-full px-2.5 py-1.5 bg-white border rounded-[6px] font-mono text-[#1F2933] text-xs ${
                      isLowConfidence('invoice_number') ? 'border-[#FF9933] bg-[#FFF7E6]' : 'border-[#D9E2EC]'
                    }`}
                  />
                  {isLowConfidence('invoice_number') && (
                    <span className="text-[10px] text-[#B26A00]">Low confidence extraction</span>
                  )}
                </div>

                <div>
                  <label className="block text-xs text-[#52606D] mb-1">Invoice Date</label>
                  <input
                    type="date"
                    value={editableInvoice.invoiceDate}
                    onChange={(e) => handleFieldChange('invoiceDate', e.target.value)}
                    className={`w-full px-2.5 py-1.5 bg-white border rounded-[6px] text-[#1F2933] text-xs ${
                      isLowConfidence('invoice_date') ? 'border-[#FF9933] bg-[#FFF7E6]' : 'border-[#D9E2EC]'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-xs text-[#52606D] mb-1">Supplier GSTIN</label>
                  <input
                    type="text"
                    value={editableInvoice.vendorGstin}
                    onChange={(e) => handleFieldChange('vendorGstin', e.target.value.toUpperCase())}
                    className={`w-full px-2.5 py-1.5 bg-white border rounded-[6px] font-mono text-[#1F2933] text-xs ${
                      isLowConfidence('supplier_gstin') ? 'border-[#FF9933] bg-[#FFF7E6]' : 'border-[#D9E2EC]'
                    }`}
                  />
                </div>

                <div>
                  <label className="block text-xs text-[#52606D] mb-1">Buyer GSTIN</label>
                  <input
                    type="text"
                    value={editableInvoice.buyerGstin}
                    onChange={(e) => handleFieldChange('buyerGstin', e.target.value.toUpperCase())}
                    className="w-full px-2.5 py-1.5 bg-white border border-[#D9E2EC] rounded-[6px] font-mono text-[#1F2933] text-xs"
                  />
                </div>

                <div>
                  <label className="block text-xs text-[#52606D] mb-1">Place of Supply</label>
                  <select
                    value={editableInvoice.placeOfSupply}
                    onChange={(e) => handleFieldChange('placeOfSupply', e.target.value)}
                    className="w-full px-2.5 py-1.5 bg-white border border-[#D9E2EC] rounded-[6px] text-[#1F2933] text-xs"
                  >
                    {Object.entries(GST_STATE_CODES).map(([c, n]) => (
                      <option key={c} value={`${c}-${n}`}>
                        {c} - {n}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs text-[#52606D] mb-1">Financial Year</label>
                  <input
                    type="text"
                    value={editableInvoice.financialYear}
                    disabled
                    className="w-full px-2.5 py-1.5 bg-[#F5F7FA] border border-[#D9E2EC] rounded-[6px] text-[#52606D] text-xs font-mono"
                  />
                </div>
              </div>
            </div>

            {/* Statutory TDS Withholding & Tally ERP Posting Card */}
            <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-4 shadow-xs space-y-3">
              <div className="flex items-center justify-between border-b border-[#D9E2EC] pb-2">
                <div className="flex items-center space-x-2">
                  <div className="p-1.5 bg-[#EBF1FA] text-[#1F4E9C] rounded-[4px]">
                    <Calculator className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-[#0B2545] uppercase tracking-wider">
                      Statutory TDS Withholding & ERP Posting
                    </h4>
                    <p className="text-[11px] text-[#52606D]">
                      Income Tax Act Section & Rate deduction for Tally Prime ledger posting
                    </p>
                  </div>
                </div>

                {editableInvoice.status === 'POSTED' ? (
                  <span
                    className="px-2.5 py-1 bg-[#EDF7ED] text-[#1B7F3B] border border-[#C8E6C9] rounded-[4px] text-xs font-semibold flex items-center space-x-1"
                    title="Invoice is locked after Tally posting. TDS details cannot be modified."
                  >
                    <Lock className="w-3.5 h-3.5" />
                    <span>TDS Locked (Posted)</span>
                  </span>
                ) : (
                  <button
                    type="button"
                    onClick={() => setShowTdsModal(true)}
                    className="px-2.5 py-1 bg-[#EBF1FA] hover:bg-[#D4E3F7] text-[#1F4E9C] border border-[#BACEEA] rounded-[4px] text-xs font-semibold flex items-center space-x-1 transition shadow-2xs cursor-pointer"
                  >
                    <Calculator className="w-3.5 h-3.5" />
                    <span>{editableInvoice.tdsSection ? 'Edit TDS Deduction' : 'Configure TDS Deduction'}</span>
                  </button>
                )}
              </div>

              {editableInvoice.tdsSection ? (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-xs font-mono">
                  <div className="p-2 bg-[#F5F7FA] rounded-[4px] border border-[#D9E2EC]">
                    <span className="text-[10px] text-[#52606D] font-sans block flex items-center justify-between">
                      <span>TDS Section & Rate</span>
                      {editableInvoice.isLowerDeductionCertificate && (
                        <span className="bg-[#1F4E9C] text-white text-[9px] px-1 py-0.2 rounded font-sans font-bold">
                          SEC 197 LDC
                        </span>
                      )}
                    </span>
                    <span className="font-bold text-[#0B2545]">
                      {editableInvoice.tdsSection === 'NO_TDS' ? 'Nil / Zero TDS' : `${editableInvoice.tdsSection} (${editableInvoice.tdsRate}%)`}
                    </span>
                  </div>

                  <div className="p-2 bg-[#F5F7FA] rounded-[4px] border border-[#D9E2EC]">
                    <span className="text-[10px] text-[#52606D] font-sans block">TDS Deducted</span>
                    <span className={`font-bold ${Number(editableInvoice.tdsAmount || 0) > 0 ? 'text-[#B42318]' : 'text-[#52606D]'}`}>
                      ₹{(Number(editableInvoice.tdsAmount) || 0).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </span>
                  </div>

                  <div className="p-2 bg-[#F5F7FA] rounded-[4px] border border-[#D9E2EC]">
                    <span className="text-[10px] text-[#52606D] font-sans block">Net Vendor Payable</span>
                    <span className="font-bold text-[#1B7F3B]">
                      ₹{(Number(editableInvoice.netPayableAmount) || (editableInvoice.invoiceTotal - Number(editableInvoice.tdsAmount || 0))).toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                    </span>
                  </div>

                  <div className="p-2 bg-[#F5F7FA] rounded-[4px] border border-[#D9E2EC]">
                    <span className="text-[10px] text-[#52606D] font-sans block">Tally TDS GL Ledger</span>
                    <span className="font-semibold text-[#1F4E9C] truncate block" title={editableInvoice.tdsGlAccount || 'Duties & Taxes'}>
                      {editableInvoice.tdsGlAccount || 'TDS Payable'}
                    </span>
                  </div>

                  {editableInvoice.isLowerDeductionCertificate && (
                    <div className="col-span-2 sm:col-span-4 p-2.5 bg-[#F0F5FF] border border-[#ADC8FF] rounded-[4px] text-xs font-sans text-[#0B2545] flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center space-x-2">
                        <ShieldCheck className="w-4 h-4 text-[#1F4E9C] shrink-0" />
                        <div>
                          <span className="font-bold text-[#1F4E9C]">Section 197 Lower Deduction Certificate:</span>{' '}
                          <span className="font-mono font-semibold">Cert #{editableInvoice.lowerDeductionCertNumber || 'FORM 13'}</span>
                          {editableInvoice.lowerDeductionCertValidTill && (
                            <span className="text-[#52606D] ml-2">
                              • Valid Till: <span className="font-mono text-[#0B2545]">{editableInvoice.lowerDeductionCertValidTill}</span>
                            </span>
                          )}
                          {editableInvoice.lowerDeductionCertLimit !== undefined && (
                            <span className="text-[#52606D] ml-2">
                              • Threshold Limit: <span className="font-mono text-[#0B2545]">₹{editableInvoice.lowerDeductionCertLimit.toLocaleString('en-IN')}</span>
                            </span>
                          )}
                        </div>
                      </div>
                      <span className="bg-[#1F4E9C] text-white text-[10px] font-mono px-2 py-0.5 rounded font-semibold">
                        LOWER RATE: {editableInvoice.tdsRate}%
                      </span>
                    </div>
                  )}

                  {editableInvoice.noTdsReason && (
                    <div className="col-span-2 sm:col-span-4 p-2 bg-[#FFF7E6] border border-[#FFE7BA] rounded-[4px] text-xs font-sans text-[#B26A00]">
                      <strong>Nil TDS Justification:</strong> {editableInvoice.noTdsReason}
                    </div>
                  )}
                </div>
              ) : (
                <div className="p-3 bg-[#F5F7FA] border border-dashed border-[#D9E2EC] rounded-[4px] flex items-center justify-between text-xs text-[#52606D]">
                  <span>TDS deduction not yet configured for this invoice. Click to deduct TDS before Tally Prime XML import.</span>
                  <button
                    type="button"
                    onClick={() => setShowTdsModal(true)}
                    className="font-semibold text-[#1F4E9C] hover:underline"
                  >
                    Select TDS Section &rarr;
                  </button>
                </div>
              )}
            </div>

            {/* TAB 1: 10-Point GST Statutory Validation Engine Results */}
            {activeTab === 'VALIDATION' && (
              <div className="space-y-3">
                <div className="flex items-center justify-between pb-1">
                  <h4 className="text-xs font-bold text-[#0B2545] uppercase tracking-wider">
                    Statutory Rule Engine Checks
                  </h4>
                  <span className="text-xs text-[#52606D]">
                    Tolerance: ±₹{companySettings.decimalTolerance?.toFixed(2) || '1.00'}
                  </span>
                </div>

                <div className="space-y-2">
                  {validationResult?.checks?.map((check) => (
                    <div
                      key={check.ruleId}
                      className={`p-3 rounded-[6px] border text-xs transition ${
                        check.status === 'PASS'
                          ? 'bg-[#EBF7EE]/40 border-[#C3E8CC]'
                          : check.status === 'WARN'
                          ? 'bg-[#FFF7E6]/50 border-[#FFE7BA]'
                          : 'bg-[#FEF3F2]/60 border-[#FECDCA]'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-2.5">
                          {check.status === 'PASS' && (
                            <CheckCircle2 className="w-4 h-4 text-[#1B7F3B] shrink-0 mt-0.5" />
                          )}
                          {check.status === 'WARN' && (
                            <AlertTriangle className="w-4 h-4 text-[#B26A00] shrink-0 mt-0.5" />
                          )}
                          {check.status === 'FAIL' && (
                            <XCircle className="w-4 h-4 text-[#B42318] shrink-0 mt-0.5" />
                          )}
                          <div>
                            <div className="flex items-center space-x-2">
                              <span className="font-semibold text-[#0B2545]">{check.name}</span>
                              <span
                                className={`px-1.5 py-0.5 rounded-[4px] text-[10px] font-bold ${
                                  check.status === 'PASS'
                                    ? 'badge-pass'
                                    : check.status === 'WARN'
                                    ? 'badge-warn'
                                    : 'badge-fail'
                                }`}
                              >
                                {check.status}
                              </span>
                            </div>
                            <p className="text-[#1F2933] mt-1 leading-relaxed">{check.reason}</p>
                            <p className="text-[10px] text-[#52606D] font-mono mt-1">
                              Ref: {check.legalReference}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* TAB 2: Line Items Editor */}
            {activeTab === 'LINE_ITEMS' && (
              <div className="space-y-4">
                <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545] sticky top-0">
                      <tr>
                        <th className="p-2 font-semibold">Description</th>
                        <th className="p-2 font-semibold w-24">HSN/SAC</th>
                        <th className="p-2 font-semibold w-16 text-right">Qty</th>
                        <th className="p-2 font-semibold w-20 text-right">Rate</th>
                        <th className="p-2 font-semibold w-16 text-right">Disc</th>
                        <th className="p-2 font-semibold w-24 text-right">Taxable</th>
                        <th className="p-2 font-semibold w-24 text-right">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#D9E2EC] font-mono">
                      {editableInvoice.lineItems.map((item, idx) => (
                        <tr key={item.id} className="even:bg-[#F5F7FA]">
                          <td className="p-2 font-sans">
                            <input
                              type="text"
                              value={item.description}
                              onChange={(e) => handleLineChange(idx, 'description', e.target.value)}
                              className="w-full px-2 py-1 bg-white border border-[#D9E2EC] rounded text-[#1F2933] text-xs"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="text"
                              value={item.hsnSac}
                              onChange={(e) => handleLineChange(idx, 'hsnSac', e.target.value)}
                              className="w-full px-2 py-1 bg-white border border-[#D9E2EC] rounded text-center text-[#1F2933] text-xs font-mono"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="number"
                              value={item.quantity}
                              onChange={(e) => handleLineChange(idx, 'quantity', parseFloat(e.target.value) || 0)}
                              className="w-full px-2 py-1 bg-white border border-[#D9E2EC] rounded text-right text-[#1F2933] text-xs"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="number"
                              value={item.rate}
                              onChange={(e) => handleLineChange(idx, 'rate', parseFloat(e.target.value) || 0)}
                              className="w-full px-2 py-1 bg-white border border-[#D9E2EC] rounded text-right text-[#1F2933] text-xs"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="number"
                              value={item.discount}
                              onChange={(e) => handleLineChange(idx, 'discount', parseFloat(e.target.value) || 0)}
                              className="w-full px-2 py-1 bg-white border border-[#D9E2EC] rounded text-right text-[#1F2933] text-xs"
                            />
                          </td>
                          <td className="p-2 text-right text-[#1F2933]">
                            ₹{item.taxableValue.toFixed(2)}
                          </td>
                          <td className="p-2 text-right font-semibold text-[#0B2545]">
                            ₹{item.total.toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Arithmetic Reconciliation Card */}
                <div className="bg-[#F5F7FA] p-4 rounded-[6px] border border-[#D9E2EC] space-y-2 text-xs">
                  <div className="flex justify-between text-[#52606D]">
                    <span>Taxable Base Value:</span>
                    <span className="font-mono text-[#1F2933] font-medium">₹{editableInvoice.totalTaxableValue.toFixed(2)}</span>
                  </div>
                  {editableInvoice.totalCgst > 0 && (
                    <div className="flex justify-between text-[#52606D]">
                      <span>CGST (Intra-state Central Tax):</span>
                      <span className="font-mono text-[#1F2933] font-medium">₹{editableInvoice.totalCgst.toFixed(2)}</span>
                    </div>
                  )}
                  {editableInvoice.totalSgst > 0 && (
                    <div className="flex justify-between text-[#52606D]">
                      <span>SGST (Intra-state State Tax):</span>
                      <span className="font-mono text-[#1F2933] font-medium">₹{editableInvoice.totalSgst.toFixed(2)}</span>
                    </div>
                  )}
                  {editableInvoice.totalIgst > 0 && (
                    <div className="flex justify-between text-[#52606D]">
                      <span>IGST (Inter-state Integrated Tax):</span>
                      <span className="font-mono text-[#1F2933] font-medium">₹{editableInvoice.totalIgst.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-[#52606D]">
                    <span>Round-Off Adjustment:</span>
                    <span className="font-mono text-[#1F2933] font-medium">₹{editableInvoice.roundOff.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between pt-2 border-t border-[#D9E2EC] font-bold text-sm text-[#0B2545]">
                    <span>Final Reconciled Total:</span>
                    <span className="font-mono text-[#1B7F3B]">₹{editableInvoice.invoiceTotal.toFixed(2)}</span>
                  </div>

                  {editableInvoice.tdsSection && (
                    <div className="mt-2 pt-2 border-t border-dashed border-[#D9E2EC] space-y-1 bg-[#F0F4F8] p-2.5 rounded-[4px]">
                      <div className="flex justify-between text-xs text-[#0B2545] font-semibold">
                        <span>TDS Deduction ({editableInvoice.tdsSection} @ {editableInvoice.tdsRate}%):</span>
                        <span className="font-mono text-[#B42318]">-₹{(editableInvoice.tdsAmount || 0).toFixed(2)}</span>
                      </div>
                      {editableInvoice.noTdsReason && (
                        <div className="text-[11px] text-[#52606D]">
                          Reason for No TDS: <span className="italic font-medium text-[#1F2933]">"{editableInvoice.noTdsReason}"</span>
                        </div>
                      )}
                      <div className="flex justify-between font-bold text-xs text-[#0B2545] pt-1.5 border-t border-[#D9E2EC]">
                        <span>Net Settlement Payable to Vendor:</span>
                        <span className="font-mono text-[#1B7F3B]">₹{(editableInvoice.netPayableAmount ?? editableInvoice.invoiceTotal).toFixed(2)}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

          </div>

          {/* Bottom Fixed Action Bar (Sticky at bottom, accessible at all viewport heights) */}
          <div className="sticky bottom-0 z-30 bg-[#F5F7FA]/95 backdrop-blur-xs border-t border-[#D9E2EC] px-4 sm:px-5 py-3 shadow-lg rounded-b-[6px]">
            {editableInvoice.status === 'APPROVED' || editableInvoice.status === 'POSTED' ? (
              <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-[#EDF7ED] p-3 rounded-[6px] border border-[#C8E6C9]">
                <div className="flex items-center space-x-2 text-xs">
                  <CheckCircle2 className="w-5 h-5 text-[#1B7F3B] shrink-0" />
                  <div>
                    <div className="font-bold text-[#1B7F3B]">
                      {editableInvoice.status === 'POSTED'
                        ? 'Invoice Successfully Posted to Tally Prime'
                        : 'Invoice Approved & Queued for Tally Prime Bridge Agent'}
                    </div>
                    <div className="text-[11px] text-[#2D5A27] space-y-0.5">
                      <div>
                        {editableInvoice.overrideReason
                          ? `Approved with Statutory Override by ${editableInvoice.overriddenBy || 'Accounts Executive'}: "${editableInvoice.overrideReason}"`
                          : `Verified & approved by ${editableInvoice.reviewedByName || 'Accounts Executive'}. Status locked.`}
                      </div>
                      {editableInvoice.tdsSection && (
                        <div className="font-medium text-[#1B7F3B]">
                          TDS {editableInvoice.tdsSection} ({editableInvoice.tdsRate}%): ₹{(editableInvoice.tdsAmount || 0).toFixed(2)} | Net Payable: ₹{(editableInvoice.netPayableAmount ?? editableInvoice.invoiceTotal).toLocaleString('en-IN')}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-2 shrink-0">
                  {editableInvoice.status === 'POSTED' && (
                    <>
                      <span className="inline-flex items-center space-x-1.5 px-3 py-2 bg-white text-[#1B7F3B] border border-[#C8E6C9] font-medium rounded-[6px] text-xs">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Tally Posted (Locked)</span>
                      </span>
                      <span className="inline-flex items-center space-x-1.5 px-3 py-2 bg-[#F0F4F8] text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs">
                        <Lock className="w-3.5 h-3.5 text-[#52606D]" />
                        <span>TDS Locked</span>
                      </span>
                    </>
                  )}

                  {editableInvoice.status === 'APPROVED' && (
                    <>
                      <button
                        type="button"
                        onClick={() => handleDownloadXmlForTallyImport(editableInvoice)}
                        className="flex items-center space-x-1.5 px-3 py-2 bg-[#EBF7EE] hover:bg-[#D4EDDA] text-[#14632E] border border-[#B7EB8F] font-semibold rounded-[6px] text-xs transition shadow-2xs cursor-pointer"
                        title="Download XML for Tally Import (Alt+O)"
                      >
                        <Download className="w-3.5 h-3.5 text-[#1B7F3B]" />
                        <span>Download XML for Tally Import</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => handleConfirmPostedInTally(editableInvoice)}
                        className="flex items-center space-x-1.5 px-3 py-2 bg-[#1B7F3B] hover:bg-[#14632E] text-white font-semibold rounded-[6px] text-xs transition shadow-2xs cursor-pointer"
                        title="Confirm this voucher is posted in Tally Prime"
                      >
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Confirm Posted in Tally</span>
                      </button>
                      <button
                        type="button"
                        onClick={() => setShowTdsModal(true)}
                        className="flex items-center space-x-1.5 px-3 py-2 bg-[#EBF1FA] hover:bg-[#D4E3F7] text-[#1F4E9C] border border-[#BACEEA] font-medium rounded-[6px] text-xs transition shadow-2xs cursor-pointer"
                        title="Update TDS Deduction"
                      >
                        <Calculator className="w-3.5 h-3.5" />
                        <span>Update TDS</span>
                      </button>
                    </>
                  )}

                  <button
                    onClick={() => setViewMode('QUEUE_TABLE')}
                    className="flex items-center space-x-1.5 px-4 py-2 bg-[#1F4E9C] hover:bg-[#173B77] text-white font-medium rounded-[6px] text-xs transition shadow-xs"
                  >
                    <ArrowLeft className="w-3.5 h-3.5" />
                    <span>Return to Review Queue</span>
                  </button>

                  {nextPendingInvoice && (
                    <button
                      onClick={() => {
                        setSelectedInvoiceId(nextPendingInvoice.id);
                        setEditableInvoice(JSON.parse(JSON.stringify(nextPendingInvoice)));
                      }}
                      className="flex items-center space-x-1.5 px-4 py-2 bg-white hover:bg-[#F5F7FA] text-[#0B2545] border border-[#D9E2EC] font-medium rounded-[6px] text-xs transition shadow-xs"
                    >
                      <span>Review Next ({nextPendingInvoice.invoiceNumber})</span>
                      <ChevronRight className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            ) : (
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div className="flex items-center space-x-2">
                  <button
                    onClick={() => setShowQueryModal(true)}
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-white hover:bg-[#FFF7E6] border border-[#FFE7BA] text-[#B26A00] rounded-[6px] text-xs font-medium transition"
                  >
                    <HelpCircle className="w-3.5 h-3.5 text-[#B26A00]" />
                    <span>Request Clarification</span>
                  </button>

                  <button
                    onClick={() => setShowRejectModal(true)}
                    className="flex items-center space-x-1.5 px-3 py-1.5 bg-white hover:bg-[#FEF3F2] border border-[#FECDCA] text-[#B42318] rounded-[6px] text-xs font-medium transition"
                  >
                    <XCircle className="w-3.5 h-3.5 text-[#B42318]" />
                    <span>Reject</span>
                  </button>
                </div>

                <div className="flex items-center space-x-2">
                  {hasFails ? (
                    <>
                      <div
                        className="flex items-center space-x-1.5 px-3 py-1.5 bg-white border border-[#FECDCA] text-[#B42318] rounded-[6px] text-xs cursor-not-allowed"
                        title="Approval is blocked while any statutory check fails."
                      >
                        <Lock className="w-3.5 h-3.5 text-[#B42318]" />
                        <span>Approval Blocked (GST Fail)</span>
                      </div>

                      {Boolean(currentUser?.canOverride || currentUser?.role === 'ADMIN') ? (
                        <button
                          onClick={() => setShowOverrideModal(true)}
                          className="flex items-center space-x-1.5 px-4 py-1.5 bg-[#B26A00] hover:bg-[#8C5300] text-white font-medium rounded-[6px] text-xs transition"
                        >
                          <Unlock className="w-3.5 h-3.5" />
                          <span>Override & Approve</span>
                        </button>
                      ) : (
                        <span className="text-xs text-[#52606D] italic">
                          Override permission required to approve failing checks
                        </span>
                      )}
                    </>
                  ) : (
                    <button
                      onClick={handleApprove}
                      className="flex items-center space-x-1.5 px-5 py-2 bg-[#1B7F3B] hover:bg-[#14632E] text-white font-medium rounded-[6px] text-xs transition"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Approve & Queue for Tally</span>
                    </button>
                  )}
                </div>
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  )}

      {/* Override Justification Modal */}
      {showOverrideModal && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <div className="bg-white border border-[#D9E2EC] w-full max-w-md rounded-[6px] p-6 shadow-lg space-y-4">
            <div className="flex items-center space-x-2 text-[#B26A00]">
              <Unlock className="w-5 h-5" />
              <h3 className="text-sm font-bold text-[#0B2545]">Override Statutory Rule & Approve</h3>
            </div>
            <p className="text-xs text-[#52606D]">
              One or more statutory validations have reported issues. To proceed with approval, you must record a mandatory justification. This action is permanently logged to the append-only audit trail.
            </p>
            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                Mandatory Override Justification *
              </label>
              <textarea
                value={overrideReason}
                onChange={(e) => setOverrideReason(e.target.value)}
                rows={3}
                placeholder="e.g. Approved under special ITC relaxation or client commercial agreement..."
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
              />
            </div>
            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setShowOverrideModal(false)}
                className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmOverrideToTds}
                disabled={!overrideReason.trim()}
                className="px-4 py-1.5 bg-[#B26A00] hover:bg-[#8C5300] disabled:opacity-50 text-white font-medium rounded-[6px] text-xs transition"
              >
                Proceed to TDS & Approve
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Clarification Query Modal */}
      {showQueryModal && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <div className="bg-white border border-[#D9E2EC] w-full max-w-lg rounded-[6px] p-6 shadow-lg space-y-4">
            <div className="flex items-center space-x-2 text-[#B42318]">
              <HelpCircle className="w-5 h-5" />
              <h3 className="text-sm font-bold text-[#0B2545]">Request Clarification from Vendor</h3>
            </div>
            <p className="text-xs text-[#52606D]">
              The invoice status will be moved to <strong className="text-[#B42318] font-mono">CLARIFICATION_REQUESTED</strong>. The vendor will receive an alert to resubmit corrected particulars.
            </p>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-[#1F2933] mb-1 font-medium">Target Field / Scope</label>
                <select
                  value={queryTargetField}
                  onChange={(e) => setQueryTargetField(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-[#1F2933]"
                >
                  <option value="Whole Invoice">Whole Invoice</option>
                  <option value="HSN/SAC Code">HSN/SAC Code</option>
                  <option value="Tax Split (CGST/SGST/IGST)">Tax Split (CGST/SGST/IGST)</option>
                  <option value="Invoice Number / Serial Format">Invoice Number / Serial Format</option>
                  <option value="Arithmetic Reconciliation">Arithmetic Reconciliation</option>
                  <option value="Buyer GSTIN Particulars">Buyer GSTIN Particulars</option>
                </select>
              </div>

              <div>
                <label className="block text-[#1F2933] mb-1 font-medium">Reason Code</label>
                <select
                  value={queryReasonCode}
                  onChange={(e) => setQueryReasonCode(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-[#1F2933]"
                >
                  <option value="RULE_46_DISCREPANCY">Rule 46 Particulars Missing</option>
                  <option value="HSN_LENGTH_MISMATCH">HSN Code Length Violation</option>
                  <option value="INCORRECT_TAX_SPLIT">Incorrect Intra/Inter State Tax</option>
                  <option value="ARITHMETIC_TOTAL_MISMATCH">Line Total Arithmetic Mismatch</option>
                  <option value="COMPOSITION_TAX_CHARGED">Composition Tax Charged Error</option>
                  <option value="SUPPORTING_DOC_REQUIRED">Supporting Delivery Challan / PO</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                Detailed Clarification Query Remarks *
              </label>
              <textarea
                value={queryText}
                onChange={(e) => setQueryText(e.target.value)}
                rows={4}
                placeholder="Specify the exact issue and required resolution..."
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
              />
            </div>

            <div className="p-2.5 bg-[#F5F7FA] rounded-[6px] border border-[#D9E2EC] text-xs text-[#52606D] flex justify-between">
              <span>SLA Response Window:</span>
              <span className="font-semibold text-[#B26A00]">{companySettings.querySlaHours || 48} Hours</span>
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setShowQueryModal(false)}
                className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleRaiseQuery}
                className="px-4 py-1.5 bg-[#B42318] hover:bg-[#8F1A12] text-white font-medium rounded-[6px] text-xs"
              >
                Send Clarification Request
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Reject Modal */}
      {showRejectModal && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <div className="bg-white border border-[#D9E2EC] w-full max-w-md rounded-[6px] p-6 shadow-lg space-y-4">
            <h3 className="text-sm font-bold text-[#0B2545]">Reject Tax Invoice</h3>
            <p className="text-xs text-[#52606D]">
              Provide a mandatory reason for rejection. The vendor will be notified and the invoice will be marked as REJECTED.
            </p>
            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">Rejection Reason *</label>
              <textarea
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
                rows={3}
                placeholder="State the non-correctable defect..."
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
              />
            </div>
            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setShowRejectModal(false)}
                className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleReject}
                className="px-4 py-1.5 bg-[#B42318] hover:bg-[#8F1A12] text-white font-medium rounded-[6px] text-xs"
              >
                Confirm Rejection
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Action Completed Notice / Transition Modal */}
      {actionNotice && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <div className="bg-white border border-[#D9E2EC] w-full max-w-md rounded-[6px] p-6 shadow-xl space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex items-center space-x-3">
              <div className={`p-2.5 rounded-full ${
                actionNotice.type === 'APPROVED' || actionNotice.type === 'OVERRIDDEN'
                  ? 'bg-[#EDF7ED] text-[#1B7F3B]'
                  : actionNotice.type === 'REJECTED'
                  ? 'bg-[#FEF3F2] text-[#B42318]'
                  : 'bg-[#FFF7E6] text-[#B26A00]'
              }`}>
                {actionNotice.type === 'APPROVED' ? (
                  <CheckCircle2 className="w-6 h-6" />
                ) : actionNotice.type === 'OVERRIDDEN' ? (
                  <Unlock className="w-6 h-6" />
                ) : actionNotice.type === 'REJECTED' ? (
                  <XCircle className="w-6 h-6" />
                ) : (
                  <HelpCircle className="w-6 h-6" />
                )}
              </div>
              <div>
                <h3 className="text-sm font-bold text-[#0B2545]">{actionNotice.title}</h3>
                <p className="text-xs text-[#52606D] mt-0.5">{actionNotice.message}</p>
              </div>
            </div>

            <div className="flex items-center justify-end space-x-2 pt-2 border-t border-[#D9E2EC]">
              <button
                onClick={() => {
                  setActionNotice(null);
                  setViewMode('QUEUE_TABLE');
                }}
                className="px-4 py-2 bg-[#1F4E9C] hover:bg-[#173B77] text-white font-medium rounded-[6px] text-xs transition shadow-xs flex items-center space-x-1.5"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Return to Queue</span>
              </button>

              {actionNotice.nextPendingId && (
                <button
                  onClick={() => {
                    const nextId = actionNotice.nextPendingId!;
                    setActionNotice(null);
                    setSelectedInvoiceId(nextId);
                    const nextInv = invoices.find((i) => i.id === nextId);
                    if (nextInv) {
                      setEditableInvoice(JSON.parse(JSON.stringify(nextInv)));
                    }
                    setViewMode('DETAIL_REVIEW');
                  }}
                  className="px-4 py-2 bg-[#0B2545] hover:bg-[#173B77] text-white font-medium rounded-[6px] text-xs transition shadow-xs flex items-center space-x-1.5"
                >
                  <span>Review Next ({actionNotice.nextPendingNumber})</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TDS Approval & Deduction Modal */}
      {showTdsModal && editableInvoice && (
        <TdsApprovalModal
          invoice={editableInvoice}
          isOpen={showTdsModal}
          isOverrideApproval={pendingIsOverride}
          configuredGlLedgers={companySettings.tdsGlLedgers}
          onClose={() => setShowTdsModal(false)}
          onConfirmApproval={handleFinalizeApprovalWithTds}
        />
      )}

      {/* Tally XML Download Confirmation Notification */}
      {downloadNotice && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#0B2545] text-white px-4 py-2.5 rounded-[6px] shadow-xl border border-[#1F4E9C] flex items-center space-x-2.5 text-xs animate-in fade-in slide-in-from-bottom-2 duration-150">
          <div className="p-1 bg-[#1B7F3B] rounded-full text-white">
            <CheckCircle2 className="w-3.5 h-3.5" />
          </div>
          <div>
            <div className="font-semibold text-white flex items-center space-x-1">
              <span>{downloadNotice.isImport ? 'Tally XML for Import Downloaded' : 'Tally XML Downloaded'}</span>
              <span className="text-[#A5C8ED]">#{downloadNotice.invoiceNumber}</span>
            </div>
            <div className="font-mono text-[11px] text-[#A5C8ED]">{downloadNotice.filename}</div>
          </div>
          <button
            type="button"
            onClick={() => setDownloadNotice(null)}
            className="ml-3 text-[#A5C8ED] hover:text-white font-bold cursor-pointer text-sm"
          >
            &times;
          </button>
        </div>
      )}

    </div>
  );
};

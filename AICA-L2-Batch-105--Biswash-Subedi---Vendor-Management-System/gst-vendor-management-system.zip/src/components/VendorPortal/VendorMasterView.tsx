/**
 * Vendor Master Profile Management
 * Validates 15-character Indian GSTIN, checksum, and PAN match.
 * Restyled with ICAI-inspired theme: White cards, Navy #0B2545, Blue #1F4E9C, 6px radius.
 */

import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { validateGSTIN } from '../../utils/gstUtils.ts';
import { Building2, ShieldCheck, AlertCircle, CheckCircle2, Save, Landmark } from 'lucide-react';

export const VendorMasterView: React.FC = () => {
  const { activeVendor, saveVendor } = useAuth();

  const [legalName, setLegalName] = useState(activeVendor?.legalName || '');
  const [tradeName, setTradeName] = useState(activeVendor?.tradeName || '');
  const [gstin, setGstin] = useState(activeVendor?.gstin || '');
  const [address, setAddress] = useState(activeVendor?.address || '');
  const [pincode, setPincode] = useState(activeVendor?.pincode || '');
  const [contactPerson, setContactPerson] = useState(activeVendor?.contactPerson || '');
  const [email, setEmail] = useState(activeVendor?.email || '');
  const [phone, setPhone] = useState(activeVendor?.phone || '');
  
  const [bankAccountName, setBankAccountName] = useState(activeVendor?.bankAccountName || '');
  const [bankAccountNumber, setBankAccountNumber] = useState(activeVendor?.bankAccountNumber || '');
  const [bankIfsc, setBankIfsc] = useState(activeVendor?.bankIfsc || '');
  const [bankName, setBankName] = useState(activeVendor?.bankName || '');

  const [isMsme, setIsMsme] = useState(activeVendor?.isMsme || false);
  const [msmeReg, setMsmeReg] = useState(activeVendor?.msmeRegistrationNumber || '');
  const [isComposition, setIsComposition] = useState(activeVendor?.isComposition || false);
  const [turnoverCategory, setTurnoverCategory] = useState<'UP_TO_5CR' | 'ABOVE_5CR'>(
    activeVendor?.turnoverCategory || 'UP_TO_5CR'
  );

  const [saveSuccess, setSaveSuccess] = useState(false);

  // Validate GSTIN on the fly
  const gstinCheck = validateGSTIN(gstin);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (!gstinCheck.isValid) {
      alert(`Invalid GSTIN: ${gstinCheck.reason}`);
      return;
    }

    if (!activeVendor) return;

    const updated = {
      ...activeVendor,
      legalName,
      tradeName,
      gstin: gstin.toUpperCase(),
      pan: gstinCheck.pan,
      stateCode: gstinCheck.stateCode,
      stateName: gstinCheck.stateName,
      address,
      pincode,
      contactPerson,
      email,
      phone,
      bankAccountName,
      bankAccountNumber,
      bankIfsc: bankIfsc.toUpperCase(),
      bankName,
      isMsme,
      msmeRegistrationNumber: msmeReg,
      isComposition,
      turnoverCategory,
      updatedAt: new Date().toISOString(),
    };

    saveVendor(updated);
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-6 shadow-sm flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 bg-[#EBF1FA] text-[#1F4E9C] rounded-[4px]">
            <Building2 className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-[#0B2545]">GST Registered Vendor Profile</h2>
            <p className="text-xs text-[#52606D]">
              GSTIN, PAN, and Banking Master particulars
            </p>
          </div>
        </div>

        <span className={`px-3 py-1 rounded-[4px] text-xs font-semibold ${
          activeVendor?.status === 'ACTIVE'
            ? 'badge-pass'
            : 'badge-warn'
        }`}>
          {activeVendor?.status === 'ACTIVE' ? 'Active Approved' : 'Pending Approval'}
        </span>
      </div>

      {saveSuccess && (
        <div className="p-4 bg-[#EBF7EE] border border-[#C3E8CC] rounded-[6px] text-[#1B7F3B] text-xs flex items-center space-x-2">
          <CheckCircle2 className="w-5 h-5 text-[#1B7F3B] shrink-0" />
          <span className="font-medium">Vendor master particulars updated successfully.</span>
        </div>
      )}

      {/* Profile Form */}
      <form onSubmit={handleSave} className="bg-white border border-[#D9E2EC] rounded-[6px] p-6 shadow-sm space-y-6">
        
        {/* Section 1: GST Identification */}
        <div className="space-y-4">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#0B2545] border-b border-[#D9E2EC] pb-2 flex items-center space-x-2">
            <ShieldCheck className="w-4 h-4 text-[#1F4E9C]" />
            <span>1. Statutory GST Registration</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                Legal Entity Name *
              </label>
              <input
                type="text"
                value={legalName}
                onChange={(e) => setLegalName(e.target.value)}
                required
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                Trade Name (if different)
              </label>
              <input
                type="text"
                value={tradeName}
                onChange={(e) => setTradeName(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                15-Digit GSTIN *
              </label>
              <input
                type="text"
                maxLength={15}
                value={gstin}
                onChange={(e) => setGstin(e.target.value.toUpperCase())}
                placeholder="27AAACA1234A1Z1"
                required
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono focus:outline-none focus:border-[#1F4E9C] uppercase"
              />
              {gstin && !gstinCheck.isValid && (
                <p className="text-xs text-[#B42318] mt-1 flex items-center space-x-1">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0 text-[#B42318]" />
                  <span>{gstinCheck.reason}</span>
                </p>
              )}
              {gstin && gstinCheck.isValid && (
                <p className="text-xs text-[#1B7F3B] mt-1 flex items-center space-x-1">
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0 text-[#1B7F3B]" />
                  <span>Valid GSTIN Checksum ({gstinCheck.stateName}, PAN: {gstinCheck.pan})</span>
                </p>
              )}
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                Turnover Category
              </label>
              <select
                value={turnoverCategory}
                onChange={(e) => setTurnoverCategory(e.target.value as any)}
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
              >
                <option value="UP_TO_5CR">Aggregate Turnover ≤ ₹5 Crore (Min 4-digit HSN)</option>
                <option value="ABOVE_5CR">Aggregate Turnover &gt; ₹5 Crore (Min 6-digit HSN)</option>
              </select>
            </div>
          </div>

          <div className="flex items-center space-x-6 pt-2">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isComposition}
                onChange={(e) => setIsComposition(e.target.checked)}
                className="w-4 h-4 text-[#1F4E9C] rounded border-[#D9E2EC]"
              />
              <span className="text-xs text-[#1F2933]">Composition Scheme Taxpayer</span>
            </label>

            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isMsme}
                onChange={(e) => setIsMsme(e.target.checked)}
                className="w-4 h-4 text-[#1F4E9C] rounded border-[#D9E2EC]"
              />
              <span className="text-xs text-[#1F2933]">MSME / Udyam Registered</span>
            </label>
          </div>

          {isMsme && (
            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                Udyam Registration Number
              </label>
              <input
                type="text"
                value={msmeReg}
                onChange={(e) => setMsmeReg(e.target.value)}
                placeholder="UDYAM-MH-12-0045612"
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono focus:outline-none focus:border-[#1F4E9C]"
              />
            </div>
          )}
        </div>

        {/* Section 2: Address & Contact */}
        <div className="space-y-4 pt-4 border-t border-[#D9E2EC]">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#0B2545] border-b border-[#D9E2EC] pb-2">
            2. Registered Principal Place of Business
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                Registered Address
              </label>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                PIN Code
              </label>
              <input
                type="text"
                value={pincode}
                onChange={(e) => setPincode(e.target.value)}
                maxLength={6}
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono focus:outline-none focus:border-[#1F4E9C]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                Contact Person
              </label>
              <input
                type="text"
                value={contactPerson}
                onChange={(e) => setContactPerson(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                Email Address
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                Mobile Number
              </label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono focus:outline-none focus:border-[#1F4E9C]"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Bank Details */}
        <div className="space-y-4 pt-4 border-t border-[#D9E2EC]">
          <h3 className="text-xs font-bold uppercase tracking-wider text-[#0B2545] border-b border-[#D9E2EC] pb-2 flex items-center space-x-2">
            <Landmark className="w-4 h-4 text-[#1F4E9C]" />
            <span>3. Bank Account Particulars (for Direct RTGS/NEFT)</span>
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                Bank Beneficiary Account Name
              </label>
              <input
                type="text"
                value={bankAccountName}
                onChange={(e) => setBankAccountName(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                Bank Account Number
              </label>
              <input
                type="text"
                value={bankAccountNumber}
                onChange={(e) => setBankAccountNumber(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono focus:outline-none focus:border-[#1F4E9C]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                IFSC Code (11 alphanumeric)
              </label>
              <input
                type="text"
                value={bankIfsc}
                maxLength={11}
                onChange={(e) => setBankIfsc(e.target.value.toUpperCase())}
                placeholder="HDFC0000240"
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono uppercase focus:outline-none focus:border-[#1F4E9C]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">
                Bank & Branch Name
              </label>
              <input
                type="text"
                value={bankName}
                onChange={(e) => setBankName(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
              />
            </div>
          </div>
        </div>

        {/* Form Actions */}
        <div className="flex justify-end pt-4 border-t border-[#D9E2EC]">
          <button
            type="submit"
            className="flex items-center space-x-2 px-6 py-2 bg-[#1F4E9C] hover:bg-[#173B77] text-white text-xs font-medium rounded-[6px] transition"
          >
            <Save className="w-4 h-4" />
            <span>Update Vendor Master</span>
          </button>
        </div>

      </form>

    </div>
  );
};

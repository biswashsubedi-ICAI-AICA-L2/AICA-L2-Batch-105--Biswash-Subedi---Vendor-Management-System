/**
 * Tally Prime Bridge Agent API, Heartbeat Monitoring, and Ledger Mapping Panel
 * Restyled with ICAI-inspired theme: White cards, Navy #0B2545, Blue #1F4E9C, 6px radius.
 */

import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { InvoiceRecord, LedgerMappingRule } from '../../types/index.ts';
import { generateTallyPurchaseXml, generateTallyBatchPurchaseXml, downloadTallyPurchaseXml } from '../../utils/tallyXmlGenerator.ts';
import {
  Cpu,
  Download,
  Code,
  Copy,
  Plus,
  Trash2,
  Key,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  RefreshCw,
  Send,
  HelpCircle,
  ExternalLink,
  Layers,
} from 'lucide-react';

export const TallyAgentPanel: React.FC = () => {
  const {
    invoices,
    agents,
    ledgerMappings,
    companySettings,
    currentUser,
    saveLedgerMapping,
    deleteLedgerMapping,
    updateInvoiceStatus,
    refreshAgentList,
  } = useAuth();

  const [activeTab, setActiveTab] = useState<'PENDING_QUEUE' | 'LEDGER_MAPPINGS' | 'AGENT_KEYS'>('PENDING_QUEUE');
  
  // Tally Prime Dispatch Assistant Modal & Push state
  const [dispatchModalInvoice, setDispatchModalInvoice] = useState<InvoiceRecord | null>(null);
  const [modalPushStatus, setModalPushStatus] = useState<'IDLE' | 'SENDING' | 'SUCCESS' | 'FAILED'>('IDLE');
  const [modalPushMessage, setModalPushMessage] = useState<string>('');
  const [directPushNotice, setDirectPushNotice] = useState<{ id: string; success: boolean; message: string } | null>(null);

  // XML Preview Modal
  const [previewXml, setPreviewXml] = useState<string | null>(null);
  const [previewInvoice, setPreviewInvoice] = useState<InvoiceRecord | null>(null);
  const [copied, setCopied] = useState(false);

  // New Ledger Mapping Modal
  const [showAddMappingModal, setShowAddMappingModal] = useState(false);
  const [mappingType, setMappingType] = useState<LedgerMappingRule['mappingType']>('HSN_SAC');
  const [matchKey, setMatchKey] = useState('');
  const [tallyLedgerName, setTallyLedgerName] = useState('');
  const [taxRate, setTaxRate] = useState<number>(18);
  const [description, setDescription] = useState('');

  // Register Agent Modal
  const [showAgentModal, setShowAgentModal] = useState(false);
  const [newAgentName, setNewAgentName] = useState('');
  const [newAgentId, setNewAgentId] = useState('');
  const [newAgentToken, setNewAgentToken] = useState('vms_tally_sec_' + Math.random().toString(36).substring(2, 10));
  const [newAgentCompany, setNewAgentCompany] = useState(companySettings.legalName);

  // Filter for Tally table
  const [tallyStatusFilter, setTallyStatusFilter] = useState<'ALL' | 'READY' | 'POSTED'>('ALL');

  // Approved invoices ready for Tally
  const allTallyInvoices = invoices.filter((i) => ['APPROVED', 'POSTING_FAILED', 'POSTING_TO_TALLY', 'POSTED'].includes(i.status));
  const pendingInvoices = allTallyInvoices.filter((i) => {
    if (tallyStatusFilter === 'READY') return i.status === 'APPROVED';
    if (tallyStatusFilter === 'POSTED') return i.status === 'POSTED';
    return true;
  });

  const readyForAgentCount = allTallyInvoices.filter((i) => i.status === 'APPROVED').length;
  const postedCount = allTallyInvoices.filter((i) => i.status === 'POSTED').length;

  // Re-queue Invoice so Tally Bridge Agent can import it
  const handleRequeueInvoice = async (inv: InvoiceRecord) => {
    await updateInvoiceStatus(
      inv.id,
      'APPROVED',
      `Invoice #${inv.invoiceNumber} re-queued for Tally Prime Bridge Agent import`,
      {
        tallyVoucherGuid: undefined,
        tallyLastError: undefined,
      }
    );
  };

  // Open Tally Prime Dispatch Assistant Modal
  const handleOpenDispatchModal = (inv: InvoiceRecord) => {
    setDispatchModalInvoice(inv);
    setModalPushStatus('IDLE');
    setModalPushMessage('');
    setDirectPushNotice(null);
  };

  // Confirm manual import or mark voucher created in Tally
  const handleConfirmVoucherCreated = async (inv: InvoiceRecord) => {
    if (inv.status === 'POSTED') {
      return; // Prevent duplicate confirmation
    }
    const ok = window.confirm(
      `Confirm Tally Posting for Invoice #${inv.invoiceNumber}?\n\nHave you imported this voucher into Tally Prime via Alt+O (Import > Transactions)? Clicking OK will record confirmation in the audit trail and mark status as POSTED.`
    );
    if (!ok) return;

    const confirmedAt = new Date().toISOString();
    const confirmedByName = currentUser?.displayName || 'Accounts Executive';
    const confirmedByUid = currentUser?.uid || 'accounts_uid';

    await updateInvoiceStatus(
      inv.id,
      'POSTED',
      `Voucher confirmed created in Tally Prime ERP by ${confirmedByName} (Alt + O Import)`,
      {
        tallyPostedAt: confirmedAt,
        tallyConfirmedBy: confirmedByName,
        tallyConfirmedByUid: confirmedByUid,
        tallyImportMethod: 'MANUAL_XML_IMPORT',
      }
    );
    setDispatchModalInvoice(null);
    setDirectPushNotice({
      id: inv.id,
      success: true,
      message: `Invoice #${inv.invoiceNumber} confirmed posted to Tally Prime!`,
    });
  };

  // TypeScript-safe RequestInit extension for Chrome Private/Local Network Access loopback targeting
  type LoopbackRequestInit = RequestInit & {
    targetAddressSpace?: 'loopback' | 'local' | 'private' | 'public';
  };

  // Attempt Direct Local Push via Bridge Agent (:9095/import-xml) on explicit user click
  const handleModalDirectSend = async (inv: InvoiceRecord) => {
    setModalPushStatus('SENDING');
    setModalPushMessage('');
    try {
      const { xml } = generateTallyPurchaseXml(inv, ledgerMappings, companySettings.legalName);

      // Explicit user-click action targeting local bridge agent with loopback address space
      const requestOptions: LoopbackRequestInit = {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ xml }),
        targetAddressSpace: 'loopback',
      };

      const response = await fetch('http://127.0.0.1:9095/import-xml', requestOptions as RequestInit);

      // Non-2xx responses are treated as failures
      if (!response.ok) {
        let errDetail = `Bridge returned HTTP ${response.status} ${response.statusText}`;
        try {
          const errData = await response.json();
          if (errData && errData.error) {
            errDetail = errData.error;
          } else if (errData && errData.tallyReply) {
            errDetail = errData.tallyReply;
          }
        } catch (_) {}

        setModalPushStatus('FAILED');
        setModalPushMessage(`Posting failed (${errDetail}). Please ensure Tally Prime is running with company opened and ODBC/XML port 9000 enabled, or use Option 1 (Alt+O Import) below.`);
        return;
      }

      const data = await response.json().catch(() => null);

      // Only report POSTED / success when the bridge returns success: true after Tally confirms CREATED>0 or ALTERED>0
      const hasVoucherConfirmed =
        data &&
        data.success === true &&
        ((typeof data.created === 'number' && data.created > 0) ||
         (typeof data.altered === 'number' && data.altered > 0));

      if (hasVoucherConfirmed) {
        // Never synthesize a fake voucher GUID or mock ID; only use genuine Tally returned values if available
        const genuineVoucherGuid = typeof data.voucherGuid === 'string' && data.voucherGuid.trim().length > 0 && !data.voucherGuid.startsWith('TALLY-')
          ? data.voucherGuid.trim()
          : undefined;
        const genuineVoucherNumber = typeof data.voucherNumber === 'string' && data.voucherNumber.trim().length > 0
          ? data.voucherNumber.trim()
          : undefined;

        const confirmedAt = new Date().toISOString();
        const confirmedByName = currentUser?.displayName || 'Accounts Executive';
        const confirmedByUid = currentUser?.uid || 'accounts_uid';

        await updateInvoiceStatus(
          inv.id,
          'POSTED',
          `Voucher created in Tally Prime via Local Bridge by ${confirmedByName} (Confirmed: ${data.created || 1} created, ${data.altered || 0} altered)`,
          {
            tallyVoucherGuid: genuineVoucherGuid,
            tallyVoucherNumber: genuineVoucherNumber,
            tallyPostedAt: confirmedAt,
            tallyConfirmedBy: confirmedByName,
            tallyConfirmedByUid: confirmedByUid,
            tallyImportMethod: 'DIRECT_BRIDGE_PUSH',
          }
        );

        setModalPushStatus('SUCCESS');
        setModalPushMessage(`Success! Voucher verified created in Tally Prime ERP (Confirmed: ${data.created || 1} created, ${data.altered || 0} altered).`);
        setDirectPushNotice({
          id: inv.id,
          success: true,
          message: `Invoice #${inv.invoiceNumber} verified and posted to Tally Prime!`,
        });
      } else {
        // JSON {success: false} or missing confirmation is treated as posting failure
        const failReason = (data && (data.error || data.tallyReply || data.message)) ||
          'Tally Prime did not confirm voucher creation (CREATED: 0, ALTERED: 0).';
        setModalPushStatus('FAILED');
        setModalPushMessage(`Posting failed: ${failReason}. Voucher remains unposted.`);
      }
    } catch (err: any) {
      setModalPushStatus('FAILED');
      const errString = String(err?.message || err || '');
      const isLoopbackOrPermissionBlocked =
        errString.includes('Failed to fetch') ||
        errString.includes('NetworkError') ||
        errString.includes('permission') ||
        errString.includes('loopback') ||
        errString.includes('Local Network') ||
        errString.includes('Private Network') ||
        errString.includes('blocked');

      if (isLoopbackOrPermissionBlocked) {
        setModalPushMessage(
          `Chrome Local Network / Loopback permission was denied or the bridge agent is not active at http://127.0.0.1:9095 (${errString}). To use direct push, start "node tally-bridge-agent.js" in your terminal and allow Local Network access when prompted by Chrome. You can also use Option 1 below at any time: click "Download XML" and import via Alt+O in Tally Prime in 2 seconds!`
        );
      } else {
        setModalPushMessage(`Connection error: ${errString}. Use Option 1 below (Download XML & Alt+O) as fallback.`);
      }
    }
  };

  // Batch Download All Ready Vouchers (Single Combined XML)
  const handleBatchDownloadAllReady = () => {
    const readyInvoices = allTallyInvoices.filter((i) => i.status === 'APPROVED');
    if (readyInvoices.length === 0) return;
    const batchXml = generateTallyBatchPurchaseXml(readyInvoices, ledgerMappings, companySettings.legalName);
    const blob = new Blob([batchXml], { type: 'application/xml;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Tally_Batch_Import_${readyInvoices.length}_Vouchers.xml`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Preview Tally XML
  const handlePreviewXml = (inv: InvoiceRecord) => {
    const { xml } = generateTallyPurchaseXml(inv, ledgerMappings, companySettings.legalName);
    setPreviewXml(xml);
    setPreviewInvoice(inv);
  };

  // Manual import download action ONLY for APPROVED invoices
  const handleDownloadXmlForImport = (inv: InvoiceRecord) => {
    try {
      downloadTallyPurchaseXml(inv, ledgerMappings, companySettings.legalName);
    } catch (err: any) {
      alert(`Cannot generate Tally XML: ${err?.message || err}`);
    }
  };

  // Regular Download Tally XML - ONLY for POSTED invoices
  const handleDownloadXml = (inv: InvoiceRecord) => {
    if (inv.status !== 'POSTED') {
      return;
    }
    try {
      downloadTallyPurchaseXml(inv, ledgerMappings, companySettings.legalName);
    } catch (err: any) {
      alert(`Cannot download Tally XML: ${err?.message || err}`);
    }
  };

  // Copy XML
  const handleCopyXml = () => {
    if (!previewXml) return;
    navigator.clipboard.writeText(previewXml);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Download Standalone Node.js Agent Script from public/
  const handleDownloadBridgeScript = async () => {
    try {
      const res = await fetch('/tally-bridge-agent.js');
      const content = await res.text();
      const blob = new Blob([content], { type: 'text/javascript' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'tally-bridge-agent.js';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (e) {
      window.open('/tally-bridge-agent.js', '_blank');
    }
  };

  // Simulate Agent posting
  const handleSimulateAgentResult = async (inv: InvoiceRecord, success: boolean) => {
    if (success) {
      const confirmedAt = new Date().toISOString();
      const confirmedByName = currentUser?.displayName || 'Accounts Executive';
      const confirmedByUid = currentUser?.uid || 'accounts_uid';
      await updateInvoiceStatus(
        inv.id,
        'POSTED',
        `Tally Bridge Agent imported voucher successfully (Simulated ACK by ${confirmedByName})`,
        {
          tallyPostedAt: confirmedAt,
          tallyConfirmedBy: confirmedByName,
          tallyConfirmedByUid: confirmedByUid,
          tallyImportMethod: 'SIMULATED',
        }
      );
    } else {
      await updateInvoiceStatus(
        inv.id,
        'POSTING_FAILED',
        'Tally import failed: Ledger "Sundry Creditors" not found or financial period locked.',
        {
          tallyLastError: 'Ledger not found or locked period.',
        }
      );
    }
  };

  // Save new ledger mapping
  const handleCreateMapping = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!matchKey.trim() || !tallyLedgerName.trim()) {
      alert('Please fill match key and Tally ledger name.');
      return;
    }

    const newRule: LedgerMappingRule = {
      id: `map_${Date.now()}`,
      mappingType,
      matchKey: matchKey.trim(),
      tallyLedgerName: tallyLedgerName.trim(),
      taxRate: mappingType === 'HSN_SAC' ? taxRate : undefined,
      description: description.trim() || `Mapping for ${matchKey}`,
      updatedAt: new Date().toISOString(),
    };

    await saveLedgerMapping(newRule);
    setShowAddMappingModal(false);
    setMatchKey('');
    setTallyLedgerName('');
    setDescription('');
  };

  // Create new Agent API key
  const handleCreateAgent = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/admin/agents/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: newAgentName,
          agentId: newAgentId || `AGENT_${Date.now()}`,
          plainToken: newAgentToken,
          tallyCompany: newAgentCompany,
        }),
      });
      if (res.ok) {
        await refreshAgentList();
        setShowAgentModal(false);
        setNewAgentName('');
        alert('Tally Bridge Agent registered successfully! Hashed token stored securely.');
      }
    } catch (err: any) {
      alert('Error creating agent: ' + err.message);
    }
  };

  const handleToggleRevoke = async (agentId: string) => {
    try {
      await fetch(`/api/admin/agents/${agentId}/toggle-revoke`, { method: 'POST' });
      await refreshAgentList();
    } catch (e) {}
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner: Tally Bridge Agent Status */}
      <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 bg-[#EBF1FA] text-[#1F4E9C] rounded-[4px]">
            <Cpu className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-xl font-bold text-[#0B2545] tracking-tight">Tally Prime Bridge Integration</h2>
              <span className="badge-pass font-semibold text-xs">
                Agent API Endpoints Live
              </span>
            </div>
            <p className="text-xs text-[#52606D] mt-1">
              Synchronizes approved GST tax invoices directly into Tally Prime ERP using automated Purchase Voucher XML.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <button
            onClick={() => setShowAgentModal(true)}
            className="flex items-center space-x-1.5 px-4 py-2 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[6px] text-xs font-medium shadow-sm transition"
          >
            <Key className="w-3.5 h-3.5" />
            <span>Generate Agent Token</span>
          </button>
        </div>
      </div>

      {/* Agent Heartbeat Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {agents.map((agent) => (
          <div key={agent.id} className="bg-white border border-[#D9E2EC] rounded-[6px] p-4 shadow-sm space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-[#0B2545] truncate">{agent.name}</span>
              <span className={`px-2 py-0.5 text-[10px] font-semibold rounded-[4px] ${
                agent.isRevoked
                  ? 'badge-fail'
                  : 'badge-pass'
              }`}>
                {agent.isRevoked ? 'REVOKED' : 'ACTIVE ONLINE'}
              </span>
            </div>
            <div className="text-xs text-[#52606D] space-y-0.5 font-mono text-[11px]">
              <div>ID: <span className="text-[#1F2933]">{agent.agentId}</span></div>
              <div>Company: <span className="text-[#1F2933]">{agent.tallyCompany}</span></div>
              <div>Token Hash: <span className="text-[#52606D]">{agent.tokenHash.slice(0, 16)}...</span></div>
              <div>Last Sync: <span className="text-[#1F2933]">{agent.lastHeartbeat ? new Date(agent.lastHeartbeat).toLocaleTimeString() : 'Pending heartbeat'}</span></div>
            </div>
            <div className="pt-2 border-t border-[#D9E2EC] flex justify-between items-center text-[11px]">
              <span className="text-[#52606D] font-sans">Version: {agent.version || '2.4.1'}</span>
              <button
                onClick={() => handleToggleRevoke(agent.id)}
                className={`text-[11px] font-semibold ${agent.isRevoked ? 'text-[#1B7F3B]' : 'text-[#B42318]'} hover:underline`}
              >
                {agent.isRevoked ? 'Re-activate' : 'Revoke Token'}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex space-x-2 border-b border-[#D9E2EC] pb-2 text-xs font-semibold">
        <button
          onClick={() => setActiveTab('PENDING_QUEUE')}
          className={`px-4 py-2 rounded-[6px] transition ${
            activeTab === 'PENDING_QUEUE' ? 'bg-[#1F4E9C] text-white' : 'text-[#52606D] hover:text-[#0B2545] hover:bg-[#EBF1FA]'
          }`}
        >
          Tally Invoices Queue ({pendingInvoices.length})
        </button>
        <button
          onClick={() => setActiveTab('LEDGER_MAPPINGS')}
          className={`px-4 py-2 rounded-[6px] transition ${
            activeTab === 'LEDGER_MAPPINGS' ? 'bg-[#1F4E9C] text-white' : 'text-[#52606D] hover:text-[#0B2545] hover:bg-[#EBF1FA]'
          }`}
        >
          Tally Ledger Mappings ({ledgerMappings.length})
        </button>
        <button
          onClick={() => setActiveTab('AGENT_KEYS')}
          className={`px-4 py-2 rounded-[6px] transition ${
            activeTab === 'AGENT_KEYS' ? 'bg-[#1F4E9C] text-white' : 'text-[#52606D] hover:text-[#0B2545] hover:bg-[#EBF1FA]'
          }`}
        >
          API Specs & Curl Commands
        </button>
      </div>

      {/* TAB 1: Pending Invoices Queue */}
      {activeTab === 'PENDING_QUEUE' && (
        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-5 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-[#0B2545]">Purchase Vouchers for Tally Import</h3>
              <p className="text-xs text-[#52606D]">
                Agent polls <code className="text-[#1F4E9C]">GET /agent/invoices/pending</code> to import approved vouchers into Tally Prime.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {readyForAgentCount > 0 && (
                <button
                  type="button"
                  onClick={handleBatchDownloadAllReady}
                  className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#1B7F3B] hover:bg-[#14632E] text-white rounded-[4px] text-xs font-semibold shadow-xs transition cursor-pointer"
                  title="Download all approved vouchers in one combined Tally XML file"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download Batch XML for Tally Import ({readyForAgentCount})</span>
                </button>
              )}

              {/* Status Filter Buttons */}
              <div className="flex items-center space-x-1.5 bg-[#F5F7FA] p-1 rounded-[6px] border border-[#D9E2EC] text-xs">
                <button
                  type="button"
                  onClick={() => setTallyStatusFilter('ALL')}
                  className={`px-2.5 py-1 rounded-[4px] font-medium transition ${
                    tallyStatusFilter === 'ALL'
                      ? 'bg-white text-[#0B2545] shadow-xs font-bold'
                      : 'text-[#52606D] hover:text-[#0B2545]'
                  }`}
                >
                  All ({allTallyInvoices.length})
                </button>
                <button
                  type="button"
                  onClick={() => setTallyStatusFilter('READY')}
                  className={`px-2.5 py-1 rounded-[4px] font-medium transition flex items-center space-x-1.5 ${
                    tallyStatusFilter === 'READY'
                      ? 'bg-[#EBF7EE] text-[#1B7F3B] shadow-xs font-bold'
                      : 'text-[#52606D] hover:text-[#1B7F3B]'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-[#1B7F3B]"></span>
                  <span>Ready for Agent ({readyForAgentCount})</span>
                </button>
                <button
                  type="button"
                  onClick={() => setTallyStatusFilter('POSTED')}
                  className={`px-2.5 py-1 rounded-[4px] font-medium transition flex items-center space-x-1.5 ${
                    tallyStatusFilter === 'POSTED'
                      ? 'bg-[#EBF1FA] text-[#1F4E9C] shadow-xs font-bold'
                      : 'text-[#52606D] hover:text-[#1F4E9C]'
                  }`}
                >
                  <span className="w-2 h-2 rounded-full bg-[#1F4E9C]"></span>
                  <span>Voucher Created ({postedCount})</span>
                </button>
              </div>
            </div>
          </div>

          {/* Direct Browser Push Notice */}
          {directPushNotice && (
            <div className={`p-3 rounded-[6px] text-xs flex items-start justify-between border ${
              directPushNotice.success
                ? 'bg-[#EBF7EE] border-[#B7EB8F] text-[#14632E]'
                : 'bg-[#FFF2F0] border-[#FFCCC7] text-[#A8071A]'
            }`}>
              <div className="flex items-start space-x-2">
                {directPushNotice.success ? (
                  <CheckCircle2 className="w-4 h-4 text-[#1B7F3B] shrink-0 mt-0.5" />
                ) : (
                  <AlertCircle className="w-4 h-4 text-[#CF1322] shrink-0 mt-0.5" />
                )}
                <div>{directPushNotice.message}</div>
              </div>
              <button
                onClick={() => setDirectPushNotice(null)}
                className="text-xs font-bold hover:underline shrink-0 ml-2"
              >
                &times;
              </button>
            </div>
          )}

          {/* Quick Notice when vouchers are posted */}
          {postedCount > 0 && (
            <div className="p-3 bg-[#F0F5FF] border border-[#ADC8FF] rounded-[6px] text-xs text-[#0B2545] flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <RotateCcw className="w-4 h-4 text-[#1F4E9C] shrink-0" />
                <span>
                  <strong>Need to re-import into Tally Prime?</strong> If an invoice already shows "Voucher Created", click <strong>"Re-queue for Tally"</strong> on its row to make it immediately available for your Tally Bridge agent to pick up again.
                </span>
              </div>
            </div>
          )}

          <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
            <table className="w-full text-left text-xs font-sans">
              <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545]">
                <tr className="font-semibold uppercase tracking-wider text-[11px]">
                  <th className="py-2.5 px-3">Invoice #</th>
                  <th className="py-2.5 px-3">Supplier Name & GSTIN</th>
                  <th className="py-2.5 px-3">Date</th>
                  <th className="py-2.5 px-3 text-right">Taxable</th>
                  <th className="py-2.5 px-3 text-right">Total (INR)</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D9E2EC] font-mono">
                {pendingInvoices.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-6 text-center text-xs text-[#52606D] font-sans">
                      No invoices found for this filter.
                    </td>
                  </tr>
                ) : (
                  pendingInvoices.map((inv) => (
                    <tr key={inv.id} className="even:bg-[#F5F7FA] hover:bg-[#EBF1FA]/40 transition">
                      <td className="py-3 px-3 font-bold text-[#0B2545]">
                        <span>{inv.invoiceNumber}</span>
                        {inv.tallyVoucherGuid && (
                          <div className="text-[10px] text-[#52606D] font-sans">GUID: {inv.tallyVoucherGuid}</div>
                        )}
                      </td>
                      <td className="py-3 px-3 font-sans text-[#1F2933]">
                        <div className="font-semibold text-[#0B2545]">{inv.vendorName}</div>
                        <div className="text-[10px] text-[#52606D] font-mono">{inv.vendorGstin}</div>
                      </td>
                      <td className="py-3 px-3 text-[#1F2933]">{inv.invoiceDate}</td>
                      <td className="py-3 px-3 text-right text-[#1F2933]">₹{inv.totalTaxableValue.toFixed(2)}</td>
                      <td className="py-3 px-3 text-right font-bold text-[#1B7F3B]">₹{inv.invoiceTotal.toFixed(2)}</td>
                      
                      <td className="py-3 px-3 font-sans">
                        {inv.status === 'APPROVED' && (
                          <span className="badge-pass font-semibold">
                            Ready for Agent
                          </span>
                        )}
                        {inv.status === 'POSTED' && (
                          <span className="badge-info font-semibold">
                            Voucher Created
                          </span>
                        )}
                        {inv.status === 'POSTING_FAILED' && (
                          <span className="badge-fail font-semibold" title={inv.tallyLastError}>
                            Posting Failed
                          </span>
                        )}
                      </td>

                      <td className="py-3 px-3 text-right font-sans">
                        <div className="flex items-center justify-end space-x-1.5">
                          <button
                            onClick={() => handlePreviewXml(inv)}
                            className="px-2.5 py-1 bg-white hover:bg-[#F5F7FA] text-[#1F2933] border border-[#D9E2EC] rounded-[4px] text-xs font-medium transition cursor-pointer"
                            title="View Tally XML payload"
                          >
                            <Code className="w-3.5 h-3.5 inline mr-1 text-[#52606D]" />
                            XML
                          </button>

                          {inv.status === 'POSTED' && (
                            <span
                              className="px-2 py-1 bg-[#EDF7ED] text-[#1B7F3B] border border-[#C8E6C9] rounded-[4px] text-[11px] font-medium flex items-center space-x-1"
                              title="Voucher posted to Tally Prime. Action locked."
                            >
                              <CheckCircle2 className="w-3 h-3 text-[#1B7F3B]" />
                              <span>Locked</span>
                            </span>
                          )}

                          {inv.status === 'APPROVED' && (
                            <>
                              <button
                                onClick={() => handleDownloadXmlForImport(inv)}
                                className="px-2 py-1 bg-[#EBF7EE] hover:bg-[#D4EDDA] text-[#14632E] border border-[#B7EB8F] rounded-[4px] text-[11px] font-semibold transition flex items-center space-x-1 shadow-2xs cursor-pointer"
                                title="Download XML for manual Tally import (Alt+O)"
                              >
                                <Download className="w-3 h-3 text-[#1B7F3B]" />
                                <span>Download XML for Tally Import</span>
                              </button>
                              <button
                                onClick={() => handleConfirmVoucherCreated(inv)}
                                className="px-2 py-1 bg-[#1B7F3B] hover:bg-[#14632E] text-white rounded-[4px] text-[11px] font-semibold transition flex items-center space-x-1 shadow-2xs cursor-pointer"
                                title="Confirm this voucher has been imported into Tally Prime"
                              >
                                <CheckCircle2 className="w-3 h-3" />
                                <span>Confirm Posted in Tally</span>
                              </button>
                              <button
                                onClick={() => handleOpenDispatchModal(inv)}
                                className="px-2.5 py-1 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[4px] text-[11px] font-semibold transition flex items-center space-x-1 shadow-2xs cursor-pointer"
                                title="Open Tally Prime Dispatch Assistant to import voucher into Tally Prime"
                              >
                                <Send className="w-3 h-3" />
                                <span>Push to Tally</span>
                              </button>
                              <button
                                onClick={() => handleSimulateAgentResult(inv, true)}
                                className="px-2 py-1 bg-[#1B7F3B] hover:bg-[#14632E] text-white rounded-[4px] text-[11px] font-medium transition cursor-pointer"
                                title="Simulate successful posting without running local bridge agent"
                              >
                                Simulate Post
                              </button>
                              <button
                                onClick={() => handleSimulateAgentResult(inv, false)}
                                className="px-2 py-1 bg-[#B42318] hover:bg-[#8F1A12] text-white rounded-[4px] text-[11px] font-medium transition cursor-pointer"
                                title="Simulate error report from Tally agent"
                              >
                                Simulate Fail
                              </button>
                            </>
                          )}

                          {inv.status === 'POSTED' && (
                            <button
                              onClick={() => handleRequeueInvoice(inv)}
                              className="px-2.5 py-1 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[4px] text-[11px] font-semibold transition flex items-center space-x-1 shadow-2xs"
                              title="Re-queue this voucher so the Tally Bridge connector agent can import it again into Tally Prime"
                            >
                              <RotateCcw className="w-3 h-3" />
                              <span>Re-queue for Tally</span>
                            </button>
                          )}

                          {inv.status === 'POSTING_FAILED' && (
                            <>
                              <button
                                onClick={() => handleRequeueInvoice(inv)}
                                className="px-2 py-1 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[4px] text-[11px] font-semibold transition flex items-center space-x-1"
                                title="Reset status to Ready for Agent"
                              >
                                <RotateCcw className="w-3 h-3" />
                                <span>Re-queue</span>
                              </button>
                              <button
                                onClick={() => handleSimulateAgentResult(inv, true)}
                                className="px-2 py-1 bg-[#B26A00] hover:bg-[#8C5300] text-white rounded-[4px] text-[11px] font-medium transition"
                              >
                                Retry Post
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 2: Ledger Mappings */}
      {activeTab === 'LEDGER_MAPPINGS' && (
        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-5 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-[#0B2545]">Tally Chart of Accounts & Tax Head Mappings</h3>
              <p className="text-xs text-[#52606D]">
                Determines the exact debit and credit ledgers in Tally Prime Purchase Vouchers.
              </p>
            </div>
            <button
              onClick={() => setShowAddMappingModal(true)}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[6px] text-xs font-medium transition"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Ledger Rule</span>
            </button>
          </div>

          <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545]">
                <tr className="uppercase tracking-wider text-[11px] font-semibold">
                  <th className="py-2.5 px-3">Mapping Type</th>
                  <th className="py-2.5 px-3">Match Key</th>
                  <th className="py-2.5 px-3">Tally Prime Ledger Name</th>
                  <th className="py-2.5 px-3">Description</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D9E2EC] font-mono">
                {ledgerMappings.map((rule) => (
                  <tr key={rule.id} className="even:bg-[#F5F7FA] hover:bg-[#EBF1FA]/40 transition">
                    <td className="py-3 px-3 font-sans">
                      <span className={`px-2 py-0.5 rounded-[4px] text-[10px] font-semibold border ${
                        rule.mappingType === 'TDS'
                          ? 'bg-[#FFF7E6] text-[#B26A00] border-[#FFE7BA]'
                          : rule.mappingType === 'TAX_HEAD'
                          ? 'bg-[#EBF7EE] text-[#1B7F3B] border-[#C3E8CC]'
                          : 'bg-[#EBF1FA] text-[#1F4E9C] border-[#D9E2EC]'
                      }`}>
                        {rule.mappingType === 'TDS' ? 'TDS (Duties & Taxes)' : rule.mappingType}
                      </span>
                    </td>
                    <td className="py-3 px-3 font-bold text-[#1F4E9C]">
                      {rule.mappingType === 'TDS' ? `Sec. ${rule.matchKey}` : rule.matchKey}
                    </td>
                    <td className="py-3 px-3 font-sans font-semibold text-[#0B2545]">{rule.tallyLedgerName}</td>
                    <td className="py-3 px-3 font-sans text-[#52606D]">{rule.description}</td>
                    <td className="py-3 px-3 text-right font-sans">
                      <button
                        onClick={() => deleteLedgerMapping(rule.id)}
                        className="text-[#52606D] hover:text-[#B42318] p-1"
                        title="Delete rule"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: API Specs & Curl Commands */}
      {activeTab === 'AGENT_KEYS' && (
        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-6 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-[#D9E2EC]">
            <div>
              <h3 className="text-sm font-bold text-[#0B2545]">Local Tally Prime Bridge Agent Connector</h3>
              <p className="text-xs text-[#52606D] mt-1">
                Runs on your local computer where Tally Prime is active. Automatically polls approved vouchers and posts Purchase XML directly to port 9000.
              </p>
            </div>
            <button
              onClick={handleDownloadBridgeScript}
              className="inline-flex items-center space-x-1.5 px-3.5 py-2 bg-[#1B7F3B] hover:bg-[#14632E] text-white rounded-[6px] text-xs font-semibold shrink-0 transition shadow-xs cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Download tally-bridge-agent.js</span>
            </button>
          </div>

          {/* PROMPT TO RUN TALLY CONNECTOR CALLOUT */}
          <div className="p-4 bg-[#EBF1FA] border border-[#BACEEA] rounded-[6px] space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Code className="w-4 h-4 text-[#1F4E9C]" />
                <h4 className="text-xs font-bold text-[#0B2545] uppercase tracking-wide">
                  Terminal Prompt / Command to Run Tally Connector
                </h4>
              </div>
              <button
                type="button"
                onClick={() => {
                  navigator.clipboard.writeText(`node tally-bridge-agent.js "${window.location.origin}" "vms_tally_sec_token_98765" "http://localhost:9000"`);
                  setCopied(true);
                  setTimeout(() => setCopied(false), 2000);
                }}
                className="px-2.5 py-1 bg-[#1F4E9C] hover:bg-[#173B77] text-white text-[11px] font-semibold rounded-[4px] flex items-center space-x-1 transition shadow-2xs cursor-pointer"
              >
                <Copy className="w-3 h-3" />
                <span>{copied ? 'Copied to Clipboard!' : 'Copy Run Prompt'}</span>
              </button>
            </div>

            <p className="text-xs text-[#1F2933]">
              In your Command Prompt, PowerShell, or Terminal, run the following command from the folder where you saved <code className="bg-white px-1.5 py-0.5 rounded border border-[#D9E2EC] font-mono font-bold text-[#0B2545]">tally-bridge-agent.js</code>:
            </p>

            <pre className="p-3 bg-[#0B2545] text-[#F5F7FA] rounded-[6px] text-xs font-mono overflow-x-auto whitespace-pre">
{`node tally-bridge-agent.js "${window.location.origin}" "vms_tally_sec_token_98765" "http://localhost:9000"`}
            </pre>

            <div className="text-[11px] text-[#52606D] space-y-1">
              <div><strong>Pre-requisite 1:</strong> Install Node.js (v18+) on the Tally machine.</div>
              <div><strong>Pre-requisite 2:</strong> In Tally Prime, press <strong>F1 (Help) &rarr; Settings &rarr; Connectivity &rarr; Client/Server Configuration</strong>. Set <em>TallyPrime acts as: Both</em> and <em>Port: 9000</em>.</div>
              <div><strong>Note on Corporate Firewalls:</strong> If Cisco Secure Access, Zscaler, or corporate proxies intercept cloud domains, ensure Node.js is run on an allowed network or route through your internal gateway.</div>
            </div>

            {/* Cloud Ingress / Auth Troubleshooting Guide */}
            <div className="p-3.5 bg-white border border-[#BACEEA] rounded-[6px] space-y-2.5 mt-2">
              <div className="flex items-center space-x-2 text-xs font-bold text-[#0B2545]">
                <HelpCircle className="w-4 h-4 text-[#1F4E9C]" />
                <span>Seeing error "Unexpected token &apos;&lt;&apos;, &quot;&lt;!doctype &quot;... is not valid JSON"?</span>
              </div>
              <p className="text-xs text-[#52606D] leading-relaxed">
                This happens because the cloud preview URL (<code className="text-[#0B2545] font-mono font-semibold">{window.location.hostname}</code>) is protected by Google AI Studio browser session authentication. Non-browser terminal requests receive a 302 redirect to the login HTML page.
              </p>
              <div className="space-y-2 pt-1 text-xs">
                <div className="p-2.5 bg-[#F5F7FA] rounded-[4px] border border-[#D9E2EC]">
                  <strong className="text-[#1B7F3B]">Method 1 (Fastest &amp; 100% Reliable &mdash; Alt+O in Tally):</strong>
                  <div className="text-[#1F2933] mt-0.5">
                    1. Go to the <strong>Tally Invoices Queue</strong> tab and click the <strong>Download icon</strong> on the invoice row.
                    <br />
                    2. In Tally Prime, press <strong>Alt + O (Import) &rarr; Transactions</strong> &rarr; Select the downloaded XML file. Tally imports the Purchase Voucher with full ledger allocations in 2 seconds!
                  </div>
                </div>

                <div className="p-2.5 bg-[#F5F7FA] rounded-[4px] border border-[#D9E2EC]">
                  <strong className="text-[#1F4E9C]">Method 2 (Local File Push without Cloud Polling):</strong>
                  <div className="text-[#1F2933] mt-0.5">
                    Download the XML file to your folder, then run:
                    <pre className="mt-1 p-2 bg-[#0B2545] text-white rounded font-mono text-[11px] overflow-x-auto">
node tally-bridge-agent.js --file=&quot;Tally_Purchase_Inv_1234.xml&quot;
                    </pre>
                  </div>
                </div>

                <div className="p-2.5 bg-[#F5F7FA] rounded-[4px] border border-[#D9E2EC]">
                  <strong className="text-[#0B2545]">Method 3 (1-Click Push from Browser):</strong>
                  <div className="text-[#1F2933] mt-0.5">
                    In the <strong>Tally Invoices Queue</strong> tab, click the blue <strong>&quot;Push to Tally&quot;</strong> button. If your browser permits local network connections, it sends the XML directly to <code className="font-mono">http://localhost:9000</code>.
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-[#0B2545] mb-1">
                <span>1. Poll Pending Invoices with Tally XML (GET /agent/invoices/pending)</span>
              </div>
              <pre className="p-3 bg-[#F5F7FA] border border-[#D9E2EC] rounded-[6px] text-xs font-mono text-[#1F2933] overflow-x-auto">
{`curl -X GET "${window.location.origin}/agent/invoices/pending" \\
  -H "Authorization: Bearer vms_tally_sec_token_98765"`}
              </pre>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-[#0B2545] mb-1">
                <span>2. Agent Post Result (POST /agent/invoices/:id/result)</span>
              </div>
              <pre className="p-3 bg-[#F5F7FA] border border-[#D9E2EC] rounded-[6px] text-xs font-mono text-[#1F2933] overflow-x-auto">
{`curl -X POST "${window.location.origin}/agent/invoices/inv_sample_002/result" \\
  -H "Authorization: Bearer vms_tally_sec_token_98765" \\
  -H "Content-Type: application/json" \\
  -d '{"status":"POSTED","tallyVoucherGuid":"TALLY-GUID-998811","tallyVoucherNumber":"PUR-TC-1089"}'`}
              </pre>
            </div>

            <div>
              <div className="flex items-center justify-between text-xs font-semibold text-[#0B2545] mb-1">
                <span>3. Agent Heartbeat (POST /agent/heartbeat)</span>
              </div>
              <pre className="p-3 bg-[#F5F7FA] border border-[#D9E2EC] rounded-[6px] text-xs font-mono text-[#1F2933] overflow-x-auto">
{`curl -X POST "${window.location.origin}/agent/heartbeat" \\
  -H "Authorization: Bearer vms_tally_sec_token_98765" \\
  -H "Content-Type: application/json" \\
  -d '{"version":"2.5.0","tallyCompany":"Bharat Industrial Tech Solutions Private Limited"}'`}
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* XML Preview Modal */}
      {previewXml && previewInvoice && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <div className="bg-white border border-[#D9E2EC] w-full max-w-3xl rounded-[6px] p-6 shadow-lg space-y-4 max-h-[85vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-[#D9E2EC] pb-3">
              <div>
                <h3 className="text-sm font-bold text-[#0B2545]">Tally Prime XML Payload</h3>
                <p className="text-xs text-[#52606D]">
                  Invoice #{previewInvoice.invoiceNumber} • {previewInvoice.vendorName}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <button
                  onClick={handleCopyXml}
                  className="flex items-center space-x-1 px-3 py-1.5 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[4px] text-xs font-medium transition"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copied ? 'Copied!' : 'Copy XML'}</span>
                </button>
                <button
                  onClick={() => setPreviewXml(null)}
                  className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[4px] text-xs"
                >
                  Close
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto bg-[#F5F7FA] p-4 rounded-[4px] border border-[#D9E2EC]">
              <pre className="text-xs font-mono text-[#1F2933] whitespace-pre leading-relaxed">
                {previewXml}
              </pre>
            </div>
          </div>
        </div>
      )}

      {/* Create Mapping Modal */}
      {showAddMappingModal && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <form onSubmit={handleCreateMapping} className="bg-white border border-[#D9E2EC] w-full max-w-md rounded-[6px] p-6 shadow-lg space-y-4">
            <h3 className="text-sm font-bold text-[#0B2545]">Add Tally Prime Ledger Mapping</h3>
            
            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">Mapping Type</label>
              <select
                value={mappingType}
                onChange={(e) => {
                  const newType = e.target.value as any;
                  setMappingType(newType);
                  if (newType === 'TDS') {
                    setMatchKey('194C');
                    setTallyLedgerName('TDS on Contractors - 194C');
                    setDescription('Statutory TDS deduction under Section 194C (Contractors / Sub-contractors)');
                  } else if (newType === 'ROUND_OFF') {
                    setMatchKey('ROUND_OFF');
                    setTallyLedgerName('Round Off Expenses / Income');
                    setDescription('Fractional rounding ledger');
                  } else if (newType === 'TAX_HEAD') {
                    setMatchKey('CGST');
                    setTallyLedgerName('Input CGST');
                    setDescription('Central GST Input Tax Credit ledger');
                  }
                }}
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-medium"
              >
                <option value="HSN_SAC">HSN / SAC Code (Debit Purchase/Expense)</option>
                <option value="TAX_HEAD">GST Tax Head (Input CGST / SGST / IGST)</option>
                <option value="TDS">TDS (Tax Deducted at Source - Duties &amp; Taxes)</option>
                <option value="VENDOR">Vendor (Sundry Creditor)</option>
                <option value="ROUND_OFF">Round Off Ledger</option>
              </select>
            </div>

            {mappingType === 'TDS' ? (
              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">
                  TDS Statutory Section / Head *
                </label>
                <select
                  value={matchKey}
                  onChange={(e) => {
                    const val = e.target.value;
                    setMatchKey(val);
                    if (val === '194C') {
                      setTallyLedgerName('TDS on Contractors - 194C');
                      setDescription('Statutory TDS deduction under Section 194C (Contractors / Sub-contractors)');
                    } else if (val === '194J_TECH') {
                      setTallyLedgerName('TDS on Technical Services - 194J');
                      setDescription('Statutory TDS deduction under Section 194J (Technical / FTS - 2%)');
                    } else if (val === '194J_PROF') {
                      setTallyLedgerName('TDS on Professional Fees - 194J');
                      setDescription('Statutory TDS deduction under Section 194J (Professional Fees - 10%)');
                    } else if (val === '194I_LAND') {
                      setTallyLedgerName('TDS on Rent - Land & Building - 194I');
                      setDescription('Statutory TDS deduction under Section 194I (Rent: Land & Building - 10%)');
                    } else if (val === '194I_PLANT') {
                      setTallyLedgerName('TDS on Rent - Plant & Machinery - 194I');
                      setDescription('Statutory TDS deduction under Section 194I (Rent: Plant & Machinery - 2%)');
                    } else if (val === '194H') {
                      setTallyLedgerName('TDS on Commission - 194H');
                      setDescription('Statutory TDS deduction under Section 194H (Commission & Brokerage - 5%)');
                    } else if (val === '194Q') {
                      setTallyLedgerName('TDS on Purchase of Goods - 194Q');
                      setDescription('Statutory TDS deduction under Section 194Q (Purchase of Goods - 0.1%)');
                    } else if (val === 'ALL_TDS') {
                      setTallyLedgerName('TDS Payable');
                      setDescription('Default statutory TDS credit ledger for all sections');
                    }
                  }}
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-medium"
                  required
                >
                  <option value="194C">Section 194C (Contractors / Sub-contractors)</option>
                  <option value="194J_TECH">Section 194J (Technical Services / FTS - 2%)</option>
                  <option value="194J_PROF">Section 194J (Professional Fees - 10%)</option>
                  <option value="194I_LAND">Section 194I (Rent: Land, Building &amp; Furniture - 10%)</option>
                  <option value="194I_PLANT">Section 194I (Rent: Plant &amp; Machinery - 2%)</option>
                  <option value="194H">Section 194H (Commission &amp; Brokerage - 5%)</option>
                  <option value="194Q">Section 194Q (Purchase of Goods - 0.1%)</option>
                  <option value="ALL_TDS">ALL_TDS (Default for All TDS Sections)</option>
                  <option value="CUSTOM">Custom Section Code...</option>
                </select>

                {matchKey === 'CUSTOM' && (
                  <input
                    type="text"
                    placeholder="Enter custom TDS code e.g. 194A, 194DA"
                    onChange={(e) => setMatchKey(e.target.value.toUpperCase())}
                    className="mt-2 w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs font-mono text-[#1F2933]"
                    required
                  />
                )}
              </div>
            ) : (
              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">Match Key *</label>
                <input
                  type="text"
                  value={matchKey}
                  onChange={(e) => setMatchKey(e.target.value)}
                  placeholder={
                    mappingType === 'HSN_SAC'
                      ? 'e.g. 847130 or 998313 or DEFAULT'
                      : mappingType === 'TAX_HEAD'
                      ? 'e.g. CGST or SGST or IGST'
                      : mappingType === 'ROUND_OFF'
                      ? 'ROUND_OFF'
                      : 'e.g. vendor_apex'
                  }
                  required
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono"
                />
              </div>
            )}

            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="text-xs font-medium text-[#1F2933]">
                  Tally Prime Ledger Name *
                </label>
                {mappingType === 'TDS' && (
                  <span className="text-[10px] bg-[#EBF1FA] text-[#1F4E9C] px-1.5 py-0.5 rounded font-mono font-semibold">
                    Parent: Duties &amp; Taxes (Credit)
                  </span>
                )}
              </div>
              <input
                type="text"
                value={tallyLedgerName}
                onChange={(e) => setTallyLedgerName(e.target.value)}
                placeholder={mappingType === 'TDS' ? 'e.g. TDS on Contractors - 194C' : 'e.g. Computer Hardware Expenses'}
                required
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
              />
              {mappingType === 'TDS' && (
                <p className="text-[11px] text-[#52606D] mt-1">
                  In Tally Prime Purchase Vouchers, this ledger will be credited with the deducted TDS amount, balancing against the Net Vendor Payable.
                </p>
              )}
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">Description</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Optional notes..."
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAddMappingModal(false)}
                className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-[#1F4E9C] hover:bg-[#173B77] text-white font-medium rounded-[6px] text-xs"
              >
                Save Mapping
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Register Agent Modal */}
      {showAgentModal && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <form onSubmit={handleCreateAgent} className="bg-white border border-[#D9E2EC] w-full max-w-md rounded-[6px] p-6 shadow-lg space-y-4">
            <h3 className="text-sm font-bold text-[#0B2545]">Generate Tally Bridge Agent Token</h3>
            <p className="text-xs text-[#52606D]">
              The plain token is shown once. The server stores only its SHA-256 hash.
            </p>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">Agent Name *</label>
              <input
                type="text"
                value={newAgentName}
                onChange={(e) => setNewAgentName(e.target.value)}
                placeholder="e.g. Head Office Tally Server"
                required
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">Agent ID</label>
              <input
                type="text"
                value={newAgentId}
                onChange={(e) => setNewAgentId(e.target.value)}
                placeholder="e.g. AGENT_HO_01"
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">Secret Token (Bearer Auth)</label>
              <input
                type="text"
                value={newAgentToken}
                onChange={(e) => setNewAgentToken(e.target.value)}
                required
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F4E9C] font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">Target Tally Company</label>
              <input
                type="text"
                value={newAgentCompany}
                onChange={(e) => setNewAgentCompany(e.target.value)}
                required
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
              />
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setShowAgentModal(false)}
                className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-[#1B7F3B] hover:bg-[#14632E] text-white font-medium rounded-[6px] text-xs"
              >
                Register & Save Hash
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Tally Prime Dispatch Assistant Modal */}
      {dispatchModalInvoice && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-[8px] max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl border border-[#D9E2EC]">
            {/* Modal Header */}
            <div className="p-4 border-b border-[#D9E2EC] flex items-center justify-between bg-[#F8FAFC]">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-[#EBF1FA] text-[#1F4E9C] rounded-[6px]">
                  <Send className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#0B2545]">Tally Prime ERP Dispatch Assistant</h3>
                  <p className="text-xs text-[#52606D]">
                    Invoice #{dispatchModalInvoice.invoiceNumber} &bull; {dispatchModalInvoice.vendorName} &bull; ₹{dispatchModalInvoice.invoiceTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setDispatchModalInvoice(null)}
                className="text-[#829AB1] hover:text-[#1F2933] text-xl font-bold p-1 cursor-pointer"
              >
                &times;
              </button>
            </div>

            {/* Modal Content */}
            <div className="p-5 space-y-5">
              
              {/* Option 1: 1-Click Native Alt+O Import (Guaranteed & Standard) */}
              <div className="border-2 border-[#1B7F3B]/30 bg-[#F6FAF7] rounded-[8px] p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="w-6 h-6 rounded-full bg-[#1B7F3B] text-white flex items-center justify-center text-xs font-bold">1</span>
                    <h4 className="text-sm font-bold text-[#14632E]">Recommended: 1-Click Alt + O Native Import</h4>
                  </div>
                  <span className="px-2 py-0.5 bg-[#EBF7EE] text-[#1B7F3B] border border-[#B7EB8F] rounded-full text-[10px] font-bold uppercase tracking-wider">
                    100% Reliable &bull; No Network Setup Required
                  </span>
                </div>

                <p className="text-xs text-[#3E5060]">
                  Tally Prime imports purchase transactions directly through its native XML parser in under 2 seconds:
                </p>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-2 text-xs">
                  <div className="bg-white p-2.5 rounded-[6px] border border-[#D9E2EC] flex flex-col justify-between space-y-2">
                    <div>
                      <span className="font-bold text-[#0B2545] block">Step A: Get XML</span>
                      <span className="text-[11px] text-[#627D98]">Download formatted Tally XML file.</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleDownloadXmlForImport(dispatchModalInvoice)}
                      className="w-full py-1.5 px-2 bg-[#1F4E9C] hover:bg-[#173B77] text-white font-medium rounded-[4px] text-xs flex items-center justify-center space-x-1.5 transition cursor-pointer"
                    >
                      <Download className="w-3.5 h-3.5" />
                      <span>Download XML for Tally Import</span>
                    </button>
                  </div>

                  <div className="bg-white p-2.5 rounded-[6px] border border-[#D9E2EC] flex flex-col justify-between">
                    <div>
                      <span className="font-bold text-[#0B2545] block">Step B: In Tally Prime</span>
                      <span className="text-[11px] text-[#627D98]">Press shortcut key:</span>
                      <div className="mt-1 font-mono font-bold text-xs bg-[#F0F4F8] text-[#0B2545] px-2 py-1 rounded inline-block">
                        Alt + O &rarr; Transactions
                      </div>
                    </div>
                    <span className="text-[10px] text-[#829AB1] mt-1">Select the downloaded XML</span>
                  </div>

                  <div className="bg-white p-2.5 rounded-[6px] border border-[#B7EB8F] flex flex-col justify-between space-y-2">
                    <div>
                      <span className="font-bold text-[#14632E] block">Step C: Confirm</span>
                      <span className="text-[11px] text-[#627D98]">Update status to Voucher Created.</span>
                    </div>
                    <button
                      type="button"
                      onClick={() => handleConfirmVoucherCreated(dispatchModalInvoice)}
                      className="w-full py-1.5 px-2 bg-[#1B7F3B] hover:bg-[#14632E] text-white font-semibold rounded-[4px] text-xs flex items-center justify-center space-x-1.5 shadow-2xs transition cursor-pointer"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>Confirm Posted in Tally</span>
                    </button>
                  </div>
                </div>
              </div>

              {/* Option 2: Direct HTTP Push (Port 9000 / Relay 9095) */}
              <div className="border border-[#D9E2EC] bg-white rounded-[8px] p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="w-6 h-6 rounded-full bg-[#1F4E9C] text-white flex items-center justify-center text-xs font-bold">2</span>
                    <h4 className="text-sm font-bold text-[#0B2545]">Direct Push (Local Relay :9095 / Port :9000)</h4>
                  </div>
                  <span className="text-[11px] text-[#627D98]">Requires Tally XML Server or Bridge Agent</span>
                </div>

                <p className="text-xs text-[#52606D]">
                  Sends the Purchase XML directly to Tally Prime. If your browser blocks cloud-to-localhost connections (Private Network Access restrictions), run <code className="bg-[#F0F4F8] text-[#1F4E9C] px-1 py-0.5 rounded">node tally-bridge-agent.js</code> on your machine or use Option 1.
                </p>

                <div className="flex flex-wrap items-center gap-3">
                  <button
                    type="button"
                    onClick={() => handleModalDirectSend(dispatchModalInvoice)}
                    disabled={modalPushStatus === 'SENDING'}
                    className="px-3.5 py-1.5 bg-[#1F4E9C] hover:bg-[#173B77] disabled:opacity-50 text-white rounded-[4px] text-xs font-semibold flex items-center space-x-1.5 transition cursor-pointer"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>{modalPushStatus === 'SENDING' ? 'Sending to Tally...' : 'Send to localhost:9000'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleDownloadBridgeScript}
                    className="px-3 py-1.5 bg-white hover:bg-[#F5F7FA] text-[#1F4E9C] border border-[#1F4E9C] rounded-[4px] text-xs font-medium flex items-center space-x-1.5 transition cursor-pointer"
                    title="Download the standalone Node.js bridge agent for automatic local sync"
                  >
                    <Cpu className="w-3.5 h-3.5" />
                    <span>Download tally-bridge-agent.js</span>
                  </button>
                </div>

                {modalPushStatus === 'SUCCESS' && (
                  <div className="p-3 bg-[#EBF7EE] border border-[#B7EB8F] rounded-[6px] text-xs text-[#14632E] flex items-start space-x-2">
                    <CheckCircle2 className="w-4 h-4 text-[#1B7F3B] shrink-0 mt-0.5" />
                    <div>{modalPushMessage}</div>
                  </div>
                )}

                {modalPushStatus === 'FAILED' && (
                  <div className="p-3 bg-[#FFF7ED] border border-[#FFD8A8] rounded-[6px] text-xs text-[#8F4700] space-y-1">
                    <div className="font-bold flex items-center space-x-1">
                      <AlertCircle className="w-4 h-4 text-[#D97706] shrink-0" />
                      <span>Direct connection notice:</span>
                    </div>
                    <div>{modalPushMessage}</div>
                    <div className="pt-1 text-[#475569]">
                      &rarr; <strong>Quickest solution:</strong> Use <strong>Option 1</strong> above: Click <strong>"Download XML"</strong> and import via <strong>Alt+O</strong> in Tally Prime!
                    </div>
                  </div>
                )}
              </div>

              {/* Option 3: Terminal Command (Zero CORS) */}
              <div className="border border-[#D9E2EC] bg-[#F8FAFC] rounded-[8px] p-4 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <span className="w-6 h-6 rounded-full bg-[#52606D] text-white flex items-center justify-center text-xs font-bold">3</span>
                    <h4 className="text-xs font-bold text-[#0B2545]">Command Line Push (Windows Terminal / PowerShell)</h4>
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const curlCmd = `curl.exe -X POST "http://localhost:9000" -H "Content-Type: text/xml" -d "@Tally_Purchase_${dispatchModalInvoice.invoiceNumber.replace(/[^a-zA-Z0-9_-]/g, '_')}.xml"`;
                      navigator.clipboard.writeText(curlCmd);
                      alert('Command copied to clipboard!');
                    }}
                    className="text-[11px] font-medium text-[#1F4E9C] hover:underline flex items-center space-x-1 cursor-pointer"
                  >
                    <Copy className="w-3 h-3" />
                    <span>Copy Command</span>
                  </button>
                </div>
                <p className="text-[11px] text-[#627D98]">
                  After downloading the XML, run this in PowerShell or Command Prompt from your Downloads folder to push directly to Tally Prime:
                </p>
                <div className="p-2 bg-[#0B2545] text-slate-100 rounded-[4px] font-mono text-[11px] overflow-x-auto select-all">
                  curl.exe -X POST &quot;http://localhost:9000&quot; -H &quot;Content-Type: text/xml&quot; -d &quot;@Tally_Purchase_{dispatchModalInvoice.invoiceNumber.replace(/[^a-zA-Z0-9_-]/g, '_')}.xml&quot;
                </div>
              </div>

            </div>

            {/* Modal Footer */}
            <div className="p-3 bg-[#F8FAFC] border-t border-[#D9E2EC] flex items-center justify-between text-xs">
              <span className="text-[#829AB1]">Tally Prime 3.0 / 4.0 / 4.1 compatible</span>
              <button
                type="button"
                onClick={() => setDispatchModalInvoice(null)}
                className="px-4 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[4px] font-medium hover:bg-[#F5F7FA] transition cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

/**
 * Indian GST Vendor Management System - Type Definitions
 */

export type UserRole = 'PENDING' | 'VENDOR' | 'ACCOUNTS_EXECUTIVE' | 'ADMIN';

export type UserStatus = 'PENDING_APPROVAL' | 'ACTIVE' | 'DEACTIVATED';

export type InvoiceStatus =
  | 'DRAFT'
  | 'SUBMITTED'
  | 'OCR_PROCESSING'
  | 'UNDER_REVIEW'
  | 'APPROVED'
  | 'CLARIFICATION_REQUESTED'
  | 'RESUBMITTED'
  | 'POSTING_TO_TALLY'
  | 'POSTED'
  | 'POSTING_FAILED'
  | 'REJECTED'
  | 'CANCELLED';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  role: UserRole;
  status: UserStatus;
  vendorId?: string;
  canOverride?: boolean;
  isActive: boolean;
  emailVerified?: boolean;
  lastLoginAt?: string;
  createdAt: string;
  updatedAt: string;
  deactivatedReason?: string;
  deactivatedBy?: string;
  deactivatedAt?: string;
  statusReason?: string;
  isDuplicateConflict?: boolean;
  mergedIntoUid?: string;
  isArchived?: boolean;
}

export interface UserInvitation {
  id: string; // Document ID: normalized email
  email: string;
  role: 'VENDOR' | 'ACCOUNTS_EXECUTIVE' | 'ADMIN';
  vendorId?: string;
  canOverride?: boolean;
  invitedBy: string;
  invitedByName?: string;
  invitedAt?: string;
  status: 'PENDING' | 'ACCEPTED' | 'REVOKED' | 'pending' | 'accepted' | 'revoked';
  acceptedUid?: string;
  acceptedAt?: string;
  lastSentAt?: string;
  createdAt: string;
}

export interface VendorMaster {
  id: string;
  legalName: string;
  tradeName: string;
  gstin: string;
  pan: string;
  stateCode: string;
  stateName: string;
  address: string;
  pincode: string;
  contactPerson: string;
  email: string;
  phone: string;
  bankAccountName: string;
  bankAccountNumber: string;
  bankIfsc: string;
  bankName: string;
  isMsme: boolean;
  msmeRegistrationNumber?: string;
  isComposition: boolean;
  turnoverCategory: 'UP_TO_5CR' | 'ABOVE_5CR';
  status: 'PENDING_APPROVAL' | 'ACTIVE' | 'REJECTED' | 'SUSPENDED' | 'ARCHIVED';
  archiveReason?: string;
  archivedAt?: string;
  archivedBy?: string;
  tallyLedgerName?: string;
  createdAt: string;
  updatedAt: string;
}

export interface InvoiceLineItem {
  id: string;
  itemNumber: number;
  description: string;
  hsnSac: string;
  quantity: number;
  uom: string;
  rate: number;
  discount: number;
  taxableValue: number;
  cgstRate: number;
  cgstAmount: number;
  sgstRate: number;
  sgstAmount: number;
  igstRate: number;
  igstAmount: number;
  cessAmount: number;
  total: number;
}

export interface ConfidenceByField {
  supplier_name?: number;
  supplier_gstin?: number;
  buyer_name?: number;
  buyer_gstin?: number;
  invoice_number?: number;
  invoice_date?: number;
  place_of_supply?: number;
  total_taxable_value?: number;
  total_cgst?: number;
  total_sgst?: number;
  total_igst?: number;
  invoice_total?: number;
  [key: string]: number | undefined;
}

export interface InvoiceRecord {
  id: string;
  vendorId: string;
  vendorGstin: string;
  vendorName: string;
  companyId?: string;
  buyerGstin: string;
  buyerName: string;
  invoiceNumber: string;
  invoiceDate: string; // YYYY-MM-DD
  financialYear: string; // e.g. "2026-27"
  poReference?: string;
  placeOfSupply: string; // e.g. "27-Maharashtra"
  isReverseCharge: boolean;
  isCompositionVendor: boolean;
  invoiceType: 'TAX_INVOICE' | 'BILL_OF_SUPPLY';
  currency: string;
  narration?: string;
  
  lineItems: InvoiceLineItem[];

  totalTaxableValue: number;
  totalCgst: number;
  totalSgst: number;
  totalIgst: number;
  totalCess: number;
  roundOff: number;
  invoiceTotal: number;

  status: InvoiceStatus;
  ocrConfidence?: number;
  confidenceByField?: ConfidenceByField;
  ocrRawResponse?: Record<string, any>;
  ocrTokenUsage?: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
  validationStatus: 'PASS' | 'WARN' | 'FAIL';
  validationResults?: GSTValidationCheck[];

  currentFileVersion: number;
  fileUrl?: string;
  fileBase64?: string;
  fileName?: string;
  fileType?: string;
  fileSize?: number;

  rejectionReason?: string;
  overrideReason?: string;
  overriddenBy?: string;

  // TDS Deduction Workflow (Statutory Income Tax Act, 1961)
  tdsSection?: string; // e.g. "194C", "194J", "194I", "194H", "194Q", "NO_TDS"
  tdsSectionName?: string; // e.g. "194C - Contractor"
  tdsRate?: number; // Rate in percentage e.g. 1, 2, 10
  tdsAmount?: number; // Auto-calculated deducted amount
  netPayableAmount?: number; // invoiceTotal - tdsAmount
  noTdsReason?: string; // Mandatory justification when no TDS is deducted
  tdsBaseAmount?: number; // Base amount (Taxable value) on which TDS was computed
  tdsGlAccount?: string; // Tally / ERP TDS General Ledger account e.g. "TDS on Contractors - 194C"
  tdsDeductedByName?: string;
  tdsDeductedAt?: string;

  // Lower TDS Rate & Section 197 Lower Deduction Certificate (LDC)
  isLowerDeductionCertificate?: boolean; // Flag indicating lower or nil rate under Section 197
  lowerDeductionCertNumber?: string; // Certificate identification number issued by Income Tax Dept / TRACES
  lowerDeductionCertValidTill?: string; // Validity date of Section 197 certificate (YYYY-MM-DD)
  lowerDeductionCertLimit?: number; // Optional monetary threshold limit specified in certificate

  // Real-time GSTIN Verification (gstin.cloud) Snapshot
  gstinVerificationSnapshot?: GSTINVerificationResult;

  tallyVoucherGuid?: string;
  tallyVoucherNumber?: string;
  tallyLastError?: string;
  tallyPostedAt?: string;
  tallyConfirmedBy?: string;
  tallyConfirmedByUid?: string;
  tallyImportMethod?: 'MANUAL_XML_IMPORT' | 'DIRECT_BRIDGE_PUSH' | 'SIMULATED' | string;

  submittedByUid: string;
  submittedByName?: string;
  reviewedByUid?: string;
  reviewedByName?: string;

  createdAt: string;
  updatedAt: string;
}

export interface InvoiceFileVersion {
  id: string;
  invoiceId: string;
  version: number;
  fileName: string;
  fileType: string;
  fileSize: number;
  fileData: string; // Base64
  uploadedBy: string;
  uploaderName?: string;
  changeNote?: string;
  createdAt: string;
}

export interface GSTValidationCheck {
  ruleId: string;
  name: string;
  status: 'PASS' | 'WARN' | 'FAIL';
  reason: string;
  legalReference: string;
  field?: string;
}

export interface ClarificationQuery {
  id: string;
  invoiceId: string;
  vendorId: string;
  targetField?: string;
  reasonCode: string;
  queryText: string;
  status: 'OPEN' | 'RESOLVED' | 'ESCALATED';
  raisedByUid: string;
  raisedByName: string;
  slaDueDate: string;
  isEscalated: boolean;
  createdAt: string;
  resolvedAt?: string;
}

export interface ThreadMessage {
  id: string;
  invoiceId: string;
  queryId?: string;
  senderUid: string;
  senderRole: UserRole;
  senderName: string;
  message: string;
  attachmentName?: string;
  attachmentData?: string;
  createdAt: string;
}

export interface AuditLogEntry {
  id: string;
  invoiceId?: string;
  userUid: string;
  userEmail: string;
  userRole: UserRole;
  action: string;
  fromState?: string;
  toState?: string;
  remarks: string;
  diff?: {
    fieldName: string;
    oldValue: any;
    newValue: any;
  }[];
  createdAt: string;
}

export interface LedgerMappingRule {
  id: string;
  mappingType: 'VENDOR' | 'HSN_SAC' | 'TAX_HEAD' | 'ROUND_OFF' | 'TDS';
  matchKey: string; // Vendor ID / HSN / Tax head name / TDS Section (e.g. 194C, 194J)
  tallyLedgerName: string;
  taxRate?: number;
  description: string;
  updatedAt: string;
}

export interface CompanySettings {
  id: string;
  legalName: string;
  tradeName: string;
  gstin: string;
  pan: string;
  stateCode: string;
  stateName: string;
  address: string;
  allowedInternalDomains: string; // comma-separated e.g. "bharattech.in,company.com"
  sessionTimeoutMinutes: number; // default 30
  currentFinancialYear: string;
  ocrConfidenceThreshold: number; // e.g. 0.85
  decimalTolerance: number; // e.g. 1.00
  defaultModelName: string;
  querySlaHours: number; // e.g. 48
  geminiApiKey?: string;
  gstinCloudApiKey?: string; // Stored securely on server for https://gstin.cloud/api/v1/verify
  tdsGlLedgers?: Record<string, string>; // Mapping of TDS Section Code to Tally/ERP GL Ledger Name
  updatedAt: string;
}

export interface GSTINFilingHistoryMonth {
  taxPeriod: string; // e.g. "032026" or "March 2026"
  monthName: string; // e.g. "Mar 2026"
  gstr1Status: 'FILED' | 'PENDING' | 'NOT_APPLICABLE';
  gstr1Dof?: string; // Date of filing (DD-MM-YYYY)
  gstr1Arn?: string;
  gstr3bStatus: 'FILED' | 'PENDING' | 'NOT_APPLICABLE';
  gstr3bDof?: string; // Date of filing (DD-MM-YYYY)
  gstr3bArn?: string;
  iffStatus?: 'FILED' | 'PENDING' | 'NOT_APPLICABLE';
  iffDof?: string;
  iffArn?: string;
}

export interface GSTINVerificationResult {
  gstin: string;
  legalName: string;
  tradeName: string;
  constitutionOfBusiness: string; // e.g. "Private Limited Company", "Partnership", "Proprietorship", "LLP"
  taxpayerType: string; // e.g. "Regular", "Composition", "ISD", "SEZ Unit"
  principalPlaceOfBusiness: string;
  stateJurisdiction?: string;
  centerJurisdiction?: string;
  registrationDate?: string;
  status: 'ACTIVE' | 'CANCELLED' | 'SUSPENDED' | 'PROVISIONAL';
  filingFrequency: 'MONTHLY' | 'QUARTERLY_QRMP';
  lastReturnFiled: {
    returnType: string; // e.g. "GSTR-3B"
    taxPeriod: string; // e.g. "March 2026"
    filingDate: string; // e.g. "20-04-2026"
    arn?: string;
  };
  filingHistory: GSTINFilingHistoryMonth[]; // 6-month completed history
  verifiedAt: string;
  isLiveApi: boolean;
  rawResponse?: Record<string, any>;
  errorMessage?: string;
}

export interface TallyAgentRecord {
  id: string;
  agentId: string;
  name: string;
  tokenHash: string;
  plainTokenMasked?: string;
  isRevoked: boolean;
  version?: string;
  tallyCompany?: string;
  lastHeartbeat?: string;
  status: 'ONLINE' | 'OFFLINE';
  createdAt: string;
}

export interface HsnSacMasterItem {
  code: string;
  description: string;
  gstRate: number;
  type: 'GOODS' | 'SERVICES';
}

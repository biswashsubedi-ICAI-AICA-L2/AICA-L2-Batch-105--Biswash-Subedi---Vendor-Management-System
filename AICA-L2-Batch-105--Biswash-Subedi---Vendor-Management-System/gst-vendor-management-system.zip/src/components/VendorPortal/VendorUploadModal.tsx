/**
 * Vendor Invoice Upload Modal with Server-Side Gemini Multimodal OCR
 * Restyled with ICAI-inspired theme: White card, Navy #0B2545, Blue #1F4E9C, 6px radius.
 */

import React, { useState, useRef } from 'react';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { InvoiceRecord, InvoiceLineItem } from '../../types/index.ts';
import { getIndianFinancialYear, GST_STATE_CODES, normalizePlaceOfSupply } from '../../utils/gstUtils.ts';
import {
  UploadCloud,
  FileText,
  AlertCircle,
  Plus,
  Trash2,
  CheckCircle2,
  X,
  Loader2,
  ArrowRight,
  Info,
} from 'lucide-react';

interface VendorUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (invoice: InvoiceRecord) => void;
  resubmitInvoice?: InvoiceRecord | null;
}

export const VendorUploadModal: React.FC<VendorUploadModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  resubmitInvoice,
}) => {
  const { activeVendor, vendors, currentUser, companySettings, saveInvoice } = useAuth();
  const resolvedVendor =
    activeVendor ||
    (currentUser?.vendorId ? vendors.find((v) => v.id === currentUser.vendorId) : null) ||
    vendors.find((v) => v.id === 'vendor_apex') ||
    vendors[0];
  const fileInputRef = useRef<HTMLInputElement>(null);
  const abortControllerRef = useRef<AbortController | null>(null);
  const timeoutRef = useRef<any>(null);

  const [step, setStep] = useState<'UPLOAD' | 'OCR_PROCESSING' | 'REVIEW'>(
    resubmitInvoice ? 'REVIEW' : 'UPLOAD'
  );
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [fileBase64, setFileBase64] = useState<string>('');
  const [fileType, setFileType] = useState<string>('application/pdf');
  const [ocrError, setOcrError] = useState<string | null>(null);
  const [ocrNotice, setOcrNotice] = useState<string | null>(null);
  const [ocrTokens, setOcrTokens] = useState<any>(null);
  const [multiInvoiceAlert, setMultiInvoiceAlert] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  // Invoice Form State
  const [invoiceNumber, setInvoiceNumber] = useState<string>(resubmitInvoice?.invoiceNumber || '');
  const [invoiceDate, setInvoiceDate] = useState<string>(
    resubmitInvoice?.invoiceDate || new Date().toISOString().slice(0, 10)
  );
  const [poReference, setPoReference] = useState<string>(resubmitInvoice?.poReference || '');
  const [placeOfSupply, setPlaceOfSupply] = useState<string>(
    resubmitInvoice?.placeOfSupply || '27-Maharashtra'
  );
  const [isReverseCharge, setIsReverseCharge] = useState<boolean>(
    resubmitInvoice?.isReverseCharge || false
  );
  const [narration, setNarration] = useState<string>(resubmitInvoice?.narration || '');
  const [invoiceType, setInvoiceType] = useState<'TAX_INVOICE' | 'BILL_OF_SUPPLY'>(
    (resolvedVendor?.isComposition || activeVendor?.isComposition) ? 'BILL_OF_SUPPLY' : 'TAX_INVOICE'
  );

  const [lineItems, setLineItems] = useState<InvoiceLineItem[]>(
    resubmitInvoice?.lineItems || [
      {
        id: 'li_1',
        itemNumber: 1,
        description: 'Industrial Consumables / Services',
        hsnSac: '847130',
        quantity: 1,
        uom: 'NOS',
        rate: 10000,
        discount: 0,
        taxableValue: 10000,
        cgstRate: 9,
        cgstAmount: 900,
        sgstRate: 9,
        sgstAmount: 900,
        igstRate: 0,
        igstAmount: 0,
        cessAmount: 0,
        total: 11800,
      },
    ]
  );

  const handleSkipOcr = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    setOcrError('AI extraction skipped. You can review and enter invoice particulars manually.');
    setStep('REVIEW');
  };

  const handleCloseModal = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    onClose();
  };

  if (!isOpen) return null;

  // Handle file selection and trigger server Gemini OCR
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      setOcrError('File size exceeds 10 MB limit.');
      return;
    }

    setSelectedFile(file);
    setFileType(file.type || 'application/pdf');
    setOcrError(null);
    setStep('OCR_PROCESSING');

    // Create abort controller with 20s maximum timeout for cloud fallback
    const abortController = new AbortController();
    abortControllerRef.current = abortController;
    if (timeoutRef.current) {
      clearTimeout(timeoutRef.current);
    }
    timeoutRef.current = setTimeout(() => {
      if (abortControllerRef.current === abortController) {
        abortController.abort();
      }
    }, 20000);

    try {
      // Optimize image files before uploading; pass PDFs directly as base64
      const getOptimizedPayload = async (): Promise<{ base64: string; mimeType: string }> => {
        const isPdf = (file.type && file.type.includes('pdf')) || file.name.toLowerCase().endsWith('.pdf');
        if (isPdf) {
          return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve({ base64: reader.result as string, mimeType: 'application/pdf' });
            reader.onerror = reject;
            reader.readAsDataURL(file);
          });
        }

        if (!file.type.startsWith('image/')) {
          return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.onload = () => resolve({ base64: reader.result as string, mimeType: file.type || 'application/pdf' });
            reader.onerror = reject;
            reader.readAsDataURL(file);
          });
        }

        return new Promise((resolve) => {
          const reader = new FileReader();
          reader.onload = () => {
            const img = new Image();
            img.onload = () => {
              const MAX_DIM = 1600;
              let { width, height } = img;
              if (width > MAX_DIM || height > MAX_DIM) {
                if (width > height) {
                  height = Math.round((height * MAX_DIM) / width);
                  width = MAX_DIM;
                } else {
                  width = Math.round((width * MAX_DIM) / height);
                  height = MAX_DIM;
                }
              }
              const canvas = document.createElement('canvas');
              canvas.width = width;
              canvas.height = height;
              const ctx = canvas.getContext('2d');
              if (ctx) {
                ctx.drawImage(img, 0, 0, width, height);
                const compressed = canvas.toDataURL('image/jpeg', 0.85);
                resolve({ base64: compressed, mimeType: 'image/jpeg' });
                return;
              }
              resolve({ base64: reader.result as string, mimeType: file.type });
            };
            img.onerror = () => resolve({ base64: reader.result as string, mimeType: file.type });
            img.src = reader.result as string;
          };
          reader.onerror = () => resolve({ base64: '', mimeType: file.type });
          reader.readAsDataURL(file);
        });
      };

      const { base64: base64Result, mimeType: effectiveMime } = await getOptimizedPayload();
      setFileBase64(base64Result);
      setFileType(effectiveMime);

      try {
        let response: Response;
        try {
          response = await fetch('/api/ocr/extract-invoice', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            signal: abortController.signal,
            body: JSON.stringify({
              fileBase64: base64Result,
              fileType: effectiveMime,
              vendorGstin: resolvedVendor?.gstin || activeVendor?.gstin,
              vendorName: resolvedVendor?.legalName || activeVendor?.legalName,
              buyerGstin: companySettings.gstin,
              defaultModelName: companySettings.defaultModelName || 'gemini-3.1-flash-lite',
            }),
          });
        } catch (netErr: any) {
          if (netErr.name === 'AbortError') {
            throw new Error('Document extraction timed out (20s limit)');
          }
          throw new Error(`Network error calling OCR API: ${netErr.message}`);
        }

          let data: any = {};
          const contentType = response.headers.get('content-type') || '';
          if (contentType.includes('application/json')) {
            data = await response.json();
          } else {
            const rawText = await response.text();
            throw new Error(`Server returned non-JSON response (${response.status}): ${rawText.slice(0, 100)}`);
          }

          if (!response.ok || data.success === false) {
            throw new Error(data.error || 'Server OCR processing failed');
          }

          if (data.isMultipleInvoicesDetected) {
            setMultiInvoiceAlert(data.multipleInvoicesWarning || 'Multiple invoices detected in file. Extracted primary invoice.');
          }

          if (data.tokensUsed) {
            setOcrTokens(data.tokensUsed);
          }

          if (Array.isArray(data.warnings) && data.warnings.length > 0) {
            setOcrNotice(data.warnings[0]);
          }

          // Populate form with extracted OCR data (support both camelCase and snake_case)
          const extractedInvNumber = data.invoiceNumber || data.data?.invoice_number;
          if (extractedInvNumber) setInvoiceNumber(String(extractedInvNumber).trim());

          const extractedInvDate = data.invoiceDate || data.data?.invoice_date;
          if (extractedInvDate) setInvoiceDate(String(extractedInvDate).slice(0, 10));

          const extractedPo = data.poReference || data.data?.po_reference;
          if (extractedPo) setPoReference(String(extractedPo).trim());

          const extractedPos = data.placeOfSupply || data.data?.place_of_supply;
          if (extractedPos) {
            setPlaceOfSupply(normalizePlaceOfSupply(extractedPos));
          }

          const rcm = typeof data.isReverseCharge === 'boolean'
            ? data.isReverseCharge
            : (typeof data.data?.reverse_charge === 'boolean' ? data.data.reverse_charge : null);
          if (rcm !== null) setIsReverseCharge(rcm);

          const narr = data.narration || data.data?.narration;
          if (narr) setNarration(narr);

          const items = (Array.isArray(data.lineItems) && data.lineItems.length > 0)
            ? data.lineItems
            : (Array.isArray(data.data?.line_items) ? data.data.line_items : null);

          if (items && items.length > 0) {
            const normalizedItems: InvoiceLineItem[] = items.map((it: any, idx: number) => {
              const taxable = Number(it.taxableValue ?? it.taxable_value ?? 0);
              const cgst = Number(it.cgstAmount ?? it.cgst_amount ?? 0);
              const sgst = Number(it.sgstAmount ?? it.sgst_amount ?? 0);
              const igst = Number(it.igstAmount ?? it.igst_amount ?? 0);
              const cess = Number(it.cessAmount ?? it.cess_amount ?? 0);
              const computedTot = it.total ?? (taxable + cgst + sgst + igst + cess);

              return {
                id: it.id || `li_${idx + 1}`,
                itemNumber: it.itemNumber || it.item_number || idx + 1,
                description: it.description || 'Supply Item',
                hsnSac: String(it.hsnSac || it.hsn_sac || '847130').trim(),
                quantity: Number(it.quantity || 1),
                uom: String(it.uom || 'NOS').trim().toUpperCase(),
                rate: Number(it.rate || (it.quantity ? taxable / it.quantity : taxable)),
                discount: Number(it.discount || 0),
                taxableValue: taxable,
                cgstRate: Number(it.cgstRate ?? it.cgst_rate ?? 0),
                cgstAmount: cgst,
                sgstRate: Number(it.sgstRate ?? it.sgst_rate ?? 0),
                sgstAmount: sgst,
                igstRate: Number(it.igstRate ?? it.igst_rate ?? 0),
                igstAmount: igst,
                cessAmount: cess,
                total: Number(computedTot) > 0 ? Number(computedTot) : taxable,
              };
            });
            setLineItems(normalizedItems);
          }

          setStep('REVIEW');
        } catch (apiErr: any) {
          console.error('OCR Endpoint error:', apiErr);
          setOcrError(`Gemini OCR Notice: ${apiErr.message}. You may enter invoice particulars manually.`);
          setStep('REVIEW');
        } finally {
          if (timeoutRef.current) {
            clearTimeout(timeoutRef.current);
          }
        }
      } catch (err: any) {
        console.error('File reading error:', err);
        setOcrError('Failed to read file from local filesystem.');
        setStep('REVIEW');
      }
  };

  const handleAddLine = () => {
    const newItem: InvoiceLineItem = {
      id: `li_${Date.now()}_${Math.random().toString(36).substring(2, 5)}`,
      itemNumber: lineItems.length + 1,
      description: 'Material / Supply Item',
      hsnSac: '8471',
      quantity: 1,
      uom: 'NOS',
      rate: 1000,
      discount: 0,
      taxableValue: 1000,
      cgstRate: 9,
      cgstAmount: 90,
      sgstRate: 9,
      sgstAmount: 90,
      igstRate: 0,
      igstAmount: 0,
      cessAmount: 0,
      total: 1180,
    };
    setLineItems([...lineItems, newItem]);
  };

  const handleUpdateLine = (index: number, field: keyof InvoiceLineItem, value: any) => {
    const updated = [...lineItems];
    const item = { ...updated[index], [field]: value };

    const qty = Number(item.quantity || 0);
    const rate = Number(item.rate || 0);
    const disc = Number(item.discount || 0);
    item.taxableValue = Number((qty * rate - disc).toFixed(2));

    const isInterstate = !placeOfSupply.startsWith(activeVendor?.stateCode || '27');
    if (isInterstate) {
      item.cgstRate = 0;
      item.cgstAmount = 0;
      item.sgstRate = 0;
      item.sgstAmount = 0;
      item.igstAmount = Number(((item.taxableValue * (item.igstRate || 18)) / 100).toFixed(2));
    } else {
      item.igstRate = 0;
      item.igstAmount = 0;
      item.cgstAmount = Number(((item.taxableValue * (item.cgstRate || 9)) / 100).toFixed(2));
      item.sgstAmount = Number(((item.taxableValue * (item.sgstRate || 9)) / 100).toFixed(2));
    }

    item.total = Number(
      (item.taxableValue + item.cgstAmount + item.sgstAmount + item.igstAmount + (item.cessAmount || 0)).toFixed(2)
    );

    updated[index] = item;
    setLineItems(updated);
  };

  const handleDeleteLine = (index: number) => {
    if (lineItems.length === 1) return;
    setLineItems(lineItems.filter((_, i) => i !== index));
  };

  // Recomputed header totals
  const totalTaxable = lineItems.reduce((acc, curr) => acc + (curr.taxableValue || 0), 0);
  const totalCgst = lineItems.reduce((acc, curr) => acc + (curr.cgstAmount || 0), 0);
  const totalSgst = lineItems.reduce((acc, curr) => acc + (curr.sgstAmount || 0), 0);
  const totalIgst = lineItems.reduce((acc, curr) => acc + (curr.igstAmount || 0), 0);
  const totalCess = lineItems.reduce((acc, curr) => acc + (curr.cessAmount || 0), 0);
  const rawTotal = totalTaxable + totalCgst + totalSgst + totalIgst + totalCess;
  const roundedTotal = Math.round(rawTotal);
  const roundOff = Number((roundedTotal - rawTotal).toFixed(2));

  const handleSubmitInvoice = async () => {
    if (!invoiceNumber.trim()) {
      alert('Invoice number is required.');
      return;
    }

    setIsSubmitting(true);
    setSubmitError(null);

    const nextVersion = resubmitInvoice ? (resubmitInvoice.currentFileVersion || 1) + 1 : 1;
    const vendorRecord = resolvedVendor;

    const invoicePayload: InvoiceRecord = {
      id: resubmitInvoice ? resubmitInvoice.id : `inv_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      vendorId: vendorRecord?.id || 'vendor_apex',
      vendorName: vendorRecord?.legalName || 'Apex Precision Engineering LLP',
      vendorGstin: vendorRecord?.gstin || '27AAACR5055K1Z7',
      buyerGstin: companySettings.gstin,
      buyerName: companySettings.legalName,
      invoiceNumber: invoiceNumber.trim(),
      invoiceDate,
      financialYear: getIndianFinancialYear(invoiceDate),
      poReference: poReference.trim(),
      placeOfSupply,
      isReverseCharge,
      isCompositionVendor: Boolean(vendorRecord?.isComposition),
      invoiceType,
      currency: 'INR',
      narration,
      lineItems,
      totalTaxableValue: Number(totalTaxable.toFixed(2)),
      totalCgst: Number(totalCgst.toFixed(2)),
      totalSgst: Number(totalSgst.toFixed(2)),
      totalIgst: Number(totalIgst.toFixed(2)),
      totalCess: Number(totalCess.toFixed(2)),
      roundOff,
      invoiceTotal: roundedTotal,
      status: 'UNDER_REVIEW',
      ocrConfidence: ocrTokens ? 0.94 : 0.88,
      validationStatus: 'PASS',
      currentFileVersion: nextVersion,
      fileBase64: fileBase64 || resubmitInvoice?.fileBase64,
      fileName: selectedFile?.name || resubmitInvoice?.fileName || 'Invoice_Upload.pdf',
      fileType: fileType || resubmitInvoice?.fileType || 'application/pdf',
      submittedByUid: currentUser?.uid || 'vendor_user',
      submittedByName: currentUser?.displayName || vendorRecord?.contactPerson || 'Vendor Rep',
      createdAt: resubmitInvoice?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    try {
      await saveInvoice(
        invoicePayload,
        resubmitInvoice
          ? `Resubmitted invoice version ${invoicePayload.currentFileVersion}`
          : `Initial invoice submission by vendor ${vendorRecord?.legalName || ''}`
      );
      if (onSuccess) {
        onSuccess(invoicePayload);
      }
      onClose();
    } catch (err: any) {
      console.error('Invoice submission failed:', err);
      setSubmitError(err.message || 'Failed to submit invoice to server. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-[#0B2545]/60 flex items-center justify-center p-4"
      onClick={(e) => {
        if (e.target === e.currentTarget) handleCloseModal();
      }}
    >
      <div className="bg-white border border-[#D9E2EC] w-full max-w-4xl rounded-[6px] shadow-lg overflow-hidden flex flex-col max-h-[90vh]">
        
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-[#D9E2EC] flex items-center justify-between bg-[#F5F7FA]">
          <div className="flex items-center space-x-2">
            <div className="p-2 bg-[#EBF1FA] text-[#1F4E9C] rounded-[4px]">
              <UploadCloud className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-[#0B2545]">
                {resubmitInvoice ? `Resubmit Invoice (v${(resubmitInvoice.currentFileVersion || 1) + 1})` : 'Upload GST Tax Invoice'}
              </h3>
              <p className="text-xs text-[#52606D]">
                Supplier: <span className="text-[#1F2933] font-medium">{resolvedVendor?.legalName || activeVendor?.legalName}</span> ({resolvedVendor?.gstin || activeVendor?.gstin})
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handleCloseModal}
              className="text-xs text-[#52606D] hover:text-[#0B2545] px-2.5 py-1 bg-white hover:bg-[#EBF1FA] border border-[#D9E2EC] rounded-[4px] transition"
              title="Close modal and return to Dashboard"
            >
              Back to Dashboard
            </button>
            <button onClick={handleCloseModal} className="text-[#52606D] hover:text-[#0B2545] p-1 rounded" title="Close">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          
          {/* STEP 1: Upload Dropzone */}
          {step === 'UPLOAD' && (
            <div className="space-y-4">
              <div
                onClick={() => fileInputRef.current?.click()}
                className="border-2 border-dashed border-[#D9E2EC] hover:border-[#1F4E9C] rounded-[6px] p-10 text-center cursor-pointer bg-[#F5F7FA] hover:bg-[#EBF1FA]/40 transition group"
              >
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  accept=".pdf,image/png,image/jpeg"
                  className="hidden"
                />
                <div className="w-14 h-14 mx-auto mb-3 rounded-[6px] bg-[#EBF1FA] border border-[#D9E2EC] flex items-center justify-center text-[#1F4E9C]">
                  <UploadCloud className="w-7 h-7" />
                </div>
                <h4 className="text-sm font-semibold text-[#0B2545]">Drop invoice file here or click to browse</h4>
                <p className="text-xs text-[#52606D] mt-1">
                  Supports PDF, JPG, and PNG formats (Max 10 MB).
                </p>
                <div className="mt-3 inline-flex items-center space-x-1.5 px-3 py-1 bg-white border border-[#D9E2EC] text-[#1F4E9C] rounded-[4px] text-xs font-medium">
                  <FileText className="w-3.5 h-3.5" />
                  <span>Multimodal Document Extraction</span>
                </div>
              </div>

              <div className="p-3 bg-[#EBF1FA] rounded-[6px] border border-[#D9E2EC] flex items-start space-x-3 text-xs text-[#52606D]">
                <Info className="w-4 h-4 text-[#1F4E9C] shrink-0 mt-0.5" />
                <span>
                  Invoice particulars (HSN, GSTIN, Tax split, Rate) will be extracted and statutory GST checks will be performed.
                </span>
              </div>
            </div>
          )}

          {/* STEP 2: Processing Animation with Instant Skip option */}
          {step === 'OCR_PROCESSING' && (
            <div className="py-12 text-center space-y-5">
              <div className="inline-flex items-center justify-center p-3.5 bg-[#EBF1FA] rounded-full text-[#1F4E9C]">
                <Loader2 className="w-10 h-10 animate-spin" />
              </div>
              <div>
                <h4 className="text-base font-bold text-[#0B2545]">Extracting Invoice Particulars...</h4>
                <p className="text-xs text-[#52606D] max-w-md mx-auto mt-1">
                  Analyzing invoice particulars, HSN codes, and GST rates against statutory requirements.
                </p>
              </div>

              <div className="pt-2">
                <button
                  type="button"
                  onClick={handleSkipOcr}
                  className="inline-flex items-center space-x-2 px-4 py-2 bg-white text-[#1F4E9C] hover:bg-[#EBF1FA] border border-[#1F4E9C] text-xs font-semibold rounded-[6px] transition shadow-xs"
                >
                  <span>Skip Extraction & Enter Details Manually</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
              <p className="text-[11px] text-[#829AB1]">
                If automatic analysis takes more than a few seconds, skip will immediately open the review form.
              </p>
            </div>
          )}

          {/* STEP 3: Review & Edit Extracted Data */}
          {step === 'REVIEW' && (
            <div className="space-y-6">
              
              {multiInvoiceAlert && (
                <div className="p-3 bg-[#FFF7E6] border border-[#FFE7BA] rounded-[6px] text-[#B26A00] text-xs flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{multiInvoiceAlert}</span>
                  </div>
                  <button onClick={() => setMultiInvoiceAlert(null)} className="text-[#B26A00] hover:text-[#873800] p-1">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {submitError && (
                <div className="p-3 bg-[#FEF3F2] border border-[#FECDCA] rounded-[6px] text-[#B42318] text-xs flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{submitError}</span>
                  </div>
                  <button onClick={() => setSubmitError(null)} className="text-[#B42318] hover:text-[#8F1A12] p-1">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {ocrError && (
                <div className="p-3 bg-[#FEF3F2] border border-[#FECDCA] rounded-[6px] text-[#B42318] text-xs flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <AlertCircle className="w-4 h-4 shrink-0" />
                    <span>{ocrError}</span>
                  </div>
                  <button onClick={() => setOcrError(null)} className="text-[#B42318] hover:text-[#8F1A12] p-1" title="Dismiss">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {ocrNotice && !ocrError && (
                <div className="p-3 bg-[#EBF1FA] border border-[#D9E2EC] rounded-[6px] text-[#1F4E9C] text-xs flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <Info className="w-4 h-4 shrink-0 text-[#1F4E9C]" />
                    <span className="font-medium">{ocrNotice}</span>
                  </div>
                  <button onClick={() => setOcrNotice(null)} className="text-[#1F4E9C] hover:text-[#0B2545] p-1" title="Dismiss">
                    <X className="w-3.5 h-3.5" />
                  </button>
                </div>
              )}

              {/* Header Fields Grid */}
              <div className="bg-[#F5F7FA] p-4 rounded-[6px] border border-[#D9E2EC] space-y-4">
                <h4 className="text-xs font-bold text-[#0B2545] uppercase tracking-wider">
                  1. Invoice Header Particulars
                </h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-[#1F2933] mb-1">
                      Invoice Number *
                    </label>
                    <input
                      type="text"
                      value={invoiceNumber}
                      onChange={(e) => setInvoiceNumber(e.target.value)}
                      placeholder="e.g. INV/26-27/012"
                      className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C] font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#1F2933] mb-1">
                      Invoice Date *
                    </label>
                    <input
                      type="date"
                      value={invoiceDate}
                      onChange={(e) => setInvoiceDate(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#1F2933] mb-1">
                      PO Reference
                    </label>
                    <input
                      type="text"
                      value={poReference}
                      onChange={(e) => setPoReference(e.target.value)}
                      placeholder="e.g. PO-2026-904"
                      className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C] font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#1F2933] mb-1">
                      Place of Supply *
                    </label>
                    <select
                      value={placeOfSupply}
                      onChange={(e) => setPlaceOfSupply(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                    >
                      {Object.entries(GST_STATE_CODES).map(([code, name]) => (
                        <option key={code} value={`${code}-${name}`}>
                          {code} - {name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-medium text-[#1F2933] mb-1">
                      Invoice Document Type
                    </label>
                    <select
                      value={invoiceType}
                      onChange={(e) => setInvoiceType(e.target.value as any)}
                      className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                    >
                      <option value="TAX_INVOICE">Tax Invoice (Standard)</option>
                      <option value="BILL_OF_SUPPLY">Bill of Supply (Composition)</option>
                    </select>
                  </div>

                  <div className="flex items-center space-x-2 pt-6">
                    <input
                      type="checkbox"
                      id="rcmCheck"
                      checked={isReverseCharge}
                      onChange={(e) => setIsReverseCharge(e.target.checked)}
                      className="w-4 h-4 text-[#1F4E9C] rounded border-[#D9E2EC]"
                    />
                    <label htmlFor="rcmCheck" className="text-xs text-[#1F2933]">
                      Reverse Charge Applicable (RCM)
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-medium text-[#1F2933] mb-1">
                    Narration / Delivery Notes
                  </label>
                  <input
                    type="text"
                    value={narration}
                    onChange={(e) => setNarration(e.target.value)}
                    placeholder="Details of materials or service milestones..."
                    className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                  />
                </div>
              </div>

              {/* Line Items Table */}
              <div className="bg-[#F5F7FA] p-4 rounded-[6px] border border-[#D9E2EC] space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-xs font-bold text-[#0B2545] uppercase tracking-wider">
                    2. Line Items & HSN/SAC Tax Heads
                  </h4>
                  <button
                    onClick={handleAddLine}
                    className="flex items-center space-x-1 px-2.5 py-1 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[4px] text-xs font-medium transition"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add Item</span>
                  </button>
                </div>

                <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545]">
                      <tr>
                        <th className="p-2 font-semibold">Description</th>
                        <th className="p-2 font-semibold w-24">HSN/SAC</th>
                        <th className="p-2 font-semibold w-16 text-right">Qty</th>
                        <th className="p-2 font-semibold w-20 text-right">Rate</th>
                        <th className="p-2 font-semibold w-16 text-right">Disc</th>
                        <th className="p-2 font-semibold w-24 text-right">Taxable</th>
                        <th className="p-2 font-semibold w-24 text-right">GST</th>
                        <th className="p-2 font-semibold w-24 text-right">Total</th>
                        <th className="p-2 w-8"></th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#D9E2EC] bg-white">
                      {lineItems.map((item, idx) => (
                        <tr key={item.id}>
                          <td className="p-2">
                            <input
                              type="text"
                              value={item.description}
                              onChange={(e) => handleUpdateLine(idx, 'description', e.target.value)}
                              className="w-full px-2 py-1 bg-white border border-[#D9E2EC] rounded text-[#1F2933]"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="text"
                              value={item.hsnSac}
                              onChange={(e) => handleUpdateLine(idx, 'hsnSac', e.target.value)}
                              className="w-full px-2 py-1 bg-white border border-[#D9E2EC] rounded font-mono text-[#1F2933] text-center"
                              placeholder="e.g. 847130"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="number"
                              value={item.quantity}
                              onChange={(e) => handleUpdateLine(idx, 'quantity', parseFloat(e.target.value) || 0)}
                              className="w-full px-2 py-1 bg-white border border-[#D9E2EC] rounded text-right text-[#1F2933]"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="number"
                              value={item.rate}
                              onChange={(e) => handleUpdateLine(idx, 'rate', parseFloat(e.target.value) || 0)}
                              className="w-full px-2 py-1 bg-white border border-[#D9E2EC] rounded text-right text-[#1F2933]"
                            />
                          </td>
                          <td className="p-2">
                            <input
                              type="number"
                              value={item.discount}
                              onChange={(e) => handleUpdateLine(idx, 'discount', parseFloat(e.target.value) || 0)}
                              className="w-full px-2 py-1 bg-white border border-[#D9E2EC] rounded text-right text-[#1F2933]"
                            />
                          </td>
                          <td className="p-2 text-right font-medium text-[#1F2933]">
                            ₹{item.taxableValue.toFixed(2)}
                          </td>
                          <td className="p-2 text-right text-[#52606D]">
                            ₹{(item.cgstAmount + item.sgstAmount + item.igstAmount).toFixed(2)}
                          </td>
                          <td className="p-2 text-right font-semibold text-[#0B2545]">
                            ₹{item.total.toFixed(2)}
                          </td>
                          <td className="p-2 text-right">
                            {lineItems.length > 1 && (
                              <button
                                onClick={() => handleDeleteLine(idx)}
                                className="text-[#52606D] hover:text-[#B42318] transition"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Totals Summary */}
                <div className="pt-3 border-t border-[#D9E2EC] flex justify-end">
                  <div className="w-64 space-y-1.5 text-xs">
                    <div className="flex justify-between text-[#52606D]">
                      <span>Total Taxable Value:</span>
                      <span className="font-mono text-[#1F2933]">₹{totalTaxable.toFixed(2)}</span>
                    </div>
                    {totalCgst > 0 && (
                      <div className="flex justify-between text-[#52606D]">
                        <span>Central GST (CGST):</span>
                        <span className="font-mono text-[#1F2933]">₹{totalCgst.toFixed(2)}</span>
                      </div>
                    )}
                    {totalSgst > 0 && (
                      <div className="flex justify-between text-[#52606D]">
                        <span>State GST (SGST):</span>
                        <span className="font-mono text-[#1F2933]">₹{totalSgst.toFixed(2)}</span>
                      </div>
                    )}
                    {totalIgst > 0 && (
                      <div className="flex justify-between text-[#52606D]">
                        <span>Integrated GST (IGST):</span>
                        <span className="font-mono text-[#1F2933]">₹{totalIgst.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-[#52606D]">
                      <span>Round Off:</span>
                      <span className="font-mono text-[#1F2933]">₹{roundOff.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between pt-2 border-t border-[#D9E2EC] text-sm font-bold text-[#0B2545]">
                      <span>Invoice Total:</span>
                      <span className="font-mono text-[#1B7F3B]">₹{roundedTotal.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>

            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="px-6 py-4 border-t border-[#D9E2EC] bg-[#F5F7FA] flex items-center justify-between">
          {step === 'REVIEW' && !resubmitInvoice && (
            <button
              onClick={() => setStep('UPLOAD')}
              className="text-xs text-[#52606D] hover:text-[#0B2545]"
            >
              ← Choose another file
            </button>
          )}
          {step === 'UPLOAD' && <div />}
          {step === 'OCR_PROCESSING' && (
            <button
              type="button"
              onClick={handleSkipOcr}
              className="text-xs font-semibold text-[#1F4E9C] hover:underline flex items-center space-x-1"
            >
              <span>Skip scanning & enter manually</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}

          <div className="flex items-center space-x-3">
            <button
              type="button"
              onClick={handleCloseModal}
              className="px-4 py-2 bg-white text-[#52606D] hover:bg-[#F5F7FA] border border-[#D9E2EC] text-xs font-medium rounded-[6px] transition"
            >
              Cancel
            </button>
            {step === 'REVIEW' && (
              <button
                onClick={handleSubmitInvoice}
                disabled={isSubmitting}
                className="flex items-center space-x-1.5 px-5 py-2 bg-[#1B7F3B] hover:bg-[#14632E] text-white text-xs font-medium rounded-[6px] transition disabled:opacity-50"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Submitting to Accounts...</span>
                  </>
                ) : (
                  <>
                    <span>Submit to Accounts Review</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            )}
          </div>
        </div>

      </div>
    </div>
  );
};

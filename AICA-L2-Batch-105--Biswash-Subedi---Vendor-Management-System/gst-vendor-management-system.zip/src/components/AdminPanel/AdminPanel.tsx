/**
 * Admin Panel for GST Vendor Management System
 * Features:
 * - User Management (Role assignment, vendor binding, override permission, activation/deactivation)
 * - Pending Invitations Table with full lifecycle: Edit, Resend, Revoke, Bulk Delete
 * - Vendor Management with GST History Protection:
 *   * Rule A: Permanent deletion with name confirmation & reason if 0 history
 *   * Rule B: Soft Archive if invoices/queries exist (deactivates users, retains invoices for duplicate checks)
 *   * Rule C: Clear on-screen explanation of compliance rules
 *   * Restore archived vendors
 *   * Filter toggle: "Include archived vendors"
 * - Company Settings, HSN/SAC Directory, and Append-Only Audit Log
 */

import React, { useState, useMemo } from 'react';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { UserProfile, UserRole, UserStatus, UserInvitation, VendorMaster } from '../../types/index.ts';
import {
  ShieldCheck,
  Building2,
  Users,
  Settings,
  History,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Save,
  Search,
  UserPlus,
  Unlock,
  UserCheck,
  UserX,
  Mail,
  Send,
  Trash2,
  Edit2,
  RotateCcw,
  Archive,
  Info,
  Wrench,
  GitMerge,
  RefreshCw,
  AlertTriangle,
  PlusCircle,
  Key,
  Eye,
  EyeOff,
  Sparkles,
  BookOpen,
} from 'lucide-react';
import { AddVendorModal } from './AddVendorModal.tsx';
import { EditVendorModal } from './EditVendorModal.tsx';
import { DEFAULT_TDS_GL_LEDGERS } from '../../utils/tdsConfig.ts';

interface AdminPanelProps {
  initialTab?: 'USERS' | 'VENDORS' | 'SETTINGS' | 'HSN' | 'AUDIT';
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ initialTab = 'USERS' }) => {
  const {
    currentUser,
    allUsers,
    invitations,
    vendors,
    assignUserRole,
    toggleUserStatus,
    activateUser,
    deactivateUser,
    deleteUser,
    bulkDeleteUsers,
    checkUserAccess,
    resyncUserAccess,
    resolveDuplicateUsers,
    createInvitation,
    editInvitation,
    resendInvitation,
    deleteInvitation,
    bulkDeleteInvitations,
    checkVendorDeleteEligibility,
    deleteVendorPermanent,
    archiveVendor,
    restoreVendor,
    bulkDeleteVendors,
    refreshVendors,
    approveVendor,
    rejectVendor,
    companySettings,
    updateCompanySettings,
    auditLogs,
    hsnMaster,
  } = useAuth();

  const [activeTab, setActiveTab] = useState<'USERS' | 'VENDORS' | 'SETTINGS' | 'HSN' | 'AUDIT'>(
    initialTab
  );

  // Add & Edit Vendor Modal State
  const [showAddVendorModal, setShowAddVendorModal] = useState(false);
  const [editingVendorMaster, setEditingVendorMaster] = useState<VendorMaster | null>(null);
  const [showEditVendorModal, setShowEditVendorModal] = useState(false);

  const handleVendorCreated = async (newVendor: VendorMaster) => {
    setVendorActionMessage(`Vendor "${newVendor.legalName}" (${newVendor.gstin}) successfully registered.`);
    await refreshVendors();
  };

  const handleVendorUpdated = async (updatedVendor: VendorMaster) => {
    setVendorActionMessage(`Vendor "${updatedVendor.legalName}" (${updatedVendor.gstin}) master details successfully updated.`);
    await refreshVendors();
  };

  // User Edit Modal State
  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [editRole, setEditRole] = useState<UserRole>('VENDOR');
  const [editStatus, setEditStatus] = useState<UserStatus>('ACTIVE');
  const [editVendorId, setEditVendorId] = useState<string>('vendor_apex');
  const [editCanOverride, setEditCanOverride] = useState<boolean>(false);
  const [editError, setEditError] = useState<string | null>(null);

  // Invite Modal State
  const [showInviteModal, setShowInviteModal] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState<'VENDOR' | 'ACCOUNTS_EXECUTIVE' | 'ADMIN'>('ACCOUNTS_EXECUTIVE');
  const [inviteVendorId, setInviteVendorId] = useState('vendor_apex');
  const [inviteCanOverride, setInviteCanOverride] = useState(true);
  const [inviteError, setInviteError] = useState<string | null>(null);

  // Edit Invitation Modal State
  const [editingInvitation, setEditingInvitation] = useState<UserInvitation | null>(null);
  const [editInvRole, setEditInvRole] = useState<'VENDOR' | 'ACCOUNTS_EXECUTIVE' | 'ADMIN'>('ACCOUNTS_EXECUTIVE');
  const [editInvVendorId, setEditInvVendorId] = useState<string>('vendor_apex');
  const [editInvCanOverride, setEditInvCanOverride] = useState<boolean>(false);
  const [editInvError, setEditInvError] = useState<string | null>(null);

  // Delete Invitation Confirmation Modal State
  const [invitationToDelete, setInvitationToDelete] = useState<UserInvitation | null>(null);
  const [selectedInvitationIds, setSelectedInvitationIds] = useState<string[]>([]);
  const [showBulkDeleteInvModal, setShowBulkDeleteInvModal] = useState(false);
  const [invActionMessage, setInvActionMessage] = useState<string | null>(null);

  // User Selection & Deletion State
  const [selectedUserUids, setSelectedUserUids] = useState<string[]>([]);
  const [userToDelete, setUserToDelete] = useState<UserProfile | null>(null);
  const [deleteUserConfirmEmail, setDeleteUserConfirmEmail] = useState('');
  const [deleteUserReason, setDeleteUserReason] = useState('');
  const [deleteUserError, setDeleteUserError] = useState<string | null>(null);
  const [showBulkDeleteUserModal, setShowBulkDeleteUserModal] = useState(false);
  const [bulkDeleteUserConfirmText, setBulkDeleteUserConfirmText] = useState('');
  const [bulkDeleteUserReason, setBulkDeleteUserReason] = useState('');
  const [bulkDeleteUserError, setBulkDeleteUserError] = useState<string | null>(null);

  // Access Diagnostic & Repair Drawer State
  const [repairUser, setRepairUser] = useState<UserProfile | null>(null);
  const [repairDiagnostics, setRepairDiagnostics] = useState<any | null>(null);
  const [isCheckingAccess, setIsCheckingAccess] = useState(false);
  const [isResyncingAccess, setIsResyncingAccess] = useState(false);
  const [repairActionMessage, setRepairActionMessage] = useState<string | null>(null);

  // Duplicate Resolution Modal State
  const [duplicateModalUser, setDuplicateModalUser] = useState<UserProfile | null>(null);
  const [duplicateKeepUid, setDuplicateKeepUid] = useState<string>('');
  const [duplicateActionMessage, setDuplicateActionMessage] = useState<string | null>(null);

  // Vendor Management State
  const [includeArchivedVendors, setIncludeArchivedVendors] = useState(false);
  const [selectedVendorIds, setSelectedVendorIds] = useState<string[]>([]);
  const [vendorToDelete, setVendorToDelete] = useState<VendorMaster | null>(null);
  const [vendorEligibility, setVendorEligibility] = useState<{
    canDeletePermanently: boolean;
    invoiceCount: number;
    queryCount: number;
    reason: string;
  } | null>(null);
  const [vendorDeleteConfirmName, setVendorDeleteConfirmName] = useState('');
  const [vendorDeleteReason, setVendorDeleteReason] = useState('');
  const [vendorModalError, setVendorModalError] = useState<string | null>(null);
  const [isCheckingEligibility, setIsCheckingEligibility] = useState(false);
  const [vendorActionMessage, setVendorActionMessage] = useState<string | null>(null);

  // Settings State
  const [legalName, setLegalName] = useState(companySettings.legalName);
  const [gstin, setGstin] = useState(companySettings.gstin);
  const [address, setAddress] = useState(companySettings.address);
  const [allowedDomains, setAllowedDomains] = useState(companySettings.allowedInternalDomains || 'bharattech.in,company.com');
  const [sessionTimeout, setSessionTimeout] = useState(companySettings.sessionTimeoutMinutes || 30);
  const [modelName, setModelName] = useState(companySettings.defaultModelName || 'gemini-3.8-flash');
  const [threshold, setThreshold] = useState(companySettings.ocrConfidenceThreshold || 0.85);
  const [tolerance, setTolerance] = useState(companySettings.decimalTolerance || 1.00);
  const [slaHours, setSlaHours] = useState(companySettings.querySlaHours || 48);
  const [tdsGlLedgers, setTdsGlLedgers] = useState<Record<string, string>>(
    companySettings.tdsGlLedgers || DEFAULT_TDS_GL_LEDGERS
  );

  const [userSearch, setUserSearch] = useState('');
  const [auditSearch, setAuditSearch] = useState('');

  // Gemini API Key Settings State
  const [geminiApiKeyInput, setGeminiApiKeyInput] = useState('');
  const [showGeminiKey, setShowGeminiKey] = useState(false);
  const [geminiConfig, setGeminiConfig] = useState<{
    configured: boolean;
    source: 'CUSTOM' | 'ENV' | 'NONE';
    maskedKey: string;
    hasCustomKey: boolean;
    defaultModelName: string;
  } | null>(null);
  const [isTestingGeminiKey, setIsTestingGeminiKey] = useState(false);
  const [isSavingGeminiKey, setIsSavingGeminiKey] = useState(false);
  const [geminiKeyFeedback, setGeminiKeyFeedback] = useState<{ type: 'SUCCESS' | 'ERROR'; message: string } | null>(null);

  // Real-Time GSTIN Verification (gstin.cloud) API Key State
  const [gstinApiKeyInput, setGstinApiKeyInput] = useState('');
  const [showGstinKey, setShowGstinKey] = useState(false);
  const [gstinConfig, setGstinConfig] = useState<{
    configured: boolean;
    source: 'CUSTOM' | 'ENV' | 'NONE';
    maskedKey: string;
    hasCustomKey: boolean;
  } | null>(null);
  const [isTestingGstinKey, setIsTestingGstinKey] = useState(false);
  const [isSavingGstinKey, setIsSavingGstinKey] = useState(false);
  const [gstinKeyFeedback, setGstinKeyFeedback] = useState<{ type: 'SUCCESS' | 'ERROR'; message: string } | null>(null);

  const fetchGeminiConfig = async () => {
    try {
      const res = await fetch('/api/admin/gemini-config');
      if (res.ok) {
        const data = await res.json();
        setGeminiConfig(data);
      }
    } catch (e) {
      console.warn('Failed to fetch Gemini config:', e);
    }
  };

  const fetchGstinConfig = async () => {
    try {
      const res = await fetch('/api/admin/gstin-config');
      if (res.ok) {
        const data = await res.json();
        setGstinConfig(data);
      }
    } catch (e) {
      console.warn('Failed to fetch GSTIN config:', e);
    }
  };

  React.useEffect(() => {
    fetchGeminiConfig();
    fetchGstinConfig();
  }, []);

  const handleTestGeminiKey = async () => {
    setIsTestingGeminiKey(true);
    setGeminiKeyFeedback(null);
    try {
      const res = await fetch('/api/admin/gemini-test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          geminiApiKey: geminiApiKeyInput.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setGeminiKeyFeedback({
          type: 'SUCCESS',
          message: data.message || 'Gemini API key verified successfully! Multi-modal OCR is active.',
        });
      } else {
        setGeminiKeyFeedback({
          type: 'ERROR',
          message: data.error || 'Failed to verify Gemini API key. Please check the key.',
        });
      }
    } catch (err: any) {
      setGeminiKeyFeedback({
        type: 'ERROR',
        message: err.message || 'Network error while testing Gemini API key.',
      });
    } finally {
      setIsTestingGeminiKey(false);
    }
  };

  const handleSaveGeminiKey = async () => {
    if (!geminiApiKeyInput.trim()) {
      setGeminiKeyFeedback({
        type: 'ERROR',
        message: 'Please enter a valid Gemini API key to save.',
      });
      return;
    }
    setIsSavingGeminiKey(true);
    setGeminiKeyFeedback(null);
    try {
      const res = await fetch('/api/admin/gemini-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          geminiApiKey: geminiApiKeyInput.trim(),
          adminUid: currentUser?.uid,
          userEmail: currentUser?.email,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setGeminiKeyFeedback({
          type: 'SUCCESS',
          message: 'Gemini API key saved and activated successfully for invoice scanning.',
        });
        setGeminiApiKeyInput('');
        await fetchGeminiConfig();
      } else {
        setGeminiKeyFeedback({
          type: 'ERROR',
          message: data.error || 'Failed to save Gemini API key.',
        });
      }
    } catch (err: any) {
      setGeminiKeyFeedback({
        type: 'ERROR',
        message: err.message || 'Error saving Gemini API key.',
      });
    } finally {
      setIsSavingGeminiKey(false);
    }
  };

  const handleRemoveCustomGeminiKey = async () => {
    setGeminiKeyFeedback(null);
    try {
      const res = await fetch('/api/admin/gemini-key/remove', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          adminUid: currentUser?.uid,
          userEmail: currentUser?.email,
        }),
      });
      if (res.ok) {
        setGeminiKeyFeedback({
          type: 'SUCCESS',
          message: 'Custom Gemini key removed. Falling back to server environment variables if available.',
        });
        setGeminiApiKeyInput('');
        await fetchGeminiConfig();
      }
    } catch (err: any) {
      setGeminiKeyFeedback({
        type: 'ERROR',
        message: err.message || 'Failed to remove custom key.',
      });
    }
  };

  const handleTestGstinKey = async () => {
    setIsTestingGstinKey(true);
    setGstinKeyFeedback(null);
    try {
      const res = await fetch('/api/admin/gstin-test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiKey: gstinApiKeyInput.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setGstinKeyFeedback({
          type: 'SUCCESS',
          message: data.message || 'gstin.cloud API Key verified successfully! Real-time GSTIN validation is active.',
        });
      } else {
        setGstinKeyFeedback({
          type: 'ERROR',
          message: data.message || data.error || 'Failed to verify gstin.cloud API Key. Please verify and try again.',
        });
      }
    } catch (err: any) {
      setGstinKeyFeedback({
        type: 'ERROR',
        message: err.message || 'Network error while testing gstin.cloud API Key.',
      });
    } finally {
      setIsTestingGstinKey(false);
    }
  };

  const handleSaveGstinKey = async () => {
    if (!gstinApiKeyInput.trim()) {
      setGstinKeyFeedback({
        type: 'ERROR',
        message: 'Please enter a valid gstin.cloud x-api-key to save.',
      });
      return;
    }
    setIsSavingGstinKey(true);
    setGstinKeyFeedback(null);
    try {
      const res = await fetch('/api/admin/gstin-key', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          apiKey: gstinApiKeyInput.trim(),
          adminUid: currentUser?.uid,
          userEmail: currentUser?.email,
        }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setGstinKeyFeedback({
          type: 'SUCCESS',
          message: 'gstin.cloud x-api-key saved and activated successfully for real-time GSTIN verification.',
        });
        setGstinApiKeyInput('');
        setGstinConfig({
          configured: true,
          source: 'CUSTOM',
          maskedKey: data.maskedKey || '••••••••',
          hasCustomKey: true,
        });
        await fetchGstinConfig();
      } else {
        setGstinKeyFeedback({
          type: 'ERROR',
          message: data.message || data.error || 'Failed to save gstin.cloud API key.',
        });
      }
    } catch (err: any) {
      setGstinKeyFeedback({
        type: 'ERROR',
        message: err.message || 'Error saving gstin.cloud API key.',
      });
    } finally {
      setIsSavingGstinKey(false);
    }
  };

  const handleRemoveCustomGstinKey = async () => {
    setGstinKeyFeedback(null);
    try {
      const res = await fetch('/api/admin/gstin-key/remove', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          adminUid: currentUser?.uid,
          userEmail: currentUser?.email,
        }),
      });
      if (res.ok) {
        setGstinKeyFeedback({
          type: 'SUCCESS',
          message: 'Custom gstin.cloud key removed. Falling back to server environment variables if available.',
        });
        setGstinApiKeyInput('');
        await fetchGstinConfig();
      }
    } catch (err: any) {
      setGstinKeyFeedback({
        type: 'ERROR',
        message: err.message || 'Failed to remove custom key.',
      });
    }
  };

  // Active Vendors list (excluding archived for dropdown bindings)
  const activeVendorsList = vendors.filter((v) => v.status !== 'ARCHIVED');

  // Handle User Edit Submit
  const handleSaveUserAssignment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;
    setEditError(null);

    try {
      await assignUserRole(
        editingUser.uid,
        editRole,
        editRole === 'VENDOR' ? editVendorId : undefined,
        editCanOverride,
        editStatus
      );
      setEditingUser(null);
    } catch (err: any) {
      setEditError(err.message || 'Failed to update user role');
    }
  };

  // Handle Invitation Submit
  const handleSendInvite = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteEmail) return;
    setInviteError(null);

    try {
      await createInvitation(
        inviteEmail.trim().toLowerCase(),
        inviteRole,
        inviteRole === 'VENDOR' ? inviteVendorId : undefined,
        inviteRole === 'ACCOUNTS_EXECUTIVE' ? inviteCanOverride : undefined
      );
      setShowInviteModal(false);
      setInviteEmail('');
      setInvActionMessage(`Pre-registered invitation created for ${inviteEmail.trim().toLowerCase()}`);
      setTimeout(() => setInvActionMessage(null), 4000);
    } catch (err: any) {
      setInviteError(err.message || 'Failed to create invitation');
    }
  };

  // Handle Edit Invitation Submit
  const handleSaveEditedInvitation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingInvitation) return;
    setEditInvError(null);

    try {
      await editInvitation(
        editingInvitation.id,
        editInvRole,
        editInvRole === 'VENDOR' ? editInvVendorId : undefined,
        editInvRole === 'ACCOUNTS_EXECUTIVE' ? editInvCanOverride : undefined
      );
      setEditingInvitation(null);
      setInvActionMessage(`Invitation updated for ${editingInvitation.email}`);
      setTimeout(() => setInvActionMessage(null), 4000);
    } catch (err: any) {
      setEditInvError(err.message || 'Failed to update invitation');
    }
  };

  // Handle Resend Invitation
  const handleResend = async (inv: UserInvitation) => {
    try {
      await resendInvitation(inv.id);
      setInvActionMessage(`Invitation resent to ${inv.email}`);
      setTimeout(() => setInvActionMessage(null), 4000);
    } catch (err: any) {
      alert(`Error resending: ${err.message}`);
    }
  };

  // Handle Delete Single Invitation
  const handleConfirmDeleteInvitation = async () => {
    if (!invitationToDelete) return;
    try {
      await deleteInvitation(invitationToDelete.id);
      setInvActionMessage(`Invitation for ${invitationToDelete.email} has been revoked and deleted.`);
      setInvitationToDelete(null);
      setTimeout(() => setInvActionMessage(null), 4000);
    } catch (err: any) {
      alert(`Error revoking invitation: ${err.message}`);
    }
  };

  // Handle Bulk Delete Invitations
  const handleConfirmBulkDeleteInvitations = async () => {
    if (selectedInvitationIds.length === 0) return;
    try {
      await bulkDeleteInvitations(selectedInvitationIds);
      setInvActionMessage(`Bulk deleted ${selectedInvitationIds.length} pending invitation(s).`);
      setSelectedInvitationIds([]);
      setShowBulkDeleteInvModal(false);
      setTimeout(() => setInvActionMessage(null), 4000);
    } catch (err: any) {
      alert(`Error in bulk delete: ${err.message}`);
    }
  };

  // Helper for canonical email matching
  const getCanonicalEmail = (email: string) => {
    const raw = String(email || '').trim().toLowerCase();
    const parts = raw.split('@');
    if (parts.length !== 2) return raw;
    let [user, domain] = parts;
    if (domain === 'gmail.com' || domain === 'googlemail.com') {
      user = user.replace(/\./g, '');
      domain = 'gmail.com';
    }
    return `${user}@${domain}`;
  };

  const canonicalEmailMap = useMemo(() => {
    const map = new Map<string, UserProfile[]>();
    for (const u of allUsers) {
      if (u.isArchived) continue;
      const canon = getCanonicalEmail(u.email);
      if (!map.has(canon)) map.set(canon, []);
      map.get(canon)!.push(u);
    }
    return map;
  }, [allUsers]);

  // Handle Direct Reactivate
  const handleDirectReactivate = async (u: UserProfile) => {
    try {
      await activateUser(u.uid);
      setInvActionMessage(`User ${u.email} has been successfully reactivated. Firebase Auth enabled and access restored.`);
      setTimeout(() => setInvActionMessage(null), 5000);
    } catch (err: any) {
      alert(`Failed to reactivate: ${err.message}`);
    }
  };

  // Handle Direct Deactivate
  const handleDirectDeactivate = async (u: UserProfile) => {
    const reason = prompt(`Enter deactivation reason for ${u.email}:`, 'Deactivated by Administrator');
    if (reason === null) return;
    try {
      await deactivateUser(u.uid, reason || 'Deactivated by Admin');
      setInvActionMessage(`User ${u.email} deactivated. Tokens revoked.`);
      setTimeout(() => setInvActionMessage(null), 5000);
    } catch (err: any) {
      alert(`Failed to deactivate: ${err.message}`);
    }
  };

  // Handle Open Check and Repair Access Modal
  const handleOpenRepairModal = async (u: UserProfile) => {
    setRepairUser(u);
    setRepairDiagnostics(null);
    setRepairActionMessage(null);
    setIsCheckingAccess(true);
    try {
      const data = await checkUserAccess(u.uid);
      setRepairDiagnostics(data);
    } catch (err: any) {
      alert(`Failed to inspect user access: ${err.message}`);
    } finally {
      setIsCheckingAccess(false);
    }
  };

  // Handle Resync User Access
  const handleResyncAccess = async () => {
    if (!repairUser) return;
    setIsResyncingAccess(true);
    setRepairActionMessage(null);
    try {
      await resyncUserAccess(repairUser.uid);
      const data = await checkUserAccess(repairUser.uid);
      setRepairDiagnostics(data);
      setRepairActionMessage(`Access resynced successfully! Firebase Auth and claims now strictly mirror profile status.`);
    } catch (err: any) {
      alert(`Failed to resync access: ${err.message}`);
    } finally {
      setIsResyncingAccess(false);
    }
  };

  // Handle Single Delete User Confirmation
  const handleOpenDeleteUserModal = (u: UserProfile) => {
    setUserToDelete(u);
    setDeleteUserConfirmEmail('');
    setDeleteUserReason('');
    setDeleteUserError(null);
  };

  const handleExecuteDeleteUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userToDelete) return;
    setDeleteUserError(null);
    try {
      await deleteUser(userToDelete.uid, deleteUserConfirmEmail, deleteUserReason);
      setInvActionMessage(`User ${userToDelete.email} permanently deleted. All past audit records and invoices remain intact.`);
      setUserToDelete(null);
      setTimeout(() => setInvActionMessage(null), 5000);
    } catch (err: any) {
      setDeleteUserError(err.message || 'Failed to delete user');
    }
  };

  // Handle Bulk Delete Users Confirmation
  const handleExecuteBulkDeleteUsers = async (e: React.FormEvent) => {
    e.preventDefault();
    setBulkDeleteUserError(null);
    try {
      await bulkDeleteUsers(selectedUserUids, bulkDeleteUserConfirmText, bulkDeleteUserReason);
      setInvActionMessage(`Bulk deleted ${selectedUserUids.length} user(s). Historical audit trail preserved.`);
      setSelectedUserUids([]);
      setShowBulkDeleteUserModal(false);
      setTimeout(() => setInvActionMessage(null), 5000);
    } catch (err: any) {
      setBulkDeleteUserError(err.message || 'Failed to bulk delete users');
    }
  };

  // Handle Resolve Duplicate
  const handleOpenDuplicateModal = (u: UserProfile) => {
    setDuplicateModalUser(u);
    setDuplicateKeepUid(u.uid);
    setDuplicateActionMessage(null);
  };

  const handleExecuteResolveDuplicate = async () => {
    if (!duplicateModalUser || !duplicateKeepUid) return;
    const canon = getCanonicalEmail(duplicateModalUser.email);
    try {
      await resolveDuplicateUsers(canon, duplicateKeepUid);
      setInvActionMessage(`Duplicates resolved for ${canon}. Kept primary profile and merged legacy records.`);
      setDuplicateModalUser(null);
      setTimeout(() => setInvActionMessage(null), 5000);
    } catch (err: any) {
      alert(`Failed to resolve duplicate: ${err.message}`);
    }
  };

  // Open Vendor Delete Modal & Check Eligibility
  const handleOpenVendorDeleteModal = async (v: VendorMaster) => {
    setVendorToDelete(v);
    setVendorEligibility(null);
    setVendorDeleteConfirmName(v.legalName || v.gstin || '');
    setVendorDeleteReason('Test / blank vendor created in error; no transactions occurred.');
    setVendorModalError(null);
    setIsCheckingEligibility(true);

    try {
      const eligibility = await checkVendorDeleteEligibility(v.id);
      setVendorEligibility(eligibility);
    } catch (err: any) {
      setVendorModalError(err.message || 'Failed to verify vendor history.');
    } finally {
      setIsCheckingEligibility(false);
    }
  };

  // Execute Permanent Vendor Delete (Rule A)
  const handleExecutePermanentDelete = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!vendorToDelete) return;
    setVendorModalError(null);

    try {
      await deleteVendorPermanent(vendorToDelete.id, vendorDeleteConfirmName, vendorDeleteReason);
      setVendorActionMessage(`Vendor "${vendorToDelete.legalName}" permanently deleted. Pending invites revoked and users deactivated.`);
      setVendorToDelete(null);
      setTimeout(() => setVendorActionMessage(null), 4000);
    } catch (err: any) {
      setVendorModalError(err.message || 'Failed to permanently delete vendor');
    }
  };

  // Execute Archive Vendor (Rule B)
  const handleExecuteArchive = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!vendorToDelete) return;
    setVendorModalError(null);

    try {
      await archiveVendor(vendorToDelete.id, vendorDeleteReason);
      setVendorActionMessage(`Vendor "${vendorToDelete.legalName}" archived. Users deactivated; GST audit trail intact.`);
      setVendorToDelete(null);
      setTimeout(() => setVendorActionMessage(null), 4000);
    } catch (err: any) {
      setVendorModalError(err.message || 'Failed to archive vendor');
    }
  };

  // Restore Archived Vendor
  const handleRestoreVendor = async (v: VendorMaster) => {
    try {
      await restoreVendor(v.id, 'Administrator restored vendor to active master');
      setVendorActionMessage(`Vendor "${v.legalName}" restored to ACTIVE master.`);
      setTimeout(() => setVendorActionMessage(null), 4000);
    } catch (err: any) {
      alert(`Failed to restore vendor: ${err.message}`);
    }
  };

  // Handle Settings Submit
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    await updateCompanySettings({
      legalName,
      gstin: gstin.toUpperCase(),
      address,
      allowedInternalDomains: allowedDomains,
      sessionTimeoutMinutes: sessionTimeout,
      defaultModelName: modelName,
      ocrConfidenceThreshold: threshold,
      decimalTolerance: tolerance,
      querySlaHours: slaHours,
      tdsGlLedgers,
    });
    alert('System settings and TDS General Ledger masters saved successfully.');
  };

  const deduplicatedInvitations: UserInvitation[] = useMemo(() => {
    const map = new Map<string, UserInvitation>();
    for (const inv of invitations) {
      const key = (inv.id || inv.email || '').trim().toLowerCase();
      if (!key) continue;
      if (!map.has(key)) {
        map.set(key, inv);
      } else {
        const existing = map.get(key)!;
        const invTime = new Date(inv.createdAt || inv.invitedAt || 0).getTime();
        const existingTime = new Date(existing.createdAt || existing.invitedAt || 0).getTime();
        if (inv.status === 'PENDING' && existing.status !== 'PENDING') {
          map.set(key, inv);
        } else if (invTime >= existingTime) {
          map.set(key, inv);
        }
      }
    }
    return Array.from(map.values());
  }, [invitations]);

  const filteredUsers: UserProfile[] = useMemo(() => {
    const seen = new Set<string>();
    return allUsers.filter((u: UserProfile) => {
      const key = (u.uid || u.email || '').trim().toLowerCase();
      if (seen.has(key)) return false;
      seen.add(key);
      if (!userSearch) return true;
      const q = userSearch.toLowerCase();
      return u.email.toLowerCase().includes(q) || Boolean(u.displayName?.toLowerCase().includes(q)) || u.role.toLowerCase().includes(q);
    });
  }, [allUsers, userSearch]);

  const displayedVendors = vendors.filter((v) => {
    if (includeArchivedVendors) return true;
    return v.status !== 'ARCHIVED';
  });

  const filteredAudit = auditLogs.filter((log) => {
    if (!auditSearch) return true;
    const q = auditSearch.toLowerCase();
    return (
      log.invoiceId?.toLowerCase().includes(q) ||
      log.action.toLowerCase().includes(q) ||
      log.userEmail.toLowerCase().includes(q) ||
      log.remarks.toLowerCase().includes(q)
    );
  });

  return (
    <div className="space-y-6">
      
      {/* Header */}
      <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-6 shadow-sm flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <div className="p-2.5 bg-[#EBF1FA] text-[#1F4E9C] rounded-[4px]">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-[#0B2545] tracking-tight">System Administration</h2>
            <p className="text-xs text-[#52606D]">
              Role assignment, pre-registered invitations, vendor master approvals, and statutory audit trail.
            </p>
          </div>
        </div>

        <div className="flex items-center space-x-2.5">
          <button
            onClick={() => setShowAddVendorModal(true)}
            className="flex items-center space-x-1.5 px-4 py-2 bg-[#0B2545] hover:bg-[#1F4E9C] text-white rounded-[6px] text-xs font-semibold transition shadow-sm"
          >
            <Building2 className="w-4 h-4" />
            <span>Add New Vendor</span>
          </button>

          <button
            onClick={() => setShowInviteModal(true)}
            className="flex items-center space-x-1.5 px-4 py-2 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[6px] text-xs font-medium transition shadow-sm"
          >
            <UserPlus className="w-4 h-4" />
            <span>Pre-Register User</span>
          </button>
        </div>
      </div>

      {/* Action Notification Banner */}
      {(invActionMessage || vendorActionMessage) && (
        <div className="p-3 bg-[#EDF7ED] border border-[#C8E6C9] rounded-[6px] text-xs text-[#1B7F3B] flex items-center justify-between shadow-sm">
          <div className="flex items-center space-x-2">
            <CheckCircle2 className="w-4 h-4 shrink-0" />
            <span>{invActionMessage || vendorActionMessage}</span>
          </div>
          <button
            onClick={() => {
              setInvActionMessage(null);
              setVendorActionMessage(null);
            }}
            className="text-[#1B7F3B] hover:text-[#0B2545] font-semibold text-xs ml-4"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Tabs */}
      <div className="flex space-x-2 border-b border-[#D9E2EC] pb-2 text-xs font-semibold overflow-x-auto">
        <button
          onClick={() => setActiveTab('USERS')}
          className={`px-4 py-2 rounded-[6px] transition ${
            activeTab === 'USERS' ? 'bg-[#1F4E9C] text-white' : 'text-[#52606D] hover:text-[#0B2545] hover:bg-[#EBF1FA]'
          }`}
        >
          User Management ({allUsers.length})
        </button>
        <button
          onClick={() => setActiveTab('VENDORS')}
          className={`px-4 py-2 rounded-[6px] transition ${
            activeTab === 'VENDORS' ? 'bg-[#1F4E9C] text-white' : 'text-[#52606D] hover:text-[#0B2545] hover:bg-[#EBF1FA]'
          }`}
        >
          Vendor Management ({displayedVendors.length})
        </button>
        <button
          onClick={() => setActiveTab('SETTINGS')}
          className={`px-4 py-2 rounded-[6px] transition ${
            activeTab === 'SETTINGS' ? 'bg-[#1F4E9C] text-white' : 'text-[#52606D] hover:text-[#0B2545] hover:bg-[#EBF1FA]'
          }`}
        >
          Allowed Domains & System Settings
        </button>
        <button
          onClick={() => setActiveTab('HSN')}
          className={`px-4 py-2 rounded-[6px] transition ${
            activeTab === 'HSN' ? 'bg-[#1F4E9C] text-white' : 'text-[#52606D] hover:text-[#0B2545] hover:bg-[#EBF1FA]'
          }`}
        >
          HSN / SAC Master
        </button>
        <button
          onClick={() => setActiveTab('AUDIT')}
          className={`px-4 py-2 rounded-[6px] transition ${
            activeTab === 'AUDIT' ? 'bg-[#1F4E9C] text-white' : 'text-[#52606D] hover:text-[#0B2545] hover:bg-[#EBF1FA]'
          }`}
        >
          Audit Log ({auditLogs.length})
        </button>
      </div>

      {/* TAB 1: User Management & Pending Invitations */}
      {activeTab === 'USERS' && (
        <div className="space-y-6">
          
          {/* Section 1A: Application Users Table */}
          <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-5 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-[#0B2545]">Application Users & Role Assignments</h3>
                <p className="text-xs text-[#52606D]">
                  Authoritative status governed by user profile. Roles and access permissions enforced server-side.
                </p>
              </div>

              <div className="flex items-center space-x-2 w-full sm:w-auto">
                {selectedUserUids.length > 0 && (
                  <button
                    onClick={() => {
                      setBulkDeleteUserConfirmText('');
                      setBulkDeleteUserReason('');
                      setBulkDeleteUserError(null);
                      setShowBulkDeleteUserModal(true);
                    }}
                    className="flex items-center space-x-1 px-3 py-1.5 bg-[#B42318] hover:bg-[#8F1A12] text-white text-xs rounded-[4px] font-medium transition shrink-0 shadow-sm"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete Selected ({selectedUserUids.length})</span>
                  </button>
                )}

                <div className="relative w-full sm:w-72">
                  <Search className="w-4 h-4 text-[#52606D] absolute left-3 top-2.5" />
                  <input
                    type="text"
                    value={userSearch}
                    onChange={(e) => setUserSearch(e.target.value)}
                    placeholder="Search user email or role..."
                    className="w-full pl-9 pr-3 py-1.5 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                  />
                </div>
              </div>
            </div>

            <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
              <table className="w-full text-left text-xs font-sans">
                <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545]">
                  <tr className="uppercase tracking-wider text-[11px] font-semibold">
                    <th className="py-2.5 px-3 w-10">
                      <input
                        type="checkbox"
                        checked={
                          filteredUsers.length > 0 &&
                          selectedUserUids.length === filteredUsers.filter((u) => u.uid !== currentUser?.uid).length
                        }
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedUserUids(
                              filteredUsers.filter((u) => u.uid !== currentUser?.uid).map((u) => u.uid)
                            );
                          } else {
                            setSelectedUserUids([]);
                          }
                        }}
                        className="rounded border-[#D9E2EC] text-[#1F4E9C]"
                        title="Select all eligible users"
                      />
                    </th>
                    <th className="py-2.5 px-3">User Email</th>
                    <th className="py-2.5 px-3">Display Name</th>
                    <th className="py-2.5 px-3">Assigned Role</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3">Status Reason</th>
                    <th className="py-2.5 px-3">Last Sign-In</th>
                    <th className="py-2.5 px-3">Vendor Association</th>
                    <th className="py-2.5 px-3">Override Permission</th>
                    <th className="py-2.5 px-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#D9E2EC] font-mono">
                  {filteredUsers.map((u: UserProfile) => {
                    const linkedVendor = vendors.find((v) => v.id === u.vendorId);
                    const canon = getCanonicalEmail(u.email);
                    const duplicateMatches = (canonicalEmailMap.get(canon) || []).filter(
                      (item) => item.uid !== u.uid
                    );
                    const hasDuplicate = duplicateMatches.length > 0 || Boolean(u.isDuplicateConflict);

                    const statusReasonText =
                      u.deactivatedReason ||
                      u.statusReason ||
                      (u.status === 'PENDING_APPROVAL'
                        ? 'Pending Approval'
                        : u.status === 'DEACTIVATED'
                        ? 'Deactivated'
                        : '-');

                    const lastLoginText = u.lastLoginAt
                      ? new Date(u.lastLoginAt).toLocaleString('en-IN', {
                          dateStyle: 'short',
                          timeStyle: 'short',
                        })
                      : 'Never';

                    return (
                      <tr key={u.uid} className="even:bg-[#F5F7FA] hover:bg-[#EBF1FA]/40 transition">
                        <td className="py-3 px-3">
                          <input
                            type="checkbox"
                            checked={selectedUserUids.includes(u.uid)}
                            disabled={currentUser?.uid === u.uid}
                            onChange={(e) => {
                              if (e.target.checked) {
                                setSelectedUserUids((prev) => [...prev, u.uid]);
                              } else {
                                setSelectedUserUids((prev) => prev.filter((id) => id !== u.uid));
                              }
                            }}
                            className="rounded border-[#D9E2EC] text-[#1F4E9C] disabled:opacity-30"
                          />
                        </td>

                        <td className="py-3 px-3 font-bold text-[#0B2545] font-sans">
                          <div className="flex items-center space-x-1.5">
                            <span>{u.email}</span>
                            {hasDuplicate && (
                              <span
                                className="px-1.5 py-0.2 bg-[#F5F0FF] text-[#6929C4] border border-[#D0BFFF] rounded text-[9px] font-semibold"
                                title="Duplicate profile detected (dot variant or legacy UID)"
                              >
                                Dual ID
                              </span>
                            )}
                          </div>
                          <div className="text-[10px] text-[#52606D] font-mono">
                            UID: {u.uid.slice(0, 12)}...
                          </div>
                        </td>

                        <td className="py-3 px-3 font-sans text-[#1F2933]">
                          {u.displayName || '-'}
                        </td>

                        <td className="py-3 px-3 font-sans">
                          <span
                            className={`px-2 py-0.5 rounded-[4px] text-[10px] font-bold ${
                              u.role === 'ADMIN'
                                ? 'badge-info font-bold'
                                : u.role === 'ACCOUNTS_EXECUTIVE'
                                ? 'badge-info'
                                : u.role === 'VENDOR'
                                ? 'bg-[#EBF1FA] text-[#1F4E9C] border border-[#D9E2EC]'
                                : 'badge-warn'
                            }`}
                          >
                            {u.role.replace(/_/g, ' ')}
                          </span>
                        </td>

                        <td className="py-3 px-3 font-sans">
                          <span
                            className={`px-2 py-0.5 rounded-[4px] text-[10px] font-semibold ${
                              u.status === 'ACTIVE'
                                ? 'badge-pass'
                                : u.status === 'PENDING_APPROVAL'
                                ? 'badge-warn'
                                : 'badge-fail'
                            }`}
                          >
                            {u.status.replace(/_/g, ' ')}
                          </span>
                        </td>

                        <td className="py-3 px-3 font-sans text-xs text-[#52606D]">
                          <span
                            className={
                              u.status === 'DEACTIVATED'
                                ? 'text-[#B42318] font-medium'
                                : u.status === 'PENDING_APPROVAL'
                                ? 'text-[#B26A00]'
                                : 'text-[#52606D]'
                            }
                          >
                            {statusReasonText}
                          </span>
                        </td>

                        <td className="py-3 px-3 font-sans text-xs text-[#52606D] whitespace-nowrap">
                          {lastLoginText}
                        </td>

                        <td className="py-3 px-3 font-sans text-[#1F2933]">
                          {u.role === 'VENDOR' ? (
                            linkedVendor ? (
                              <span className="font-medium text-[#0B2545]">{linkedVendor.legalName}</span>
                            ) : (
                              <span className="text-[#B26A00]">Unlinked Vendor</span>
                            )
                          ) : (
                            <span className="text-[#52606D]">Internal Staff</span>
                          )}
                        </td>

                        <td className="py-3 px-3 font-sans">
                          {u.canOverride ? (
                            <span className="text-[#1B7F3B] font-semibold flex items-center space-x-1">
                              <Unlock className="w-3 h-3" />
                              <span>Granted</span>
                            </span>
                          ) : (
                            <span className="text-[#52606D]">No</span>
                          )}
                        </td>

                        <td className="py-3 px-3 text-right font-sans">
                          <div className="flex items-center justify-end space-x-1.5 flex-wrap gap-y-1">
                            {/* Direct Reactivate button for deactivated users */}
                            {u.status === 'DEACTIVATED' && (
                              <button
                                onClick={() => handleDirectReactivate(u)}
                                className="px-2 py-1 bg-[#1B7F3B] hover:bg-[#14632E] text-white rounded-[4px] text-xs font-medium transition flex items-center space-x-1 shadow-sm"
                                title="Reactivate user immediately"
                              >
                                <UserCheck className="w-3.5 h-3.5" />
                                <span>Reactivate</span>
                              </button>
                            )}

                            {/* Check and Repair Access button */}
                            <button
                              onClick={() => handleOpenRepairModal(u)}
                              className="px-2 py-1 bg-white hover:bg-[#EBF1FA] text-[#1F4E9C] border border-[#D9E2EC] rounded-[4px] text-xs font-medium transition flex items-center space-x-1"
                              title="Check & Repair access diagnostics"
                            >
                              <Wrench className="w-3 h-3" />
                              <span>Repair</span>
                            </button>

                            {/* Resolve duplicate if conflict or multiple accounts exist */}
                            {hasDuplicate && (
                              <button
                                onClick={() => handleOpenDuplicateModal(u)}
                                className="px-2 py-1 bg-[#F5F0FF] hover:bg-[#ECE2FE] text-[#6929C4] border border-[#D0BFFF] rounded-[4px] text-xs font-medium transition flex items-center space-x-1"
                                title="Resolve conflicting duplicate profiles"
                              >
                                <GitMerge className="w-3 h-3" />
                                <span>Merge</span>
                              </button>
                            )}

                            <button
                              onClick={() => {
                                setEditingUser(u);
                                setEditRole(u.role);
                                setEditStatus(u.status);
                                setEditVendorId(u.vendorId || vendors[0]?.id || '');
                                setEditCanOverride(Boolean(u.canOverride));
                                setEditError(null);
                              }}
                              className="px-2 py-1 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[4px] text-xs font-medium transition"
                            >
                              Edit
                            </button>

                            {u.status === 'ACTIVE' && (
                              <button
                                onClick={() => handleDirectDeactivate(u)}
                                className="p-1 text-[#52606D] hover:text-[#B42318] transition"
                                title="Deactivate user"
                              >
                                <UserX className="w-3.5 h-3.5" />
                              </button>
                            )}

                            <button
                              onClick={() => handleOpenDeleteUserModal(u)}
                              disabled={currentUser?.uid === u.uid}
                              className="p-1 text-[#52606D] hover:text-[#B42318] transition disabled:opacity-20"
                              title={
                                currentUser?.uid === u.uid
                                  ? 'Cannot delete your own account'
                                  : 'Permanently delete user'
                              }
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 1B: Pre-Registered Invitations Table (Required by Part 3) */}
          <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-5 shadow-sm space-y-4">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-bold text-[#0B2545]">
                  Pending Invitations ({deduplicatedInvitations.length})
                </h3>
                <p className="text-xs text-[#52606D]">
                  Pre-registered emails are onboarded automatically upon Google sign-in. Pending invitations can be edited, resent, or revoked.
                </p>
              </div>

              {selectedInvitationIds.length > 0 && (
                <button
                  onClick={() => setShowBulkDeleteInvModal(true)}
                  className="flex items-center space-x-1 px-3 py-1.5 bg-[#B42318] hover:bg-[#8F1A12] text-white text-xs rounded-[4px] font-medium transition"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Delete Selected ({selectedInvitationIds.length})</span>
                </button>
              )}
            </div>

            <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
              <table className="w-full text-left text-xs font-sans">
                <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545]">
                  <tr className="uppercase tracking-wider text-[11px] font-semibold">
                    <th className="py-2.5 px-3 w-10">
                      <input
                        type="checkbox"
                        checked={
                          deduplicatedInvitations.length > 0 &&
                          selectedInvitationIds.length === deduplicatedInvitations.filter((i: UserInvitation) => i.status !== 'ACCEPTED').length
                        }
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedInvitationIds(
                              deduplicatedInvitations.filter((i: UserInvitation) => i.status !== 'ACCEPTED').map((i: UserInvitation) => i.id)
                            );
                          } else {
                            setSelectedInvitationIds([]);
                          }
                        }}
                        className="rounded border-[#D9E2EC] text-[#1F4E9C]"
                      />
                    </th>
                    <th className="py-2.5 px-3">Email Address</th>
                    <th className="py-2.5 px-3">Role</th>
                    <th className="py-2.5 px-3">Linked Vendor</th>
                    <th className="py-2.5 px-3">Invited By</th>
                    <th className="py-2.5 px-3">Invited Date</th>
                    <th className="py-2.5 px-3">Status</th>
                    <th className="py-2.5 px-3 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#D9E2EC]">
                  {deduplicatedInvitations.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-6 text-center text-xs text-[#52606D]">
                        No pre-registered invitations found. Click &quot;Pre-Register User&quot; to invite.
                      </td>
                    </tr>
                  ) : (
                    deduplicatedInvitations.map((inv: UserInvitation) => {
                      const linkedVendor = vendors.find((v) => v.id === inv.vendorId);
                      const isAccepted = inv.status === 'ACCEPTED' || inv.status === 'accepted';
                      const isSelected = selectedInvitationIds.includes(inv.id);

                      return (
                        <tr key={inv.id} className="even:bg-[#F5F7FA] hover:bg-[#EBF1FA]/40 transition">
                          <td className="py-3 px-3">
                            <input
                              type="checkbox"
                              disabled={isAccepted}
                              checked={isSelected}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedInvitationIds((prev) => [...prev, inv.id]);
                                } else {
                                  setSelectedInvitationIds((prev) => prev.filter((id) => id !== inv.id));
                                }
                              }}
                              className="rounded border-[#D9E2EC] text-[#1F4E9C] disabled:opacity-40"
                            />
                          </td>

                          <td className="py-3 px-3 font-semibold text-[#0B2545] font-mono">
                            {inv.email}
                          </td>

                          <td className="py-3 px-3">
                            <span className="font-semibold text-[#1F4E9C]">
                              {inv.role.replace(/_/g, ' ')}
                            </span>
                            {inv.canOverride && (
                              <span className="ml-1.5 px-1 py-0.2 text-[9px] bg-[#EBF1FA] text-[#1B7F3B] font-bold rounded">
                                Override
                              </span>
                            )}
                          </td>

                          <td className="py-3 px-3 text-[#1F2933]">
                            {inv.role === 'VENDOR' ? (
                              linkedVendor ? (
                                <span className="font-medium">{linkedVendor.legalName}</span>
                              ) : (
                                <span className="text-[#B26A00]">Unlinked</span>
                              )
                            ) : (
                              <span className="text-[#52606D]">N/A</span>
                            )}
                          </td>

                          <td className="py-3 px-3 text-[#52606D]">
                            {inv.invitedByName || inv.invitedBy || 'Admin'}
                          </td>

                          <td className="py-3 px-3 text-[#52606D] font-mono text-[11px]">
                            {inv.invitedAt ? new Date(inv.invitedAt).toLocaleDateString() : new Date(inv.createdAt).toLocaleDateString()}
                          </td>

                          <td className="py-3 px-3">
                            <span className={`px-2 py-0.5 rounded-[4px] text-[10px] font-semibold ${
                              isAccepted ? 'badge-pass' : 'badge-warn'
                            }`}>
                              {isAccepted ? 'ACCEPTED' : 'PENDING'}
                            </span>
                          </td>

                          <td className="py-3 px-3 text-right">
                            <div className="flex items-center justify-end space-x-1.5">
                              {/* Edit Invitation */}
                              <button
                                onClick={() => {
                                  setEditingInvitation(inv);
                                  setEditInvRole(inv.role);
                                  setEditInvVendorId(inv.vendorId || vendors[0]?.id || '');
                                  setEditInvCanOverride(Boolean(inv.canOverride));
                                  setEditInvError(null);
                                }}
                                disabled={isAccepted}
                                title={isAccepted ? 'Accepted invitations cannot be edited' : 'Edit role & vendor binding'}
                                className="p-1 text-[#1F4E9C] hover:bg-[#EBF1FA] rounded transition disabled:opacity-30 disabled:cursor-not-allowed"
                              >
                                <Edit2 className="w-3.5 h-3.5" />
                              </button>

                              {/* Resend Invitation */}
                              <button
                                onClick={() => handleResend(inv)}
                                disabled={isAccepted}
                                title={isAccepted ? 'User has already accepted invitation' : 'Resend invitation email'}
                                className="p-1 text-[#1B7F3B] hover:bg-[#EDF7ED] rounded transition disabled:opacity-30 disabled:cursor-not-allowed"
                              >
                                <Send className="w-3.5 h-3.5" />
                              </button>

                              {/* Delete / Revoke Invitation */}
                              <button
                                onClick={() => setInvitationToDelete(inv)}
                                disabled={isAccepted}
                                title={isAccepted ? 'Accepted invitations cannot be deleted (deactivate user instead)' : 'Revoke and delete invitation'}
                                className="p-1 text-[#B42318] hover:bg-[#FEF3F2] rounded transition disabled:opacity-30 disabled:cursor-not-allowed"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* TAB 2: Vendor Management (Required by Part 4) */}
      {activeTab === 'VENDORS' && (
        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-5 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-[#0B2545]">Registered Indian GST Vendors</h3>
              <p className="text-xs text-[#52606D]">
                Vendors with zero history can be permanently deleted. Vendors with invoice or audit history are protected under GST compliance and can only be archived.
              </p>
            </div>

            {/* Filter Toggle & Add Vendor Button */}
            <div className="flex items-center space-x-3">
              <button
                onClick={() => setShowAddVendorModal(true)}
                className="flex items-center space-x-1.5 px-3.5 py-1.5 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[6px] text-xs font-semibold transition shadow-xs"
              >
                <PlusCircle className="w-3.5 h-3.5" />
                <span>Add Vendor</span>
              </button>

              <label className="flex items-center space-x-2 text-xs text-[#1F2933] cursor-pointer bg-[#F5F7FA] px-3 py-1.5 rounded-[6px] border border-[#D9E2EC]">
                <input
                  type="checkbox"
                  checked={includeArchivedVendors}
                  onChange={(e) => setIncludeArchivedVendors(e.target.checked)}
                  className="rounded border-[#D9E2EC] text-[#1F4E9C]"
                />
                <span className="font-medium">Include archived vendors</span>
              </label>
            </div>
          </div>

          <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
            <table className="w-full text-left text-xs font-sans">
              <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545]">
                <tr className="uppercase tracking-wider text-[11px] font-semibold">
                  <th className="py-2.5 px-3">Legal Entity & Trade Name</th>
                  <th className="py-2.5 px-3">15-Digit GSTIN</th>
                  <th className="py-2.5 px-3">State & Code</th>
                  <th className="py-2.5 px-3">Turnover / Scheme</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D9E2EC] font-mono">
                {displayedVendors.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-6 text-center text-xs text-[#52606D]">
                      No vendors found matching current filter.
                    </td>
                  </tr>
                ) : (
                  displayedVendors.map((v) => {
                    const isArchived = v.status === 'ARCHIVED';

                    return (
                      <tr
                        key={v.id}
                        className={`transition ${isArchived ? 'bg-[#F5F7FA] opacity-75' : 'even:bg-[#F5F7FA] hover:bg-[#EBF1FA]/40'}`}
                      >
                        <td className="py-3 px-3 font-sans">
                          <div className="font-bold text-[#0B2545]">{v.legalName}</div>
                          <div className="text-[11px] text-[#52606D]">{v.contactPerson} ({v.phone})</div>
                          {isArchived && v.archiveReason && (
                            <div className="text-[10px] text-[#B42318] mt-0.5">
                              Archived: {v.archiveReason}
                            </div>
                          )}
                        </td>

                        <td className="py-3 px-3 font-bold text-[#1F4E9C]">{v.gstin}</td>

                        <td className="py-3 px-3 font-sans text-[#1F2933]">
                          {v.stateName} ({v.stateCode})
                        </td>

                        <td className="py-3 px-3 font-sans text-[#1F2933]">
                          <div>{v.turnoverCategory === 'ABOVE_5CR' ? '> ₹5 Cr Turnover' : '≤ ₹5 Cr Turnover'}</div>
                          {v.isComposition && <span className="text-[10px] text-[#52606D]">Composition Scheme</span>}
                        </td>

                        <td className="py-3 px-3 font-sans">
                          <span className={`px-2 py-0.5 rounded-[4px] text-[11px] font-semibold ${
                            v.status === 'ACTIVE'
                              ? 'badge-pass'
                              : v.status === 'PENDING_APPROVAL'
                              ? 'badge-warn'
                              : v.status === 'ARCHIVED'
                              ? 'bg-[#52606D] text-white'
                              : 'badge-fail'
                          }`}>
                            {v.status.replace(/_/g, ' ')}
                          </span>
                        </td>

                        <td className="py-3 px-3 text-right font-sans">
                          <div className="flex items-center justify-end space-x-1.5">
                            {v.status === 'PENDING_APPROVAL' && (
                              <>
                                <button
                                  onClick={() => approveVendor(v.id)}
                                  className="px-2.5 py-1 bg-[#1B7F3B] hover:bg-[#14632E] text-white rounded-[4px] text-xs font-medium transition"
                                >
                                  Approve
                                </button>
                                <button
                                  onClick={() => rejectVendor(v.id)}
                                  className="px-2 py-1 bg-[#B42318] hover:bg-[#8F1A12] text-white rounded-[4px] text-xs font-medium transition"
                                >
                                  Reject
                                </button>
                              </>
                            )}

                            {/* Edit Vendor Particulars (including GSTIN, PAN, Bank, Address) */}
                            <button
                              type="button"
                              onClick={() => {
                                setEditingVendorMaster(v);
                                setShowEditVendorModal(true);
                              }}
                              className="px-2.5 py-1 text-[#1F4E9C] hover:bg-[#EBF1FA] border border-[#D9E2EC] rounded-[4px] text-xs font-medium transition flex items-center space-x-1"
                              title="Edit Vendor Master particulars (GSTIN, State, PAN, Address, Bank details, Tally Ledger)"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                              <span>Edit</span>
                            </button>

                            {v.status === 'ACTIVE' && (
                              <button
                                onClick={() => handleOpenVendorDeleteModal(v)}
                                className="px-2.5 py-1 text-[#B42318] hover:bg-[#FEF3F2] border border-[#D9E2EC] rounded-[4px] text-xs font-medium transition flex items-center space-x-1"
                              >
                                <Trash2 className="w-3.5 h-3.5" />
                                <span>Delete</span>
                              </button>
                            )}

                            {isArchived && (
                              <button
                                onClick={() => handleRestoreVendor(v)}
                                className="px-2.5 py-1 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[4px] text-xs font-medium transition flex items-center space-x-1"
                              >
                                <RotateCcw className="w-3.5 h-3.5" />
                                <span>Restore</span>
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: Allowed Domains & Settings */}
      {activeTab === 'SETTINGS' && (
        <form onSubmit={handleSaveSettings} className="bg-white border border-[#D9E2EC] rounded-[6px] p-6 shadow-sm space-y-6">
          <div className="space-y-4">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#0B2545] border-b border-[#D9E2EC] pb-2">
              Allowed Corporate Email Domains (Accounts & Admin Roles Only)
            </h3>

            <div className="space-y-2">
              <label className="block text-xs font-medium text-[#1F2933]">
                Allowed Internal Email Domains (comma-separated)
              </label>
              <input
                type="text"
                value={allowedDomains}
                onChange={(e) => setAllowedDomains(e.target.value)}
                placeholder="e.g. bharattech.in, company.com, gmail.com"
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono focus:outline-none focus:border-[#1F4E9C]"
              />
              <p className="text-[11px] text-[#52606D] leading-relaxed">
                Only users with email addresses ending in these domains can be assigned Accounts Executive or Admin roles. Vendors are not restricted by domain.
              </p>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">
                  Session Inactivity Timeout (Minutes)
                </label>
                <input
                  type="number"
                  min="5"
                  max="1440"
                  value={sessionTimeout}
                  onChange={(e) => setSessionTimeout(parseInt(e.target.value) || 30)}
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono focus:outline-none focus:border-[#1F4E9C]"
                />
                <span className="text-[11px] text-[#52606D]">Default: 30 minutes of idle inactivity.</span>
              </div>

              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">
                  Query SLA Window (Hours)
                </label>
                <input
                  type="number"
                  value={slaHours}
                  onChange={(e) => setSlaHours(parseInt(e.target.value) || 48)}
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono focus:outline-none focus:border-[#1F4E9C]"
                />
                <span className="text-[11px] text-[#52606D]">Unanswered queries escalate to Admin after this window.</span>
              </div>
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t border-[#D9E2EC]">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#0B2545] border-b border-[#D9E2EC] pb-2">
              Company GST Details & Gemini OCR Model
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">Legal Entity Name *</label>
                <input
                  type="text"
                  value={legalName}
                  onChange={(e) => setLegalName(e.target.value)}
                  required
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">Company GSTIN *</label>
                <input
                  type="text"
                  value={gstin}
                  onChange={(e) => setGstin(e.target.value.toUpperCase())}
                  required
                  maxLength={15}
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono uppercase focus:outline-none focus:border-[#1F4E9C]"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">Gemini OCR Model</label>
                <input
                  type="text"
                  value={modelName}
                  onChange={(e) => setModelName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono focus:outline-none focus:border-[#1F4E9C]"
                />
              </div>

              <div className="md:col-span-3">
                <label className="block text-xs font-medium text-[#1F2933] mb-1">Registered Address</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                />
              </div>
            </div>
          </div>

          {/* Gemini AI OCR Key Configuration Card */}
          <div className="space-y-4 pt-4 border-t border-[#D9E2EC]">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-[#D9E2EC] pb-2">
              <div className="flex items-center space-x-2">
                <Key className="w-4 h-4 text-[#1F4E9C]" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-[#0B2545]">
                  Gemini AI OCR API Key Configuration
                </h3>
              </div>
              
              <div className="flex items-center space-x-2">
                <span className="text-[11px] text-[#52606D]">Status:</span>
                {geminiConfig?.configured ? (
                  <span className="px-2 py-0.5 rounded-[4px] text-[10px] font-bold bg-[#EBF7EE] text-[#1B7F3B] border border-[#C3E8CC] flex items-center space-x-1">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>
                      Active ({geminiConfig.source === 'CUSTOM' ? 'Custom Key' : 'Environment Key'})
                    </span>
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-[4px] text-[10px] font-bold bg-[#FFF7E6] text-[#B26A00] border border-[#FFE7BA] flex items-center space-x-1">
                    <AlertTriangle className="w-3 h-3" />
                    <span>Not Configured</span>
                  </span>
                )}
              </div>
            </div>

            <p className="text-xs text-[#52606D] leading-relaxed">
              Configure your Google Gemini API key to power Indian GST tax invoice multimodal OCR extraction, line items detection, and HSN code classification. All requests are securely processed through the backend server.
            </p>

            {geminiKeyFeedback && (
              <div
                className={`p-3 rounded-[6px] border text-xs flex items-center space-x-2 ${
                  geminiKeyFeedback.type === 'SUCCESS'
                    ? 'bg-[#EBF7EE] border-[#C3E8CC] text-[#1B7F3B]'
                    : 'bg-[#FEF3F2] border-[#FECDCA] text-[#B42318]'
                }`}
              >
                {geminiKeyFeedback.type === 'SUCCESS' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0" />
                )}
                <span>{geminiKeyFeedback.message}</span>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">
                  Gemini API Key (Google AI Studio)
                </label>
                <div className="relative">
                  <input
                    type={showGeminiKey ? 'text' : 'password'}
                    value={geminiApiKeyInput}
                    onChange={(e) => setGeminiApiKeyInput(e.target.value)}
                    placeholder={geminiConfig?.maskedKey ? `Current: ${geminiConfig.maskedKey}` : 'Paste AIzaSy... key here'}
                    className="w-full pl-3 pr-10 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono focus:outline-none focus:border-[#1F4E9C]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowGeminiKey(!showGeminiKey)}
                    className="absolute right-2.5 top-2 text-[#52606D] hover:text-[#0B2545]"
                    title={showGeminiKey ? 'Hide key' : 'Show key'}
                  >
                    {showGeminiKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <div className="flex items-center justify-between text-[11px] text-[#52606D] mt-1">
                  <span>Enter new key to update or test.</span>
                  {geminiConfig?.hasCustomKey && (
                    <button
                      type="button"
                      onClick={handleRemoveCustomGeminiKey}
                      className="text-[#B42318] hover:underline"
                    >
                      Clear custom key
                    </button>
                  )}
                </div>
              </div>

              <div className="flex flex-col justify-end">
                <div className="flex items-center space-x-2 pt-1">
                  <button
                    type="button"
                    onClick={handleTestGeminiKey}
                    disabled={isTestingGeminiKey || (!geminiApiKeyInput.trim() && !geminiConfig?.configured)}
                    className="flex-1 px-4 py-2 bg-white hover:bg-[#F5F7FA] border border-[#D9E2EC] text-[#0B2545] font-semibold rounded-[6px] text-xs transition flex items-center justify-center space-x-1.5 disabled:opacity-40"
                  >
                    <Sparkles className={`w-3.5 h-3.5 text-[#1F4E9C] ${isTestingGeminiKey ? 'animate-spin' : ''}`} />
                    <span>{isTestingGeminiKey ? 'Testing Connection...' : 'Test Connection'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSaveGeminiKey}
                    disabled={isSavingGeminiKey || !geminiApiKeyInput.trim()}
                    className="flex-1 px-4 py-2 bg-[#0B2545] hover:bg-[#173B77] text-white font-semibold rounded-[6px] text-xs transition flex items-center justify-center space-x-1.5 disabled:opacity-40"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{isSavingGeminiKey ? 'Saving...' : 'Save Gemini Key'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* Real-Time GSTIN Validation (gstin.cloud) Configuration Card */}
          <div className="bg-[#F8FAFC] border border-[#CBD5E1] rounded-[8px] p-5 space-y-4 shadow-xs">
            <div className="flex items-center justify-between border-b border-[#E2E8F0] pb-3">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-[#EBF1FA] rounded-[6px] text-[#1F4E9C]">
                  <ShieldCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-[#0B2545]">
                    Real-Time GSTIN Validation API (gstin.cloud)
                  </h3>
                  <p className="text-[11px] text-[#52606D]">
                    Endpoint: <code className="font-mono text-[#1F4E9C] bg-[#EBF1FA] px-1 py-0.5 rounded">https://gstin.cloud/api/v1/verify</code> (authenticated via <code className="font-mono text-[#0B2545]">x-api-key</code>)
                  </p>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <span className="text-[11px] text-[#52606D]">Status:</span>
                {gstinConfig?.configured ? (
                  <span className="px-2 py-0.5 rounded-[4px] text-[10px] font-bold bg-[#EBF7EE] text-[#1B7F3B] border border-[#C3E8CC] flex items-center space-x-1">
                    <CheckCircle2 className="w-3 h-3" />
                    <span>
                      Active ({gstinConfig.source === 'CUSTOM' ? 'Custom Key' : 'Environment Key'})
                    </span>
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-[4px] text-[10px] font-bold bg-[#FFF7E6] text-[#B26A00] border border-[#FFE7BA] flex items-center space-x-1">
                    <AlertTriangle className="w-3 h-3" />
                    <span>Not Configured</span>
                  </span>
                )}
              </div>
            </div>

            <p className="text-xs text-[#52606D] leading-relaxed">
              Upon opening any invoice in the Accounts Review screen, the system automatically validates the supplier's GSTIN against the live GST portal. It extracts legal particulars, taxpayer constitution, principal place of business, last filed return (GSTR-3B), and a 6-month statutory filing compliance history (GSTR-1, GSTR-3B, IFF). The key is securely maintained on the server.
            </p>

            {gstinKeyFeedback && (
              <div
                className={`p-3 rounded-[6px] border text-xs flex items-center space-x-2 ${
                  gstinKeyFeedback.type === 'SUCCESS'
                    ? 'bg-[#EBF7EE] border-[#C3E8CC] text-[#1B7F3B]'
                    : 'bg-[#FEF3F2] border-[#FECDCA] text-[#B42318]'
                }`}
              >
                {gstinKeyFeedback.type === 'SUCCESS' ? (
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                ) : (
                  <AlertCircle className="w-4 h-4 shrink-0" />
                )}
                <span>{gstinKeyFeedback.message}</span>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">
                  gstin.cloud x-api-key
                </label>
                <div className="relative">
                  <input
                    type={showGstinKey ? 'text' : 'password'}
                    value={gstinApiKeyInput}
                    onChange={(e) => setGstinApiKeyInput(e.target.value)}
                    placeholder={gstinConfig?.maskedKey ? `Current: ${gstinConfig.maskedKey}` : 'Paste gstin.cloud x-api-key here'}
                    className="w-full pl-3 pr-10 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono focus:outline-none focus:border-[#1F4E9C]"
                  />
                  <button
                    type="button"
                    onClick={() => setShowGstinKey(!showGstinKey)}
                    className="absolute right-2.5 top-2 text-[#52606D] hover:text-[#0B2545]"
                    title={showGstinKey ? 'Hide key' : 'Show key'}
                  >
                    {showGstinKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <div className="flex items-center justify-between text-[11px] text-[#52606D] mt-1">
                  <span>Passed in HTTP header: <code className="font-mono text-[#0B2545]">x-api-key</code></span>
                  {gstinConfig?.hasCustomKey && (
                    <button
                      type="button"
                      onClick={handleRemoveCustomGstinKey}
                      className="text-[#B42318] hover:underline"
                    >
                      Clear custom key
                    </button>
                  )}
                </div>
              </div>

              <div className="flex flex-col justify-end">
                <div className="flex items-center space-x-2 pt-1">
                  <button
                    type="button"
                    onClick={handleTestGstinKey}
                    disabled={isTestingGstinKey || (!gstinApiKeyInput.trim() && !gstinConfig?.configured)}
                    className="flex-1 px-4 py-2 bg-white hover:bg-[#F5F7FA] border border-[#D9E2EC] text-[#0B2545] font-semibold rounded-[6px] text-xs transition flex items-center justify-center space-x-1.5 disabled:opacity-40"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 text-[#1F4E9C] ${isTestingGstinKey ? 'animate-spin' : ''}`} />
                    <span>{isTestingGstinKey ? 'Testing Connection...' : 'Test Connection'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={handleSaveGstinKey}
                    disabled={isSavingGstinKey || !gstinApiKeyInput.trim()}
                    className="flex-1 px-4 py-2 bg-[#0B2545] hover:bg-[#173B77] text-white font-semibold rounded-[6px] text-xs transition flex items-center justify-center space-x-1.5 disabled:opacity-40"
                  >
                    <Save className="w-3.5 h-3.5" />
                    <span>{isSavingGstinKey ? 'Saving...' : 'Save x-api-key'}</span>
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* TDS General Ledger (GL) Master Configuration Card */}
          <div className="bg-[#F8FAFC] border border-[#CBD5E1] rounded-[8px] p-5 space-y-4 shadow-xs">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-[#E2E8F0] pb-3">
              <div className="flex items-center space-x-2.5">
                <div className="p-2 bg-[#EBF1FA] rounded-[6px] text-[#1F4E9C]">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-[#0B2545]">
                    TDS General Ledger (GL) Master Configuration (Tally Prime / ERP)
                  </h3>
                  <p className="text-[11px] text-[#52606D]">
                    Configure default ledger names created under <code className="font-mono text-[#1F4E9C] bg-[#EBF1FA] px-1 py-0.5 rounded">Duties &amp; Taxes</code> when deducting Tax Deducted at Source on invoice approvals.
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => setTdsGlLedgers({ ...DEFAULT_TDS_GL_LEDGERS })}
                className="px-2.5 py-1 text-xs text-[#1F4E9C] bg-white border border-[#D9E2EC] hover:bg-[#F5F7FA] rounded-[4px] font-medium transition shrink-0"
              >
                Reset to Defaults
              </button>
            </div>

            <p className="text-xs text-[#52606D] leading-relaxed">
              When an invoice is approved with TDS deduction, the system automatically defaults to these General Ledger accounts during the TDS approval popup and incorporates them into Tally Prime XML accounting vouchers, accurately balancing the Net Vendor Credit and TDS Payable under Duties &amp; Taxes.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 pt-1">
              {[
                { code: '194C', label: 'Section 194C (Contractors / Sub-contractors)', defaultName: 'TDS on Contractors - 194C' },
                { code: '194J_TECH', label: 'Section 194J (Technical / FTS - 2%)', defaultName: 'TDS on Technical Services - 194J' },
                { code: '194J_PROF', label: 'Section 194J (Professional Fees - 10%)', defaultName: 'TDS on Professional Fees - 194J' },
                { code: '194I_LAND', label: 'Section 194I (Rent: Land, Building & Furniture - 10%)', defaultName: 'TDS on Rent - Land & Building - 194I' },
                { code: '194I_PLANT', label: 'Section 194I (Rent: Plant & Machinery - 2%)', defaultName: 'TDS on Rent - Plant & Machinery - 194I' },
                { code: '194H', label: 'Section 194H (Commission & Brokerage - 5%)', defaultName: 'TDS on Commission - 194H' },
                { code: '194Q', label: 'Section 194Q (Purchase of Goods - 0.1%)', defaultName: 'TDS on Purchase of Goods - 194Q' },
              ].map((item) => (
                <div key={item.code} className="bg-white p-3 rounded-[6px] border border-[#E2E8F0]">
                  <label className="block text-xs font-semibold text-[#0B2545] mb-1">
                    {item.label}
                  </label>
                  <input
                    type="text"
                    value={tdsGlLedgers[item.code] || item.defaultName}
                    onChange={(e) =>
                      setTdsGlLedgers((prev) => ({
                        ...prev,
                        [item.code]: e.target.value,
                      }))
                    }
                    placeholder={item.defaultName}
                    className="w-full px-2.5 py-1.5 bg-white border border-[#CBD5E1] rounded-[4px] text-xs font-mono text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                  />
                  <div className="flex items-center justify-between mt-1 text-[10px] text-[#64748B]">
                    <span>Tally Parent: <strong className="text-[#0B2545]">Duties &amp; Taxes</strong></span>
                    <button
                      type="button"
                      onClick={() =>
                        setTdsGlLedgers((prev) => ({
                          ...prev,
                          [item.code]: item.defaultName,
                        }))
                      }
                      className="hover:text-[#1F4E9C] underline"
                    >
                      Default
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="flex items-center space-x-1.5 px-6 py-2 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[6px] text-xs font-medium transition"
            >
              <Save className="w-4 h-4" />
              <span>Save System Settings</span>
            </button>
          </div>
        </form>
      )}

      {/* TAB 4: HSN Master */}
      {activeTab === 'HSN' && (
        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-5 shadow-sm space-y-4">
          <h3 className="text-sm font-bold text-[#0B2545]">HSN / SAC Master Directory</h3>
          <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
            <table className="w-full text-left text-xs font-sans">
              <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545]">
                <tr className="uppercase tracking-wider text-[11px] font-semibold">
                  <th className="py-2.5 px-3">Code</th>
                  <th className="py-2.5 px-3">Description</th>
                  <th className="py-2.5 px-3">Classification</th>
                  <th className="py-2.5 px-3 text-right">Standard GST Rate</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D9E2EC] font-mono">
                {hsnMaster.map((h) => (
                  <tr key={h.code} className="even:bg-[#F5F7FA] hover:bg-[#EBF1FA]/40 transition">
                    <td className="py-3 px-3 font-bold text-[#1F4E9C]">{h.code}</td>
                    <td className="py-3 px-3 font-sans text-[#1F2933]">{h.description}</td>
                    <td className="py-3 px-3 font-sans">
                      <span className="px-2 py-0.5 rounded-[4px] text-[10px] font-semibold bg-[#EBF1FA] text-[#1F4E9C] border border-[#D9E2EC]">
                        {h.type}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-right font-bold text-[#1B7F3B]">{h.gstRate}%</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 5: Audit Log */}
      {activeTab === 'AUDIT' && (
        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-5 shadow-sm space-y-4">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-bold text-[#0B2545]">Append-Only Immutable Audit Log</h3>
              <p className="text-xs text-[#52606D]">
                Statutory audit trail of sign-ins, invitations, vendor deletions, overrides, and invoice states.
              </p>
            </div>

            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-[#52606D] absolute left-3 top-2.5" />
              <input
                type="text"
                value={auditSearch}
                onChange={(e) => setAuditSearch(e.target.value)}
                placeholder="Search audit trail..."
                className="w-full pl-9 pr-3 py-1.5 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
              />
            </div>
          </div>

          <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545]">
                <tr className="uppercase tracking-wider text-[11px] font-sans font-semibold">
                  <th className="py-2.5 px-3">Timestamp</th>
                  <th className="py-2.5 px-3">Action</th>
                  <th className="py-2.5 px-3">User & Role</th>
                  <th className="py-2.5 px-3">Invoice ID</th>
                  <th className="py-2.5 px-3">Remarks / Details</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D9E2EC]">
                {filteredAudit.map((log) => (
                  <tr key={log.id} className="even:bg-[#F5F7FA] hover:bg-[#EBF1FA]/40 transition text-[11px]">
                    <td className="py-3 px-3 text-[#52606D]">{log.createdAt.replace('T', ' ').slice(0, 19)}</td>
                    <td className="py-3 px-3">
                      <span className="px-1.5 py-0.5 bg-[#EBF1FA] text-[#1F4E9C] border border-[#D9E2EC] rounded-[4px]">
                        {log.action}
                      </span>
                    </td>
                    <td className="py-3 px-3 text-[#1F2933] font-sans">
                      {log.userEmail} ({log.userRole})
                    </td>
                    <td className="py-3 px-3 text-[#1F4E9C]">{log.invoiceId || '-'}</td>
                    <td className="py-3 px-3 text-[#1F2933] font-sans max-w-md truncate">
                      {log.remarks}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Edit User Modal */}
      {editingUser && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <form onSubmit={handleSaveUserAssignment} className="bg-white border border-[#D9E2EC] w-full max-w-md rounded-[6px] p-6 shadow-lg space-y-4">
            <h3 className="text-sm font-bold text-[#0B2545]">Assign Role & Permissions</h3>
            <p className="text-xs text-[#52606D]">
              User: <strong className="text-[#1F2933]">{editingUser.email}</strong>
            </p>

            {editError && (
              <div className="p-3 bg-[#FEF3F2] border border-[#FECDCA] rounded-[6px] text-[#B42318] text-xs">
                {editError}
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">Role</label>
              <select
                value={editRole}
                onChange={(e) => setEditRole(e.target.value as any)}
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
              >
                <option value="VENDOR">Vendor (Scoped to specific vendor entity)</option>
                <option value="ACCOUNTS_EXECUTIVE">Accounts Executive (Review & Approve)</option>
                <option value="ADMIN">System Admin (Full system configuration)</option>
                <option value="PENDING">Pending (No access)</option>
              </select>
            </div>

            {editRole === 'VENDOR' && (
              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">
                  Bind to Vendor Master Record *
                </label>
                <select
                  value={editVendorId}
                  onChange={(e) => setEditVendorId(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                >
                  {activeVendorsList.map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.legalName} ({v.gstin})
                    </option>
                  ))}
                </select>
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">Account Status</label>
              <select
                value={editStatus}
                onChange={(e) => setEditStatus(e.target.value as any)}
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
              >
                <option value="ACTIVE">Active (Permitted)</option>
                <option value="PENDING_APPROVAL">Pending Approval (Locked)</option>
                <option value="DEACTIVATED">Deactivated (Blocked & Signed Out)</option>
              </select>
            </div>

            {editRole === 'ACCOUNTS_EXECUTIVE' && (
              <div className="pt-2">
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editCanOverride}
                    onChange={(e) => setEditCanOverride(e.target.checked)}
                    className="w-4 h-4 text-[#1F4E9C] rounded border-[#D9E2EC]"
                  />
                  <span className="text-xs text-[#1F2933]">
                    Grant Statutory Override Permission (can approve with justification even when GST check fails)
                  </span>
                </label>
              </div>
            )}

            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-[#1F4E9C] hover:bg-[#173B77] text-white font-medium rounded-[6px] text-xs"
              >
                Save Role Assignment
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Pre-Register Invite Modal */}
      {showInviteModal && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <form onSubmit={handleSendInvite} className="bg-white border border-[#D9E2EC] w-full max-w-md rounded-[6px] p-6 shadow-lg space-y-4">
            <h3 className="text-sm font-bold text-[#0B2545]">Pre-Register Email Invitation</h3>
            <p className="text-xs text-[#52606D]">
              When this email signs in with Google, the profile will automatically activate with the assigned role. If the user already signed in and is pending approval, they will be activated immediately!
            </p>

            {inviteError && (
              <div className="p-3 bg-[#FEF3F2] border border-[#FECDCA] rounded-[6px] text-[#B42318] text-xs">
                {inviteError}
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">Email Address *</label>
              <input
                type="email"
                value={inviteEmail}
                onChange={(e) => setInviteEmail(e.target.value.toLowerCase())}
                placeholder="user@domain.com"
                required
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">Role *</label>
              <select
                value={inviteRole}
                onChange={(e) => setInviteRole(e.target.value as any)}
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
              >
                <option value="ACCOUNTS_EXECUTIVE">Accounts Executive</option>
                <option value="VENDOR">Vendor</option>
                <option value="ADMIN">System Admin</option>
              </select>
            </div>

            {inviteRole === 'VENDOR' && (
              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">Bind to Vendor *</label>
                <select
                  value={inviteVendorId}
                  onChange={(e) => setInviteVendorId(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                >
                  {activeVendorsList.map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.legalName} ({v.gstin})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {inviteRole === 'ACCOUNTS_EXECUTIVE' && (
              <div>
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={inviteCanOverride}
                    onChange={(e) => setInviteCanOverride(e.target.checked)}
                    className="w-4 h-4 text-[#1F4E9C] rounded border-[#D9E2EC]"
                  />
                  <span className="text-xs text-[#1F2933]">Grant Statutory Override Permission</span>
                </label>
              </div>
            )}

            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setShowInviteModal(false)}
                className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-[#1F4E9C] hover:bg-[#173B77] text-white font-medium rounded-[6px] text-xs"
              >
                Create Pre-Registration
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Edit Invitation Modal (Part 3) */}
      {editingInvitation && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <form onSubmit={handleSaveEditedInvitation} className="bg-white border border-[#D9E2EC] w-full max-w-md rounded-[6px] p-6 shadow-lg space-y-4">
            <h3 className="text-sm font-bold text-[#0B2545]">Edit Pending Invitation</h3>
            <p className="text-xs text-[#52606D]">
              Email: <strong className="text-[#0B2545] font-mono">{editingInvitation.email}</strong>
            </p>

            {editInvError && (
              <div className="p-3 bg-[#FEF3F2] border border-[#FECDCA] rounded-[6px] text-[#B42318] text-xs">
                {editInvError}
              </div>
            )}

            <div>
              <label className="block text-xs font-medium text-[#1F2933] mb-1">Role *</label>
              <select
                value={editInvRole}
                onChange={(e) => setEditInvRole(e.target.value as any)}
                className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
              >
                <option value="ACCOUNTS_EXECUTIVE">Accounts Executive</option>
                <option value="VENDOR">Vendor</option>
                <option value="ADMIN">System Admin</option>
              </select>
            </div>

            {editInvRole === 'VENDOR' && (
              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">Bind to Vendor *</label>
                <select
                  value={editInvVendorId}
                  onChange={(e) => setEditInvVendorId(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                >
                  {activeVendorsList.map((v) => (
                    <option key={v.id} value={v.id}>
                      {v.legalName} ({v.gstin})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {editInvRole === 'ACCOUNTS_EXECUTIVE' && (
              <div>
                <label className="flex items-center space-x-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={editInvCanOverride}
                    onChange={(e) => setEditInvCanOverride(e.target.checked)}
                    className="w-4 h-4 text-[#1F4E9C] rounded border-[#D9E2EC]"
                  />
                  <span className="text-xs text-[#1F2933]">Grant Statutory Override Permission</span>
                </label>
              </div>
            )}

            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setEditingInvitation(null)}
                className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-1.5 bg-[#1F4E9C] hover:bg-[#173B77] text-white font-medium rounded-[6px] text-xs"
              >
                Save Changes
              </button>
            </div>
          </form>
        </div>
      )}

      {/* Delete (Revoke) Single Invitation Confirmation Modal */}
      {invitationToDelete && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <div className="bg-white border border-[#D9E2EC] w-full max-w-md rounded-[6px] p-6 shadow-lg space-y-4">
            <div className="flex items-center space-x-2 text-[#B42318]">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <h3 className="text-sm font-bold">Revoke Pending Invitation</h3>
            </div>
            <p className="text-xs text-[#52606D] leading-relaxed">
              Are you sure you want to revoke and delete the pending invitation for{' '}
              <strong className="text-[#0B2545] font-mono">{invitationToDelete.email}</strong> ({invitationToDelete.role})?
            </p>
            <p className="text-xs text-[#52606D] leading-relaxed">
              If this user signs in with Google after revocation, their account will land on the Pending Approval screen instead of being granted automatic access.
            </p>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setInvitationToDelete(null)}
                className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmDeleteInvitation}
                className="px-4 py-1.5 bg-[#B42318] hover:bg-[#8F1A12] text-white font-medium rounded-[6px] text-xs transition"
              >
                Revoke Invitation
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Bulk Delete Invitations Confirmation Modal */}
      {showBulkDeleteInvModal && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <div className="bg-white border border-[#D9E2EC] w-full max-w-md rounded-[6px] p-6 shadow-lg space-y-4">
            <div className="flex items-center space-x-2 text-[#B42318]">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <h3 className="text-sm font-bold">Revoke Selected Invitations</h3>
            </div>
            <p className="text-xs text-[#52606D] leading-relaxed">
              Are you sure you want to delete <strong className="text-[#0B2545]">{selectedInvitationIds.length}</strong> selected pending invitation(s)?
            </p>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                onClick={() => setShowBulkDeleteInvModal(false)}
                className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleConfirmBulkDeleteInvitations}
                className="px-4 py-1.5 bg-[#B42318] hover:bg-[#8F1A12] text-white font-medium rounded-[6px] text-xs transition"
              >
                Delete Selected
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Vendor Delete / Archive Modal (Rules A, B, C from Part 4) */}
      {vendorToDelete && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <div className="bg-white border border-[#D9E2EC] w-full max-w-lg rounded-[6px] p-6 shadow-lg space-y-4">
            
            <div className="flex items-center justify-between border-b border-[#D9E2EC] pb-3">
              <div className="flex items-center space-x-2">
                <Building2 className="w-5 h-5 text-[#0B2545]" />
                <h3 className="text-sm font-bold text-[#0B2545]">
                  Vendor Removal & History Assessment
                </h3>
              </div>
              <span className="text-xs text-[#52606D] font-mono">{vendorToDelete.gstin}</span>
            </div>

            {/* Vendor Details */}
            <div className="p-3 bg-[#F5F7FA] border border-[#D9E2EC] rounded-[6px] text-xs space-y-1">
              <div><span className="text-[#52606D]">Legal Name:</span> <strong className="text-[#0B2545]">{vendorToDelete.legalName}</strong></div>
              <div><span className="text-[#52606D]">Trade Name:</span> <span className="text-[#1F2933]">{vendorToDelete.tradeName}</span></div>
            </div>

            {isCheckingEligibility ? (
              <div className="py-6 text-center text-xs text-[#52606D]">
                Evaluating GST audit history and invoice records...
              </div>
            ) : vendorEligibility ? (
              <>
                {/* Rule (c): On-screen explanation of which rule applies and why */}
                <div className={`p-3.5 rounded-[6px] border text-xs leading-relaxed ${
                  vendorEligibility.canDeletePermanently
                    ? 'bg-[#EBF1FA] border-[#D9E2EC] text-[#0B2545]'
                    : 'bg-[#FFF7E6] border-[#FFE7BA] text-[#B26A00]'
                }`}>
                  <div className="font-bold flex items-center space-x-1.5 mb-1">
                    <Info className="w-4 h-4 shrink-0" />
                    <span>
                      {vendorEligibility.canDeletePermanently
                        ? 'Rule A Applies: Permanent Deletion Allowed'
                        : 'Rule B Applies: Statutory Retention Required (Archive Vendor)'}
                    </span>
                  </div>
                  <p>{vendorEligibility.reason}</p>
                </div>

                {vendorModalError && (
                  <div className="p-3 bg-[#FEF3F2] border border-[#FECDCA] rounded-[6px] text-[#B42318] text-xs">
                    {vendorModalError}
                  </div>
                )}

                {/* Case 1: Can Delete Permanently (Rule A) */}
                {vendorEligibility.canDeletePermanently ? (
                  <form onSubmit={handleExecutePermanentDelete} className="space-y-4">
                    <div className="text-xs text-[#52606D] flex flex-col gap-1.5">
                      <div>
                        To confirm permanent deletion of this unused/blank vendor, please type{' '}
                        <strong className="text-[#0B2545]">&quot;{vendorToDelete.legalName || vendorToDelete.gstin || 'DELETE'}&quot;</strong> below or click an auto-fill option:
                      </div>
                      <div className="flex flex-wrap items-center gap-2 pt-1">
                        <button
                          type="button"
                          onClick={() => {
                            setVendorDeleteConfirmName(vendorToDelete.legalName || vendorToDelete.gstin || 'DELETE');
                            if (!vendorDeleteReason.trim()) {
                              setVendorDeleteReason('Test / blank vendor created in error; no transactions occurred.');
                            }
                          }}
                          className="px-2.5 py-1 bg-[#EBF1FA] hover:bg-[#D4E3F7] text-[#1F4E9C] border border-[#BACEEA] rounded-[4px] text-xs font-semibold flex items-center space-x-1 transition cursor-pointer"
                        >
                          <span>⚡ Auto-Fill Confirmation</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            setVendorDeleteConfirmName('DELETE');
                            if (!vendorDeleteReason.trim()) {
                              setVendorDeleteReason('Test / blank vendor created in error; no transactions occurred.');
                            }
                          }}
                          className="px-2.5 py-1 bg-[#FEF3F2] hover:bg-[#FEE4E2] text-[#B42318] border border-[#FECDCA] rounded-[4px] text-xs font-semibold flex items-center space-x-1 transition cursor-pointer"
                        >
                          <span>Type &quot;DELETE&quot;</span>
                        </button>
                      </div>
                    </div>

                    <div>
                      <input
                        type="text"
                        value={vendorDeleteConfirmName}
                        onChange={(e) => setVendorDeleteConfirmName(e.target.value)}
                        placeholder={vendorToDelete.legalName || vendorToDelete.gstin || 'Type vendor name, GSTIN, or DELETE'}
                        className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono focus:outline-none focus:border-[#1F4E9C]"
                      />
                      <p className="text-[11px] text-[#52606D] mt-1">
                        Accepts: Legal Name, Trade Name, GSTIN, or &quot;DELETE&quot;.
                      </p>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-[#1F2933] mb-1">
                        Reason for Permanent Deletion
                      </label>
                      <textarea
                        value={vendorDeleteReason}
                        onChange={(e) => setVendorDeleteReason(e.target.value)}
                        placeholder="e.g. Test / blank vendor created in error; no transactions occurred."
                        rows={2}
                        className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
                      />
                    </div>

                    <div className="p-2.5 bg-[#FEF3F2] border border-[#FECDCA] rounded-[4px] text-[11px] text-[#B42318]">
                      Note: Deleting this vendor will permanently revoke any pending invitations and deactivate linked vendor users.
                    </div>

                    <div className="flex justify-end space-x-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setVendorToDelete(null)}
                        className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs font-medium cursor-pointer"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={(() => {
                          const conf = vendorDeleteConfirmName.trim().toLowerCase();
                          const legal = (vendorToDelete.legalName || '').trim().toLowerCase();
                          const trade = (vendorToDelete.tradeName || '').trim().toLowerCase();
                          const gstin = (vendorToDelete.gstin || '').trim().toLowerCase();
                          const isBlank = !legal && !gstin;
                          const isMatch = isBlank || conf === legal || conf === trade || conf === gstin || conf === 'delete' || conf === 'confirm';
                          return !isMatch;
                        })()}
                        className="px-4 py-1.5 bg-[#B42318] hover:bg-[#8F1A12] text-white font-medium rounded-[6px] text-xs transition disabled:opacity-40 shadow-xs cursor-pointer disabled:cursor-not-allowed"
                      >
                        Permanently Delete Vendor
                      </button>
                    </div>
                  </form>
                ) : (
                  /* Case 2: Invoices exist -> Archive Vendor (Rule B) */
                  <form onSubmit={handleExecuteArchive} className="space-y-4">
                    <p className="text-xs text-[#52606D] leading-relaxed">
                      Archiving will soft-delete the vendor. Vendor users will be deactivated and signed out. The vendor is excluded from active dropdowns, but existing invoices, audit trail, and Tally logs remain intact. Duplicate invoice validation will continue to protect against duplicate invoices.
                    </p>

                    <div>
                      <label className="block text-xs font-medium text-[#1F2933] mb-1">
                        Reason for Archiving *
                      </label>
                      <textarea
                        value={vendorDeleteReason}
                        onChange={(e) => setVendorDeleteReason(e.target.value)}
                        placeholder="e.g. Contract terminated; business relationship concluded."
                        required
                        rows={2}
                        className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                      />
                    </div>

                    <div className="flex justify-end space-x-2 pt-2">
                      <button
                        type="button"
                        onClick={() => setVendorToDelete(null)}
                        className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs"
                      >
                        Cancel
                      </button>
                      <button
                        type="submit"
                        disabled={!vendorDeleteReason.trim()}
                        className="px-4 py-1.5 bg-[#0B2545] hover:bg-[#173B77] text-white font-medium rounded-[6px] text-xs transition disabled:opacity-40 flex items-center space-x-1"
                      >
                        <Archive className="w-3.5 h-3.5" />
                        <span>Archive Vendor</span>
                      </button>
                    </div>
                  </form>
                )}
              </>
            ) : null}

          </div>
        </div>
      )}

      {/* Check & Repair Access Diagnostics Drawer / Modal */}
      {repairUser && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <div className="bg-white border border-[#D9E2EC] w-full max-w-lg rounded-[6px] p-6 shadow-xl space-y-4 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-[#D9E2EC] pb-3">
              <div className="flex items-center space-x-2">
                <Wrench className="w-5 h-5 text-[#1F4E9C]" />
                <h3 className="text-sm font-bold text-[#0B2545]">Check & Repair User Access</h3>
              </div>
              <button onClick={() => setRepairUser(null)} className="text-xs text-[#52606D] hover:text-[#0B2545]">
                ✕
              </button>
            </div>

            <div className="p-3 bg-[#F5F7FA] border border-[#D9E2EC] rounded-[6px] text-xs space-y-1">
              <div>
                <span className="text-[#52606D]">User Email:</span>{' '}
                <strong className="text-[#0B2545] font-mono">{repairUser.email}</strong>
              </div>
              <div>
                <span className="text-[#52606D]">Firebase UID:</span>{' '}
                <span className="text-[#1F2933] font-mono">{repairUser.uid}</span>
              </div>
              <div>
                <span className="text-[#52606D]">Display Name:</span>{' '}
                <span className="text-[#1F2933]">{repairUser.displayName || '-'}</span>
              </div>
            </div>

            {repairActionMessage && (
              <div className="p-3 bg-[#EDF7ED] border border-[#C8E6C9] rounded-[6px] text-xs text-[#1B7F3B] flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{repairActionMessage}</span>
              </div>
            )}

            {isCheckingAccess ? (
              <div className="py-8 text-center text-xs text-[#52606D]">
                Checking synchronization status across Firestore profile, Firebase Authentication, and custom claims...
              </div>
            ) : repairDiagnostics ? (
              <div className="space-y-3 text-xs">
                {/* Sync Summary Banner */}
                <div
                  className={`p-3 rounded-[6px] border flex items-start space-x-2 ${
                    repairDiagnostics.isSynced
                      ? 'bg-[#EDF7ED] border-[#C8E6C9] text-[#1B7F3B]'
                      : 'bg-[#FFF7E6] border-[#FFE7BA] text-[#B26A00]'
                  }`}
                >
                  {repairDiagnostics.isSynced ? (
                    <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                  ) : (
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  )}
                  <div>
                    <strong className="block font-bold">
                      {repairDiagnostics.isSynced ? 'All Access Systems In Sync' : 'Access Drift Detected'}
                    </strong>
                    <span>
                      {repairDiagnostics.isSynced
                        ? 'Firestore profile, Firebase Authentication disabled status, and role claims are aligned.'
                        : 'System drift exists between the profile status and Firebase Auth claims/disabled flags. Click "Resync" to repair.'}
                    </span>
                  </div>
                </div>

                {/* Diagnostic Breakdown */}
                <div className="border border-[#D9E2EC] rounded-[6px] divide-y divide-[#D9E2EC]">
                  <div className="p-2.5 flex justify-between items-center">
                    <span className="text-[#52606D]">Authoritative Firestore Status:</span>
                    <span
                      className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                        repairDiagnostics.firestoreStatus === 'ACTIVE' ? 'badge-pass' : 'badge-fail'
                      }`}
                    >
                      {repairDiagnostics.firestoreStatus}
                    </span>
                  </div>

                  <div className="p-2.5 flex justify-between items-center">
                    <span className="text-[#52606D]">Status Reason / Deactivation Note:</span>
                    <span className="font-medium text-[#0B2545]">
                      {repairDiagnostics.deactivatedReason || 'None (Account Active)'}
                    </span>
                  </div>

                  <div className="p-2.5 flex justify-between items-center">
                    <span className="text-[#52606D]">Firebase Authentication Flag:</span>
                    <span
                      className={`font-semibold ${
                        repairDiagnostics.authDisabled ? 'text-[#B42318]' : 'text-[#1B7F3B]'
                      }`}
                    >
                      {repairDiagnostics.authDisabled
                        ? 'Disabled (Blocked at Auth)'
                        : 'Enabled (Sign-in Permitted)'}
                    </span>
                  </div>

                  <div className="p-2.5 flex justify-between items-center">
                    <span className="text-[#52606D]">Active Role & Claims:</span>
                    <span className="font-mono text-[#0B2545]">
                      {repairDiagnostics.roleClaims?.role}{' '}
                      {repairDiagnostics.roleClaims?.canOverride ? '(Override Granted)' : ''}
                    </span>
                  </div>

                  <div className="p-2.5 flex justify-between items-center">
                    <span className="text-[#52606D]">Vendor Master Binding:</span>
                    <span className="text-[#0B2545]">
                      {repairDiagnostics.vendorLink?.vendorName
                        ? `${repairDiagnostics.vendorLink.vendorName} (${repairDiagnostics.vendorLink.vendorStatus})`
                        : 'Internal Staff / None'}
                    </span>
                  </div>

                  {repairDiagnostics.duplicates && repairDiagnostics.duplicates.length > 0 && (
                    <div className="p-2.5 space-y-1 bg-[#FEF3F2]">
                      <div className="text-[#B42318] font-bold flex items-center space-x-1">
                        <AlertTriangle className="w-3.5 h-3.5" />
                        <span>Duplicate Profiles Detected for Canonical Email:</span>
                      </div>
                      {repairDiagnostics.duplicates.map((dup: any) => (
                        <div key={dup.uid} className="text-[11px] text-[#52606D] font-mono pl-4">
                          • {dup.email} (UID: {dup.uid.slice(0, 14)}..., Status: {dup.status}, Role:{' '}
                          {dup.role})
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="flex justify-end space-x-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setRepairUser(null)}
                    className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs font-medium"
                  >
                    Close
                  </button>
                  <button
                    type="button"
                    onClick={handleResyncAccess}
                    disabled={isResyncingAccess}
                    className="px-4 py-1.5 bg-[#1F4E9C] hover:bg-[#173B77] text-white font-medium rounded-[6px] text-xs transition flex items-center space-x-1.5 shadow-sm disabled:opacity-50"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${isResyncingAccess ? 'animate-spin' : ''}`} />
                    <span>{isResyncingAccess ? 'Resyncing...' : 'Resync & Repair Access'}</span>
                  </button>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* Single User Delete Confirmation Modal */}
      {userToDelete && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <div className="bg-white border border-[#D9E2EC] w-full max-w-md rounded-[6px] p-6 shadow-xl space-y-4">
            <div className="flex items-center space-x-2 text-[#B42318]">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <h3 className="text-sm font-bold">Permanently Delete User</h3>
            </div>

            <p className="text-xs text-[#52606D] leading-relaxed">
              You are about to delete user profile{' '}
              <strong className="text-[#0B2545] font-mono">{userToDelete.email}</strong>. Their Firebase
              Authentication account will be deleted, refresh tokens revoked, and pending invitations removed.
            </p>

            <div className="p-3 bg-[#F5F7FA] border border-[#D9E2EC] rounded-[6px] text-[11px] text-[#52606D] space-y-1">
              <div className="font-semibold text-[#0B2545]">Statutory GST Audit Protection:</div>
              <div>• Past audit log records, invoice approvals, and queries made by this user are preserved.</div>
              <div>
                • If this user is associated with an Indian GST Vendor, the vendor master and invoices are NOT
                deleted.
              </div>
              <div>• This email can be re-invited as a fresh user in the future.</div>
            </div>

            {deleteUserError && (
              <div className="p-3 bg-[#FEF3F2] border border-[#FECDCA] rounded-[6px] text-[#B42318] text-xs">
                {deleteUserError}
              </div>
            )}

            <form onSubmit={handleExecuteDeleteUser} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">
                  To confirm, type the user&apos;s exact email{' '}
                  <strong className="text-[#0B2545]">{userToDelete.email}</strong>:
                </label>
                <input
                  type="text"
                  value={deleteUserConfirmEmail}
                  onChange={(e) => setDeleteUserConfirmEmail(e.target.value)}
                  placeholder={userToDelete.email}
                  required
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">
                  Reason for Deletion (Optional)
                </label>
                <input
                  type="text"
                  value={deleteUserReason}
                  onChange={(e) => setDeleteUserReason(e.target.value)}
                  placeholder="e.g. Employee offboarded; test user account cleanup."
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setUserToDelete(null)}
                  className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={
                    deleteUserConfirmEmail.trim().toLowerCase() !== userToDelete.email.trim().toLowerCase()
                  }
                  className="px-4 py-1.5 bg-[#B42318] hover:bg-[#8F1A12] text-white font-medium rounded-[6px] text-xs transition disabled:opacity-40"
                >
                  Permanently Delete User
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Bulk Delete Users Confirmation Modal */}
      {showBulkDeleteUserModal && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <div className="bg-white border border-[#D9E2EC] w-full max-w-md rounded-[6px] p-6 shadow-xl space-y-4">
            <div className="flex items-center space-x-2 text-[#B42318]">
              <AlertCircle className="w-5 h-5 shrink-0" />
              <h3 className="text-sm font-bold">Bulk Delete Users</h3>
            </div>

            <p className="text-xs text-[#52606D] leading-relaxed">
              You have selected <strong className="text-[#0B2545]">{selectedUserUids.length}</strong>{' '}
              user(s) for permanent deletion. Their profiles and Firebase Auth credentials will be removed.
              Historical audit trails will remain preserved.
            </p>

            {bulkDeleteUserError && (
              <div className="p-3 bg-[#FEF3F2] border border-[#FECDCA] rounded-[6px] text-[#B42318] text-xs">
                {bulkDeleteUserError}
              </div>
            )}

            <form onSubmit={handleExecuteBulkDeleteUsers} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">
                  To confirm, type{' '}
                  <strong className="text-[#0B2545] font-mono">DELETE {selectedUserUids.length}</strong>:
                </label>
                <input
                  type="text"
                  value={bulkDeleteUserConfirmText}
                  onChange={(e) => setBulkDeleteUserConfirmText(e.target.value)}
                  placeholder={`DELETE ${selectedUserUids.length}`}
                  required
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-[#1F2933] mb-1">
                  Reason for Bulk Deletion (Optional)
                </label>
                <input
                  type="text"
                  value={bulkDeleteUserReason}
                  onChange={(e) => setBulkDeleteUserReason(e.target.value)}
                  placeholder="e.g. Mass cleanup of inactive or test user accounts."
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>

              <div className="flex justify-end space-x-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowBulkDeleteUserModal(false)}
                  className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs font-medium"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={
                    bulkDeleteUserConfirmText.trim().toUpperCase() !== `DELETE ${selectedUserUids.length}`
                  }
                  className="px-4 py-1.5 bg-[#B42318] hover:bg-[#8F1A12] text-white font-medium rounded-[6px] text-xs transition disabled:opacity-40"
                >
                  Bulk Delete Users
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Resolve Duplicate Profiles Modal */}
      {duplicateModalUser && (
        <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4">
          <div className="bg-white border border-[#D9E2EC] w-full max-w-lg rounded-[6px] p-6 shadow-xl space-y-4">
            <div className="flex items-center space-x-2 text-[#6929C4]">
              <GitMerge className="w-5 h-5 shrink-0" />
              <h3 className="text-sm font-bold text-[#0B2545]">Resolve Duplicate User Profiles</h3>
            </div>

            <p className="text-xs text-[#52606D] leading-relaxed">
              Multiple profiles were detected matching the canonical Gmail address{' '}
              <strong className="text-[#0B2545] font-mono">
                {getCanonicalEmail(duplicateModalUser.email)}
              </strong>
              . Select the authoritative profile to keep as the primary active record. Secondary profiles
              will be merged and archived.
            </p>

            <div className="space-y-2 border border-[#D9E2EC] rounded-[6px] p-3 max-h-60 overflow-y-auto">
              {(canonicalEmailMap.get(getCanonicalEmail(duplicateModalUser.email)) || []).map((prof) => (
                <label
                  key={prof.uid}
                  className={`flex items-start space-x-3 p-2.5 rounded-[4px] border cursor-pointer transition ${
                    duplicateKeepUid === prof.uid
                      ? 'border-[#1F4E9C] bg-[#EBF1FA]/60'
                      : 'border-[#D9E2EC] hover:bg-[#F5F7FA]'
                  }`}
                >
                  <input
                    type="radio"
                    name="duplicateKeep"
                    value={prof.uid}
                    checked={duplicateKeepUid === prof.uid}
                    onChange={() => setDuplicateKeepUid(prof.uid)}
                    className="mt-1 text-[#1F4E9C]"
                  />
                  <div className="text-xs flex-1">
                    <div className="flex items-center space-x-2">
                      <strong className="text-[#0B2545]">{prof.email}</strong>
                      <span
                        className={`px-1.5 py-0.2 rounded text-[10px] font-bold ${
                          prof.status === 'ACTIVE' ? 'badge-pass' : 'badge-fail'
                        }`}
                      >
                        {prof.status}
                      </span>
                      <span className="badge-info text-[10px]">{prof.role}</span>
                    </div>
                    <div className="text-[11px] text-[#52606D] font-mono mt-0.5">
                      UID: {prof.uid} | Last Login:{' '}
                      {prof.lastLoginAt ? new Date(prof.lastLoginAt).toLocaleString('en-IN') : 'Never'}
                    </div>
                  </div>
                </label>
              ))}
            </div>

            <div className="flex justify-end space-x-2 pt-2">
              <button
                type="button"
                onClick={() => setDuplicateModalUser(null)}
                className="px-3 py-1.5 bg-white text-[#52606D] border border-[#D9E2EC] rounded-[6px] text-xs font-medium"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExecuteResolveDuplicate}
                className="px-4 py-1.5 bg-[#1F4E9C] hover:bg-[#173B77] text-white font-medium rounded-[6px] text-xs transition shadow-sm"
              >
                Confirm & Merge Profiles
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add Vendor Master Modal */}
      <AddVendorModal
        isOpen={showAddVendorModal}
        onClose={() => setShowAddVendorModal(false)}
        onVendorCreated={handleVendorCreated}
        adminUid={currentUser?.uid}
      />

      {/* Edit Vendor Master Modal */}
      {showEditVendorModal && editingVendorMaster && (
        <EditVendorModal
          isOpen={showEditVendorModal}
          onClose={() => {
            setShowEditVendorModal(false);
            setEditingVendorMaster(null);
          }}
          vendor={editingVendorMaster}
          onVendorUpdated={handleVendorUpdated}
          adminUid={currentUser?.uid}
        />
      )}

    </div>
  );
};

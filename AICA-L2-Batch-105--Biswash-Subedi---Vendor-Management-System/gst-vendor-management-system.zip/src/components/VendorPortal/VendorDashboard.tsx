/**
 * Vendor Portal Dashboard
 * View invoice status, open queries, upload new invoices, and resubmit.
 * Restyled with ICAI-inspired theme: White cards, Navy #0B2545, Blue #1F4E9C, WCAG AA badges.
 */

import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { InvoiceRecord } from '../../types/index.ts';
import { VendorUploadModal } from './VendorUploadModal.tsx';
import {
  FileText,
  UploadCloud,
  Clock,
  HelpCircle,
  CheckCircle2,
  AlertTriangle,
  Search,
  Eye,
  Trash2,
  Loader2,
  X,
} from 'lucide-react';

interface VendorDashboardProps {
  onSelectInvoiceForReview: (invoice: InvoiceRecord) => void;
  onOpenClarification: (invoice: InvoiceRecord) => void;
  onOpenUploadModal?: (resubmitInvoice?: InvoiceRecord | null) => void;
}

export const VendorDashboard: React.FC<VendorDashboardProps> = ({
  onSelectInvoiceForReview,
  onOpenClarification,
  onOpenUploadModal,
}) => {
  const { activeVendor, invoices, queries, saveInvoice, deleteInvoice } = useAuth();

  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [resubmittingInvoice, setResubmittingInvoice] = useState<InvoiceRecord | null>(null);
  const [viewingInvoiceParticulars, setViewingInvoiceParticulars] = useState<InvoiceRecord | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [invoiceToDelete, setInvoiceToDelete] = useState<InvoiceRecord | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);

  const handleConfirmDelete = async () => {
    if (!invoiceToDelete) return;
    setIsDeleting(true);
    setDeleteError(null);
    try {
      await deleteInvoice(
        invoiceToDelete.id,
        `Vendor deleted invoice ${invoiceToDelete.invoiceNumber} (Total: ₹${invoiceToDelete.invoiceTotal})`
      );
      setInvoiceToDelete(null);
    } catch (err: any) {
      console.error('Delete invoice error:', err);
      setDeleteError(err.message || 'Failed to delete invoice. Please try again.');
    } finally {
      setIsDeleting(false);
    }
  };

  // Filter invoices for current active vendor
  const vendorInvoices = invoices.filter(
    (inv) => !activeVendor || inv.vendorId === activeVendor.id
  );

  const underReviewCount = vendorInvoices.filter((i) => i.status === 'UNDER_REVIEW' || i.status === 'SUBMITTED' || i.status === 'RESUBMITTED').length;
  const clarificationCount = vendorInvoices.filter((i) => i.status === 'CLARIFICATION_REQUESTED').length;
  const approvedCount = vendorInvoices.filter((i) => i.status === 'APPROVED').length;
  const postedCount = vendorInvoices.filter((i) => i.status === 'POSTED').length;
  const totalValue = vendorInvoices.reduce((acc, i) => acc + (i.invoiceTotal || 0), 0);

  // Queries for active vendor
  const vendorQueries = queries.filter(
    (q) => (!activeVendor || q.vendorId === activeVendor.id) && q.status === 'OPEN'
  );

  const filteredInvoices = vendorInvoices.filter((inv) => {
    if (statusFilter !== 'ALL' && inv.status !== statusFilter) return false;
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      const matchNum = inv.invoiceNumber?.toLowerCase().includes(q);
      const matchPo = inv.poReference?.toLowerCase().includes(q);
      const matchGstin = inv.vendorGstin?.toLowerCase().includes(q);
      return matchNum || matchPo || matchGstin;
    }
    return true;
  });

  const getStatusBadge = (status: InvoiceRecord['status']) => {
    switch (status) {
      case 'UNDER_REVIEW':
      case 'SUBMITTED':
      case 'RESUBMITTED':
        return (
          <span className="badge-warn inline-flex items-center">
            <Clock className="w-3 h-3 mr-1" />
            Under Review
          </span>
        );
      case 'CLARIFICATION_REQUESTED':
        return (
          <span className="badge-fail inline-flex items-center">
            <HelpCircle className="w-3 h-3 mr-1" />
            Clarification Required
          </span>
        );
      case 'APPROVED':
        return (
          <span className="badge-pass inline-flex items-center">
            <CheckCircle2 className="w-3 h-3 mr-1" />
            Approved
          </span>
        );
      case 'POSTED':
        return (
          <span className="badge-info inline-flex items-center">
            <CheckCircle2 className="w-3 h-3 mr-1" />
            Posted in Tally
          </span>
        );
      case 'POSTING_FAILED':
        return (
          <span className="badge-fail inline-flex items-center">
            <AlertTriangle className="w-3 h-3 mr-1" />
            Posting Failed
          </span>
        );
      default:
        return (
          <span className="badge-info inline-flex items-center">
            {status}
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      
      {/* Top Banner / Vendor Master Info */}
      <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-6 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center space-x-2">
            <h2 className="text-xl font-bold text-[#0B2545] tracking-tight">{activeVendor?.legalName}</h2>
            <span className={`px-2 py-0.5 text-xs font-semibold rounded-[4px] ${
              activeVendor?.status === 'ACTIVE'
                ? 'badge-pass'
                : 'badge-warn'
            }`}>
              {activeVendor?.status === 'ACTIVE' ? 'Active GST Vendor' : 'Pending Approval'}
            </span>
            {activeVendor?.isComposition && (
              <span className="px-2 py-0.5 text-xs font-semibold rounded-[4px] bg-[#EBF1FA] text-[#1F4E9C] border border-[#D9E2EC]">
                Composition Scheme
              </span>
            )}
            {activeVendor?.isMsme && (
              <span className="px-2 py-0.5 text-xs font-semibold rounded-[4px] bg-[#EBF1FA] text-[#1F4E9C] border border-[#D9E2EC]">
                MSME Registered
              </span>
            )}
          </div>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-[#52606D] mt-2 font-mono">
            <span>GSTIN: <strong className="text-[#1F2933]">{activeVendor?.gstin}</strong></span>
            <span>•</span>
            <span>PAN: <strong className="text-[#1F2933]">{activeVendor?.pan}</strong></span>
            <span>•</span>
            <span>State: <strong className="text-[#1F2933]">{activeVendor?.stateName} ({activeVendor?.stateCode})</strong></span>
            <span>•</span>
            <span>Turnover: <strong className="text-[#1F2933]">{activeVendor?.turnoverCategory === 'ABOVE_5CR' ? '> ₹5 Crore' : '<= ₹5 Crore'}</strong></span>
          </div>
        </div>

        <button
          onClick={() => {
            if (onOpenUploadModal) {
              onOpenUploadModal(null);
            } else {
              setResubmittingInvoice(null);
              setIsUploadOpen(true);
            }
          }}
          className="inline-flex items-center space-x-2 px-5 py-2.5 bg-[#1F4E9C] hover:bg-[#173B77] text-white text-sm font-medium rounded-[6px] transition shrink-0 shadow-sm"
        >
          <UploadCloud className="w-4 h-4" />
          <span>Upload Tax Invoice</span>
        </button>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-4 shadow-sm">
          <div className="flex items-center justify-between text-xs text-[#52606D]">
            <span>Under Review</span>
            <Clock className="w-4 h-4 text-[#B26A00]" />
          </div>
          <p className="text-2xl font-bold text-[#0B2545] mt-2">{underReviewCount}</p>
          <span className="text-[11px] text-[#B26A00] font-medium">Pending Accounts check</span>
        </div>

        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-4 shadow-sm">
          <div className="flex items-center justify-between text-xs text-[#52606D]">
            <span>Clarifications</span>
            <HelpCircle className="w-4 h-4 text-[#B42318]" />
          </div>
          <p className="text-2xl font-bold text-[#0B2545] mt-2">{clarificationCount}</p>
          <span className="text-[11px] text-[#B42318] font-medium">Needs vendor reply</span>
        </div>

        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-4 shadow-sm">
          <div className="flex items-center justify-between text-xs text-[#52606D]">
            <span>Approved / Tally</span>
            <CheckCircle2 className="w-4 h-4 text-[#1B7F3B]" />
          </div>
          <p className="text-2xl font-bold text-[#0B2545] mt-2">{approvedCount + postedCount}</p>
          <span className="text-[11px] text-[#1B7F3B] font-medium">Ready or Posted</span>
        </div>

        <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-4 shadow-sm">
          <div className="flex items-center justify-between text-xs text-[#52606D]">
            <span>Total Invoiced</span>
            <FileText className="w-4 h-4 text-[#1F4E9C]" />
          </div>
          <p className="text-2xl font-bold text-[#0B2545] mt-2">
            ₹{totalValue.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
          </p>
          <span className="text-[11px] text-[#52606D]">{vendorInvoices.length} invoices submitted</span>
        </div>
      </div>

      {/* Invoice Filter & Search Bar */}
      <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-5 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-[#52606D] absolute left-3 top-2.5" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by invoice #, PO reference..."
              className="w-full pl-9 pr-3 py-1.5 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
            />
          </div>

          <div className="flex items-center space-x-1.5 overflow-x-auto w-full sm:w-auto">
            {['ALL', 'UNDER_REVIEW', 'CLARIFICATION_REQUESTED', 'APPROVED', 'POSTED'].map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-3 py-1 rounded-[6px] text-xs font-medium whitespace-nowrap transition ${
                  statusFilter === st
                    ? 'bg-[#1F4E9C] text-white'
                    : 'bg-[#F5F7FA] text-[#52606D] hover:bg-[#EBF1FA] hover:text-[#0B2545]'
                }`}
              >
                {st.replace(/_/g, ' ')}
              </button>
            ))}
          </div>

        </div>

        {/* Invoices List Table */}
        <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545] font-semibold uppercase tracking-wider text-[11px]">
              <tr>
                <th className="py-2.5 px-4">Invoice #</th>
                <th className="py-2.5 px-4">Date & FY</th>
                <th className="py-2.5 px-4">PO Ref</th>
                <th className="py-2.5 px-4 text-right">Taxable</th>
                <th className="py-2.5 px-4 text-right">GST Total</th>
                <th className="py-2.5 px-4 text-right">Total (INR)</th>
                <th className="py-2.5 px-4">Status</th>
                <th className="py-2.5 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#D9E2EC] font-mono">
              {filteredInvoices.map((inv) => (
                <tr key={inv.id} className="even:bg-[#F5F7FA] hover:bg-[#EBF1FA]/50 transition">
                  <td className="py-3 px-4 font-bold text-[#0B2545]">
                    <div>
                      <span>{inv.invoiceNumber}</span>
                      {inv.currentFileVersion > 1 && (
                        <span className="ml-1.5 text-[10px] px-1.5 py-0.5 bg-[#EBF1FA] text-[#1F4E9C] border border-[#D9E2EC] rounded-[4px] font-sans">
                          v{inv.currentFileVersion}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] text-[#52606D] font-normal font-sans block truncate max-w-xs">
                      {inv.lineItems?.[0]?.description || 'Supply items'}
                    </span>
                  </td>

                  <td className="py-3 px-4 text-[#1F2933]">
                    <div>{inv.invoiceDate}</div>
                    <div className="text-[10px] text-[#52606D] font-sans">FY {inv.financialYear}</div>
                  </td>

                  <td className="py-3 px-4 text-[#1F2933]">
                    {inv.poReference || <span className="text-[#52606D] font-sans">-</span>}
                  </td>

                  <td className="py-3 px-4 text-right text-[#1F2933]">
                    ₹{inv.totalTaxableValue.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </td>

                  <td className="py-3 px-4 text-right text-[#1F2933]">
                    ₹{(inv.totalCgst + inv.totalSgst + inv.totalIgst).toLocaleString('en-IN', {
                      minimumFractionDigits: 2,
                    })}
                  </td>

                  <td className="py-3 px-4 text-right font-bold text-[#1B7F3B] text-sm">
                    ₹{inv.invoiceTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </td>

                  <td className="py-3 px-4 font-sans">
                    {getStatusBadge(inv.status)}
                  </td>

                  <td className="py-3 px-4 text-right font-sans">
                    <div className="flex items-center justify-end space-x-1.5">
                      {inv.status === 'CLARIFICATION_REQUESTED' && (
                        <button
                          onClick={() => onOpenClarification(inv)}
                          className="px-2.5 py-1 bg-[#B42318] hover:bg-[#8F1A12] text-white rounded-[4px] text-xs font-medium transition"
                        >
                          Query Thread
                        </button>
                      )}

                      <button
                        onClick={() => setViewingInvoiceParticulars(inv)}
                        className="p-1.5 bg-white hover:bg-[#F5F7FA] text-[#1F2933] border border-[#D9E2EC] rounded-[4px] transition"
                        title="View Particulars"
                      >
                        <Eye className="w-3.5 h-3.5 text-[#52606D]" />
                      </button>

                      {inv.status === 'CLARIFICATION_REQUESTED' && (
                        <button
                          onClick={() => {
                            if (onOpenUploadModal) {
                              onOpenUploadModal(inv);
                            } else {
                              setResubmittingInvoice(inv);
                              setIsUploadOpen(true);
                            }
                          }}
                          className="px-2.5 py-1 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[4px] text-xs font-medium transition"
                        >
                          Upload v{(inv.currentFileVersion || 1) + 1}
                        </button>
                      )}

                      <button
                        onClick={() => {
                          setInvoiceToDelete(inv);
                          setDeleteError(null);
                        }}
                        className="p-1.5 bg-white hover:bg-[#FEF3F2] text-[#52606D] hover:text-[#B42318] border border-[#D9E2EC] hover:border-[#FECDCA] rounded-[4px] transition"
                        title={`Delete invoice ${inv.invoiceNumber}`}
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}

              {filteredInvoices.length === 0 && (
                <tr>
                  <td colSpan={8} className="py-8 text-center text-[#52606D] font-sans">
                    No invoices match the selected filter criteria.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

      </div>

      {/* View Invoice Particulars Modal (In-place vendor view without permission issues) */}
      {viewingInvoiceParticulars && (
        <div
          className="fixed inset-0 z-50 overflow-y-auto bg-[#0B2545]/60 flex items-center justify-center p-4"
          onClick={(e) => {
            if (e.target === e.currentTarget) setViewingInvoiceParticulars(null);
          }}
        >
          <div className="bg-white border border-[#D9E2EC] w-full max-w-4xl rounded-[6px] shadow-lg overflow-hidden flex flex-col max-h-[90vh]">
            <div className="px-6 py-4 border-b border-[#D9E2EC] bg-[#F5F7FA] flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <div className="p-2 bg-[#EBF1FA] text-[#1F4E9C] rounded-[4px]">
                  <FileText className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#0B2545] font-mono">
                    Invoice #{viewingInvoiceParticulars.invoiceNumber}
                  </h3>
                  <p className="text-xs text-[#52606D]">
                    Date: {viewingInvoiceParticulars.invoiceDate} (FY {viewingInvoiceParticulars.financialYear})
                  </p>
                </div>
              </div>
              <div className="flex items-center space-x-2">
                <span className="font-sans">{getStatusBadge(viewingInvoiceParticulars.status)}</span>
                <button
                  onClick={() => setViewingInvoiceParticulars(null)}
                  className="text-[#52606D] hover:text-[#0B2545] p-1 rounded"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-6 space-y-6">
              {/* Header Particulars */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-[#F5F7FA] p-4 rounded-[6px] border border-[#D9E2EC] text-xs">
                <div>
                  <h4 className="font-bold text-[#0B2545] mb-2 uppercase tracking-wider text-[11px]">Supplier Information</h4>
                  <p className="font-semibold text-[#1F2933]">{viewingInvoiceParticulars.vendorName}</p>
                  <p className="font-mono text-[#52606D]">GSTIN: {viewingInvoiceParticulars.vendorGstin}</p>
                </div>
                <div>
                  <h4 className="font-bold text-[#0B2545] mb-2 uppercase tracking-wider text-[11px]">Recipient / Buyer</h4>
                  <p className="font-semibold text-[#1F2933]">{viewingInvoiceParticulars.buyerName}</p>
                  <p className="font-mono text-[#52606D]">GSTIN: {viewingInvoiceParticulars.buyerGstin}</p>
                </div>
                <div className="pt-2 border-t border-[#D9E2EC]">
                  <span className="text-[#52606D]">Place of Supply: </span>
                  <span className="font-medium text-[#1F2933]">{viewingInvoiceParticulars.placeOfSupply}</span>
                </div>
                <div className="pt-2 border-t border-[#D9E2EC]">
                  <span className="text-[#52606D]">Reverse Charge (RCM): </span>
                  <span className="font-medium text-[#1F2933]">
                    {viewingInvoiceParticulars.isReverseCharge ? 'Yes (Applicable)' : 'No'}
                  </span>
                </div>
                {viewingInvoiceParticulars.poReference && (
                  <div className="col-span-full pt-1">
                    <span className="text-[#52606D]">PO Reference: </span>
                    <span className="font-medium text-[#1F2933]">{viewingInvoiceParticulars.poReference}</span>
                  </div>
                )}
              </div>

              {/* Line Items Table */}
              <div>
                <h4 className="text-xs font-bold text-[#0B2545] uppercase tracking-wider mb-2">
                  Line Items & Tax heads
                </h4>
                <div className="overflow-x-auto border border-[#D9E2EC] rounded-[6px]">
                  <table className="w-full text-left text-xs font-mono">
                    <thead className="bg-[#F5F7FA] border-b border-[#D9E2EC] text-[#0B2545] font-semibold text-[11px]">
                      <tr>
                        <th className="py-2 px-3">#</th>
                        <th className="py-2 px-3">Description</th>
                        <th className="py-2 px-3">HSN/SAC</th>
                        <th className="py-2 px-3 text-right">Qty</th>
                        <th className="py-2 px-3 text-right">Rate</th>
                        <th className="py-2 px-3 text-right">Taxable</th>
                        <th className="py-2 px-3 text-right">CGST</th>
                        <th className="py-2 px-3 text-right">SGST</th>
                        <th className="py-2 px-3 text-right">IGST</th>
                        <th className="py-2 px-3 text-right">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[#D9E2EC]">
                      {(viewingInvoiceParticulars.lineItems || []).map((li, idx) => (
                        <tr key={li.id || idx}>
                          <td className="py-2 px-3 text-[#52606D]">{li.itemNumber || idx + 1}</td>
                          <td className="py-2 px-3 text-[#1F2933] font-sans">{li.description}</td>
                          <td className="py-2 px-3 text-[#1F4E9C] font-semibold">{li.hsnSac}</td>
                          <td className="py-2 px-3 text-right">{li.quantity} {li.uom}</td>
                          <td className="py-2 px-3 text-right">₹{li.rate?.toLocaleString('en-IN')}</td>
                          <td className="py-2 px-3 text-right">₹{li.taxableValue?.toLocaleString('en-IN')}</td>
                          <td className="py-2 px-3 text-right text-[#52606D]">₹{li.cgstAmount?.toLocaleString('en-IN')}</td>
                          <td className="py-2 px-3 text-right text-[#52606D]">₹{li.sgstAmount?.toLocaleString('en-IN')}</td>
                          <td className="py-2 px-3 text-right text-[#52606D]">₹{li.igstAmount?.toLocaleString('en-IN')}</td>
                          <td className="py-2 px-3 text-right font-bold text-[#1B7F3B]">₹{li.total?.toLocaleString('en-IN')}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Total Calculation Summary */}
              <div className="bg-[#F5F7FA] p-4 rounded-[6px] border border-[#D9E2EC] flex justify-end font-mono text-xs">
                <div className="w-72 space-y-1.5">
                  <div className="flex justify-between text-[#52606D]">
                    <span>Taxable Amount:</span>
                    <span>₹{viewingInvoiceParticulars.totalTaxableValue?.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                  </div>
                  <div className="flex justify-between text-[#52606D]">
                    <span>CGST Total:</span>
                    <span>₹{viewingInvoiceParticulars.totalCgst?.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                  </div>
                  <div className="flex justify-between text-[#52606D]">
                    <span>SGST Total:</span>
                    <span>₹{viewingInvoiceParticulars.totalSgst?.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                  </div>
                  <div className="flex justify-between text-[#52606D]">
                    <span>IGST Total:</span>
                    <span>₹{viewingInvoiceParticulars.totalIgst?.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                  </div>
                  {viewingInvoiceParticulars.roundOff ? (
                    <div className="flex justify-between text-[#52606D]">
                      <span>Round Off:</span>
                      <span>₹{viewingInvoiceParticulars.roundOff?.toFixed(2)}</span>
                    </div>
                  ) : null}
                  <div className="flex justify-between font-bold text-sm text-[#0B2545] pt-2 border-t border-[#D9E2EC]">
                    <span>Invoice Total:</span>
                    <span className="text-[#1B7F3B]">₹{viewingInvoiceParticulars.invoiceTotal?.toLocaleString('en-IN', { minimumFractionDigits: 2 })}</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="px-6 py-4 border-t border-[#D9E2EC] bg-[#F5F7FA] flex items-center justify-between">
              {viewingInvoiceParticulars.status === 'CLARIFICATION_REQUESTED' ? (
                <button
                  onClick={() => {
                    const inv = viewingInvoiceParticulars;
                    setViewingInvoiceParticulars(null);
                    onOpenClarification(inv);
                  }}
                  className="px-4 py-2 bg-[#B42318] hover:bg-[#8F1A12] text-white text-xs font-medium rounded-[6px] transition flex items-center space-x-1.5"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  <span>Open Clarification Query Thread</span>
                </button>
              ) : (
                <div />
              )}

              <button
                onClick={() => setViewingInvoiceParticulars(null)}
                className="px-4 py-2 bg-white text-[#52606D] hover:bg-[#F5F7FA] border border-[#D9E2EC] text-xs font-medium rounded-[6px] transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Upload & OCR Modal fallback if not handled by root */}
      {isUploadOpen && !onOpenUploadModal && (
        <VendorUploadModal
          isOpen={isUploadOpen}
          onClose={() => {
            setIsUploadOpen(false);
            setResubmittingInvoice(null);
          }}
          resubmitInvoice={resubmittingInvoice}
          onSuccess={(_newInv) => {
            // Handled asynchronously inside VendorUploadModal with real-time sync
          }}
        />
      )}

      {/* Delete Invoice Confirmation Modal */}
      {invoiceToDelete && (
        <div className="fixed inset-0 z-50 overflow-y-auto bg-[#0B2545]/60 flex items-center justify-center p-4">
          <div className="bg-white border border-[#D9E2EC] w-full max-w-md rounded-[6px] shadow-lg overflow-hidden flex flex-col">
            <div className="px-6 py-4 border-b border-[#D9E2EC] flex items-center justify-between bg-[#F5F7FA]">
              <div className="flex items-center space-x-2 text-[#B42318]">
                <Trash2 className="w-5 h-5" />
                <h3 className="text-base font-bold text-[#0B2545]">Delete Invoice</h3>
              </div>
              <button
                onClick={() => setInvoiceToDelete(null)}
                className="text-[#52606D] hover:text-[#0B2545] p-1 rounded"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              {deleteError && (
                <div className="p-3 bg-[#FEF3F2] border border-[#FECDCA] rounded-[6px] text-[#B42318] text-xs flex items-center space-x-2">
                  <AlertTriangle className="w-4 h-4 shrink-0" />
                  <span>{deleteError}</span>
                </div>
              )}

              <p className="text-sm text-[#1F2933]">
                Are you sure you want to delete invoice <strong className="font-mono text-[#0B2545]">{invoiceToDelete.invoiceNumber}</strong>?
              </p>

              <div className="bg-[#F5F7FA] p-3.5 rounded-[6px] border border-[#D9E2EC] space-y-1.5 text-xs">
                <div className="flex justify-between text-[#52606D]">
                  <span>Invoice Date:</span>
                  <span className="font-mono text-[#1F2933]">{invoiceToDelete.invoiceDate}</span>
                </div>
                <div className="flex justify-between text-[#52606D]">
                  <span>Total Amount:</span>
                  <span className="font-mono font-bold text-[#0B2545]">
                    ₹{invoiceToDelete.invoiceTotal.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </span>
                </div>
                <div className="flex justify-between text-[#52606D]">
                  <span>Current Status:</span>
                  <span className="font-medium text-[#1F4E9C]">{invoiceToDelete.status}</span>
                </div>
              </div>

              <div className="p-3 bg-[#FEF3F2] rounded-[6px] border border-[#FECDCA] text-xs text-[#B42318] space-y-1">
                <p className="font-semibold">Irreversible Action Notice:</p>
                <p>
                  Deleting this invoice will permanently remove it from the Accounts Review queue along with any clarification thread history.
                </p>
                {invoiceToDelete.status === 'POSTED' && (
                  <p className="font-medium mt-1">
                    Note: This invoice was already posted in Tally Prime. Deleting here removes it from this portal only.
                  </p>
                )}
              </div>
            </div>

            <div className="px-6 py-3 border-t border-[#D9E2EC] bg-[#F5F7FA] flex items-center justify-end space-x-3">
              <button
                type="button"
                onClick={() => setInvoiceToDelete(null)}
                disabled={isDeleting}
                className="px-4 py-2 bg-white text-[#52606D] hover:bg-[#F5F7FA] border border-[#D9E2EC] text-xs font-medium rounded-[6px] transition disabled:opacity-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                disabled={isDeleting}
                className="flex items-center space-x-1.5 px-4 py-2 bg-[#B42318] hover:bg-[#8F1A12] text-white text-xs font-medium rounded-[6px] transition shadow-sm disabled:opacity-50"
              >
                {isDeleting ? (
                  <>
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>Deleting...</span>
                  </>
                ) : (
                  <>
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Delete Invoice</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
};

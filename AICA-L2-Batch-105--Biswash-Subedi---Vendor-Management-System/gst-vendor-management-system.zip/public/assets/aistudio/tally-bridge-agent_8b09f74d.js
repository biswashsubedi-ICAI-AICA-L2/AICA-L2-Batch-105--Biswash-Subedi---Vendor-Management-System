/**
 * Standalone Tally Prime Bridge Connector Agent (Node.js)
 * Connects GST VMS Portal to local Tally Prime XML Server on http://localhost:9000
 *
 * Usage / Command Line:
 *   node tally-bridge-agent.js
 *   node tally-bridge-agent.js --file="Tally_Purchase_Inv_1234.xml"
 *   node tally-bridge-agent.js --cookie="YOUR_BROWSER_COOKIE"
 */

const fs = require('fs');
const path = require('path');
const http = require('http');

const args = process.argv.slice(2);
const positionalArgs = args.filter(a => !a.startsWith('--'));

const VMS_BASE_URL = positionalArgs[0] || process.env.VMS_URL || 'https://ais-dev-kvrjycbxhxkroyewtdlmxj-782860110704.asia-east1.run.app';
const AGENT_TOKEN = positionalArgs[1] || process.env.AGENT_TOKEN || 'vms_tally_sec_token_98765';
const TALLY_URL = positionalArgs[2] || process.env.TALLY_URL || 'http://localhost:9000';
const LOCAL_RELAY_PORT = 9095;

const IS_FORCE_ALL = args.includes('--all') || args.includes('--force');
const INVOICE_PARAM = (args.find(a => a.startsWith('--invoice=')) || '').replace('--invoice=', '') || null;
const REQUEUE_PARAM = (args.find(a => a.startsWith('--requeue=')) || '').replace('--requeue=', '') || null;
const COOKIE_PARAM = (args.find(a => a.startsWith('--cookie=')) || '').replace('--cookie=', '') || process.env.VMS_COOKIE || null;
const FILE_PARAM = (args.find(a => a.startsWith('--file=')) || '').replace('--file=', '') || null;

const POLL_INTERVAL_MS = 15000;

console.log('\n================================================================');
console.log('🇮🇳  GST VMS - Tally Prime XML Bridge Connector Agent');
console.log('================================================================');
console.log('  Tally Server      : ' + TALLY_URL);
console.log('  Local Bridge Port : http://127.0.0.1:' + LOCAL_RELAY_PORT);
console.log('  VMS Portal URL    : ' + VMS_BASE_URL);
if (COOKIE_PARAM) {
  console.log('  Session Cookie    : Configured');
}
console.log('================================================================\n');

async function postXmlToTally(xmlContent) {
  const res = await fetch(TALLY_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'text/xml;charset=utf-8' },
    body: xmlContent,
  });
  return await res.text();
}

/**
 * 1. Automatic Scan for Local Tally XML Files in Current Working Directory
 */
async function processLocalXmlFiles() {
  try {
    const cwd = process.cwd();
    const files = fs.readdirSync(cwd).filter(f => f.toLowerCase().endsWith('.xml'));
    const tallyVoucherFiles = files.filter(f => {
      try {
        const snippet = fs.readFileSync(path.join(cwd, f), 'utf8').slice(0, 500);
        return snippet.includes('<TALLYREQUEST>') || snippet.includes('<ENVELOPE>') || snippet.includes('<VOUCHER');
      } catch (e) {
        return false;
      }
    });

    if (tallyVoucherFiles.length > 0) {
      console.log(`📂 Found ${tallyVoucherFiles.length} Tally XML voucher file(s) in current directory (${cwd}):`);
      for (const fileName of tallyVoucherFiles) {
        const fullPath = path.join(cwd, fileName);
        const xml = fs.readFileSync(fullPath, 'utf8');
        console.log(`\n-> Importing file: "${fileName}" into Tally Prime...`);
        try {
          const tallyRes = await postXmlToTally(xml);
          const isOk =
            tallyRes.includes('<CREATED>1</CREATED>') ||
            tallyRes.includes('<ALTERED>1</ALTERED>') ||
            (!tallyRes.includes('<ERRORS>') && !tallyRes.includes('<LINEERROR>') && !tallyRes.includes('<EXCEPTION>'));

          if (isOk) {
            console.log(`   ✅ [SUCCESS] Imported into Tally Prime! (Response: ${tallyRes.replace(/\s+/g, ' ').slice(0, 150)})`);
          } else {
            console.error(`   ❌ [REJECTED] Tally reported issue: ${tallyRes.replace(/\s+/g, ' ').slice(0, 250)}`);
          }
        } catch (postErr) {
          console.error(`   ❌ Failed to connect to Tally Prime on ${TALLY_URL}: ${postErr.message}`);
          console.error('      Make sure Tally Prime is open and F1 -> Settings -> Connectivity -> Port: 9000.');
        }
      }
      console.log('\n----------------------------------------------------------------');
    }
  } catch (err) {
    // Silent directory scan failure
  }
}

/**
 * 2. Start Local HTTP Relay Server on Port 9095
 * Allows the browser portal to directly push vouchers without CORS/SSL barriers!
 */
function startLocalRelayServer() {
  try {
    const server = http.createServer(async (req, res) => {
      // CORS headers allowing preview's exact origin without deprecated private network headers
      const requestOrigin = req.headers['origin'];
      if (requestOrigin) {
        res.setHeader('Access-Control-Allow-Origin', requestOrigin);
        res.setHeader('Vary', 'Origin');
      } else {
        res.setHeader('Access-Control-Allow-Origin', '*');
      }
      res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
      res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, Target-Address-Space, target-address-space');

      if (req.method === 'OPTIONS') {
        res.writeHead(204);
        return res.end();
      }

      if (req.url === '/status' && req.method === 'GET') {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        return res.end(JSON.stringify({ status: 'ONLINE', tallyUrl: TALLY_URL, bridgeVersion: '3.1.0' }));
      }

      if (req.url === '/import-xml' && req.method === 'POST') {
        let body = '';
        req.on('data', chunk => { body += chunk; });
        req.on('end', async () => {
          try {
            let xml = body;
            try {
              const parsed = JSON.parse(body);
              if (parsed && typeof parsed.xml === 'string') xml = parsed.xml;
            } catch (e) {}

            console.log(`\n📥 Received voucher push from VMS Web Portal (${Buffer.byteLength(xml)} bytes)...`);
            console.log(`   Forwarding to Tally Prime on ${TALLY_URL}...`);
            const tallyReply = await postXmlToTally(xml);

            // Confirm CREATED > 0 or ALTERED > 0 from Tally Prime
            const createdMatch = tallyReply.match(/<CREATED>(\d+)<\/CREATED>/i);
            const alteredMatch = tallyReply.match(/<ALTERED>(\d+)<\/ALTERED>/i);
            const createdCount = createdMatch ? parseInt(createdMatch[1], 10) : 0;
            const alteredCount = alteredMatch ? parseInt(alteredMatch[1], 10) : 0;
            const errorsMatch = tallyReply.match(/<ERRORS>(\d+)<\/ERRORS>/i);
            const errorCount = errorsMatch ? parseInt(errorsMatch[1], 10) : 0;
            const hasLineError = tallyReply.includes('<LINEERROR>') || tallyReply.includes('<EXCEPTION>');

            const isOk = (createdCount > 0 || alteredCount > 0) && errorCount === 0 && !hasLineError;

            // Extract genuine Tally GUID / ID if present in reply
            const guidMatch = tallyReply.match(/<GUID>(.*?)<\/GUID>/i) || tallyReply.match(/<LASTVCHID>(.*?)<\/LASTVCHID>/i);
            const voucherGuid = guidMatch ? guidMatch[1].trim() : undefined;
            const vchNoMatch = tallyReply.match(/<VOUCHERNUMBER>(.*?)<\/VOUCHERNUMBER>/i);
            const voucherNumber = vchNoMatch ? vchNoMatch[1].trim() : undefined;

            if (isOk) {
              console.log(`   ✅ Successfully posted voucher into Tally Prime ERP! (Created: ${createdCount}, Altered: ${alteredCount})`);
              res.writeHead(200, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({
                success: true,
                created: createdCount,
                altered: alteredCount,
                voucherGuid: voucherGuid || undefined,
                voucherNumber: voucherNumber || undefined,
                tallyReply: tallyReply.slice(0, 500)
              }));
            } else {
              console.warn('   ⚠️ Tally rejected or did not confirm creation: ' + tallyReply.slice(0, 300).replace(/\s+/g, ' '));
              res.writeHead(422, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({
                success: false,
                created: createdCount,
                altered: alteredCount,
                error: hasLineError
                  ? 'Tally reported line error (ledger not found or configuration issue).'
                  : (errorCount > 0 ? `Tally reported ${errorCount} error(s).` : 'Tally did not confirm voucher creation (CREATED: 0, ALTERED: 0).'),
                tallyReply: tallyReply.slice(0, 500)
              }));
            }
          } catch (err) {
            console.error('   ❌ Relay error to Tally Prime:', err.message);
            res.writeHead(502, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({
              success: false,
              error: `Could not connect to Tally Prime on ${TALLY_URL} (${err.message}). Ensure Tally Prime is running with ODBC/XML port 9000 enabled.`
            }));
          }
        });
        return;
      }

      res.writeHead(404);
      res.end('Not Found');
    });

    server.listen(LOCAL_RELAY_PORT, '127.0.0.1', () => {
      console.log(`⚡ Local Relay Server active at http://127.0.0.1:${LOCAL_RELAY_PORT}`);
      console.log('   You can now click "Push to Tally" in your VMS Portal browser tab anytime!\n');
    });

    server.on('error', (err) => {
      if (err.code === 'EADDRINUSE') {
        console.log(`ℹ️  Local Relay port ${LOCAL_RELAY_PORT} is already running.`);
      }
    });
  } catch (e) {}
}

/**
 * 3. Specific File Mode
 */
if (FILE_PARAM) {
  (async () => {
    try {
      if (!fs.existsSync(FILE_PARAM)) {
        console.error(`\n❌ Error: File not found: ${FILE_PARAM}`);
        process.exit(1);
      }
      const xml = fs.readFileSync(FILE_PARAM, 'utf8');
      console.log(`\n📄 Sending "${FILE_PARAM}" to Tally Prime on ${TALLY_URL}...`);
      const reply = await postXmlToTally(xml);
      console.log('   Tally response: ' + reply.replace(/\s+/g, ' ').slice(0, 250));
    } catch (e) {
      console.error(`\n❌ Connection error: ${e.message}`);
    }
    process.exit(0);
  })();
}

function getRequestHeaders() {
  const headers = {
    'Authorization': 'Bearer ' + AGENT_TOKEN,
  };
  if (COOKIE_PARAM) {
    headers['Cookie'] = COOKIE_PARAM;
  }
  return headers;
}

let cloudAuthNoticeShown = false;

/**
 * 4. Cloud Polling Function
 */
async function pollCloud() {
  if (FILE_PARAM) return;

  try {
    let pendingUrl = VMS_BASE_URL + '/agent/invoices/pending';
    const qParams = [];
    if (IS_FORCE_ALL) qParams.push('all=true');
    if (INVOICE_PARAM) qParams.push('invoice=' + encodeURIComponent(INVOICE_PARAM));
    if (qParams.length > 0) pendingUrl += '?' + qParams.join('&');

    const res = await fetch(pendingUrl, {
      headers: getRequestHeaders(),
    });

    const rawText = await res.text();

    let data;
    try {
      data = JSON.parse(rawText);
    } catch (parseErr) {
      if (!cloudAuthNoticeShown) {
        cloudAuthNoticeShown = true;
        console.log('\n🔒 [Google AI Studio Cloud Ingress Protected]');
        console.log('   The cloud preview URL requires browser authentication session cookies.');
        console.log('   Don\'t worry! You have 3 instant ways to import your vouchers:\n');
        console.log('   👉 WAY 1 (1-Click in Browser - Recommended):');
        console.log('      Open the VMS Portal tab in your browser and click "Push to Tally".');
        console.log('      Since this agent is running, it will instantly relay it to Tally Prime!\n');
        console.log('   👉 WAY 2 (Auto-Scan Local XML):');
        console.log('      Click "Download XML" on Inv 1234 in the portal. It saves into your Downloads folder.');
        console.log('      This agent automatically detects any downloaded *.xml files and pushes them!\n');
        console.log('   👉 WAY 3 (Native Alt+O Import in Tally):');
        console.log('      In Tally Prime, press Alt+O (Import) -> Transactions -> select the downloaded XML.\n');
        console.log('   Ready and listening on local port 9095 for browser sync...\n');
      }
      return;
    }

    const list = data.invoices || [];
    if (list.length > 0) {
      console.log(`\n📥 Received ${list.length} approved voucher(s) from cloud portal!`);
      for (const inv of list) {
        console.log(`-> Sending Invoice #${inv.invoiceNumber} to Tally Prime...`);
        try {
          const tallyRes = await postXmlToTally(inv.tallyXml);
          console.log(`   ✅ Tally imported: ${tallyRes.replace(/\s+/g, ' ').slice(0, 150)}`);
        } catch (e) {
          console.error(`   ❌ Tally error: ${e.message}`);
        }
      }
    }
  } catch (e) {
    // Silent polling catch
  }
}

// Execute auto-scan, start relay, and run polling
(async () => {
  await processLocalXmlFiles();
  startLocalRelayServer();
  setInterval(processLocalXmlFiles, 10000); // Check for newly downloaded XML files every 10s
  setInterval(pollCloud, POLL_INTERVAL_MS);
  pollCloud();
})();

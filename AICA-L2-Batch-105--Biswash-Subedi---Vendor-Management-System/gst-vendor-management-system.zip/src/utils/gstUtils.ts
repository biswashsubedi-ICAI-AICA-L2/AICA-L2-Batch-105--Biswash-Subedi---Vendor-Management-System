/**
 * Indian Goods and Services Tax (GST) Utilities
 * Covers GSTIN validation, checksum, state codes, and statutory rule definitions.
 */

// Official 2-digit Indian GST State / UT Codes
export const GST_STATE_CODES: Record<string, string> = {
  '01': 'Jammu & Kashmir',
  '02': 'Himachal Pradesh',
  '03': 'Punjab',
  '04': 'Chandigarh',
  '05': 'Uttarakhand',
  '06': 'Haryana',
  '07': 'Delhi',
  '08': 'Rajasthan',
  '09': 'Uttar Pradesh',
  '10': 'Bihar',
  '11': 'Sikkim',
  '12': 'Arunachal Pradesh',
  '13': 'Nagaland',
  '14': 'Manipur',
  '15': 'Mizoram',
  '16': 'Tripura',
  '17': 'Meghalaya',
  '18': 'Assam',
  '19': 'West Bengal',
  '20': 'Jharkhand',
  '21': 'Odisha',
  '22': 'Chhattisgarh',
  '23': 'Madhya Pradesh',
  '24': 'Gujarat',
  '25': 'Daman and Diu',
  '26': 'Dadra and Nagar Haveli and Daman and Diu',
  '27': 'Maharashtra',
  '28': 'Andhra Pradesh (Old)',
  '29': 'Karnataka',
  '30': 'Goa',
  '31': 'Lakshadweep',
  '32': 'Kerala',
  '33': 'Tamil Nadu',
  '34': 'Puducherry',
  '35': 'Andaman & Nicobar Islands',
  '36': 'Telangana',
  '37': 'Andhra Pradesh (New)',
  '38': 'Ladakh',
  '97': 'Other Territory',
};

// Common Indian HSN and SAC Code Master with prescribed GST Rates
export const DEFAULT_HSN_SAC_MASTER: Array<{
  code: string;
  description: string;
  gstRate: number;
  type: 'GOODS' | 'SERVICES';
}> = [
  { code: '998311', description: 'Management consulting and management services', gstRate: 18, type: 'SERVICES' },
  { code: '998313', description: 'Information technology (IT) consulting and support services', gstRate: 18, type: 'SERVICES' },
  { code: '998314', description: 'Information technology (IT) design and development services', gstRate: 18, type: 'SERVICES' },
  { code: '998319', description: 'Other information technology services n.e.c.', gstRate: 18, type: 'SERVICES' },
  { code: '998221', description: 'Accounting, auditing and bookkeeping services', gstRate: 18, type: 'SERVICES' },
  { code: '998211', description: 'Legal advisory and representation services', gstRate: 18, type: 'SERVICES' },
  { code: '998711', description: 'Maintenance and repair services of commercial buildings', gstRate: 18, type: 'SERVICES' },
  { code: '996511', description: 'Road transport services of goods by freight', gstRate: 5, type: 'SERVICES' },
  { code: '847130', description: 'Portable automatic data processing machines (Laptops/Notebooks)', gstRate: 18, type: 'GOODS' },
  { code: '847141', description: 'Other automatic data processing machines (Desktops/Servers)', gstRate: 18, type: 'GOODS' },
  { code: '852852', description: 'Monitors capable of connecting to automatic data processing machine', gstRate: 18, type: 'GOODS' },
  { code: '851762', description: 'Machines for reception, conversion and transmission of voice/data (Routers/Switches)', gstRate: 18, type: 'GOODS' },
  { code: '4802', description: 'Uncoated paper used for writing, printing or graphic purposes', gstRate: 12, type: 'GOODS' },
  { code: '940310', description: 'Metal furniture of a kind used in offices', gstRate: 18, type: 'GOODS' },
  { code: '9405', description: 'Lamps and lighting fittings (LED bulbs, tubes)', gstRate: 12, type: 'GOODS' },
  { code: '844332', description: 'Printers, facsimile machines, whether or not combined', gstRate: 18, type: 'GOODS' },
  { code: '850440', description: 'Static converters (UPS, inverters, power adapters)', gstRate: 18, type: 'GOODS' },
  { code: '996331', description: 'Restaurant and catering services', gstRate: 5, type: 'SERVICES' }
];

/**
 * Standard Indian GSTIN Regex:
 * 2 digits state code
 * 10 char PAN (5 uppercase letters, 4 digits, 1 uppercase letter)
 * 1 entity number (1-9 or A-Z)
 * 'Z' default 14th character
 * 1 alphanumeric checksum character
 */
export const GSTIN_REGEX = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
export const PAN_REGEX = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;

const GST_CHARS = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';

/**
 * Computes official Mod 36 checksum for a 14-character GSTIN prefix
 * based on ISO 7064 Mod 36, 36 standard adapted by GSTN.
 */
export function calculateGstinChecksum(gstin14: string): string {
  if (gstin14.length < 14) return '';
  const clean = gstin14.toUpperCase().slice(0, 14);

  let sum = 0;
  for (let i = 0; i < 14; i++) {
    const char = clean[i];
    const val = GST_CHARS.indexOf(char);
    if (val === -1) return '';
    // Alternating factor: 1 for odd index (0-based: 0, 2, 4...), 2 for even index (1, 3, 5...)
    const factor = (i % 2 === 0) ? 1 : 2;
    const product = val * factor;
    // Quotient + Remainder of product / 36
    const digit = Math.floor(product / 36) + (product % 36);
    sum += digit;
  }

  const remainder = sum % 36;
  const checkCodePoint = (36 - remainder) % 36;
  return GST_CHARS[checkCodePoint] || '';
}

/**
 * Validates 15-character GSTIN format, state code, and checksum.
 */
export function validateGSTIN(gstin: string): {
  isValid: boolean;
  stateCode: string;
  stateName: string;
  pan: string;
  reason?: string;
} {
  if (!gstin) {
    return { isValid: false, stateCode: '', stateName: '', pan: '', reason: 'GSTIN is empty.' };
  }

  const clean = gstin.trim().toUpperCase();

  if (clean.length !== 15) {
    return {
      isValid: false,
      stateCode: '',
      stateName: '',
      pan: '',
      reason: `GSTIN must be exactly 15 characters (provided ${clean.length}).`
    };
  }

  if (!GSTIN_REGEX.test(clean)) {
    return {
      isValid: false,
      stateCode: '',
      stateName: '',
      pan: '',
      reason: 'GSTIN pattern invalid. Expected format: 2-digit state + 10-char PAN + 1-char entity + "Z" + 1-char checksum.'
    };
  }

  const stateCode = clean.substring(0, 2);
  const stateName = GST_STATE_CODES[stateCode];
  if (!stateName) {
    return {
      isValid: false,
      stateCode,
      stateName: 'Unknown State',
      pan: '',
      reason: `State code "${stateCode}" is not a recognized Indian State or Union Territory.`
    };
  }

  const pan = clean.substring(2, 12);
  const expectedChecksum = calculateGstinChecksum(clean.slice(0, 14));
  const actualChecksum = clean[14];

  if (expectedChecksum && actualChecksum !== expectedChecksum) {
    return {
      isValid: false,
      stateCode,
      stateName,
      pan,
      reason: `Checksum digit mismatch: expected '${expectedChecksum}', got '${actualChecksum}'.`
    };
  }

  return {
    isValid: true,
    stateCode,
    stateName,
    pan
  };
}

/**
 * Derive Indian Financial Year from Date (e.g. 2026-05-15 -> "2026-27")
 * In India, FY runs from April 1 to March 31.
 */
export function getIndianFinancialYear(dateString: string): string {
  const d = new Date(dateString);
  if (isNaN(d.getTime())) {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth(); // 0-indexed, 3 = April
    return month >= 3 ? `${year}-${String(year + 1).slice(-2)}` : `${year - 1}-${String(year).slice(-2)}`;
  }
  const year = d.getFullYear();
  const month = d.getMonth(); // 0 = Jan, 3 = Apr
  return month >= 3 ? `${year}-${String(year + 1).slice(-2)}` : `${year - 1}-${String(year).slice(-2)}`;
}

/**
 * Extract state code from place of supply string, e.g. "27-Maharashtra" or "Maharashtra"
 */
export function extractStateCode(pos: string): string | null {
  if (!pos) return null;
  const match = pos.match(/^(\d{2})/);
  if (match) return match[1];

  const lower = pos.toLowerCase();
  for (const [code, name] of Object.entries(GST_STATE_CODES)) {
    if (lower.includes(name.toLowerCase())) return code;
  }
  return null;
}

/**
 * Extract clean State Name from place of supply, e.g. "27-Maharashtra" -> "Maharashtra", "10 - Bihar" -> "Bihar"
 */
export function extractStateName(pos: string | null | undefined): string {
  if (!pos) return 'Maharashtra';
  const clean = String(pos).trim();

  // If in "27-Maharashtra" format
  if (clean.includes('-')) {
    const parts = clean.split('-');
    return parts.slice(1).join('-').trim() || clean;
  }

  // If 2-digit code
  if (/^\d{2}$/.test(clean) && GST_STATE_CODES[clean]) {
    return GST_STATE_CODES[clean];
  }

  return clean;
}

/**
 * Normalizes any Place of Supply string ("10 - Bihar", "10", "Bihar", "27-Maharashtra", etc.)
 * to the exact `<select>` option format `${code}-${name}` (e.g. "10-Bihar", "27-Maharashtra")
 */
export function normalizePlaceOfSupply(pos: string | null | undefined): string {
  if (!pos) return '27-Maharashtra';
  const clean = String(pos).trim();

  // Check if already in `${code}-${name}` format matching an option exactly
  for (const [code, name] of Object.entries(GST_STATE_CODES)) {
    if (clean === `${code}-${name}`) {
      return clean;
    }
  }

  // Check if format is "27 - Maharashtra" (with spaces around hyphen)
  const spacedMatch = clean.match(/^(\d{2})\s*-\s*(.+)$/);
  if (spacedMatch) {
    const code = spacedMatch[1];
    const name = GST_STATE_CODES[code] || spacedMatch[2].trim();
    return `${code}-${name}`;
  }

  // Check if only 2-digit code
  if (/^\d{2}$/.test(clean) && GST_STATE_CODES[clean]) {
    return `${clean}-${GST_STATE_CODES[clean]}`;
  }

  // Check by state name matching
  const lower = clean.toLowerCase();
  for (const [code, name] of Object.entries(GST_STATE_CODES)) {
    const nameLower = name.toLowerCase();
    if (lower === nameLower || lower.includes(nameLower) || nameLower.includes(lower)) {
      return `${code}-${name}`;
    }
  }

  // Fallback to code if leading 2 digits exist
  const codeMatch = clean.match(/^(\d{2})/);
  if (codeMatch && GST_STATE_CODES[codeMatch[1]]) {
    return `${codeMatch[1]}-${GST_STATE_CODES[codeMatch[1]]}`;
  }

  return clean;
}

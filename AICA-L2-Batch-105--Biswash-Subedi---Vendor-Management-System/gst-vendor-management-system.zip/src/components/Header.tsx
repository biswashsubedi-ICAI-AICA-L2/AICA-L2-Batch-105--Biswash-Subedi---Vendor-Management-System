/**
 * Header Component with Role-Based Navigation
 * ICAI-inspired professional palette: Navy #0B2545, Blue #1F4E9C, thin dual accent line.
 * Strict RBAC menu rendering without marketing slogans or emojis.
 */

import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext.tsx';
import {
  FileText,
  Building2,
  LogOut,
  ChevronDown,
  CheckCircle2,
  Unlock,
  RefreshCw,
  LayoutDashboard,
} from 'lucide-react';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenUploadModal?: () => void;
}

export const Header: React.FC<HeaderProps> = ({ activeTab, setActiveTab, onOpenUploadModal }) => {
  const {
    currentUser,
    currentRole,
    activeVendor,
    vendors,
    invoices,
    queries,
    setActiveVendorId,
    signOut,
    triggerSync,
    isSyncing,
  } = useAuth();

  const [showVendorDropdown, setShowVendorDropdown] = useState(false);

  // Compute counts
  const underReviewCount = invoices.filter(
    (i) => i.status === 'UNDER_REVIEW' || i.status === 'SUBMITTED' || i.status === 'RESUBMITTED'
  ).length;

  const vendorQueriesCount = queries.filter(
    (q) => q.status === 'OPEN' && (currentRole !== 'VENDOR' || q.vendorId === activeVendor?.id)
  ).length;

  const approvedTallyCount = invoices.filter(
    (i) => i.status === 'APPROVED' || i.status === 'POSTING_FAILED'
  ).length;

  const canOverride = Boolean(currentUser?.canOverride || currentRole === 'ADMIN');

  return (
    <header className="sticky top-0 z-40 bg-[#0B2545] text-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          
          {/* Brand Identity */}
          <div
            className="flex items-center space-x-3 cursor-pointer shrink-0"
            onClick={() => {
              if (currentRole === 'VENDOR') setActiveTab('vendor-dashboard');
              else if (currentRole === 'ACCOUNTS_EXECUTIVE') setActiveTab('accounts-review-queue');
              else if (currentRole === 'ADMIN') setActiveTab('admin-users');
            }}
          >
            <div className="h-8 w-8 rounded-[6px] bg-[#1F4E9C] flex items-center justify-center text-white shadow-sm">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <span className="font-bold text-sm sm:text-base tracking-tight text-white block">
                GST Vendor Management System
              </span>
            </div>
          </div>

          {/* Role-Specific Navigation Menu */}
          <nav className="hidden lg:flex items-center space-x-1 overflow-x-auto py-2">
            
            {/* 1. VENDOR NAVIGATION */}
            {currentRole === 'VENDOR' && (
              <>
                <button
                  onClick={() => setActiveTab('vendor-dashboard')}
                  className={`inline-flex items-center px-3 py-1.5 rounded-[6px] text-xs font-medium transition ${
                    activeTab === 'vendor-dashboard' ? 'bg-[#1F4E9C] text-white' : 'text-[#D9E2EC] hover:bg-[#173B77]/60'
                  }`}
                  title="My Dashboard"
                >
                  <LayoutDashboard className="w-3.5 h-3.5 mr-1.5 shrink-0" />
                  <span>My Dashboard</span>
                </button>

                <button
                  onClick={() => {
                    setActiveTab('vendor-dashboard');
                    onOpenUploadModal?.();
                  }}
                  className="px-3 py-1.5 rounded-[6px] text-xs font-medium text-white bg-[#1B7F3B] hover:bg-[#14632E] transition"
                >
                  Upload Invoice
                </button>

                <button
                  onClick={() => setActiveTab('vendor-invoices')}
                  className={`px-3 py-1.5 rounded-[6px] text-xs font-medium transition ${
                    activeTab === 'vendor-invoices' ? 'bg-[#1F4E9C] text-white' : 'text-[#D9E2EC] hover:bg-[#173B77]/60'
                  }`}
                >
                  My Invoices
                </button>

                <button
                  onClick={() => setActiveTab('vendor-queries')}
                  className={`relative px-3 py-1.5 rounded-[6px] text-xs font-medium transition ${
                    activeTab === 'vendor-queries' ? 'bg-[#1F4E9C] text-white' : 'text-[#D9E2EC] hover:bg-[#173B77]/60'
                  }`}
                >
                  Queries and Messages
                  {vendorQueriesCount > 0 && (
                    <span className="ml-1.5 px-1.5 py-0.5 bg-[#B42318] text-white text-[10px] font-bold rounded-[4px]">
                      {vendorQueriesCount}
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('vendor-master')}
                  className={`px-3 py-1.5 rounded-[6px] text-xs font-medium transition ${
                    activeTab === 'vendor-master' ? 'bg-[#1F4E9C] text-white' : 'text-[#D9E2EC] hover:bg-[#173B77]/60'
                  }`}
                >
                  My Vendor Profile
                </button>
              </>
            )}

            {/* 2. ACCOUNTS EXECUTIVE NAVIGATION */}
            {currentRole === 'ACCOUNTS_EXECUTIVE' && (
              <>
                <button
                  onClick={() => setActiveTab('accounts-review-queue')}
                  className={`relative px-3 py-1.5 rounded-[6px] text-xs font-medium transition ${
                    activeTab === 'accounts-review-queue' || activeTab === 'accounts-review'
                      ? 'bg-[#1F4E9C] text-white'
                      : 'text-[#D9E2EC] hover:bg-[#173B77]/60'
                  }`}
                >
                  Review Queue
                  {underReviewCount > 0 && (
                    <span className="ml-1.5 px-1.5 py-0.5 bg-[#B26A00] text-white text-[10px] font-bold rounded-[4px]">
                      {underReviewCount}
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('tally-posting-status')}
                  className={`relative px-3 py-1.5 rounded-[6px] text-xs font-medium transition ${
                    activeTab === 'tally-posting-status' ? 'bg-[#1F4E9C] text-white' : 'text-[#D9E2EC] hover:bg-[#173B77]/60'
                  }`}
                >
                  Tally Posting Status
                  {approvedTallyCount > 0 && (
                    <span className="ml-1.5 px-1.5 py-0.5 bg-[#1B7F3B] text-white text-[10px] font-bold rounded-[4px]">
                      {approvedTallyCount}
                    </span>
                  )}
                </button>

                <button
                  onClick={() => setActiveTab('accounts-vendors')}
                  className={`px-3 py-1.5 rounded-[6px] text-xs font-medium transition ${
                    activeTab === 'accounts-vendors' ? 'bg-[#1F4E9C] text-white' : 'text-[#D9E2EC] hover:bg-[#173B77]/60'
                  }`}
                >
                  Vendors Directory
                </button>

                <button
                  onClick={() => setActiveTab('reports')}
                  className={`px-3 py-1.5 rounded-[6px] text-xs font-medium transition ${
                    activeTab === 'reports' ? 'bg-[#1F4E9C] text-white' : 'text-[#D9E2EC] hover:bg-[#173B77]/60'
                  }`}
                >
                  Reports
                </button>
              </>
            )}

            {/* 3. ADMIN NAVIGATION */}
            {currentRole === 'ADMIN' && (
              <>
                <button
                  onClick={() => setActiveTab('admin-users')}
                  className={`px-3 py-1.5 rounded-[6px] text-xs font-medium transition ${
                    activeTab === 'admin-users' ? 'bg-[#1F4E9C] text-white' : 'text-[#D9E2EC] hover:bg-[#173B77]/60'
                  }`}
                >
                  Users
                </button>

                <button
                  onClick={() => setActiveTab('admin-vendors')}
                  className={`px-3 py-1.5 rounded-[6px] text-xs font-medium transition ${
                    activeTab === 'admin-vendors' ? 'bg-[#1F4E9C] text-white' : 'text-[#D9E2EC] hover:bg-[#173B77]/60'
                  }`}
                >
                  Vendors
                </button>

                <button
                  onClick={() => setActiveTab('accounts-review-queue')}
                  className={`px-3 py-1.5 rounded-[6px] text-xs font-medium transition ${
                    activeTab === 'accounts-review-queue' || activeTab === 'accounts-review'
                      ? 'bg-[#1F4E9C] text-white'
                      : 'text-[#D9E2EC] hover:bg-[#173B77]/60'
                  }`}
                >
                  Invoices ({underReviewCount})
                </button>

                <button
                  onClick={() => setActiveTab('tally-agent')}
                  className={`px-3 py-1.5 rounded-[6px] text-xs font-medium transition ${
                    activeTab === 'tally-agent' ? 'bg-[#1F4E9C] text-white' : 'text-[#D9E2EC] hover:bg-[#173B77]/60'
                  }`}
                >
                  Tally Bridge
                </button>

                <button
                  onClick={() => setActiveTab('admin-settings')}
                  className={`px-3 py-1.5 rounded-[6px] text-xs font-medium transition ${
                    activeTab === 'admin-settings' ? 'bg-[#1F4E9C] text-white' : 'text-[#D9E2EC] hover:bg-[#173B77]/60'
                  }`}
                >
                  Settings & HSN
                </button>

                <button
                  onClick={() => setActiveTab('admin-audit')}
                  className={`px-3 py-1.5 rounded-[6px] text-xs font-medium transition ${
                    activeTab === 'admin-audit' ? 'bg-[#1F4E9C] text-white' : 'text-[#D9E2EC] hover:bg-[#173B77]/60'
                  }`}
                >
                  Audit Log
                </button>

                <button
                  onClick={() => setActiveTab('reports')}
                  className={`px-3 py-1.5 rounded-[6px] text-xs font-medium transition ${
                    activeTab === 'reports' ? 'bg-[#1F4E9C] text-white' : 'text-[#D9E2EC] hover:bg-[#173B77]/60'
                  }`}
                >
                  Reports
                </button>
              </>
            )}

          </nav>

          {/* Right Controls: User Profile, Role Badge, Logout */}
          <div className="flex items-center space-x-3">
            
            {/* Vendor Profile Selector (for Vendor users with linked records) */}
            {currentRole === 'VENDOR' && (
              <div className="relative hidden sm:block">
                <button
                  onClick={() => setShowVendorDropdown(!showVendorDropdown)}
                  className="flex items-center space-x-1.5 px-2.5 py-1.5 bg-[#173B77] border border-[#1F4E9C] rounded-[6px] text-xs text-white hover:bg-[#1F4E9C] transition"
                  title="Vendor Profile"
                >
                  <Building2 className="w-3.5 h-3.5 text-[#FF9933]" />
                  <span className="max-w-[130px] truncate">{activeVendor?.tradeName || activeVendor?.legalName}</span>
                  <ChevronDown className="w-3 h-3 text-[#D9E2EC]" />
                </button>

                {showVendorDropdown && (
                  <div className="absolute right-0 mt-2 w-64 bg-white border border-[#D9E2EC] rounded-[6px] shadow-lg py-1 z-50 text-[#1F2933]">
                    <div className="px-3 py-2 border-b border-[#D9E2EC] text-[10px] text-[#52606D] font-semibold uppercase">
                      Linked Vendor Entity
                    </div>
                    {vendors.filter((v) => v.status !== 'ARCHIVED').map((v) => (
                      <button
                        key={v.id}
                        onClick={() => {
                          setActiveVendorId(v.id);
                          setShowVendorDropdown(false);
                        }}
                        className={`w-full text-left px-3 py-2 hover:bg-[#F5F7FA] transition flex items-center justify-between ${
                          activeVendor?.id === v.id ? 'bg-[#EBF1FA] text-[#1F4E9C] font-medium' : 'text-[#1F2933]'
                        }`}
                      >
                        <div>
                          <p className="text-xs truncate">{v.legalName}</p>
                          <p className="text-[10px] text-[#52606D] font-mono">{v.gstin}</p>
                        </div>
                        {activeVendor?.id === v.id && <CheckCircle2 className="w-3.5 h-3.5 text-[#1F4E9C]" />}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Role & User Identity Badge */}
            <div className="hidden sm:flex flex-col items-end text-right">
              <div className="flex items-center space-x-1.5">
                <span className="text-xs font-semibold text-white">{currentUser?.displayName || currentUser?.email}</span>
                <span className="px-2 py-0.5 rounded-[4px] text-[10px] font-bold uppercase tracking-wider bg-[#1F4E9C] text-white">
                  {currentRole.replace('_', ' ')}
                </span>
              </div>
              <div className="flex items-center space-x-2 text-[10px] text-[#D9E2EC] mt-0.5">
                <span>{currentUser?.email}</span>
                {canOverride && currentRole !== 'VENDOR' && (
                  <span className="text-[#138808] bg-white px-1 rounded flex items-center space-x-0.5 font-semibold" title="Authorized to override statutory validation flags">
                    <Unlock className="w-2.5 h-2.5" />
                    <span>Override</span>
                  </span>
                )}
              </div>
            </div>

            {/* Live Sync Status & Manual Trigger */}
            <button
              onClick={() => triggerSync()}
              disabled={isSyncing}
              className="flex items-center space-x-1.5 px-2.5 py-1.5 bg-[#173B77] hover:bg-[#1F4E9C] text-[#D9E2EC] hover:text-white rounded-[6px] text-xs font-medium border border-[#1F4E9C] transition disabled:opacity-50"
              title="Real-time Server Sync (auto-polls every 3s)"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isSyncing ? 'animate-spin text-[#FF9933]' : 'text-[#28A745]'}`} />
              <span className="hidden md:inline">{isSyncing ? 'Syncing...' : 'Live'}</span>
            </button>

            {/* Logout Button */}
            <button
              onClick={signOut}
              className="flex items-center space-x-1.5 px-3 py-1.5 bg-[#173B77] hover:bg-[#B42318] text-white rounded-[6px] text-xs font-medium border border-[#1F4E9C] transition"
              title="Sign Out"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Logout</span>
            </button>

          </div>
        </div>
      </div>

      {/* Saffron and Green Thin Accent Rule Under Header */}
      <div className="rule-accent w-full" />
    </header>
  );
};

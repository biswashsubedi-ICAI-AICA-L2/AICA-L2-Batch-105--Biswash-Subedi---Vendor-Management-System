/**
 * Pending Approval Screen
 * Displayed exclusively to users with role="PENDING" or status="PENDING_APPROVAL".
 * Restricts all dashboard, invoice, and menu access.
 * Displays:
 * - Current signed-in Google account email
 * - Status badge
 * - Informative notice if an invitation exists for a different email address
 * - Live auto-activation listener: transitions directly into workspace upon approval/invite without manual refresh
 */

import React, { useEffect, useState } from 'react';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { Clock, LogOut, AlertCircle, Info, RefreshCw, CheckCircle2 } from 'lucide-react';

export const PendingApprovalScreen: React.FC = () => {
  const { currentUser, signOut } = useAuth();
  const [otherPendingEmails, setOtherPendingEmails] = useState<string[]>([]);
  const [hasInvitationForThisEmail, setHasInvitationForThisEmail] = useState<boolean>(false);
  const [isChecking, setIsChecking] = useState<boolean>(false);

  const checkStatus = async () => {
    if (!currentUser?.email) return;
    try {
      setIsChecking(true);
      const res = await fetch(
        `/api/auth/profile-status?email=${encodeURIComponent(currentUser.email)}&uid=${encodeURIComponent(currentUser.uid)}`
      );
      if (res.ok) {
        const data = await res.json();
        if (data.otherPendingInvitations && Array.isArray(data.otherPendingInvitations)) {
          setOtherPendingEmails(data.otherPendingInvitations);
        }
      }

      // Check if an invitation exists for this email
      const invRes = await fetch(`/api/auth/invitation-info?email=${encodeURIComponent(currentUser.email)}`);
      if (invRes.ok) {
        const invData = await invRes.json();
        setHasInvitationForThisEmail(invData.hasInvitation);
      }
    } catch (e) {
      // Ignore network hiccup
    } finally {
      setIsChecking(false);
    }
  };

  useEffect(() => {
    checkStatus();
    const interval = setInterval(checkStatus, 3000);
    return () => clearInterval(interval);
  }, [currentUser]);

  return (
    <div className="min-h-screen bg-[#F5F7FA] flex flex-col justify-center items-center py-12 px-4 sm:px-6 lg:px-8 text-center font-sans">
      <div className="max-w-md w-full bg-white border border-[#D9E2EC] rounded-[6px] p-8 shadow-sm space-y-6">
        
        {/* Status Icon */}
        <div className="mx-auto w-14 h-14 rounded-[6px] bg-[#FFF7E6] border border-[#FFE7BA] flex items-center justify-center text-[#B26A00]">
          <Clock className="w-7 h-7" />
        </div>

        <div>
          <h2 className="text-xl font-bold text-[#0B2545] tracking-tight">
            Access Request Awaiting Approval
          </h2>
          <div className="rule-accent w-20 mx-auto my-3" />
          <p className="text-xs text-[#52606D] mt-2 leading-relaxed">
            Your account has been registered with the GST Vendor Management System and is currently awaiting administrator review and role assignment.
          </p>
        </div>

        {/* User Card */}
        <div className="bg-[#F5F7FA] p-4 rounded-[6px] border border-[#D9E2EC] text-left space-y-2 text-xs">
          <div className="flex justify-between">
            <span className="text-[#52606D]">Account Email:</span>
            <span className="text-[#1F2933] font-medium font-mono">{currentUser?.email}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#52606D]">Current Status:</span>
            <span className="badge-warn font-semibold">
              <Clock className="w-3 h-3 inline mr-1" />
              Pending Approval
            </span>
          </div>
          <div className="flex justify-between">
            <span className="text-[#52606D]">Submitted:</span>
            <span className="text-[#52606D] font-mono">
              {currentUser?.createdAt ? new Date(currentUser.createdAt).toLocaleString() : 'Just now'}
            </span>
          </div>
        </div>

        {/* Notice: Invitation status for this email */}
        {hasInvitationForThisEmail ? (
          <div className="p-3.5 bg-[#EDF7ED] border border-[#C8E6C9] rounded-[6px] text-left text-xs text-[#1B7F3B] flex items-start space-x-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <strong>Invitation Detected:</strong> An invitation was found for {currentUser?.email}. Your workspace is synchronizing and will open momentarily...
            </div>
          </div>
        ) : (
          <div className="p-3.5 bg-[#F5F7FA] border border-[#D9E2EC] rounded-[6px] text-left text-xs text-[#52606D] flex items-start space-x-2">
            <Info className="w-4 h-4 shrink-0 mt-0.5 text-[#1F4E9C]" />
            <div className="leading-relaxed">
              No pre-registered invitation was found for <strong className="text-[#0B2545]">{currentUser?.email}</strong>. Once an Administrator assigns your role, you will be directed straight to your workspace.
            </div>
          </div>
        )}

        {/* Notice: Invitation exists for a different email address */}
        {otherPendingEmails.length > 0 && !hasInvitationForThisEmail && (
          <div className="p-3.5 bg-[#FFF7E6] border border-[#FFE7BA] rounded-[6px] text-left text-xs text-[#B26A00] flex items-start space-x-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <strong className="block text-[#7A4500] mb-0.5">Different Email Invited?</strong>
              An invitation is currently pending for <code className="font-mono bg-white px-1 rounded text-[#0B2545] font-semibold">{otherPendingEmails[0]}</code>. If you were invited using that address (e.g. corporate or work account), please sign out and sign in with that email address.
            </div>
          </div>
        )}

        {/* Automatic Refresh Indicator */}
        <div className="flex items-center justify-center space-x-2 text-[11px] text-[#52606D]">
          <RefreshCw className={`w-3.5 h-3.5 ${isChecking ? 'animate-spin text-[#1F4E9C]' : ''}`} />
          <span>Auto-checking approval status every 3s...</span>
        </div>

        <button
          onClick={signOut}
          className="w-full flex items-center justify-center space-x-2 py-2.5 bg-white hover:bg-[#F5F7FA] text-[#1F2933] border border-[#D9E2EC] rounded-[6px] text-xs font-medium transition shadow-sm"
        >
          <LogOut className="w-4 h-4 text-[#52606D]" />
          <span>Sign Out</span>
        </button>

      </div>
    </div>
  );
};

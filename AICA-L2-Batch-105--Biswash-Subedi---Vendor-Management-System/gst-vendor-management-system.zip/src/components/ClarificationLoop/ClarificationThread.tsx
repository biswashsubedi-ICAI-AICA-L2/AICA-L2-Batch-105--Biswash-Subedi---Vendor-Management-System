/**
 * Clarification Loop & Threaded Messages
 * Supports multi-round communication, versioned document history, and SLA countdowns.
 * Restyled with ICAI-inspired theme: White cards, Navy #0B2545, Blue #1F4E9C, 6px radius.
 */

import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext.tsx';
import { InvoiceRecord } from '../../types/index.ts';
import {
  HelpCircle,
  Clock,
  Send,
  CheckCircle2,
  Loader2,
  AlertCircle,
  ArrowLeft,
} from 'lucide-react';

interface ClarificationThreadProps {
  invoice: InvoiceRecord;
  onResubmitInvoice?: (invoice: InvoiceRecord) => void;
  onBack: () => void;
}

export const ClarificationThread: React.FC<ClarificationThreadProps> = ({
  invoice,
  onResubmitInvoice,
  onBack,
}) => {
  const {
    invoices,
    queries,
    messages,
    addMessage,
    resolveAndResubmitInvoice,
    currentUser,
    currentRole,
  } = useAuth();

  // Find live invoice in context to ensure instant UI reactivity
  const currentInvoice =
    invoices.find((i) => i.id === invoice.id || (i.invoiceNumber === invoice.invoiceNumber && i.vendorId === invoice.vendorId)) ||
    invoice;

  const [replyText, setReplyText] = useState('');
  const [isResolving, setIsResolving] = useState(false);
  const [resolutionSuccess, setResolutionSuccess] = useState(false);
  const [resolveError, setResolveError] = useState<string | null>(null);

  const invoiceQueries = queries.filter((q) => q.invoiceId === currentInvoice.id);
  const activeQuery = invoiceQueries.find((q) => q.status === 'OPEN') || invoiceQueries[0] || null;

  const invoiceMessages = messages.filter((m) => m.invoiceId === currentInvoice.id || (activeQuery && m.queryId === activeQuery.id));

  // Compute SLA remaining
  const calculateSlaHoursRemaining = (slaDateStr?: string) => {
    if (!slaDateStr) return 48;
    const diff = new Date(slaDateStr).getTime() - Date.now();
    return Math.max(0, Math.round(diff / (1000 * 60 * 60)));
  };

  const slaRemaining = calculateSlaHoursRemaining(activeQuery?.slaDueDate);
  const isSlaBreached = slaRemaining === 0 && activeQuery?.status === 'OPEN';

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!replyText.trim()) return;

    await addMessage({
      invoiceId: currentInvoice.id,
      queryId: activeQuery?.id,
      senderUid: currentUser?.uid || 'user_id',
      senderRole: currentRole,
      senderName: currentUser?.displayName || (currentRole === 'VENDOR' ? 'Vendor Representative' : 'Accounts Team'),
      message: replyText.trim(),
    });

    setReplyText('');
  };

  const handleResubmit = async () => {
    setIsResolving(true);
    setResolveError(null);
    try {
      await resolveAndResubmitInvoice(
        currentInvoice.id,
        activeQuery?.id,
        replyText.trim() || 'Vendor resolved queries and resubmitted invoice particulars for review.'
      );
      setResolutionSuccess(true);
      setReplyText('');
      if (onResubmitInvoice) {
        onResubmitInvoice(currentInvoice);
      }
    } catch (err: any) {
      console.error('Failed to resubmit invoice:', err);
      setResolveError(err.message || 'Failed to mark resolved and resubmit invoice. Please try again.');
    } finally {
      setIsResolving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      
      {/* Top Header */}
      <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-6 shadow-sm flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <button
            onClick={onBack}
            className="px-3 py-1.5 bg-[#F5F7FA] hover:bg-[#EBF1FA] text-[#1F2933] border border-[#D9E2EC] rounded-[6px] text-xs font-medium transition flex items-center space-x-1"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back</span>
          </button>
          <div>
            <div className="flex items-center space-x-2">
              <h2 className="text-lg font-bold text-[#0B2545]">Invoice #{currentInvoice.invoiceNumber} Clarification Thread</h2>
              <span className={`px-2 py-0.5 rounded-[4px] text-xs font-semibold ${
                currentInvoice.status === 'CLARIFICATION_REQUESTED'
                  ? 'badge-fail'
                  : currentInvoice.status === 'RESUBMITTED' || currentInvoice.status === 'UNDER_REVIEW'
                  ? 'badge-warn'
                  : 'badge-pass'
              }`}>
                {currentInvoice.status}
              </span>
            </div>
            <p className="text-xs text-[#52606D] mt-0.5">
              Vendor: <strong className="text-[#1F2933]">{currentInvoice.vendorName}</strong> ({currentInvoice.vendorGstin}) • Total: ₹{currentInvoice.invoiceTotal}
            </p>
          </div>
        </div>

        {/* SLA Badge */}
        <div className={`px-3 py-1.5 rounded-[4px] text-xs font-semibold flex items-center space-x-2 ${
          isSlaBreached
            ? 'badge-fail'
            : slaRemaining < 12
            ? 'badge-warn'
            : 'badge-info'
        }`}>
          <Clock className="w-4 h-4" />
          <span>
            {isSlaBreached ? 'SLA Breached' : `${slaRemaining}h SLA Remaining`}
          </span>
        </div>
      </div>

      {/* Query Context Box */}
      {activeQuery && (
        <div className="bg-[#FEF3F2] border border-[#FECDCA] rounded-[6px] p-5 shadow-sm space-y-3">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center space-x-2">
              <HelpCircle className="w-4 h-4 text-[#B42318]" />
              <span className="font-bold text-[#B42318] uppercase tracking-wider">
                Reason: {activeQuery.reasonCode}
              </span>
              <span className="text-[#52606D]">| Scope: {activeQuery.targetField || 'General'}</span>
            </div>
            <span className="text-[#52606D] font-mono text-[11px]">{activeQuery.createdAt.slice(0, 16)}</span>
          </div>
          <p className="text-xs text-[#1F2933] bg-white p-3 rounded-[6px] border border-[#FECDCA] leading-relaxed">
            {activeQuery.queryText}
          </p>
          <div className="flex items-center justify-between text-xs text-[#52606D]">
            <span>Raised by: {activeQuery.raisedByName}</span>
            <span>Due by: {new Date(activeQuery.slaDueDate).toLocaleString()}</span>
          </div>
        </div>
      )}

      {/* Thread Messages List */}
      <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-6 shadow-sm space-y-4">
        <h3 className="text-xs font-bold text-[#0B2545] uppercase tracking-wider border-b border-[#D9E2EC] pb-3">
          Conversation History & Audit Exchange
        </h3>

        <div className="space-y-4 min-h-[200px]">
          {invoiceMessages.map((msg) => {
            const isVendor = msg.senderRole === 'VENDOR';
            return (
              <div
                key={msg.id}
                className={`flex flex-col ${isVendor ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-lg p-3.5 rounded-[6px] text-xs space-y-1.5 shadow-sm ${
                    isVendor
                      ? 'bg-[#1F4E9C] text-white'
                      : 'bg-[#F5F7FA] text-[#1F2933] border border-[#D9E2EC]'
                  }`}
                >
                  <div className={`flex items-center justify-between space-x-3 text-[10px] font-semibold pb-1 border-b ${
                    isVendor ? 'border-white/20 text-white/90' : 'border-[#D9E2EC] text-[#52606D]'
                  }`}>
                    <span>{msg.senderName} ({msg.senderRole})</span>
                    <span className="font-mono">{msg.createdAt.slice(11, 16)}</span>
                  </div>
                  <p className="text-xs leading-relaxed">{msg.message}</p>
                </div>
              </div>
            );
          })}

          {invoiceMessages.length === 0 && (
            <p className="text-xs text-[#52606D] text-center py-8">
              No replies yet. Type a message below to coordinate clarification.
            </p>
          )}
        </div>

        {/* Message Input Box */}
        <form onSubmit={handleSendMessage} className="pt-4 border-t border-[#D9E2EC] flex items-center space-x-2">
          <input
            type="text"
            value={replyText}
            onChange={(e) => setReplyText(e.target.value)}
            placeholder={`Reply as ${currentRole.replace('_', ' ')}...`}
            className="flex-1 px-4 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] focus:outline-none focus:border-[#1F4E9C]"
          />
          <button
            type="submit"
            className="px-4 py-2 bg-[#1F4E9C] hover:bg-[#173B77] text-white rounded-[6px] transition flex items-center space-x-1"
          >
            <Send className="w-4 h-4" />
            <span className="text-xs font-medium">Send</span>
          </button>
        </form>
      </div>

      {/* Vendor Resubmission Actions */}
      {currentRole === 'VENDOR' && (
        <>
          {resolveError && (
            <div className="p-3 bg-[#FEF3F2] border border-[#FECDCA] rounded-[6px] text-[#B42318] text-xs flex items-center space-x-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{resolveError}</span>
            </div>
          )}

          {resolutionSuccess ? (
            <div className="bg-[#EBF7EE] border border-[#C3E8CC] rounded-[6px] p-5 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#1B7F3B]">
              <div className="flex items-center space-x-2.5">
                <CheckCircle2 className="w-6 h-6 text-[#1B7F3B] shrink-0" />
                <div>
                  <h4 className="font-bold text-sm text-[#0B2545]">Clarification Marked as Resolved!</h4>
                  <p className="text-[#52606D] mt-0.5">
                    Invoice <strong>{currentInvoice.invoiceNumber}</strong> has been returned to the Accounts Review queue with status <strong>RESUBMITTED</strong>.
                  </p>
                </div>
              </div>
              <button
                onClick={onBack}
                className="flex items-center space-x-1.5 px-4 py-2 bg-[#1B7F3B] hover:bg-[#14632E] text-white rounded-[6px] font-medium text-xs transition shadow-sm"
              >
                <ArrowLeft className="w-3.5 h-3.5" />
                <span>Return to Dashboard</span>
              </button>
            </div>
          ) : currentInvoice.status === 'CLARIFICATION_REQUESTED' ? (
            <div className="bg-white border border-[#D9E2EC] rounded-[6px] p-5 shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <h4 className="text-sm font-bold text-[#0B2545]">Finished corrections?</h4>
                <p className="text-xs text-[#52606D] mt-0.5">
                  Confirm your explanation or particulars and resubmit the invoice back to the Accounts Review queue.
                </p>
              </div>
              <button
                onClick={handleResubmit}
                disabled={isResolving}
                className="flex items-center space-x-2 px-5 py-2.5 bg-[#1B7F3B] hover:bg-[#14632E] text-white font-medium text-xs rounded-[6px] transition shadow-sm disabled:opacity-50 shrink-0"
              >
                {isResolving ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    <span>Resubmitting to Accounts...</span>
                  </>
                ) : (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>Mark Resolved & Resubmit</span>
                  </>
                )}
              </button>
            </div>
          ) : (
            <div className="bg-[#EBF1FA] border border-[#D9E2EC] rounded-[6px] p-4 text-xs text-[#0B2545] flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <CheckCircle2 className="w-4 h-4 text-[#1F4E9C]" />
                <span>This invoice is currently <strong>{currentInvoice.status}</strong> and undergoing review by the Accounts team.</span>
              </div>
              <button
                onClick={onBack}
                className="text-xs text-[#1F4E9C] hover:underline font-medium"
              >
                ← Return to Dashboard
              </button>
            </div>
          )}
        </>
      )}

    </div>
  );
};

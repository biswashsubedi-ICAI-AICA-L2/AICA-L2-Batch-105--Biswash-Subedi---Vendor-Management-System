import React, { useState } from 'react';
import {
  Building2,
  X,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  CreditCard,
  Phone,
  Mail,
  MapPin,
  Save,
  FileCheck2,
} from 'lucide-react';
import { VendorMaster } from '../../types/index.ts';

interface AddVendorModalProps {
  isOpen: boolean;
  onClose: () => void;
  onVendorCreated: (vendor: VendorMaster) => void;
  adminUid?: string;
}

const INDIAN_STATES_MAP: Record<string, string> = {
  '01': 'Jammu & Kashmir',
  '02': 'Himachal Pradesh',
  '03': 'Punjab',
  '04': 'Chandigarh',
  '05': 'Uttarakhand',
  '06': 'Haryana',
  '07': 'Delhi',
  '08': 'Rajasthan',
  '09': 'Uttar Pradesh',
  '10': 'Bihar',
  '11': 'Sikkim',
  '12': 'Arunachal Pradesh',
  '13': 'Nagaland',
  '14': 'Manipur',
  '15': 'Mizoram',
  '16': 'Tripura',
  '17': 'Meghalaya',
  '18': 'Assam',
  '19': 'West Bengal',
  '20': 'Jharkhand',
  '21': 'Odisha',
  '22': 'Chhattisgarh',
  '23': 'Madhya Pradesh',
  '24': 'Gujarat',
  '26': 'Dadra & Nagar Haveli and Daman & Diu',
  '27': 'Maharashtra',
  '29': 'Karnataka',
  '30': 'Goa',
  '31': 'Lakshadweep',
  '32': 'Kerala',
  '33': 'Tamil Nadu',
  '34': 'Puducherry',
  '35': 'Andaman & Nicobar Islands',
  '36': 'Telangana',
  '37': 'Andhra Pradesh',
  '38': 'Ladakh',
};

export const AddVendorModal: React.FC<AddVendorModalProps> = ({
  isOpen,
  onClose,
  onVendorCreated,
  adminUid,
}) => {
  const [legalName, setLegalName] = useState('');
  const [tradeName, setTradeName] = useState('');
  const [gstin, setGstin] = useState('');
  const [pan, setPan] = useState('');
  const [stateCode, setStateCode] = useState('27');
  const [stateName, setStateName] = useState('Maharashtra');
  const [address, setAddress] = useState('');
  const [pincode, setPincode] = useState('');
  const [contactPerson, setContactPerson] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [turnoverCategory, setTurnoverCategory] = useState<'UP_TO_5CR' | 'ABOVE_5CR'>('ABOVE_5CR');
  const [isMsme, setIsMsme] = useState(false);
  const [msmeRegistrationNumber, setMsmeRegistrationNumber] = useState('');
  const [isComposition, setIsComposition] = useState(false);
  const [bankAccountName, setBankAccountName] = useState('');
  const [bankAccountNumber, setBankAccountNumber] = useState('');
  const [bankIfsc, setBankIfsc] = useState('');
  const [bankName, setBankName] = useState('');
  const [tallyLedgerName, setTallyLedgerName] = useState('');

  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  // Auto-extract PAN & State from GSTIN
  const handleGstinChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.toUpperCase().trim();
    setGstin(val);

    if (val.length >= 2) {
      const code = val.slice(0, 2);
      setStateCode(code);
      if (INDIAN_STATES_MAP[code]) {
        setStateName(INDIAN_STATES_MAP[code]);
      }
    }
    if (val.length >= 12) {
      setPan(val.slice(2, 12));
    }
  };

  const handleLegalNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setLegalName(val);
    if (!tradeName || tradeName === legalName) {
      setTradeName(val);
    }
    if (!bankAccountName || bankAccountName === legalName) {
      setBankAccountName(val);
    }
    if (!tallyLedgerName || tallyLedgerName === legalName) {
      setTallyLedgerName(val);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    // Validation
    if (!legalName.trim()) {
      setError('Legal Entity Name is mandatory under Rule 46.');
      return;
    }

    const cleanGstin = gstin.trim().toUpperCase();
    if (!/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/.test(cleanGstin)) {
      setError('Please enter a valid 15-character GSTIN (e.g. 27AAACA1234A1Z1).');
      return;
    }

    if (isMsme && !msmeRegistrationNumber.trim()) {
      setError('MSME Udyam Registration Number is required when MSME is enabled.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/admin/vendors/create', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          legalName: legalName.trim(),
          tradeName: tradeName.trim() || legalName.trim(),
          gstin: cleanGstin,
          pan: pan.trim().toUpperCase() || cleanGstin.slice(2, 12),
          stateCode: stateCode.trim() || cleanGstin.slice(0, 2),
          stateName: stateName.trim() || 'Maharashtra',
          address: address.trim() || 'Registered Commercial Premises',
          pincode: pincode.trim() || '400001',
          contactPerson: contactPerson.trim() || 'Finance Lead',
          email: email.trim().toLowerCase() || 'vendor@example.com',
          phone: phone.trim() || '+91 98000 00000',
          turnoverCategory,
          isMsme,
          msmeRegistrationNumber: isMsme ? msmeRegistrationNumber.trim() : undefined,
          isComposition,
          bankAccountName: bankAccountName.trim() || legalName.trim(),
          bankAccountNumber: bankAccountNumber.trim() || '000011112222',
          bankIfsc: bankIfsc.trim().toUpperCase() || 'HDFC0000001',
          bankName: bankName.trim() || 'HDFC Bank',
          tallyLedgerName: tallyLedgerName.trim() || legalName.trim(),
          adminUid: adminUid || 'admin',
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to create vendor');
      }

      onVendorCreated(data.vendor);
      onClose();
    } catch (err: any) {
      setError(err.message || 'An error occurred while registering the vendor.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#0B2545]/60 flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white border border-[#D9E2EC] w-full max-w-2xl rounded-[8px] shadow-2xl my-8 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-[#0B2545] text-white flex items-center justify-between shrink-0">
          <div className="flex items-center space-x-2.5">
            <div className="p-2 bg-white/10 rounded-[6px]">
              <Building2 className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-base font-bold">Register New Indian GST Vendor</h3>
              <p className="text-xs text-white/70">
                Statutory vendor onboarding conforming to Section 31 & Rule 46 of CGST Act.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white/70 hover:text-white p-1 rounded-md transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5 overflow-y-auto flex-1 text-xs">
          {error && (
            <div className="p-3 bg-[#FEF3F2] border border-[#FECDCA] rounded-[6px] text-[#B42318] flex items-center space-x-2 font-medium">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {/* Section 1: Statutory GST Identity */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2 border-b border-[#D9E2EC] pb-1.5">
              <FileCheck2 className="w-4 h-4 text-[#1F4E9C]" />
              <h4 className="font-bold text-[#0B2545] uppercase tracking-wider text-[11px]">
                1. Statutory GST Identity
              </h4>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              <div>
                <label className="block font-semibold text-[#1F2933] mb-1">
                  15-Digit GSTIN *
                </label>
                <input
                  type="text"
                  value={gstin}
                  onChange={handleGstinChange}
                  placeholder="e.g. 27AAACA1234A1Z1"
                  maxLength={15}
                  required
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs font-mono uppercase tracking-wider text-[#0B2545] font-bold focus:border-[#1F4E9C] focus:outline-none"
                />
                <p className="text-[10px] text-[#52606D] mt-0.5">
                  State code (first 2) and PAN (next 10) are auto-derived.
                </p>
              </div>

              <div>
                <label className="block font-semibold text-[#1F2933] mb-1">
                  Permanent Account Number (PAN) *
                </label>
                <input
                  type="text"
                  value={pan}
                  onChange={(e) => setPan(e.target.value.toUpperCase())}
                  placeholder="e.g. AAACA1234A"
                  maxLength={10}
                  required
                  className="w-full px-3 py-2 bg-[#F5F7FA] border border-[#D9E2EC] rounded-[6px] text-xs font-mono uppercase font-semibold text-[#1F2933]"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block font-semibold text-[#1F2933] mb-1">
                  Legal Entity Name *
                </label>
                <input
                  type="text"
                  value={legalName}
                  onChange={handleLegalNameChange}
                  placeholder="e.g. Apex Precision Engineering LLP"
                  required
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933] font-medium focus:border-[#1F4E9C] focus:outline-none"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#1F2933] mb-1">
                  Trade / Doing-Business-As (DBA) Name
                </label>
                <input
                  type="text"
                  value={tradeName}
                  onChange={(e) => setTradeName(e.target.value)}
                  placeholder="e.g. Apex Precision"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#1F2933] mb-1">
                  State of Registration *
                </label>
                <input
                  type="text"
                  value={`${stateCode} - ${stateName}`}
                  readOnly
                  className="w-full px-3 py-2 bg-[#F5F7FA] border border-[#D9E2EC] rounded-[6px] text-xs text-[#52606D] font-medium"
                />
              </div>
            </div>
          </div>

          {/* Section 2: Statutory Scheme & Classification */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2 border-b border-[#D9E2EC] pb-1.5">
              <Building2 className="w-4 h-4 text-[#1F4E9C]" />
              <h4 className="font-bold text-[#0B2545] uppercase tracking-wider text-[11px]">
                2. GST Classification & Compliance Flags
              </h4>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              <div>
                <label className="block font-semibold text-[#1F2933] mb-1">
                  Turnover Category (Section 31 / HSN Rule) *
                </label>
                <select
                  value={turnoverCategory}
                  onChange={(e) => setTurnoverCategory(e.target.value as any)}
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                >
                  <option value="ABOVE_5CR">&gt; ₹5 Crore Turnover (Mandatory 6/8-digit HSN)</option>
                  <option value="UP_TO_5CR">&le; ₹5 Crore Turnover (4-digit HSN permitted)</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold text-[#1F2933] mb-1">
                  Tally Ledger Name (for XML voucher posting)
                </label>
                <input
                  type="text"
                  value={tallyLedgerName}
                  onChange={(e) => setTallyLedgerName(e.target.value)}
                  placeholder="Exact Sundry Creditor ledger in Tally"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>
            </div>

            <div className="flex flex-wrap gap-4 pt-1">
              <label className="flex items-center space-x-2 text-xs text-[#1F2933] cursor-pointer">
                <input
                  type="checkbox"
                  checked={isMsme}
                  onChange={(e) => setIsMsme(e.target.checked)}
                  className="rounded border-[#D9E2EC] text-[#1F4E9C]"
                />
                <span className="font-medium">MSME Registered (45-Day Payment Rule)</span>
              </label>

              <label className="flex items-center space-x-2 text-xs text-[#1F2933] cursor-pointer">
                <input
                  type="checkbox"
                  checked={isComposition}
                  onChange={(e) => setIsComposition(e.target.checked)}
                  className="rounded border-[#D9E2EC] text-[#1F4E9C]"
                />
                <span className="font-medium">Composition Dealer (No ITC Charged)</span>
              </label>
            </div>

            {isMsme && (
              <div className="p-3 bg-[#EBF1FA] border border-[#D9E2EC] rounded-[6px]">
                <label className="block font-semibold text-[#0B2545] mb-1">
                  MSME Udyam Registration Number *
                </label>
                <input
                  type="text"
                  value={msmeRegistrationNumber}
                  onChange={(e) => setMsmeRegistrationNumber(e.target.value.toUpperCase())}
                  placeholder="e.g. UDYAM-MH-12-0012345"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs font-mono text-[#0B2545] font-semibold"
                />
              </div>
            )}
          </div>

          {/* Section 3: Contact & Address */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2 border-b border-[#D9E2EC] pb-1.5">
              <MapPin className="w-4 h-4 text-[#1F4E9C]" />
              <h4 className="font-bold text-[#0B2545] uppercase tracking-wider text-[11px]">
                3. Business Address & Authorized Contact
              </h4>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              <div>
                <label className="block font-semibold text-[#1F2933] mb-1">Contact Person</label>
                <input
                  type="text"
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  placeholder="e.g. Rajesh Patil"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#1F2933] mb-1">Official Email Address</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="accounts@apexprecision.com"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#1F2933] mb-1">Contact Phone</label>
                <input
                  type="tel"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+91 98201 12345"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#1F2933] mb-1">PIN Code</label>
                <input
                  type="text"
                  value={pincode}
                  onChange={(e) => setPincode(e.target.value)}
                  placeholder="411026"
                  maxLength={6}
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block font-semibold text-[#1F2933] mb-1">Registered Address</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Plot 45, MIDC Industrial Area, Pune"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Bank Details */}
          <div className="space-y-3">
            <div className="flex items-center space-x-2 border-b border-[#D9E2EC] pb-1.5">
              <CreditCard className="w-4 h-4 text-[#1F4E9C]" />
              <h4 className="font-bold text-[#0B2545] uppercase tracking-wider text-[11px]">
                4. Bank Particulars (for RTGS / NEFT Settlements)
              </h4>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              <div>
                <label className="block font-semibold text-[#1F2933] mb-1">Bank Name</label>
                <input
                  type="text"
                  value={bankName}
                  onChange={(e) => setBankName(e.target.value)}
                  placeholder="e.g. HDFC Bank"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#1F2933] mb-1">IFSC Code</label>
                <input
                  type="text"
                  value={bankIfsc}
                  onChange={(e) => setBankIfsc(e.target.value.toUpperCase())}
                  placeholder="e.g. HDFC0000001"
                  maxLength={11}
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs font-mono uppercase text-[#1F2933]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#1F2933] mb-1">Account Number</label>
                <input
                  type="text"
                  value={bankAccountNumber}
                  onChange={(e) => setBankAccountNumber(e.target.value)}
                  placeholder="e.g. 50200012345678"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs font-mono text-[#1F2933]"
                />
              </div>

              <div>
                <label className="block font-semibold text-[#1F2933] mb-1">Account Beneficiary Name</label>
                <input
                  type="text"
                  value={bankAccountName}
                  onChange={(e) => setBankAccountName(e.target.value)}
                  placeholder="e.g. Apex Precision Engineering LLP"
                  className="w-full px-3 py-2 bg-white border border-[#D9E2EC] rounded-[6px] text-xs text-[#1F2933]"
                />
              </div>
            </div>
          </div>

          {/* Modal Footer */}
          <div className="pt-4 border-t border-[#D9E2EC] flex items-center justify-end space-x-3">
            <button
              type="button"
              onClick={onClose}
              disabled={isSubmitting}
              className="px-4 py-2 border border-[#D9E2EC] text-[#52606D] hover:bg-[#F5F7FA] font-medium rounded-[6px] transition text-xs"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting}
              className="inline-flex items-center space-x-1.5 px-5 py-2 bg-[#1F4E9C] hover:bg-[#173B77] text-white font-semibold rounded-[6px] transition text-xs shadow-sm disabled:opacity-50"
            >
              <Save className="w-4 h-4" />
              <span>{isSubmitting ? 'Registering Vendor...' : 'Save & Register Vendor'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
